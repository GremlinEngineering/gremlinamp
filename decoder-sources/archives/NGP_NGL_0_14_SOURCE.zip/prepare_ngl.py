from pathlib import Path
import shutil,subprocess,difflib,json,hashlib
R=Path(__file__).resolve().parent;S=R/'references/beetle-ngp-libretro-a50d5ac288a81f2104ddf43195a4efdd15c72227';O=R/'ngl-source';B=R/'build';B.mkdir(exist_ok=True)
shutil.copytree(S,O,dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.o','*.dylib','*.log'));shutil.copyfile(R/'ngl_decoder.cpp',O/'ngl_decoder.cpp')
p=O/'mednafen/ngp/sound.cpp';old=p.read_text();new=old[:old.index('extern "C" int MDFNNGPCSOUND_StateAction')];p.write_text(new);patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/mednafen/ngp/sound.cpp',tofile='ngl/mednafen/ngp/sound.cpp'));(B/'ngl-source.patch').write_text(patch)
sources=['ngl_decoder.cpp','mednafen/ngp/T6W28_Apu.cpp','mednafen/sound/Blip_Buffer.cpp','mednafen/sound/Stereo_Buffer.cpp'];common=['-O2','-std=c++17','-D__LIBRETRO__','-I'+str(O),'-I'+str(O/'mednafen'),'-I'+str(O/'mednafen/include'),'-I'+str(O/'mednafen/hw_sound'),'-I'+str(O/'libretro-common/include')]
command=['c++',*common,'-dynamiclib','-fPIC',*[str(O/s)for s in sources],'-o',str(B/'libgremlin-ngl-native.dylib')]
with (B/'ngl-native-build.log').open('w')as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
(B/'ngl-native-build.json').write_text(json.dumps({'sources':sources,'command':command,'source_commit':'a50d5ac288a81f2104ddf43195a4efdd15c72227','changes':'Bridge replays original T6W28/DAC writes and original frame flushes, resets frontend objects on load. Only unused state-serialization function excluded from upstream sound.cpp. Audio algorithms unchanged.'},indent=2)+'\n');print('Built native NGL renderer')
