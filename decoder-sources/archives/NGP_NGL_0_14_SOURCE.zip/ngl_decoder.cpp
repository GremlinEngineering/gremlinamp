// NGL1 original NGP register-log bridge. Upstream T6W28/DAC/Blip math unchanged.
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <deque>
#include <array>
#include <new>
extern "C" { int32_t ngpc_soundTS=0; }
#include "mednafen/ngp/sound.cpp"
struct Event{uint64_t tick;uint8_t op,data;};
static std::vector<Event>events;
static std::deque<std::array<int16_t,2>>pcm;
static size_t next_event=0;
static uint64_t frame_base=0,queue_base=0,output_frame=0,play_frames=0;
static unsigned output_rate=0;
static bool loaded=false,source_end=false;
static std::string error_text,devices;
static uint32_t rd32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static uint64_t rd64(const uint8_t*p){return rd32(p)|(uint64_t(rd32(p+4))<<32);}
static void reset_sound(){
 apu.~T6W28_Apu();new(&apu)T6W28_Apu();
 buf.~Stereo_Buffer();new(&buf)Stereo_Buffer();
 using Synth=Blip_Synth<blip_good_quality,0xFF>;
 synth.~Synth();new(&synth)Synth();
 LastDACLeft=LastDACRight=CurrentDACLeft=CurrentDACRight=0;schipenable=false;ngpc_soundTS=0;MDFNNGPCSOUND_Init();
}
static bool next_frame(){
 if(source_end)return false;
 while(next_event<events.size()){
  Event e=events[next_event++];ngpc_soundTS=int32_t((e.tick-frame_base)*2);
  switch(e.op){
   case 0:Write_SoundChipLeft(e.data);break;
   case 1:Write_SoundChipRight(e.data);break;
   case 2:dac_write_left(e.data);break;
   case 3:dac_write_right(e.data);break;
   case 4:MDFNNGPCSOUND_SetEnable(e.data);break;
   case 5:{
    int16_t block[8192];int n=MDFNNGPCSOUND_Flush(block,4096);
    if(n<0||n>4096){error_text="Invalid original sound-core output";return false;}
    for(int i=0;i<n;i++)pcm.push_back({block[i*2],block[i*2+1]});frame_base=e.tick;return true;
   }
  }
 }
 source_end=true;return false;
}
extern "C" {
void gremlin_ngl_close(){events.clear();pcm.clear();next_event=0;frame_base=queue_base=output_frame=play_frames=0;output_rate=0;loaded=false;source_end=false;}
const char*gremlin_ngl_error(){return error_text.c_str();}
const char*gremlin_ngl_devices(){return devices.c_str();}
int gremlin_ngl_load(const uint8_t*b,uint32_t length,uint32_t rate){
 gremlin_ngl_close();error_text.clear();devices.clear();
 auto fail=[](const char*s){error_text=s;gremlin_ngl_close();return 1;};
 if(!b||length<96||memcmp(b,"NGL\x1a",4)||rd32(b+4)!=1)return fail("Invalid NGL1 header");
 if(rd32(b+8)!=3072000||rd32(b+12)!=44100||rd32(b+20)!=96||rate<8000||rate>192000)return fail("Unsupported NGL clock or output rate");
 uint32_t count=rd32(b+16);uint64_t skip=rd64(b+24);play_frames=rd64(b+32);uint64_t total=rd64(b+72);
 if(!count||count>5000000||uint64_t(count)*8+96!=length||skip>44100*120ull||!play_frames||play_frames>44100*3600ull||!total||total>3072000*3600ull)return fail("Invalid NGL event or duration bounds");
 for(unsigned i=80;i<96;i++)if(b[i])return fail("Unsupported NGL reserved flags");
 uint64_t previous=0,last_flush=0;unsigned dac_events=0;events.reserve(count);
 for(unsigned i=0;i<count;i++){
  const uint8_t*p=b+96+i*8;uint64_t tick=previous+rd32(p);unsigned op=p[4],data=p[5];
  if(tick<previous||tick>total||tick-last_flush>3072000/4||op>5||p[6]||p[7]||(op==4&&data>1)||(op==5&&data))return fail("Invalid NGL event ordering or opcode");
  if(op==5){if(tick==last_flush)return fail("Empty NGL frame");last_flush=tick;}
  if(op==2||op==3)dac_events++;events.push_back({tick,uint8_t(op),uint8_t(data)});previous=tick;
 }
 if(events.back().op!=5||events.back().tick!=total)return fail("NGL must end on a complete original frame");
 uint64_t expected=total*44100/3072000;
 if(skip+play_frames>expected+64||skip+play_frames+64<expected)return fail("NGL PCM bounds differ from captured clocks");
 reset_sound();output_rate=rate;
 while(skip){
  if(pcm.empty()&&!next_frame())return fail("NGL preroll exceeds captured audio");
  size_t n=size_t(skip<pcm.size()?skip:pcm.size());for(size_t i=0;i<n;i++)pcm.pop_front();skip-=n;
 }
 loaded=true;
 char text[550];snprintf(text,sizeof text,"[{\"type\":\"t6w28\",\"voices\":4,\"clock_hz\":3072000,\"source_sample_rate\":44100,\"output_sample_rate\":%u,\"core\":\"pinned Beetle NeoPop T6W28/Blip\",\"cartridge_dependency\":false},{\"type\":\"ngp_dac\",\"channels\":2,\"bits\":8,\"captured_events\":%u}]",rate,dac_events);devices=text;return 0;
}
uint32_t gremlin_ngl_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;
 for(unsigned i=0;i<frames;i++,output_frame++){
  uint64_t numerator=output_frame*44100,position=numerator/output_rate;unsigned remainder=numerator%output_rate;
  if(position>=play_frames)continue;
  while(queue_base+pcm.size()<=position+1){
   if(!next_frame()){
    if(!error_text.empty()){loaded=false;return 0;}
    pcm.push_back({0,0});
   }
  }
  size_t at=size_t(position-queue_base);
  for(unsigned c=0;c<2;c++){double a=pcm[at][c],b=pcm[at+1][c];out[i*2+c]=float((a+(b-a)*double(remainder)/output_rate)/32768.0);}
  while(queue_base<position){pcm.pop_front();queue_base++;}
 }
 return frames;
}
}
