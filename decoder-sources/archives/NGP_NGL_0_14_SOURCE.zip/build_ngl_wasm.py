from pathlib import Path
import subprocess,os,json,hashlib
R=Path(__file__).resolve().parent;S=R/'ngl-source';SDK=R.parent/'work-040/references/emsdk';B=R/'build/ngl-wasm';B.mkdir(exist_ok=True);O=R/'built';O.mkdir(exist_ok=True);env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten')}
sources=['ngl_decoder.cpp','mednafen/ngp/T6W28_Apu.cpp','mednafen/sound/Blip_Buffer.cpp','mednafen/sound/Stereo_Buffer.cpp'];common=['-O3','-std=c++17','-ffp-contract=off','-D__LIBRETRO__','-I'+str(S),'-I'+str(S/'mednafen'),'-I'+str(S/'mednafen/include'),'-I'+str(S/'mednafen/hw_sound'),'-I'+str(S/'libretro-common/include')];objects=[]
for name in sources:
 obj=B/(name.replace('/','_')+'.o');cmd=['python3',str(SDK/'install/emscripten/em++.py'),*common,'-c',str(S/name),'-o',str(obj)]
 with (B/(obj.name+'.log')).open('w')as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 objects.append(obj)
exports=['_gremlin_ngl_load','_gremlin_ngl_render','_gremlin_ngl_close','_gremlin_ngl_error','_gremlin_ngl_devices','_malloc','_free'];cmd=['python3',str(SDK/'install/emscripten/em++.py'),'-O3','-ffp-contract=off',*[str(p)for p in objects],'--no-entry','-sMODULARIZE=1','-sEXPORT_NAME=GremlinNgpMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=134217728','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(O/'gremlin-ngl.js')]
with(B/'link.log').open('w')as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
files=[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in O.glob('gremlin-ngl.*')];(O/'BUILD.json').write_text(json.dumps({'player':'0.14','compiler':'Emscripten6.0.13','source_commit':'a50d5ac288a81f2104ddf43195a4efdd15c72227','format':'NGL1 / NGZ, complete original T6W28+stereoDAC events at3072000Hz, original frame flushes, hidden original preroll','source_sample_rate':44100,'output':'StereoFloat32 from original signed16bit output; deterministic rational linear conversion','files':files},indent=2)+'\n');print(files)
