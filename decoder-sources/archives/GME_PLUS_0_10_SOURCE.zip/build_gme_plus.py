"""Build an isolated pinned NSF/NSFE/SGC decoder, preserving every previous core."""
from pathlib import Path
import subprocess,os,json,hashlib,argparse
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--sdk',type=Path);p.add_argument('--native-only',action='store_true');a=p.parse_args()
g=ROOT/'third_party/gme/gme';f=ROOT/'third_party/file-extractor/fex';out=ROOT/'built';out.mkdir(exist_ok=True);logs=ROOT/'build';logs.mkdir(exist_ok=True)
names=['gme.cpp','blargg_common.cpp','blargg_errors.cpp','Music_Emu.cpp','Gme_File.cpp','Gme_Loader.cpp','M3u_Playlist.cpp','Track_Filter.cpp','Classic_Emu.cpp','Blip_Buffer.cpp','Multi_Buffer.cpp','Rom_Data.cpp',
 'Nsf_Emu.cpp','Nsfe_Emu.cpp','Nsf_Core.cpp','Nsf_Impl.cpp','Nsf_Cpu.cpp','Nes_Cpu.cpp','Z80_Cpu.cpp','Nes_Apu.cpp','Nes_Oscs.cpp','Nes_Fds_Apu.cpp','Nes_Namco_Apu.cpp','Nes_Vrc6_Apu.cpp','Nes_Fme7_Apu.cpp','Nes_Vrc7_Apu.cpp',
 'Gbs_Emu.cpp','Gbs_Core.cpp','Gbs_Cpu.cpp','Gb_Cpu.cpp','Gb_Apu.cpp','Gb_Oscs.cpp','Sgc_Emu.cpp','Sgc_Core.cpp','Sgc_Impl.cpp','Sgc_Cpu.cpp','Sms_Apu.cpp','Sms_Fm_Apu.cpp','Ym2413_Emu.cpp','Dual_Resampler.cpp','Fir_Resampler.cpp','Resampler.cpp','ym2413.c']
sources=[g/n for n in names]+[ROOT/'src/data_reader.cpp',ROOT/'src/gme_plus_bridge.cpp']
assert all(p.is_file() for p in sources),[str(p) for p in sources if not p.is_file()]
flags=['-O3','-std=c++11','-DNDEBUG','-DHAVE_STDINT_H=1','-DGME_DISABLE_EFFECTS=1','-DGME_TYPE_LIST=gme_nsf_type,gme_nsfe_type,gme_sgc_type,gme_gbs_type','-I'+str(g),'-I'+str(f)]
def run(cmd,name,env=None):
 log=logs/(name+'.log')
 with log.open('w') as file:r=subprocess.run(cmd,stdout=file,stderr=subprocess.STDOUT,env=env)
 if r.returncode:print(log.read_text()[-6000:]);raise SystemExit(r.returncode)
cpp=[str(s) for s in sources if s.suffix=='.cpp'];csrc=[s for s in sources if s.suffix=='.c'];cobjects=[]
for s in csrc:
 obj=logs/(s.stem+'-native.o');run(['gcc','-O3','-fPIC','-std=gnu99','-DNDEBUG','-I'+str(g),'-c',str(s),'-o',str(obj)],s.stem+'-native');cobjects.append(str(obj))
run(['g++','-shared','-fPIC','-Wl,--no-undefined']+flags+cpp+cobjects+['-o',str(out/'libgme-plus.so')],'native')
if not a.native_only:
 assert a.sdk,'--sdk required for WASM';sdk=a.sdk.resolve();env={**os.environ,'EMSDK':str(sdk),'EM_CONFIG':str(sdk/'.emscripten'),'PATH':str(sdk/'upstream/emscripten')+os.pathsep+os.environ['PATH']}
 exports=['_gremlin_gme_open_data','_gme_open_data','_gme_delete','_gme_ignore_silence','_gme_start_track','_gme_play','_gme_track_count','_gme_type_list','_gme_identify_extension','_gme_type_system','_malloc','_free']
 wasmobjects=[]
 for s in csrc:
  obj=logs/(s.stem+'-wasm.o');run(['python3',str(sdk/'upstream/emscripten/emcc.py'),'-O3','-std=gnu99','-DNDEBUG','-I'+str(g),'-c',str(s),'-o',str(obj)],s.stem+'-wasm',env);wasmobjects.append(str(obj))
 cmd=['python3',str(sdk/'upstream/emscripten/em++.py')]+flags+cpp+wasmobjects+['--no-entry','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sMAXIMUM_MEMORY=134217728','-sENVIRONMENT=worker,node','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAP32"]','-o',str(out/'gme-plus.js')]
 run(cmd,'wasm',env)
 files=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [out/'gme-plus.js',out/'gme-plus.wasm']]
 (out/'BUILD.json').write_text(json.dumps({'version':'0.10','component':'gme-plus','formats':['nsf','nsfe','sgc','gbs'],'sources':json.loads((ROOT/'source-receipts.json').read_text()),'compiler':'Emscripten4.0.10','type_list':['NSF','NSFE','SGC','GBS'],'upstream_sources_modified':True,'upstream_patch':'Sgc_Impl.cpp: index seven RST vectors from rst_addrs[(i-1)*2] instead of reading beyond the header array; no music input data altered.','files':files,'production_deployed':False},indent=2)+'\n')
 print(json.dumps(files))
