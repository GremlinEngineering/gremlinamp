// Keep mix headroom inside synthesis, before any int16 saturation can occur.
// Original music files and chip registers are not modified.
#include "Music_Emu.h"
#include "gme.h"
extern "C" gme_err_t gremlin_gme_open_data(void const* data, long size, gme_t** out, int rate) {
    if (!out || !data || size < 4 || rate < 8000 || rate > 192000) return "Invalid music input";
    *out = nullptr;
    auto type = gme_identify_extension(gme_identify_header(data));
    if (!type) return "Unsupported music signature";
    gme_t* emu = gme_new_emu(type, rate);
    if (!emu) return "Music emulator allocation failed";
    emu->set_gain((type == gme_sgc_type || type == gme_gbs_type) ? 0.5 : 1.0);
    auto error = gme_load_data(emu, data, size);
    if (error) { gme_delete(emu); return error; }
    *out = emu;
    return nullptr;
}
