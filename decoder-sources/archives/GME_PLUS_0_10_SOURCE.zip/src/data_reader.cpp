// Integrate the pinned File_Extractor memory reader with GME's shared types.
// Both projects define the same global UTF helpers; scope the reader's copies.
#include "blargg_common.h"
#define utf8_char_len_from_header fex_utf8_char_len_from_header
#define utf8_decode_char fex_utf8_decode_char
#define utf8_encode_char fex_utf8_encode_char
#define utf16_encode_char fex_utf16_encode_char
#define utf16_decode_char fex_utf16_decode_char
#define blargg_to_utf8 fex_blargg_to_utf8
#define blargg_to_wide fex_blargg_to_wide
#include "../third_party/file-extractor/fex/Data_Reader.cpp"
