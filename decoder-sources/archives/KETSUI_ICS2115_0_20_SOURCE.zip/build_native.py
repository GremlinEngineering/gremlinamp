from pathlib import Path
import subprocess
R=Path(__file__).resolve().parent;S=R/'source';B=R/'build';z=S/'mednafen/hw_cpu/z80-fuse'
for name in ['z80','z80_ops']:subprocess.run(['clang','-O2','-fwrapv','-DINLINE=inline','-I'+str(S),'-c',str(z/(name+'.c')),'-o',str(B/(name+'.o'))],check=True)
subprocess.run(['clang++','-std=c++20','-O2','-fwrapv','-ffp-contract=off','-fPIC','-fvisibility=hidden','-dynamiclib','-DINLINE=inline','-I'+str(S),'-I'+str(S/'hash'),str(S/'ki_core.cpp'),str(S/'ics2115.cpp'),str(S/'hash/sha256.cpp'),str(B/'z80.o'),str(B/'z80_ops.o'),'-o',str(B/'libgremlin-ki.dylib')],check=True)
