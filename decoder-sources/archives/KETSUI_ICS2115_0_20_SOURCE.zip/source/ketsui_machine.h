#pragma once
#include "ics2115.h"
#include <fstream>
#include <string>
extern "C" {
#include "mednafen/hw_cpu/z80-fuse/z80.h"
}
struct KetsuiMachine {
 ics2115_device chip;std::array<u8,65536> ram{};u8 latch[3]={};u64 writes=0,reads=0,unknown=0,nmis=0;u32 music_rate=0;static KetsuiMachine*active;
 static u8 readmem(u16 a){return active->ram[a];}static void writemem(u16 a,u8 v){active->ram[a]=v;}
 static u8 readport(u16 a){auto&m=*active;m.chip.advance(z80_tstates*4);m.reads++;switch(a>>8){case 0x80:return m.chip.read(a&255);case 0x81:return m.latch[2];case 0x82:return m.latch[0];case 0x84:return m.latch[1];default:m.unknown++;return 0xff;}}
 static void writeport(u16 a,u8 v){auto&m=*active;m.chip.advance(z80_tstates*4);m.writes++;switch(a>>8){case 0x80:m.chip.write(a&255,v);break;case 0x81:m.latch[2]=v;break;case 0x82:m.latch[0]=v;break;case 0x84:m.latch[1]=v;break;default:m.unknown++;break;}}
 void open(const std::vector<u8>&boot,const std::vector<u8>&samples){if(boot.size()!=65536||samples.size()!=4194304)throw std::runtime_error("Ketsui source bounds");active=this;std::copy(boot.begin(),boot.end(),ram.begin());chip.rom.assign(8388608,0);std::copy(samples.begin(),samples.end(),chip.rom.begin()+0x400000);chip.m_irq_cb=[](int n){z80_set_interrupt(n);};z80_readbyte=readmem;z80_writebyte=writemem;z80_readport=readport;z80_writeport=writeport;z80_init();z80_reset();z80_set_interrupt(0);advance(16934400);chip.output.clear();music_rate=chip.stream.rate;}
 void advance(u64 tick){while(z80_tstates<tick){z80_do_opcode();chip.advance(z80_tstates*4);}chip.advance(std::max(chip.now,tick*4));}
 void request(const std::vector<u8>&j){if(j.empty()||j.size()%16)throw std::runtime_error("Original request bounds");u32 lastframe=0;u64 start=z80_tstates;for(size_t i=0;i<j.size();i+=16){auto get=[&](int p){return u32(j[i+p])|(u32(j[i+p+1])<<8)|(u32(j[i+p+2])<<16)|(u32(j[i+p+3])<<24);};u32 f=get(0),op=get(4),a=get(8),v=get(12);if(f>15||f<lastframe)throw std::runtime_error("Request frame bounds");if(f!=lastframe)advance(start+u64(f)*8467200*640*264/10000000);lastframe=f;if(op==0&&a<65536&&v<256)ram[a]=v;else if(op==1&&v<=65535&&a==0xc0000c)latch[2]=v;else if(op==1&&v<=65535&&a==0xc00002){latch[0]=v;z80_nmi();nmis++;}else throw std::runtime_error("Original request operation");}chip.output.clear();}
 float sample(){while(chip.output.empty())advance(z80_tstates+256);float a=chip.output.front();chip.output.pop_front();if(chip.stream.rate!=music_rate)throw std::runtime_error("Music clock changed");return a;}
};
