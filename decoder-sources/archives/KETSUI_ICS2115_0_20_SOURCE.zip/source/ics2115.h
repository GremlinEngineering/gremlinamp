// BSD-3-Clause; original authors Alex Marshall,nimitz,austere. See source receipt.
#pragma once
#include "ics_shim.h"
class ics2115_device
{
public:
 ics2115_device();
 sound_stream stream;
 TimerShim timer_storage[2];
 std::vector<u8> rom;
 u64 now=0,next_sample=1024,samples=0,timer_events=0,rate_changes=0;
 std::deque<float> output;
 void advance(u64 tick);
 u32 clock() const {return 33868800;}
 MachineShim machine() const {return {};}
 u8 sample_byte(u32 address) const {address &= 0xffffff;return address<rom.size()?rom[address]:0xff;}
 std::function<void(int)> m_irq_cb=[](int){};
	u8 read(offs_t offset);
	void write(offs_t offset, u8 data);

	// 16-bit read / write handlers (when /IOCS16 is low)
	u16 word_r(offs_t offset, u16 mem_mask);
	void word_w(offs_t offset, u16 data, u16 mem_mask);
	TIMER_CALLBACK_MEMBER(timer_cb);

public:
	// device-levels
	void device_start();
	void device_reset();
	void device_clock_changed();

	// device_sound_interfaces
	void sound_stream_update(sound_stream &stream);

	static constexpr u16 revision = 0x1;

	struct ics2115_voice {
		struct {
			s32 left;
			u32 acc, start, end; // address counters (20.9 fixed point)
			u16 fc;              // frequency (6.9 fixed point)
			u8 ctl, saddr;
		} osc;

		struct {
			s32 left;
			u32 add;
			u32 start, end;
			u32 acc;
			u16 regacc;
			u8 incr;
			u8 pan, mode;
		} vol;

		union {
			struct {
				u8 ulaw       : 1;   // compressed sample format
				u8 stop       : 1;   // stops wave + vol envelope
				u8 eightbit   : 1;   // 8 bit sample format
				u8 loop       : 1;   // loop enable
				u8 loop_bidir : 1;   // bi-directional loop enable
				u8 irq        : 1;   // enable IRQ generation
				u8 invert     : 1;   // invert direction
				u8 irq_pending: 1;   // (read only?) IRQ pending
				// IRQ on variable?
			} bitflags;
			u8 value;
		} osc_conf;

		union {
			struct {
				u8 done       : 1;   // indicates ramp has stopped
				u8 stop       : 1;   // stops the ramp
				u8 rollover   : 1;   // rollover (TODO)
				u8 loop       : 1;   // loop enable
				u8 loop_bidir : 1;   // bi-directional loop enable
				u8 irq        : 1;   // enable IRQ generation
				u8 invert     : 1;   // invert direction
				u8 irq_pending: 1;   // (read only?) IRQ pending
				// noenvelope == (done | stop)
			} bitflags;
			u8 value;
		} vol_ctrl;

		// Possibly redundant state. => improvements of wavetable logic
		// may lead to its elimination.
		struct {
			bool on;
			int ramp;       // 100 0000 = 0x40 maximum
		} state;

		u16 regs[0x20]; // channel registers
		bool playing();
		int update_volume_envelope();
		int update_oscillator();
		void update_ramp();
	};

	struct ics2115_timer {
		u8 scale, preset;
		TimerShim *timer;
		u64 period;  /* in nsec */
	};

	// internal register helper functions
	u16 reg_read();
	void reg_write(u16 data, u16 mem_mask);
	void recalc_timer(int timer);
	void keyon();
	void recalc_irq();

	// stream helper functions
	int fill_output(ics2115_voice& voice, sound_stream &stream);
	s32 get_sample(ics2115_voice& voice);
	u8 read_sample(ics2115_voice& voice, u32 addr) { return sample_byte((voice.osc.saddr << 20) | (addr & 0xfffff)); }

	sound_stream *m_stream;

	// internal state
	s16 m_ulaw[256];
	u16 m_volume[4096];
	u16 m_panlaw[256];
	static const int volume_bits = 15;

	ics2115_voice m_voice[32];
	ics2115_timer m_timer[2];

	u8 m_active_osc;
	u8 m_osc_select;
	u8 m_reg_select;
	u8 m_irq_enabled, m_irq_pending;
	bool m_irq_on;

	u16 m_regs[0x40]; // global registers

	/*
	    Unknown variable, seems to be effected by 0x12. Further investigation
	    Required.
	*/
	u8 m_vmode;
};


