#include "ketsui_machine.h"
#include <memory>
KetsuiMachine*KetsuiMachine::active=nullptr;
#include "hash/mednafen/mednafen.h"
#include "hash/sha256.h"
#include <deque>
#include <string>
static std::unique_ptr<KetsuiMachine>ki_state;
static bool loaded=false;static u32 output_rate=0;static u64 output_position=0,queue_base=0;
static std::deque<std::array<float,2>>pcm;static std::string error_text,stats_text;
static u32 r32(const u8*p){return u32(p[0])|u32(p[1])<<8|u32(p[2])<<16|u32(p[3])<<24;}
static void ensure(u64 index){while(queue_base+pcm.size()<=index){float x=ki_state->sample();if(!std::isfinite(x))throw std::runtime_error("Nonfinite ICS2115 output");pcm.push_back({x,x});}}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_ki_close(){loaded=false;pcm.clear();ki_state.reset();output_position=queue_base=0;}
API const char*gremlin_ki_error(){return error_text.c_str();}
API const char*gremlin_ki_devices(){return "[{\"type\":\"ics2115\",\"clock_hz\":33868800,\"internal_sample_rate\":33075,\"voices\":32,\"original_sound_cpu\":\"Z80@8467200\",\"routing\":\"original PGM mono sum duplicated to stereo\",\"core\":\"pinned MAME ICS2115; retained source imperfect sound limitations\",\"game_rom_or_bios_dependency\":false}]";}
API const char*gremlin_ki_stats(){if(!ki_state)return "{}";char b[512];auto&m=*ki_state;snprintf(b,sizeof(b),"{\"cpu_cycles\":%llu,\"cpu_pc\":%u,\"writes\":%llu,\"reads\":%llu,\"unknown_bus_accesses\":%llu,\"nmis\":%llu,\"timer_events\":%llu}",z80_tstates,z80_getpc(),m.writes,m.reads,m.unknown,m.nmis,m.chip.timer_events);stats_text=b;return stats_text.c_str();}
API int gremlin_ki_load(const u8*b,u32 length,u32 rate,u32 command){gremlin_ki_close();error_text.clear();try{
 if(!b||length<160||memcmp(b,"KIM\x1a",4)||r32(b+4)!=1)throw std::runtime_error("Invalid KIM1 header");
 if(r32(b+8)!=1||r32(b+12)!=8467200||r32(b+16)!=33868800||r32(b+20)!=0||r32(b+24)!=33075||r32(b+28)!=65536||r32(b+32)!=4194304||r32(b+40)!=160||r32(b+44)!=16934400||rate<8000||rate>192000)throw std::runtime_error("Unsupported original Ketsui profile");
 u32 count=r32(b+36),po=r32(b+48),so=r32(b+52),co=r32(b+56),tail=r32(b+60);if(!count||count>13||po!=160+u64(count)*16||so!=u64(po)+65536||co!=u64(so)+4194304||tail<co||tail!=length)throw std::runtime_error("Invalid KI original region bounds");
 auto ph=Mednafen::sha256(b+po,65536),sh=Mednafen::sha256(b+so,4194304),ch=Mednafen::sha256(b+co,tail-co);if(memcmp(ph.data(),b+64,32)||memcmp(sh.data(),b+96,32)||memcmp(ch.data(),b+128,32))throw std::runtime_error("Original KI bank SHA256 differs");
 bool seen[13]={},found=false;u32 offset=0,n=0,next=co;
 for(unsigned i=0;i<count;i++){const u8*p=b+160+i*16;u32 id=r32(p),a=r32(p+4),size=r32(p+8);if(id>=13||seen[id]||!size||size%16||size>400000||r32(p+12)||a!=next||u64(a)+size>tail)throw std::runtime_error("Invalid KI command table");seen[id]=true;next=a+size;if(id==command){found=true;offset=a;n=size;}}
 if(!found||next!=tail)throw std::runtime_error("Original KI music command absent");
 ki_state=std::make_unique<KetsuiMachine>();ki_state->open(std::vector<u8>(b+po,b+so),std::vector<u8>(b+so,b+co));ki_state->request(std::vector<u8>(b+offset,b+offset+n));output_rate=rate;loaded=true;return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_ki_close();return 1;}}
API u32 gremlin_ki_render(float*out,u32 frames){if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;try{
 for(unsigned i=0;i<frames;i++,output_position++){u64 numerator=output_position*33075,at=numerator/output_rate;u32 rem=numerator%output_rate;ensure(at+1);size_t q=at-queue_base;for(unsigned c=0;c<2;c++){double a=pcm[q][c],b=pcm[q+1][c];out[i*2+c]=float(a+(b-a)*double(rem)/output_rate);}while(queue_base<at){pcm.pop_front();queue_base++;}}
 return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_ki_close();return 0;}}
}
