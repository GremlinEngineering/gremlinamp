#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <deque>
#include <functional>
#include <stdexcept>
#include <vector>
using u8=uint8_t;using u16=uint16_t;using u32=uint32_t;using u64=uint64_t;using s8=int8_t;using s16=int16_t;using s32=int32_t;using s64=int64_t;using offs_t=uint32_t;
#define TIMER_CALLBACK_MEMBER(x) void x(int param)
#define LOGUNK(...) ((void)0)
#define LOGVOICE(...) ((void)0)
#define LOGTIMER(...) ((void)0)
#define ACCESSING_BITS_0_7 (mem_mask&0x00ff)
#define ACCESSING_BITS_8_15 (mem_mask&0xff00)
#define COMBINE_DATA(p) (*(p)=(*(p)&~mem_mask)|(data&mem_mask))
#define BIT(x,n) (((x)>>(n))&1)
#define ASSERT_LINE 1
#define CLEAR_LINE 0
struct MachineShim {bool side_effects_disabled()const{return false;} const char* describe_context()const{return "original Ketsui sound CPU";}};
struct attotime{u64 ticks;static attotime from_ticks(u64 t,u32){return {t};}static const attotime never;};
inline const attotime attotime::never={UINT64_MAX};
struct TimerShim{u64*now=nullptr;u64 due=UINT64_MAX,period=UINT64_MAX;void adjust(attotime t,int,attotime p=attotime::never){period=p.ticks;due=t.ticks==UINT64_MAX?UINT64_MAX:*now+t.ticks;}};
struct sound_stream{float left=0,right=0;u32 rate=33075;void update(){}void set_sample_rate(u32 r){rate=r;}int samples()const{return 1;}void add_int(int ch,int,s32 v,s32 scale){float f=float(v)/float(scale);if(ch)right+=f;else left+=f;}};
