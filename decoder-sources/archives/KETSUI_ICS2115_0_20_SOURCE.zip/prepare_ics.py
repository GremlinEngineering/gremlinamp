from pathlib import Path
import re,shutil,hashlib,json
R=Path(__file__).resolve().parent;S=R/'source';src=(R.parent/'work-040/references/mame-ics2115.cpp').read_text();hdr=(R.parent/'work-040/references/mame-ics2115.h').read_text()
hdr=hdr[hdr.index('class ics2115_device'):hdr.index('// device type definition')]
hdr=re.sub(r'class ics2115_device : public[^\n]+','class ics2115_device',hdr)
a=hdr.index('\tstatic constexpr feature_type');b=hdr.index('\tu8 read(',a)
hdr=hdr[:a]+''' ics2115_device();
 sound_stream stream;
 TimerShim timer_storage[2];
 std::vector<u8> rom;
 u64 now=0,next_sample=1024,samples=0,timer_events=0,rate_changes=0;
 std::deque<float> output;
 void advance(u64 tick);
 u32 clock() const {return 33868800;}
 MachineShim machine() const {return {};}
 u8 sample_byte(u32 address) const {address &= 0xffffff;return address<rom.size()?rom[address]:0xff;}
 std::function<void(int)> m_irq_cb=[](int){};
''' +hdr[b:]
hdr=hdr.replace('protected:','public:').replace('private:','public:').replace(' override ATTR_COLD','').replace(' override','').replace('virtual ','')
a=hdr.index('\t// device_memory_interface configuration');b=hdr.index('\tstatic constexpr u16 revision',a);hdr=hdr[:a]+hdr[b:]
hdr=hdr.replace('return m_cache.read_byte((voice.osc.saddr << 20) | (addr & 0xfffff));','return sample_byte((voice.osc.saddr << 20) | (addr & 0xfffff));')
a=hdr.index('\tmemory_access<');b=hdr.index('\ts16 m_ulaw',a);hdr=hdr[:a]+hdr[b:]
hdr=hdr.replace('emu_timer *timer','TimerShim *timer')
(S/'ics2115.h').write_text('// BSD-3-Clause; original authors Alex Marshall,nimitz,austere. See source receipt.\n#pragma once\n#include "ics_shim.h"\n'+hdr)
# Extract all methods after device framework, retain device reset + clock, exact runtime methods.
a=src.index('void ics2115_device::device_reset()');b=src.index('device_memory_interface::space_config_vector',a);part1=src[a:b];part1=part1[:part1.rfind('//-------------------------------------------------')]
a=src.index('int ics2115_device::ics2115_voice::update_volume_envelope()');runtime=src[a:]
start=src[src.index('\t//Exact formula'):src.index('\tsave_item(')]
ctor='''ics2115_device::ics2115_device() {
 m_stream=&stream;
 for(int i=0;i<2;i++){timer_storage[i].now=&now;m_timer[i].timer=&timer_storage[i];}
'''+start+'''\n device_reset();
}
void ics2115_device::advance(u64 tick){
 while(true){
  u64 event=next_sample;
  for(auto &t:timer_storage)event=std::min(event,t.due);
  if(event>tick)break;
  now=event;
  for(int i=0;i<2;i++)if(timer_storage[i].due==event){auto&t=timer_storage[i];t.due=t.period==UINT64_MAX?UINT64_MAX:event+t.period;timer_cb(i);timer_events++;}
  if(next_sample==event){stream.left=stream.right=0;sound_stream_update(stream);float mono=stream.left+stream.right;output.push_back(mono);samples++;next_sample+=u64(m_active_osc+1)*32;}
 }
 now=tick;
}
'''
(S/'ics2115.cpp').write_text('// Runtime methods extracted from pinned MAME; BSD-3-Clause.\n#include "ics2115.h"\n'+ctor+part1+runtime)
for sub in ['mednafen/hw_cpu/z80-fuse']:
 shutil.copytree(R.parent/'work-051/source'/sub,S/sub,dirs_exist_ok=True)
(S/'ics_shim.h').write_text('''#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <deque>
#include <functional>
#include <stdexcept>
#include <vector>
using u8=uint8_t;using u16=uint16_t;using u32=uint32_t;using u64=uint64_t;using s8=int8_t;using s16=int16_t;using s32=int32_t;using s64=int64_t;using offs_t=uint32_t;
#define TIMER_CALLBACK_MEMBER(x) void x(int param)
#define LOGUNK(...) ((void)0)
#define LOGVOICE(...) ((void)0)
#define LOGTIMER(...) ((void)0)
#define ACCESSING_BITS_0_7 (mem_mask&0x00ff)
#define ACCESSING_BITS_8_15 (mem_mask&0xff00)
#define COMBINE_DATA(p) (*(p)=(*(p)&~mem_mask)|(data&mem_mask))
#define BIT(x,n) (((x)>>(n))&1)
#define ASSERT_LINE 1
#define CLEAR_LINE 0
struct MachineShim {bool side_effects_disabled()const{return false;} const char* describe_context()const{return "original Ketsui sound CPU";}};
struct attotime{u64 ticks;static attotime from_ticks(u64 t,u32){return {t};}static const attotime never;};
inline const attotime attotime::never={UINT64_MAX};
struct TimerShim{u64*now=nullptr;u64 due=UINT64_MAX,period=UINT64_MAX;void adjust(attotime t,int,attotime p=attotime::never){period=p.ticks;due=t.ticks==UINT64_MAX?UINT64_MAX:*now+t.ticks;}};
struct sound_stream{float left=0,right=0;u32 rate=33075;void update(){}void set_sample_rate(u32 r){rate=r;}int samples()const{return 1;}void add_int(int ch,int,s32 v,s32 scale){float f=float(v)/float(scale);if(ch)right+=f;else left+=f;}};
''')
print('prepared',len(runtime),len(hdr))
