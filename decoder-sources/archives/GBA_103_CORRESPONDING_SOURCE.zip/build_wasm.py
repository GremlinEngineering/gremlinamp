#!/usr/bin/env python3
"""Offline rebuild of original pinned mGBA GBA/Libretro plus music frontend."""
from pathlib import Path
import argparse, json, zipfile, subprocess, os, sys, tempfile, hashlib

HERE = Path(__file__).resolve().parent
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--emsdk', type=Path, required=True)
    p.add_argument('--cmake', default='cmake')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    sdk = a.emsdk.resolve()
    em = sdk / 'install/emscripten'
    if not em.exists(): em = sdk / 'upstream/emscripten'
    output = a.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, EM_CONFIG=str(sdk / '.emscripten'), SOURCE_DATE_EPOCH='0')
    with tempfile.TemporaryDirectory(prefix='gremlin-gba-build-') as temp:
        root = Path(temp)
        source = root / 'mgba'
        source.mkdir()
        with zipfile.ZipFile(HERE / 'upstream-source.zip') as z:
            prefix = z.namelist()[0].split('/')[0] + '/'
            for name in z.namelist():
                if name.endswith('/'): continue
                relative = Path(name[len(prefix):])
                assert not relative.is_absolute() and '..' not in relative.parts
                f = source / relative
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_bytes(z.read(name))
        build = root / 'build'
        opts = json.loads((HERE / 'build-options.json').read_text())
        flags = [f'-D{k}={v}' for k, v in opts.items()]
        with (output / 'upstream-build.log').open('w') as log:
            subprocess.run([sys.executable, str(em / 'emcmake.py'), a.cmake, '-S', str(source), '-B', str(build), *flags,
                            '-DCMAKE_C_FLAGS=-D_GNU_SOURCE', '-DCMAKE_CXX_FLAGS=-D_GNU_SOURCE'], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
            subprocess.run([a.cmake, '--build', str(build), '--target', 'mgba_libretro', '-j4'], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        cc = [sys.executable, str(em / 'emcc.py')]
        host = root / 'gba_host.o'
        subprocess.run([*cc, '-O3', '-DNDEBUG', '-I' + str(source / 'src/platform/libretro'), '-c', str(HERE / 'gba_host.c'), '-o', str(host)], env=env, check=True)
        objects = sorted((build / 'CMakeFiles/mgba_libretro.dir').rglob('*.o'))
        assert len(objects) == 87
        exports = ['_malloc', '_free'] + ['_gremlin_gba_' + x for x in ['load', 'close', 'step', 'audio', 'audio_frames', 'video', 'video_width', 'video_height', 'capture_video', 'error', 'source_rate', 'source_fps']]
        subprocess.run([*cc, '-O3', '--no-entry', str(host), *map(str, objects), '-sMODULARIZE', '-sEXPORT_NAME=GremlinGBAMusic',
                        '-sENVIRONMENT=web,worker,node', '-sALLOW_MEMORY_GROWTH', '-sINITIAL_MEMORY=134217728', '-sSTACK_SIZE=1048576', '-sFILESYSTEM=1',
                        '-sEXPORTED_FUNCTIONS=' + json.dumps(exports), '-sEXPORTED_RUNTIME_METHODS=' + json.dumps(['HEAPU8', 'HEAP16', 'HEAPU32', 'UTF8ToString']),
                        '-o', str(output / 'gremlin-gba.js')], env=env, check=True)
    result = {'core': 'mGBA0.10.3', 'commit': '1c61b54208ca6266129d0f2394c04bd8c44f98c5', 'core_changes': False, 'outputs': {}}
    for name in ['gremlin-gba.js', 'gremlin-gba.wasm']:
        b = (output / name).read_bytes()
        result['outputs'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    (output / 'BUILD.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__': main()
