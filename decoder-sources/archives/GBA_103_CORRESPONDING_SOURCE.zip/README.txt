Original full Game Boy Advance music backend103, player0.30.
Source mGBA0.10.3 commit1c61b54208ca6266129d0f2394c04bd8c44f98c5.
https://github.com/mgba-emu/mgba/tree/1c61b54208ca6266129d0f2394c04bd8c44f98c5
Original ARM CPU, GBA audio PSG/DirectSound, renderer, original cartridge and default core options. No core code, original score or cartridge-byte edits. Small gba_host.c is a standard Libretro frontend, using exact owned input ROM and ordinary controller events. Empty filesystem, original default HLE BIOS, no external BIOS.

The complete code needed for this GBA/Libretro binary is included. Upstream original C/C++/header code is unchanged and hashes are recorded. One unused3DS frontend bios.wav asset is omitted from the source archive because releases contain no rendered audio. It is not compiled, read or needed by this build. Source provenance records the original and repacked archive hashes. All original source licenses are retained.

Offline reproduction requires Emscripten6.0.13-git and CMake3.31.10:
python3 build_wasm.py --emsdk /path/to/emsdk --cmake /path/to/cmake --output /path/to/output
No downloads, ROMs or music recordings are required. CMake builds the original GBA-only Libretro target with threading disabled by its upstream target, other frontends, debug tools and optional external libraries disabled. -D_GNU_SOURCE exposes original POSIX libc declarations with current Emscripten; no core source patch is used. SOURCE_DATE_EPOCH=0 is supplied for deterministic build metadata.

Timing: original source output32768Hz; Libretro advertises59.727500915527344fps (original float constant); GBA master clock16777216Hz, frame280896master ticks. This is the original emulator profile, not a measured physical board. Source audio counts and phase are preserved, followed only by external player fades. A fresh native process matches a fresh Wasm module per song.
