// BSD-3-Clause. Original MAME K005289 methods by Bryan McPhail.
// Host schedules original register events and averages chip-clock samples to48kHz.
#include <cstdint>
#include <cstring>
#include <cmath>
#include <memory>
#include <string>
using u8=uint8_t;using u16=uint16_t;using s16=int16_t;using offs_t=uint32_t;
class sound_stream {
 public:int count=0;double sum=0;
 int samples()const{return count;}
 void add_int(int,int,int value,int divisor){sum+=double(value)/divisor;}
 void update(){} // Caller already renders the prefix up to each register write.
};
class k005289_device {
 public:
 const u8 *m_sound_prom; sound_stream stream; sound_stream *m_stream=&stream;
struct voice_t
	{
		voice_t() { reset(); }

		void reset()
		{
			counter = 0;
			frequency = 0;
			pitch = 0;
			waveform = 0;
			volume = 0;
		}

		s16 counter;
		u16 frequency;
		u16 pitch;
		u16 waveform;
		u8 volume;
	};
 voice_t m_voice[2];
 explicit k005289_device(const u8*p):m_sound_prom(p){}
 void sound_stream_update(sound_stream&);
 void control_A_w(u8);void control_B_w(u8);
 void ld1_w(offs_t,u8);void ld2_w(offs_t,u8);void tg1_w(u8);void tg2_w(u8);
};
void k005289_device::sound_stream_update(sound_stream &stream)
{
	for (int sampid = 0; sampid < stream.samples(); sampid++)
	{
		for (int i = 0; i < 2; i++)
		{
			voice_t &v = m_voice[i];
			if (--v.counter < 0)
			{
				v.waveform = (v.waveform & ~0x1f) | ((v.waveform + 1) & 0x1f);
				v.counter = v.frequency;
			}
			stream.add_int(0, sampid, ((m_sound_prom[((i & 1) << 8) | v.waveform] & 0xf) - 8) * v.volume, 512);
		}
	}
}

void k005289_device::control_A_w(u8 data)
{
	m_stream->update();

	m_voice[0].volume = data & 0xf;
	m_voice[0].waveform = (m_voice[0].waveform & ~0xe0) | (data & 0xe0);
}

void k005289_device::control_B_w(u8 data)
{
	m_stream->update();

	m_voice[1].volume = data & 0xf;
	m_voice[1].waveform = (m_voice[1].waveform & ~0xe0) | (data & 0xe0);
}

void k005289_device::ld1_w(offs_t offset, u8 data)
{
	m_voice[0].pitch = 0xfff - offset;
}

void k005289_device::ld2_w(offs_t offset, u8 data)
{
	m_voice[1].pitch = 0xfff - offset;
}

void k005289_device::tg1_w(u8 data)
{
	m_stream->update();

	m_voice[0].frequency = m_voice[0].pitch;
}

void k005289_device::tg2_w(u8 data)
{
	m_stream->update();

	m_voice[1].frequency = m_voice[1].pitch;
}
static u8 original_prom[512];static std::unique_ptr<k005289_device> chip;
static uint64_t phase=0;static float audio[32768];static std::string last_error;
extern "C" {
int gremlin_k0_reset(const u8*p,unsigned bytes){
 if(!p||bytes!=512){last_error="Original512byte K005289 PROM required";return 1;}
 memcpy(original_prom,p,512);chip=std::make_unique<k005289_device>(original_prom);phase=0;last_error.clear();return 0;
}
int gremlin_k0_write(unsigned action,unsigned value){
 if(!chip||action>5||value>(action<2?4095:action<4?0:255)){last_error="K005289 register bounds";return 1;}
 switch(action){case 0:chip->ld1_w(value,0);break;case 1:chip->ld2_w(value,0);break;case 2:chip->tg1_w(0);break;case 3:chip->tg2_w(0);break;case 4:chip->control_A_w(value);break;case 5:chip->control_B_w(value);break;}return 0;
}
int gremlin_k0_render(unsigned frames){
 if(!chip||frames<1||frames>16384){last_error="K005289 output bounds";return 1;}
 for(unsigned i=0;i<frames;i++){
  phase+=3579545;unsigned ticks=phase/48000;phase%=48000;
  chip->stream.count=ticks;chip->stream.sum=0;chip->sound_stream_update(chip->stream);
  const float sample=float(chip->stream.sum/ticks);if(!std::isfinite(sample)){last_error="Nonfinite K005289 output";return 1;}
  audio[i*2]=sample;audio[i*2+1]=sample;
 }return 0;
}
const float *gremlin_k0_audio(){return audio;}
const char *gremlin_k0_error(){return last_error.c_str();}
void gremlin_k0_close(){chip.reset();}
}
