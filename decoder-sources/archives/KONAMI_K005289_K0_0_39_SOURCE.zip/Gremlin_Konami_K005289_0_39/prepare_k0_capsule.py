from pathlib import Path
import json,struct,gzip,hashlib,zipfile
W=Path(__file__).resolve().parent;O=W/'k0-capsules';O.mkdir(exist_ok=True)
raw=(W/'contexts/nemesis-filter-chip-trace/sound-events.bin').read_bytes();rows=list(struct.iter_unpack('<IIIII',raw));clock=3579545;start=(1882-1)*800;frames=11*48000;end=start+frames
def source_sample(f,cy):return max(0,(f-1)*800+cy*48000//clock)
latch=[0,0];ay=[];ke=[];filterwrites=[]
for f,k,a,b,cy in rows:
 at=source_sample(f,cy)
 if at>end:continue
 if k==9:
  if b<256:latch[a]=b&15
  elif latch[a]<14:ay.append((at,a,latch[a],b&255))
 elif k==19:ke.append((at,a,b))
 elif k==20:filterwrites.append(dict(frame=f,address=a,C2_enabled=bool(a&0x800)))
assert not any(p['C2_enabled']for p in filterwrites),'Selected source uses an unimplemented active analog capacitor'
stream=bytearray();now=0
def wait(at):
 global now
 assert at>=now
 n=at-now
 while n:part=min(65535,n);stream.extend(b'\x61'+struct.pack('<H',part));n-=part
 now=at
for at,chip,reg,value in ay:wait(at*44100//48000);stream+=bytes([0xa0,(chip<<7)|reg,value])
total=end*44100//48000;wait(total);stream.append(0x66)
# Standard VGM absolute chip volumes:0x100 unity;0x33 is the nearest0.20.
extra=struct.pack('<III',12,0,4)+bytes([2])+struct.pack('<BBH',0x12,0,0x33)+struct.pack('<BBH',0x12,1,0x100)
h=bytearray(0x100)+extra;h[:4]=b'Vgm ';struct.pack_into('<I',h,8,0x171);struct.pack_into('<I',h,0x18,total);struct.pack_into('<I',h,0x24,60);struct.pack_into('<I',h,0x34,len(h)-0x34);struct.pack_into('<I',h,0x74,1789772|0x40000000);struct.pack_into('<I',h,0xbc,0x100-0xbc)
vgm=h+stream;struct.pack_into('<I',vgm,4,len(vgm)-4)
with zipfile.ZipFile(W/'sources/nemesis-original.zip')as z:rom=z.read('456-d09.9c');prom=z.read('400-a01.fse')+z.read('400-a02.fse')
assert len(prom)==512
events=b''.join(struct.pack('<IBBH',at,action,0,value)for at,action,value in ke)
sha=lambda b:hashlib.sha256(b).hexdigest()
p=dict(version=1,profile=1,game_id='game-ra-12157',track_id='stage-music',title='Музыка первого уровня — фрагмент',source_rate=48000,source_cpu_clock=clock,capture_fps=60,MAME_commit='40d0f1125befade5edc08ec5699442ca3a229c01',K_clock=clock,AY_clock=1789772,K_gain=.35,AY_absolute_VGM_volumes=[0x33,0x100],start_sample=start,audio_frames=frames,rom_sha256=sha(rom),prom_sha256=sha(prom),vgm_sha256=sha(vgm),events_sha256=sha(events),rom_bytes=len(rom),prom_bytes=len(prom),vgm_bytes=len(vgm),event_count=len(ke),source_trace_sha256=sha(raw),original_CPU_program_unmodified=True,original_K_methods_and_PROM_unchanged=True,filter_C2_off=True,physical_board_measured=False)
j=json.dumps(p,ensure_ascii=False,separators=(',',':')).encode();b=b'K0M\x1a'+struct.pack('<IIIII',len(j),len(rom),len(vgm),len(prom),len(ke))+j+rom+vgm+prom+events
file=O/'gradius-nemesis-stage.k0z';file.write_bytes(gzip.compress(b,compresslevel=9,mtime=0));p.update(file=file.name,bytes=file.stat().st_size,sha256=sha(file.read_bytes()))
(O/'profiles.json').write_text(json.dumps({'1':p},ensure_ascii=False,indent=2)+'\n');(O/'PROOF.json').write_text(json.dumps(dict(profile=p,filter_writes=filterwrites,AY_original_data_writes=len(ay),K_original_writes=len(ke),original_source_PCM_and_video_unchanged=True,source_context='contexts/nemesis-filter-chip-trace',original_ROM_verification='additional-ROM-proofs.json',identity_source='https://retroachievements.org/game/12157',core_resampling='MAME original K clock samples averaged to48kHz; original libvgm AY rendering at48kHz; final linear output resampling',mix='MAME routed K gain0.35 and AY gains nearest VGM0.20,1.0; full analog PCB response is not claimed',play_ms=10000,fade_ms=1000,full_original_album_complete=False),ensure_ascii=False,indent=2)+'\n')
print(file.name,'bytes',file.stat().st_size,'AY writes',len(ay),'K writes',len(ke),'filters',filterwrites)
