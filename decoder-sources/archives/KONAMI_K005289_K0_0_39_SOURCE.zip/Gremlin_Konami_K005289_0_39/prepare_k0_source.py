from pathlib import Path
import json,hashlib,re
W=Path(__file__).resolve().parent;O=W/'k0-source';O.mkdir(exist_ok=True)
s=(W/'sources/k005289.cpp').read_text();h=(W/'sources/k005289.h').read_text()
def balanced(text,start):
 begin=text.index('{',start);depth=1;at=begin+1
 while depth:
  if text[at]=='{':depth+=1
  elif text[at]=='}':depth-=1
  at+=1
 return at
a=h.index('struct voice_t');b=balanced(h,a)+1;voice=h[a:b];methods=[];receipts=[]
for name in ['sound_stream_update','control_A_w','control_B_w','ld1_w','ld2_w','tg1_w','tg2_w']:
 a=s.index('void k005289_device::'+name);b=balanced(s,a);method=s[a:b];methods.append(method);receipts.append(dict(method=name,sha256=hashlib.sha256(method.encode()).hexdigest(),source_start_line=s[:a].count('\n')+1))
out='''// BSD-3-Clause. Original MAME K005289 methods by Bryan McPhail.
// Host schedules original register events and averages chip-clock samples to48kHz.
#include <cstdint>
#include <cstring>
#include <cmath>
#include <memory>
#include <string>
using u8=uint8_t;using u16=uint16_t;using s16=int16_t;using offs_t=uint32_t;
class sound_stream {
 public:int count=0;double sum=0;
 int samples()const{return count;}
 void add_int(int,int,int value,int divisor){sum+=double(value)/divisor;}
 void update(){} // Caller already renders the prefix up to each register write.
};
class k005289_device {
 public:
 const u8 *m_sound_prom; sound_stream stream; sound_stream *m_stream=&stream;
'''+voice+'''
 voice_t m_voice[2];
 explicit k005289_device(const u8*p):m_sound_prom(p){}
 void sound_stream_update(sound_stream&);
 void control_A_w(u8);void control_B_w(u8);
 void ld1_w(offs_t,u8);void ld2_w(offs_t,u8);void tg1_w(u8);void tg2_w(u8);
};
'''+('\n\n'.join(methods))+'''
static u8 original_prom[512];static std::unique_ptr<k005289_device> chip;
static uint64_t phase=0;static float audio[32768];static std::string last_error;
extern "C" {
int gremlin_k0_reset(const u8*p,unsigned bytes){
 if(!p||bytes!=512){last_error="Original512byte K005289 PROM required";return 1;}
 memcpy(original_prom,p,512);chip=std::make_unique<k005289_device>(original_prom);phase=0;last_error.clear();return 0;
}
int gremlin_k0_write(unsigned action,unsigned value){
 if(!chip||action>5||value>(action<2?4095:action<4?0:255)){last_error="K005289 register bounds";return 1;}
 switch(action){case0:chip->ld1_w(value,0);break;case1:chip->ld2_w(value,0);break;case2:chip->tg1_w(0);break;case3:chip->tg2_w(0);break;case4:chip->control_A_w(value);break;case5:chip->control_B_w(value);break;}return 0;
}
int gremlin_k0_render(unsigned frames){
 if(!chip||frames<1||frames>16384){last_error="K005289 output bounds";return 1;}
 for(unsigned i=0;i<frames;i++){
  phase+=3579545;unsigned ticks=phase/48000;phase%=48000;
  chip->stream.count=ticks;chip->stream.sum=0;chip->sound_stream_update(chip->stream);
  const float sample=float(chip->stream.sum/ticks);if(!std::isfinite(sample)){last_error="Nonfinite K005289 output";return 1;}
  audio[i*2]=sample;audio[i*2+1]=sample;
 }return 0;
}
const float *gremlin_k0_audio(){return audio;}
const char *gremlin_k0_error(){return last_error.c_str();}
void gremlin_k0_close(){chip.reset();}
}
'''
# Add ordinary whitespace to host switch labels; original methods remain verbatim.
out=re.sub(r'\bcase([0-5]):',r'case \1:',out)
(O/'k0_core.cpp').write_text(out)
(O/'SOURCE_PROOF.json').write_text(json.dumps(dict(MAME_commit='40d0f1125befade5edc08ec5699442ca3a229c01',source_cpp_sha256=hashlib.sha256(s.encode()).hexdigest(),source_header_sha256=hashlib.sha256(h.encode()).hexdigest(),original_voice_structure_sha256=hashlib.sha256(voice.encode()).hexdigest(),methods=receipts,chip_clock=3579545,output_rate=48000,original_methods_unchanged=True,resampler='Host arithmetic mean of original chip-clock samples; explicitly not a physical PCB measurement or MAME sound-stream resampler'),indent=2)+'\n')
print('Prepared original K005289 counter/PROM methods and standalone clock host.')
