from pathlib import Path
import subprocess,json,os,hashlib,sys
W=Path(__file__).resolve().parent;B=W/'k0-built';B.mkdir(exist_ok=True);SDK=Path(os.environ.get('GREMLIN_EMSDK',W.parent/'work-040/references/emsdk'))
env={**os.environ,'DEVELOPER_DIR':'/Library/Developer/CommandLineTools','EM_CONFIG':str(SDK/'.emscripten'),'SOURCE_DATE_EPOCH':'0'}
flags=['-std=c++20','-O2','-fwrapv','-ffp-contract=off','-ffile-prefix-map='+str(W)+'=/gremlin-session122']
with(B/'native-build.log').open('w')as log:subprocess.run(['clang++',*flags,'-dynamiclib','-Wl,-install_name,@rpath/libgremlin-k0.dylib',str(W/'k0-source/k0_core.cpp'),'-o',str(B/'libgremlin-k0.dylib')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
exports=['_malloc','_free']+['_gremlin_k0_'+x for x in ['reset','write','render','audio','error','close']]
cmd=[sys.executable,str(SDK/'install/emscripten/em++.py'),*flags,'-fwasm-exceptions',str(W/'k0-source/k0_core.cpp'),'--no-entry','-sSUPPORT_LONGJMP=wasm','-sMODULARIZE=1','-sEXPORT_NAME=GremlinKonamiMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=67108864','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(B/'gremlin-k0.js')]
with(B/'wasm-build.log').open('w')as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
j={'MAME_commit':'40d0f1125befade5edc08ec5699442ca3a229c01','core':'Original MAME K005289 voice counters and512byte waveform PROM; explicit host clock averaging','source_rate':48000,'original_circuit_values':True,'hand_written_note_tables':False,'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in B.iterdir()if p.suffix in ['.dylib','.wasm','.js']}}
(B/'BUILD.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j),flush=True)
