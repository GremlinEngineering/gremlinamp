from pathlib import Path
import ctypes as C,json,struct,gzip,hashlib,wave
import numpy as np
W=Path(__file__).resolve().parent;O=W/'k0-reference';O.mkdir(exist_ok=True)
k=C.CDLL(str(W/'k0-built/libgremlin-k0.dylib'));v=C.CDLL(str(W.parent/'work-089/vgm-native-musl/libgremlin-libvgm.dylib'))
k.gremlin_k0_reset.argtypes=[C.c_void_p,C.c_uint];k.gremlin_k0_audio.restype=C.c_void_p;k.gremlin_k0_error.restype=C.c_char_p
v.gremlin_vgm_load.argtypes=[C.c_void_p,C.c_uint,C.c_uint];v.gremlin_vgm_render.argtypes=[C.c_void_p,C.c_uint];v.gremlin_vgm_error.restype=C.c_char_p;v.gremlin_vgm_devices.restype=C.c_char_p
results=[]
for file in (W/'k0-capsules').glob('*.k0z'):
 b=gzip.decompress(file.read_bytes());j,r,z,q,n=struct.unpack_from('<IIIII',b,4);p=json.loads(b[24:24+j]);at=24+j+r;vgm=b[at:at+z];at+=z;prom=b[at:at+q];at+=q;events=list(struct.iter_unpack('<IBBH',b[at:]));assert len(events)==n
 pb=C.create_string_buffer(prom);vb=C.create_string_buffer(vgm);assert k.gremlin_k0_reset(pb,len(prom))==0,k.gremlin_k0_error();assert v.gremlin_vgm_load(vb,len(vgm),48000)==0,v.gremlin_vgm_error();devices=json.loads(v.gremlin_vgm_devices());scratch=np.zeros(8192,np.float32);position=0;index=0;blocks=[];end=p['start_sample']+p['audio_frames']
 while position<end:
  while index<n and events[index][0]==position:
   e=events[index];assert k.gremlin_k0_write(e[1],e[3])==0;index+=1
  stop=min(end,events[index][0]if index<n else end,position+4096)
  if position<p['start_sample']:stop=min(stop,p['start_sample'])
  count=stop-position;assert count>0
  assert k.gremlin_k0_render(count)==0,k.gremlin_k0_error();v.gremlin_vgm_render(scratch.ctypes.data,count)
  if position>=p['start_sample']:
   a=np.frombuffer(C.string_at(k.gremlin_k0_audio(),count*8),np.float32).astype(np.float64);ay=scratch[:count*2].astype(np.float64);blocks.append((ay+a*p['K_gain']).astype(np.float32))
  position=stop
 x=np.concatenate(blocks).reshape(-1,2);assert len(x)==p['audio_frames']and np.isfinite(x).all();x.tofile(O/(file.stem+'.f32'))
 with wave.open(str(O/(file.stem+'-diagnostic.wav')),'wb')as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(48000);f.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
 row=dict(file=file.name,game_id=p['game_id'],frames=len(x),seconds=len(x)/48000,peak=float(np.max(np.abs(x))),rms=float(np.sqrt(np.mean(x.astype(float)**2))),native_f32_sha256=hashlib.sha256(x.tobytes()).hexdigest(),devices=devices,expected={})
 for rate in [44100,48000]:
  frames=int(np.ceil(len(x)*rate/48000))+128;idx=np.arange(frames,dtype=np.int64);num=idx*48000;offset=num//rate;rem=num%rate;valid=offset<len(x);xx=np.vstack([x,np.zeros((1,2),np.float32)]).astype(float);out=np.zeros((frames,2),np.float32);a=xx[offset[valid]];bb=xx[offset[valid]+1];out[valid]=(a+(bb-a)*rem[valid,None]/rate).astype(np.float32);name=f'{file.stem}-{rate}.f32';out.tofile(O/name);row['expected'][str(rate)]=dict(file=name,frames=frames,sha256=hashlib.sha256(out.tobytes()).hexdigest())
 results.append(row);print(json.dumps(row),flush=True);k.gremlin_k0_close();v.gremlin_vgm_close()
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
