from pathlib import Path
import shutil,subprocess,difflib,hashlib,json
R=Path(__file__).resolve().parent;H=R.parent/'work-048';P=H/'references/mednafen';S=R/'sas-source';S.parent.mkdir(exist_ok=True);shutil.copytree(H/'ssfplay-base',S,dirs_exist_ok=True)
for name in ['scsp.h','scsp.inc']:shutil.copyfile(P/'src/ss'/name,S/'mednafen/src/ss'/name)
shutil.copytree(P/'src/hw_cpu/m68k',S/'mednafen/src/hw_cpu/m68k',dirs_exist_ok=True)
shutil.copyfile(P/'src/endian.cpp',S/'mednafen/src/endian.cpp')
shutil.copytree(P/'src/hash',S/'mednafen/src/hash',dirs_exist_ok=True)
inc=S/'mednafen/include/mednafen';inc.parent.mkdir(exist_ok=True)
if inc.is_symlink():inc.unlink()
elif inc.exists():shutil.rmtree(inc)
inc.symlink_to('../src',target_is_directory=True)
cm=(S/'CMakeLists.txt').read_text();cm+='\ntarget_sources(ssfplay PRIVATE mednafen/src/endian.cpp mednafen/src/hash/sha256.cpp)\n';(S/'CMakeLists.txt').write_text(cm)
original=(P/'src/sasplay/sasplay.cpp').read_text();prefix=original.split('struct ROMLayout')[0]
for name in ['general.h','FileStream.h','MemoryStream.h','player.h']:prefix=prefix.replace('#include <mednafen/'+name+'>\n','')
prefix+='\n} // Original SASPlay audio-core namespace.\n'
D=S/'mednafen/src/sasplay';D.mkdir(exist_ok=True);(D/'sas-core.inc').write_text(prefix)
(S/'src/ssfplay.cpp').write_text('#include "../mednafen/src/sasplay/sas-core.inc"\n#include "gremlin_m2s_sas.inc"\n');shutil.copyfile(R/'m2s_sas_bridge.inc',S/'src/gremlin_m2s_sas.inc')
(R/'sas-core-extraction.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),prefix.splitlines(True),fromfile='official1.32.1/sasplay.cpp',tofile='standalone/sas-core.inc')))
cmake=R.parent/'work-040/references/cmake-3.31.10/cmake/data/bin/cmake'
with(R/'native-build.log').open('w')as out:
 subprocess.run([str(cmake.resolve()),'-S',str(S.resolve()),'-B',str((R/'build-native').resolve()),'-DSSFPLAY_BUILD_SHARED=ON','-DSSFPLAY_BUILD_CLI=OFF','-DSSFPLAY_BUILD_PLAYER=OFF','-DSSFPLAY_BUILD_LIBVGM_AB_PLAYER=OFF','-DBUILD_TESTING=OFF','-DCMAKE_BUILD_TYPE=Release'],stdout=out,stderr=subprocess.STDOUT,check=True)
 subprocess.run([str(cmake.resolve()),'--build',str((R/'build-native').resolve()),'-j4'],stdout=out,stderr=subprocess.STDOUT,check=True)
(R/'official-core-identities.json').write_text(json.dumps({'official_tar_sha256':'de7eb94ab66212ae7758376524368a8ab208234b33796625ca630547dbc83832','source_url':'https://mednafen.github.io/releases/files/mednafen-1.32.1.tar.xz','scsp':{name:hashlib.sha256((P/'src/ss'/name).read_bytes()).hexdigest()for name in['scsp.h','scsp.inc']},'audio_core':'Official SASPlay prefix unchanged except removal of unused frontend includes; UI/database/file-discovery portion omitted. Official SCSP and M68000 core files unchanged. Original Load initialization and StartSong protocol copied exactly into the bounded M2S bridge.'},indent=2)+'\n');print('Built official SASPlay1.32.1 original audio core')
