from pathlib import Path
import os,subprocess,json,shutil,hashlib
R=Path(__file__).resolve().parent;S=R/'sas-source';SDK=R.parent/'work-040/references/emsdk';CMAKE=R.parent/'work-040/references/cmake-3.31.10/cmake/data/bin/cmake';B=R/'build-wasm';O=R/'built';O.mkdir(exist_ok=True)
cm=(S/'CMakeLists.txt').read_text().split('# Gremlin M2S WASM target')[0]+'''
# Gremlin M2S WASM target
if(EMSCRIPTEN)
 add_executable(gremlin_m2s src/gremlin_m2s_empty.cpp)
 target_link_libraries(gremlin_m2s PRIVATE ssfplay::ssfplay)
 target_link_options(gremlin_m2s PRIVATE
  "--no-entry" "-fwasm-exceptions" "-sSUPPORT_LONGJMP=wasm"
  "-sMODULARIZE=1" "-sEXPORT_NAME=GremlinModel2Music"
  "-sENVIRONMENT=web,worker,node" "-sALLOW_MEMORY_GROWTH=1"
  "-sINITIAL_MEMORY=33554432" "-sMAXIMUM_MEMORY=134217728" "-sFILESYSTEM=0"
  "SHELL:-sEXPORTED_FUNCTIONS=['_malloc','_free','_gremlin_m2s_load','_gremlin_m2s_render','_gremlin_m2s_close','_gremlin_m2s_error','_gremlin_m2s_devices']"
  "SHELL:-sEXPORTED_RUNTIME_METHODS=['UTF8ToString','HEAPU8','HEAPF32']")
 set_target_properties(gremlin_m2s PROPERTIES OUTPUT_NAME "gremlin-m2s" SUFFIX ".js")
endif()
''';(S/'CMakeLists.txt').write_text(cm);(S/'src/gremlin_m2s_empty.cpp').write_text('// Library entry points are explicitly exported; no main.\n')
env={**os.environ,'EM_CONFIG':str((SDK/'.emscripten').resolve()),'PATH':str(CMAKE.parent.resolve())+os.pathsep+str((SDK/'install/emscripten').resolve())+os.pathsep+os.environ['PATH']}
with(R/'wasm-build.log').open('w')as out:
 subprocess.run([str(CMAKE.resolve()),'-S',str(S.resolve()),'-B',str(B.resolve()),'-DCMAKE_TOOLCHAIN_FILE='+str((SDK/'install/emscripten/cmake/Modules/Platform/Emscripten.cmake').resolve()),'-DSSFPLAY_BUILD_SHARED=OFF','-DSSFPLAY_BUILD_CLI=OFF','-DSSFPLAY_BUILD_PLAYER=OFF','-DSSFPLAY_BUILD_LIBVGM_AB_PLAYER=OFF','-DBUILD_TESTING=OFF','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_FLAGS=-fwasm-exceptions -ffp-contract=off'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 subprocess.run([str(CMAKE.resolve()),'--build',str(B.resolve()),'--target','gremlin_m2s','-j4'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
for ext in ['js','wasm']:shutil.copyfile(B/('gremlin-m2s.'+ext),O/('gremlin-m2s.'+ext))
(O/'BUILD.json').write_text(json.dumps({'compiler':'Emscripten6.0.13','profile':'original Model2 M68000 11289600 / SCSP22579200, full DSP, digital stereo44100','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in O.glob('gremlin-m2s.*')]},indent=2)+'\n');print((O/'BUILD.json').read_text())
