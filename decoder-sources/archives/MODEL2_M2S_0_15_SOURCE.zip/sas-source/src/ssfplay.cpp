#include "../mednafen/src/sasplay/sas-core.inc"
#include "gremlin_m2s_sas.inc"
