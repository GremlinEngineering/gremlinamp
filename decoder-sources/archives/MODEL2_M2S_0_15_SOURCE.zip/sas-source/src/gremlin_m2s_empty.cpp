// Library entry points are explicitly exported; no main.
