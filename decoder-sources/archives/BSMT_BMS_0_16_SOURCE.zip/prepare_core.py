"""Extract pinned MAME TMS320C15 instruction methods without changing them.
Only the device-framework bus/UI wrapper is replaced. Z80/Fuse is unchanged.
"""
from pathlib import Path
import re,shutil,hashlib,json,difflib
R=Path(__file__).resolve().parent;Q=R.parent/'work-040/references';S=R/'source';S.mkdir(exist_ok=True)
src=(Q/'mame-tms320c1x.cpp').read_text();hdr=(Q/'mame-tms320c1x.h').read_text()
assert hashlib.sha256(src.encode()).hexdigest()=='458ea93ee59291545245c6bf02664994f24596416ac999a4fef513a520ad3650'
body=hdr[hdr.index('\tusing opcode_func'):hdr.index('\n};',hdr.index('\tusing opcode_func'))]
a=body.index('\ttypename memory_access');b=body.index('\n\tinline void CLR',a);body=body[:a]+'\tBus m_cache,m_program,m_data,m_io;\n'+body[b:]
head='''// license:BSD-3-Clause
// copyright-holders:Tony La Porta
// MAME40d0f1125befade5edc08ec5699442ca3a229c01 instruction methods, unchanged.
#pragma once
#include <cstdint>
#include <functional>
#include <stdexcept>
#include <cstdio>
#include <cstdarg>
#define CLEAR_LINE 0
#define ASSERT_LINE 1
union PAIR {uint32_t d;struct{uint16_t l,h;}w;struct{uint8_t l,h,h2,h3;}b;};
struct Bus {std::function<uint16_t(unsigned)> r;std::function<void(unsigned,uint16_t)> w;uint16_t read_word(unsigned a){return r(a);}void write_word(unsigned a,uint16_t v){w(a,v);}};
[[noreturn]] inline void fatalerror(const char *s){throw std::runtime_error(s);}
[[noreturn]] inline void logerror(const char *s,...){char b[256];va_list a;va_start(a,s);vsnprintf(b,sizeof(b),s,a);va_end(a);throw std::runtime_error(b);}
template<int HighBits>class tms320c1x_device_base {
public:
 static constexpr uint32_t TMS320C1X_INT_PENDING=0x80000000,TMS320C1X_INT_NONE=0;
 std::function<int()> m_bio_in=[](){return 0;};
 void debugger_instruction_hook(unsigned){} void standard_irq_callback(unsigned,unsigned){}
 tms320c1x_device_base():m_PC(0),m_PREVPC(0),m_STR(0),m_ACC{},m_ALU{},m_Preg{},m_Treg(0),m_AR{},m_STACK{},m_opcode{},m_INTF(0),m_icount(0),m_oldacc{},m_memaccess(0),m_addr_mask((1u<<HighBits)-1){}
 void buses(Bus p,Bus d,Bus io){m_cache=m_program=p;m_data=d;m_io=io;}
 void device_reset();void execute_run();void execute_set_input(int,int);
 int step(){m_icount=1;execute_run();return 1-m_icount;}
 unsigned pc()const{return m_PC;}
'''
(S/'tms320c15.h').write_text(head+body+'\n};\n')
start=src.index('/*********  The following');end=src.index('template <int HighBits>\nvoid tms320c1x_device_base<HighBits>::device_start()');methods=src[start:end]
rs=src.index('template <int HighBits>\nvoid tms320c1x_device_base<HighBits>::device_reset()');re_=src.index('template <int HighBits>\nvoid tms320c1x_device_base<HighBits>::state_string_export',rs)
es=src.index('template <int HighBits>\nvoid tms320c1x_device_base<HighBits>::execute_set_input')
out='#include "tms320c15.h"\n'+src[src.index('#define M_RDROM'):src.index('DEFINE_DEVICE_TYPE')]+methods+src[rs:re_]+src[es:]+'\ntemplate class tms320c1x_device_base<12>;\n'
(S/'tms320c15.cpp').write_text(out)
(R/'tms-core-extraction.patch').write_text(''.join(difflib.unified_diff(src.splitlines(True),out.splitlines(True),fromfile='pinned-MAME/tms320c1x.cpp',tofile='source/tms320c15.cpp')))
z=R.parent/'work-045/host-source/mednafen/hw_cpu/z80-fuse';dest=S/'mednafen/hw_cpu/z80-fuse';dest.mkdir(parents=True,exist_ok=True)
for p in z.iterdir():
 if p.suffix in('.c','.h'):shutil.copyfile(p,dest/p.name)
shutil.copyfile(z.parent.parent/'mednafen-types.h',S/'mednafen/mednafen-types.h')
(S/'boolean.h').write_text('#include <stdbool.h>\n')
(R/'core-source-identities.json').write_text(json.dumps({'mame_pin':'40d0f1125befade5edc08ec5699442ca3a229c01','mame_tms_source_sha256':hashlib.sha256(src.encode()).hexdigest(),'instruction_methods_unchanged':True,'z80_source_pin':'libretro/beetle-ngp-libretro a50d5ac288a81f2104ddf43195a4efdd15c72227','z80_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in dest.iterdir()if p.is_file()}},indent=2)+'\n')
print('Prepared original DSP instruction methods and unchanged Fuse Z80')
