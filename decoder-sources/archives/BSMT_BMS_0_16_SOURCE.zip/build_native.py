from pathlib import Path
import subprocess
R=Path(__file__).resolve().parent;S=R/'source';B=R/'build';B.mkdir(exist_ok=True);z=S/'mednafen/hw_cpu/z80-fuse'
for name in ['z80','z80_ops']:subprocess.run(['clang','-O2','-fwrapv','-fvisibility=hidden','-DINLINE=inline','-I'+str(S),'-c',str(z/(name+'.c')),'-o',str(B/(name+'-bank.o'))],check=True)
subprocess.run(['clang++','-std=c++17','-O2','-fwrapv','-ffp-contract=off','-fPIC','-fvisibility=hidden','-dynamiclib','-DINLINE=inline','-I'+str(S/'hash'),str(S/'bms_core.cpp'),str(S/'tms320c15.cpp'),str(S/'hash/sha256.cpp'),str(B/'z80-bank.o'),str(B/'z80_ops-bank.o'),'-o',str(B/'libgremlin-bms.dylib')],check=True)
