// Original audio firmware execution. Bus/IRQ map: pinned MAME btoads.cpp.
// Main-to-sound byte protocol: pinned M1 brd_btoads.cpp, original sequence bytes.
#pragma once
#include "bsmt_device.h"
extern "C" {
#include "mednafen/hw_cpu/z80-fuse/z80.h"
}
struct OriginalBtoads {
 Bsmt chip;std::array<uint8_t,65536>memory{};std::vector<uint8_t>sequence;
 size_t sequence_at=0;uint64_t next_irq=32768,writes=0,acks=0,unknown_reads=0,unknown_writes=0;uint8_t intstate=0;bool sent=false;
 static OriginalBtoads*active;
 static uint8_t readmem(uint16_t a){return active->memory[a];}
 static void writemem(uint16_t a,uint8_t v){if(a>=0x8000)active->memory[a]=v;}
 static uint8_t readport(uint16_t a){auto&m=*active;m.chip.advance(z80_tstates);switch(a){case 0x8000:if(m.sequence_at>=m.sequence.size())throw std::runtime_error("Absent original command byte");return m.sequence[m.sequence_at++];case 0x8004:return m.sent&&m.sequence_at<m.sequence.size()?0:0x80;case 0x8005:return 0x80;case 0x8006:return m.chip.pending?0:0x80;default:m.unknown_reads++;return 0xff;}}
 static void writeport(uint16_t a,uint8_t v){auto&m=*active;m.chip.advance(z80_tstates);if(a<0x8000){m.chip.write(a>>8,((a&255)<<8)|v);m.writes++;}else if(a==0x8002){if(!(m.intstate&0x80)&&(v&0x80))m.chip.reset_cpu();m.intstate=v;z80_set_interrupt(0);}else if(a==0x8000)m.acks++;else m.unknown_writes++;}
 void open(const std::vector<uint8_t>&z,const std::vector<uint8_t>&p,const std::vector<uint8_t>&s,const std::vector<uint8_t>&q){
  if(z.size()!=32768||q.empty()||q.size()>32768)throw std::runtime_error("Original audio firmware bounds");active=this;memory.fill(0);std::copy(z.begin(),z.end(),memory.begin());chip.open(p,s);sequence=q;sequence_at=0;sent=false;intstate=0;next_irq=32768;writes=acks=unknown_reads=unknown_writes=0;
  z80_readbyte=readmem;z80_writebyte=writemem;z80_readport=readport;z80_writeport=writeport;z80_init();z80_reset();z80_set_interrupt(0);
 }
 void advance(uint64_t tick){
  while(z80_tstates<tick){if(!sent&&z80_tstates>=12000000)sent=true;if(z80_tstates>=next_irq){z80_set_interrupt(1);next_irq+=32768;}z80_do_opcode();chip.advance(std::min(z80_tstates,tick));}
  chip.advance(tick);
 }
};
OriginalBtoads*OriginalBtoads::active=nullptr;
