// license:BSD-3-Clause
// BSMT2000 I/O behavior follows pinned MAME, copyright Aaron Giles.
// Original mask-ROM code executes on the unchanged MAME TMS320C15 methods.
#pragma once
#include "tms320c15.h"
#include <vector>
#include <array>
#include <algorithm>
#ifdef GREMLIN_LEGACY_TMS_REFERENCE
#include "legacy_tms_reference.h"
#endif
struct Bsmt {
#ifdef GREMLIN_LEGACY_TMS_REFERENCE
 LegacyCpu cpu;
#else
 tms320c1x_device_base<12> cpu;
#endif
 std::array<uint16_t,256> ram{};
 std::vector<uint8_t> rom,samples;
 uint16_t reg=0,data=0,addr=0,bank=0;
 int16_t left=0,right=0;
 bool pending=false;
 uint64_t cycles=0,next_sample=0,reads=0,dac_writes=0,missed=0,out_of_range=0;
 std::function<void(int16_t,int16_t)> output=[](int16_t,int16_t){};
 void open(const std::vector<uint8_t>&p,const std::vector<uint8_t>&s){
  if(p.size()!=8192||s.size()!=2097152)throw std::runtime_error("Original BSMT ROM size differs");
  rom=p;samples=s;ram.fill(0);reg=data=addr=bank=0;left=right=0;pending=false;cycles=next_sample=reads=dac_writes=missed=out_of_range=0;
#ifndef GREMLIN_LEGACY_TMS_REFERENCE
  // A new bank is a new powered-on device; in-game RESET still uses device_reset().
  cpu=tms320c1x_device_base<12>();
#endif
  cpu.buses(Bus{[this](unsigned a){if(a>=4096)throw std::runtime_error("DSP PC out of ROM");return uint16_t(rom[a*2]<<8|rom[a*2+1]);},[](unsigned,uint16_t){throw std::runtime_error("DSP ROM write");}},Bus{[this](unsigned a){return ram.at(a);},[this](unsigned a,uint16_t v){ram.at(a)=v;}},Bus{[this](unsigned a){return input(a);},[this](unsigned a,uint16_t v){port(a,v);}});
  cpu.m_bio_in=[this](){return pending?1:0;};cpu.device_reset();
 }
 void emit_to(uint64_t tick){while(next_sample<=tick){output(left,right);next_sample+=32;}}
 void advance(uint64_t tick){while(cycles<tick){cycles+=cpu.step();}emit_to(tick);}
 void reset_cpu(){cpu.device_reset();}
 uint16_t input(unsigned a){
  if(a==0)return reg;
  if(a==1){pending=false;return data;}
  if(a==2){reads++;unsigned pos=(unsigned(bank)<<16)+addr;if(pos>=samples.size()){out_of_range++;return 0;}return uint16_t(samples[pos])<<8;}
  throw std::runtime_error("Unexpected BSMT input port");
 }
 void port(unsigned a,uint16_t v){
  if(a==0)addr=v;else if(a==1)bank=v;
  else if(a==3||a==7){emit_to(cycles);if(a==3)left=int16_t(v);else right=int16_t(v);dac_writes++;}
  else throw std::runtime_error("Unexpected BSMT output port");
 }
 void write(unsigned r,unsigned d){reg=r;data=d;if(pending)missed++;pending=true;}
};
