// license:BSD-3-Clause
// copyright-holders:Tony La Porta
// MAME40d0f1125befade5edc08ec5699442ca3a229c01 instruction methods, unchanged.
#pragma once
#include <cstdint>
#include <functional>
#include <stdexcept>
#include <cstdio>
#include <cstdarg>
#define CLEAR_LINE 0
#define ASSERT_LINE 1
union PAIR {uint32_t d;struct{uint16_t l,h;}w;struct{uint8_t l,h,h2,h3;}b;};
struct Bus {std::function<uint16_t(unsigned)> r;std::function<void(unsigned,uint16_t)> w;uint16_t read_word(unsigned a){return r(a);}void write_word(unsigned a,uint16_t v){w(a,v);}};
[[noreturn]] inline void fatalerror(const char *s){throw std::runtime_error(s);}
[[noreturn]] inline void logerror(const char *s,...){char b[256];va_list a;va_start(a,s);vsnprintf(b,sizeof(b),s,a);va_end(a);throw std::runtime_error(b);}
template<int HighBits>class tms320c1x_device_base {
public:
 static constexpr uint32_t TMS320C1X_INT_PENDING=0x80000000,TMS320C1X_INT_NONE=0;
 std::function<int()> m_bio_in=[](){return 0;};
 void debugger_instruction_hook(unsigned){} void standard_irq_callback(unsigned,unsigned){}
 tms320c1x_device_base():m_PC(0),m_PREVPC(0),m_STR(0),m_ACC{},m_ALU{},m_Preg{},m_Treg(0),m_AR{},m_STACK{},m_opcode{},m_INTF(0),m_icount(0),m_oldacc{},m_memaccess(0),m_addr_mask((1u<<HighBits)-1){}
 void buses(Bus p,Bus d,Bus io){m_cache=m_program=p;m_data=d;m_io=io;}
 void device_reset();void execute_run();void execute_set_input(int,int);
 int step(){m_icount=1;execute_run();return 1-m_icount;}
 unsigned pc()const{return m_PC;}
	using opcode_func = void (tms320c1x_device_base::*)();
	struct tms320c1x_opcode
	{
		uint8_t       cycles;
		opcode_func function;
	};
	static const tms320c1x_opcode s_opcode_main[256];
	static const tms320c1x_opcode s_opcode_7F[32];

	/******************** CPU Internal Registers *******************/
	uint16_t  m_PC;
	uint16_t  m_PREVPC;     /* previous program counter */
	uint16_t  m_STR;
	PAIR      m_ACC;
	PAIR      m_ALU;
	PAIR      m_Preg;
	uint16_t  m_Treg;
	uint16_t  m_AR[2];
	uint16_t  m_STACK[4];

	PAIR      m_opcode;
	int       m_INTF;       /* Pending Interrupt flag */
	int       m_icount;
	PAIR      m_oldacc;
	uint16_t  m_memaccess;
	int       m_addr_mask;

	Bus m_cache,m_program,m_data,m_io;

	inline void CLR(uint16_t flag);
	inline void SET_FLAG(uint16_t flag);
	inline void CALCULATE_ADD_OVERFLOW(int32_t addval);
	inline void CALCULATE_SUB_OVERFLOW(int32_t subval);
	inline uint16_t POP_STACK();
	inline void PUSH_STACK(uint16_t data);
	inline void UPDATE_AR();
	inline void UPDATE_ARP();
	inline void getdata(uint8_t shift,uint8_t signext);
	inline void putdata(uint16_t data);
	inline void putdata_sar(uint8_t data);
	inline void putdata_sst(uint16_t data);
	void opcodes_7F();
	void illegal();
	void abst();
	void add_sh();
	void addh();
	void adds();
	void and_();
	void apac();
	void br();
	void banz();
	void bgez();
	void bgz();
	void bioz();
	void blez();
	void blz();
	void bnz();
	void bv();
	void bz();
	void cala();
	void call();
	void dint();
	void dmov();
	void eint();
	void in_p();
	void lac_sh();
	void lack();
	void lar_ar0();
	void lar_ar1();
	void lark_ar0();
	void lark_ar1();
	void larp_mar();
	void ldp();
	void ldpk();
	void lst();
	void lt();
	void lta();
	void ltd();
	void mpy();
	void mpyk();
	void nop();
	void or_();
	void out_p();
	void pac();
	void pop();
	void push();
	void ret();
	void rovm();
	void sach_sh();
	void sacl();
	void sar_ar0();
	void sar_ar1();
	void sovm();
	void spac();
	void sst();
	void sub_sh();
	void subc();
	void subh();
	void subs();
	void tblr();
	void tblw();
	void xor_();
	void zac();
	void zalh();
	void zals();
	inline int add_branch_cycle();
	int Ext_IRQ();
};
