#include "bsmt_device.h"
#include "hash/mednafen/mednafen.h"
#include "hash/sha256.h"
#include <deque>
#include <string>
#include <cstring>
static Bsmt chip;
static bool loaded=false;
static uint32_t output_rate,end_tick,skip_frames,event_count,event_at;
static uint64_t output_position,sample_counter,queue_base;
static std::vector<uint8_t> events;
static std::deque<std::array<int16_t,2>>pcm;
static std::string error_text,device_text;
static uint32_t u32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static uint16_t u16(const uint8_t*p){return uint16_t(p[0])|uint16_t(p[1])<<8;}
static void receive_sample(int16_t l,int16_t r){if(sample_counter>=skip_frames)pcm.push_back({l,r});sample_counter++;}
static void run_to(uint64_t tick){
 while(event_at<event_count&&u32(events.data()+size_t(event_at)*8)<=tick){const auto*p=events.data()+size_t(event_at)*8;uint32_t t=u32(p);chip.advance(t);if(chip.cycles!=t)throw std::runtime_error("Original DSP event boundary differs");if(p[4]==0)chip.write(p[5],u16(p+6));else chip.reset_cpu();event_at++;}
 chip.advance(tick);
}
static void ensure_sample(uint64_t index){
 while(queue_base+pcm.size()<=index){uint64_t absolute=uint64_t(skip_frames)+queue_base+pcm.size();if(absolute*32>end_tick)pcm.push_back({0,0});else run_to(absolute*32);}
}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_bms_close(){loaded=false;pcm.clear();events.clear();output_position=sample_counter=queue_base=event_at=0;chip.output=[](int16_t,int16_t){};chip.rom.clear();chip.samples.clear();}
API const char*gremlin_bms_error(){return error_text.c_str();}
API const char*gremlin_bms_devices(){return device_text.c_str();}
API int gremlin_bms_load(const uint8_t*b,uint32_t length,uint32_t rate,uint32_t subsong){
 gremlin_bms_close();error_text.clear();device_text.clear();
 try{
  if(!b||length<128||memcmp(b,"BMS\x1a",4)||u32(b+4)!=1)throw std::runtime_error("Invalid BMS1 header");
  if(u32(b+8)!=1||u32(b+12)!=24000000||u32(b+16)!=6000000||u32(b+20)!=187500||u32(b+24)!=8192||u32(b+28)!=2097152||u32(b+48)!=128||u32(b+52)!=128+8192+2097152||u32(b+56)||u32(b+60)||rate<8000||rate>192000||subsong)throw std::runtime_error("Unsupported BSMT profile");
  uint32_t count=u32(b+32),end=u32(b+36),skip=u32(b+40),cue=u32(b+44);uint64_t off=128+8192+2097152;
  if(!count||count>3500000||!end||end>3600000000u||skip>=end||skip%32||!cue||cue>255||off+uint64_t(count)*8!=length)throw std::runtime_error("Invalid BMS region bounds");
  auto ph=Mednafen::sha256(b+128,8192),sh=Mednafen::sha256(b+128+8192,2097152);if(memcmp(ph.data(),b+64,32)||memcmp(sh.data(),b+96,32))throw std::runtime_error("Original DSP or sample SHA256 differs");
  uint32_t previous=0;
  for(uint32_t i=0;i<count;i++){const auto*p=b+off+size_t(i)*8;uint32_t t=u32(p);if(t<previous||t>end||(p[4]!=0&&p[4]!=1)||(p[4]==0&&p[5]>127)||(p[4]==1&&(p[5]||u16(p+6))))throw std::runtime_error("Invalid BMS command event");previous=t;}
  events.assign(b+off,b+length);event_count=count;end_tick=end;skip_frames=skip/32;output_rate=rate;
  chip.open(std::vector<uint8_t>(b+128,b+128+8192),std::vector<uint8_t>(b+128+8192,b+off));chip.output=receive_sample;run_to(skip);loaded=true;
  char text[520];snprintf(text,sizeof(text),"[{\"type\":\"bsmt2000\",\"clock_hz\":24000000,\"source_event_rate\":6000000,\"internal_sample_rate\":187500,\"output_sample_rate\":%u,\"original_dsp\":\"TMS320C15 mask ROM\",\"core\":\"pinned MAME TMS320C15 methods\",\"sequencer\":\"original Z80 register trace\",\"game_rom_or_bios_dependency\":false}]",rate);device_text=text;return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_bms_close();return 1;}
}
API uint32_t gremlin_bms_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;
 try{
  for(unsigned i=0;i<frames;i++,output_position++){
   uint64_t numerator=output_position*187500,at=numerator/output_rate;uint32_t remainder=numerator%output_rate;ensure_sample(at+1);size_t q=size_t(at-queue_base);
   for(unsigned c=0;c<2;c++){double a=pcm[q][c],b=pcm[q+1][c];out[i*2+c]=float((a+(b-a)*double(remainder)/output_rate)/32768.0);}
   while(queue_base<at){pcm.pop_front();queue_base++;}
  }
  return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_bms_close();return 0;}
}
}
