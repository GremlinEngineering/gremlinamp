// Diagnostic-only adapter for unchanged, independently implemented 2002 M1 CPU.
// Not used in the delivered browser decoder. Original license accompanies source.
#pragma once
extern "C" {
void tms32010_init();void tms32010_reset(void*);int tms32010_execute(int);unsigned tms32010_get_reg(int);
int cpu_getactivecpu(){return 0;}
void state_save_register_UINT16(const char*,int,const char*,uint16_t*,unsigned){}
void state_save_register_UINT32(const char*,int,const char*,uint32_t*,unsigned){}
void state_save_register_INT32(const char*,int,const char*,int32_t*,unsigned){}
void logerror_legacy(char*s,...){char b[256];va_list a;va_start(a,s);vsnprintf(b,sizeof(b),s,a);va_end(a);throw std::runtime_error(b);}
}
struct LegacyCpu {
 Bus p,d,io;std::function<int()>m_bio_in;static LegacyCpu *current;
 LegacyCpu(){current=this;tms32010_init();}
 void buses(Bus a,Bus b,Bus c){p=a;d=b;io=c;}
 void device_reset(){tms32010_reset(nullptr);}
 int step(){int c=tms32010_execute(4);if(c%4)throw std::runtime_error("Nonintegral DSP clock");return c/4;}
 unsigned pc()const{return tms32010_get_reg(1);}
};
LegacyCpu*LegacyCpu::current=nullptr;
extern "C" {
unsigned tms32010_read16(unsigned a){auto*c=LegacyCpu::current;return a>=0x8000?c->p.read_word((a-0x8000)/2):c->d.read_word(a/2);}
void tms32010_write16(unsigned a,unsigned v){auto*c=LegacyCpu::current;if(a>=0x8000)c->p.write_word((a-0x8000)/2,v);else c->d.write_word(a/2,v);}
unsigned tms32010_readport(unsigned a){auto*c=LegacyCpu::current;return a==0x100?c->m_bio_in():c->io.read_word(a/2);}
void tms32010_writeport(unsigned a,unsigned v){LegacyCpu::current->io.write_word(a/2,v);}
}
