#include "original_btoads.h"
#include "hash/mednafen/mednafen.h"
#include "hash/sha256.h"
#include <deque>
#include <string>
#include <cstring>
static OriginalBtoads original;
static bool loaded=false;
static uint32_t output_rate,skip_frames;
static uint64_t output_position,sample_counter,queue_base;
static std::deque<std::array<int16_t,2>>pcm;
static std::string error_text,device_text,stats_text;
static uint32_t u32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static void receive_sample(int16_t l,int16_t r){if(sample_counter>=skip_frames)pcm.push_back({l,r});sample_counter++;}
static void ensure_sample(uint64_t index){while(queue_base+pcm.size()<=index){uint64_t absolute=uint64_t(skip_frames)+queue_base+pcm.size();original.advance(absolute*32);}}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_bms_close(){loaded=false;pcm.clear();output_position=sample_counter=queue_base=0;original.chip.output=[](int16_t,int16_t){};original.chip.rom.clear();original.chip.samples.clear();original.sequence.clear();}
API const char*gremlin_bms_error(){return error_text.c_str();}
API const char*gremlin_bms_devices(){return device_text.c_str();}
API const char*gremlin_bms_stats(){char b[500];snprintf(b,sizeof(b),"{\"z80_cycles\":%llu,\"z80_pc\":%u,\"dsp_cycles\":%llu,\"dsp_pc\":%u,\"sequence_bytes\":%zu,\"consumed_bytes\":%zu,\"bsmt_writes\":%llu,\"missed_data\":%llu,\"unknown_reads\":%llu,\"unknown_writes\":%llu}",(unsigned long long)z80_tstates,z80_getpc(),(unsigned long long)original.chip.cycles,original.chip.cpu.pc(),original.sequence.size(),original.sequence_at,(unsigned long long)original.writes,(unsigned long long)original.chip.missed,(unsigned long long)original.unknown_reads,(unsigned long long)original.unknown_writes);stats_text=b;return stats_text.c_str();}
API int gremlin_bms_load(const uint8_t*b,uint32_t length,uint32_t rate,uint32_t command){
 gremlin_bms_close();error_text.clear();device_text.clear();
 try{
  if(!b||length<160||memcmp(b,"BMS\x1a",4)||u32(b+4)!=1)throw std::runtime_error("Invalid BMS1 header");
  if(u32(b+8)!=2||u32(b+12)!=6000000||u32(b+16)!=24000000||u32(b+20)!=187500||u32(b+24)!=32768||u32(b+28)!=8192||u32(b+32)!=2097152||u32(b+40)!=160||u32(b+44)!=12000000||rate<8000||rate>192000)throw std::runtime_error("Unsupported original BSMT profile");
  uint32_t count=u32(b+36),zo=u32(b+48),po=u32(b+52),so=u32(b+56),qo=u32(b+60);uint64_t expected=160+uint64_t(count)*64;
  if(!count||count>256||zo!=expected||po!=uint64_t(zo)+32768||so!=uint64_t(po)+8192||qo!=uint64_t(so)+2097152||qo>length)throw std::runtime_error("Invalid BMS region bounds");
  auto zh=Mednafen::sha256(b+zo,32768),ph=Mednafen::sha256(b+po,8192),sh=Mednafen::sha256(b+so,2097152);if(memcmp(zh.data(),b+64,32)||memcmp(ph.data(),b+96,32)||memcmp(sh.data(),b+128,32))throw std::runtime_error("Original audio-region SHA256 differs");
  bool seen[256]={};uint32_t selected_offset=0,selected_length=0;uint64_t next=qo;
  const uint8_t signature[]={0x52,0x61,0x72,0x65,4,5,10,18};
  for(unsigned i=0;i<count;i++){
   const auto*p=b+160+i*64;uint32_t id=u32(p),off=u32(p+4),len=u32(p+8);if(id>255||seen[id]||off!=next||len<10||len>32768||uint64_t(off)+len>length)throw std::runtime_error("Invalid BMS original selector table");seen[id]=true;for(unsigned j=12;j<32;j++)if(p[j])throw std::runtime_error("Unsupported BMS selector flags");if(memcmp(b+off,signature,sizeof(signature)))throw std::runtime_error("Original command handshake absent");auto h=Mednafen::sha256(b+off,len);if(memcmp(h.data(),p+32,32))throw std::runtime_error("Original sequence SHA256 differs");if(id==command){selected_offset=off;selected_length=len;}next+=len;
  }
  if(next!=length||!selected_length)throw std::runtime_error("BMS selector absent or trailing data");
  skip_frames=12000000/32;output_rate=rate;original.open(std::vector<uint8_t>(b+zo,b+po),std::vector<uint8_t>(b+po,b+so),std::vector<uint8_t>(b+so,b+qo),std::vector<uint8_t>(b+selected_offset,b+selected_offset+selected_length));original.chip.output=receive_sample;original.advance(12000000);loaded=true;
  char text[520];snprintf(text,sizeof(text),"[{\"type\":\"bsmt2000\",\"clock_hz\":24000000,\"internal_sample_rate\":187500,\"output_sample_rate\":%u,\"original_dsp\":\"TMS320C15 mask ROM\",\"core\":\"pinned MAME TMS320C15 methods\",\"original_sound_cpu\":\"Z80@6000000\",\"game_rom_or_bios_dependency\":false}]",rate);device_text=text;return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_bms_close();return 1;}
}
API uint32_t gremlin_bms_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;
 try{
  for(unsigned i=0;i<frames;i++,output_position++){
   uint64_t numerator=output_position*187500,at=numerator/output_rate;uint32_t remainder=numerator%output_rate;ensure_sample(at+1);size_t q=size_t(at-queue_base);
   for(unsigned c=0;c<2;c++){double a=pcm[q][c],b=pcm[q+1][c];out[i*2+c]=float((a+(b-a)*double(remainder)/output_rate)/32768.0);}
   while(queue_base<at){pcm.pop_front();queue_base++;}
  }
  return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_bms_close();return 0;}
}
}
