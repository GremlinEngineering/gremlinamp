"""Build pinned Atari cores as separate headless WASM modules and native references."""
from pathlib import Path
import argparse,os,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--sdk',type=Path,required=True);a=p.parse_args();sdk=a.sdk.resolve()
out=ROOT/'built';out.mkdir(exist_ok=True);build=ROOT/'build-atari';build.mkdir(exist_ok=True)
env={**os.environ,'EMSDK':str(sdk),'EM_CONFIG':str(sdk/'.emscripten'),'PATH':str(sdk/'upstream/emscripten')+os.pathsep+os.environ['PATH']}
receipts=json.loads((ROOT/'source-receipts.json').read_text());reports=[]
for name in ['tia','prosystem']:
 src=ROOT/'third_party'/name
 if name=='tia':
  sources=[src/'src'/n for n in ['cpu.c','riot.c','tia.c','palette.c','cart.c','bus.c','libretro.c']];includes=[src/'src'];defines=[]
 else:
  core=src/'core';common=src/'libretro-common';sources=[core/n for n in ['libretro.c','Bios.c','BupChip.c','Cartridge.c','Database.c','Hash.c','Maria.c','Memory.c','Palette.c','Pokey.c','ProSystem.c','Region.c','Riot.c','Sally.c','Tia.c']]
  sources += [src/'bupboop/coretone'/n for n in ['channel.c','coretone.c','music.c','sample.c']]
  sources += [common/n for n in ['compat/compat_posix_string.c','compat/compat_strcasestr.c','compat/compat_snprintf.c','compat/compat_strl.c','compat/fopen_utf8.c','encodings/encoding_utf.c','file/file_path.c','file/file_path_io.c','streams/file_stream.c','streams/file_stream_transforms.c','string/stdstring.c','time/rtime.c','vfs/vfs_implementation.c']]
  includes=[core,common/'include'];defines=['-DGREMLIN_A78=1','-D__LIBRETRO__','-DRIGHTSHIFT_IS_SAR','-DLSB_FIRST']
 args=['-O3','-std=gnu99']+defines+['-I'+str(x) for x in includes]+[str(ROOT/'src/atari_bridge.c')]+[str(x) for x in sources]+['-lm']
 def run(cmd,label):
  log=build/(name+'-'+label+'.log')
  with log.open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:print(log.read_text()[-6000:]);raise SystemExit(r.returncode)
 wasm=out/('gremlin-'+name+'.js')
 command=['python3',str(sdk/'upstream/emscripten/emcc.py')]+args+['-sMODULARIZE=1','-sEXPORT_NAME=GremlinAtari','-sENVIRONMENT=worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sMAXIMUM_MEMORY=134217728','-sSTACK_SIZE=1048576','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS=["_gremlin_atari_load","_gremlin_atari_render","_gremlin_atari_error","_gremlin_atari_rate","_gremlin_atari_fps","_malloc","_free"]','-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(wasm)]
 run(command,'wasm');run(['cc','-shared','-fPIC']+args+['-o',str(out/('libgremlin-'+name+'.so'))],'native')
 files=[]
 for suffix in ['js','wasm']:
  f=wasm.with_suffix('.'+suffix);files.append({'path':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 reports.append({'name':name,'upstream':next(r for r in receipts if r['name']==name),'files':files});print(name,'built',files,flush=True)
(out/'BUILD.json').write_text(json.dumps({'compiler':'Emscripten 6.0.13','cores':reports,'bridge_license':'GPL-2.0-or-later','pcm':'stereo Float32; linear native-rate conversion','bios_bundled':False},indent=2)+'\n')
