/* SPDX-License-Identifier: GPL-2.0-or-later
 * Headless libretro audio bridge for music-only Atari ROMs.
 * No BIOS, display, network, input automation or game assets are bundled.
 */
#include "libretro.h"
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#define CAP 16384u
static int16_t samples[CAP*2];
static uint32_t rates[CAP];
static size_t read_pos, queued;
static double phase, current_rate=31400.0, fps=60.0;
static int target_rate, loaded, initialized, overflow;
static char error_text[256];
static const char *region_value="auto";
static void log_ignore(enum retro_log_level level,const char *fmt,...) {(void)level;(void)fmt;}
static bool environment(unsigned cmd,void *data) {
 switch(cmd) {
 case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: ((struct retro_log_callback*)data)->log=log_ignore;return true;
 case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char**)data="/gremlin-no-bios";return true;
 case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned*)data=0;return true;
 case RETRO_ENVIRONMENT_GET_VARIABLE: {
  struct retro_variable *v=(struct retro_variable*)data;v->value=NULL;
  if(!strcmp(v->key,"tia_region")){v->value=region_value;return true;}
  return false;
 }
 case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool*)data=false;return true;
 case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool*)data=true;return true;
 case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
  const struct retro_system_av_info *a=(const struct retro_system_av_info*)data;
  if(a->timing.sample_rate>0)current_rate=a->timing.sample_rate;
  if(a->timing.fps>0)fps=a->timing.fps;return true;
 }
 case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
 case RETRO_ENVIRONMENT_SET_VARIABLES:
 case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
 case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
 case RETRO_ENVIRONMENT_SET_GEOMETRY:
 case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
  return true;
 default:return false;
 }
}
static void video_ignore(const void *data,unsigned w,unsigned h,size_t pitch){(void)data;(void)w;(void)h;(void)pitch;}
static void poll_ignore(void){}
static int16_t input_none(unsigned port,unsigned device,unsigned index,unsigned id){(void)port;(void)device;(void)index;(void)id;return 0;}
static void audio_one(int16_t l,int16_t r){
 size_t n;if(queued>=CAP){overflow=1;return;}n=(read_pos+queued)%CAP;
 samples[n*2]=l;samples[n*2+1]=r;rates[n]=(uint32_t)current_rate;queued++;
}
static size_t audio_batch(const int16_t *p,size_t frames){size_t i;for(i=0;i<frames;i++)audio_one(p[i*2],p[i*2+1]);return frames;}
const char *gremlin_atari_error(void){return error_text;}
double gremlin_atari_rate(void){return current_rate;}
double gremlin_atari_fps(void){return fps;}
int gremlin_atari_load(const uint8_t *data,size_t size,int rate,int region) {
 struct retro_game_info game;struct retro_system_av_info av;
 if(rate<8000||rate>192000){strcpy(error_text,"Invalid output sample rate");return 1;}
 if(loaded){retro_unload_game();loaded=0;}
 if(initialized)retro_deinit();initialized=0;
 read_pos=queued=0;phase=0;overflow=0;error_text[0]=0;target_rate=rate;
 region_value=region==1?"ntsc":region==2?"pal":region==3?"pal60":region==4?"secam":"auto";
 retro_set_environment(environment);retro_set_video_refresh(video_ignore);retro_set_audio_sample(audio_one);retro_set_audio_sample_batch(audio_batch);retro_set_input_poll(poll_ignore);retro_set_input_state(input_none);
 retro_init();initialized=1;memset(&game,0,sizeof(game));
#ifdef GREMLIN_A78
 game.path="music.a78";
#else
 game.path="music.a26";
#endif
 game.data=data;game.size=size;
 if(!retro_load_game(&game)){strcpy(error_text,"Atari core rejected this music ROM");return 2;}
 loaded=1;retro_get_system_av_info(&av);current_rate=av.timing.sample_rate;fps=av.timing.fps;
 if(!isfinite(current_rate)||current_rate<8000||current_rate>192000){strcpy(error_text,"Invalid Atari core sample rate");return 3;}
 return 0;
}
int gremlin_atari_render(float *out,unsigned frames){
 unsigned i,ch;size_t need,n;int attempts;
 if(!loaded||frames>16384){strcpy(error_text,"Atari is not loaded or render block is too large");return 1;}
 for(i=0;i<frames;i++){
  attempts=0;
  /* Keep enough native samples for interpolation and a downsampling step. */
  need=2+(size_t)ceil(192000.0/target_rate);
  while(queued<need){size_t before=queued;retro_run();if(overflow){strcpy(error_text,"Atari audio queue overflow");return 2;}if(queued==before&&++attempts>120){strcpy(error_text,"Atari ROM produced no audio clock");return 3;}}
  for(ch=0;ch<2;ch++){float a=samples[read_pos*2+ch]/32768.0f;float b=samples[((read_pos+1)%CAP)*2+ch]/32768.0f;out[i*2+ch]=a+(b-a)*(float)phase;}
  phase+=(double)rates[read_pos]/target_rate;n=(size_t)phase;phase-=n;
  if(n>queued){strcpy(error_text,"Atari resampler underflow");return 4;}
  read_pos=(read_pos+n)%CAP;queued-=n;
 }
 return 0;
}
