"""Independent native builds of the pinned upstream cores; no WASM involved."""
from pathlib import Path
import ctypes as C,numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'verification/native-reference';out.mkdir(exist_ok=True)
results=[]
for fmt,core in [('a26','tia'),('a78','prosystem')]:
 lib=C.CDLL(str(ROOT/'built'/('libgremlin-'+core+'.so')));lib.gremlin_atari_load.argtypes=[C.c_void_p,C.c_size_t,C.c_int,C.c_int];lib.gremlin_atari_load.restype=C.c_int;lib.gremlin_atari_render.argtypes=[C.c_void_p,C.c_uint];lib.gremlin_atari_render.restype=C.c_int;lib.gremlin_atari_error.restype=C.c_char_p;lib.gremlin_atari_rate.restype=C.c_double
 for region in ['ntsc','pal']:
  for rate in [44100,48000]:
   f=ROOT/'verification/fixtures'/('beside-'+fmt+'-'+region+'.'+fmt);b=f.read_bytes();buf=C.create_string_buffer(b);assert lib.gremlin_atari_load(buf,len(b),rate,0)==0,lib.gremlin_atari_error()
   n=rate*30;data=np.empty((n,2),dtype='<f4');pos=0
   while pos<n:
    frames=min(4096,n-pos);assert lib.gremlin_atari_render(data[pos:].ctypes.data,frames)==0,lib.gremlin_atari_error();pos+=frames
   assert np.isfinite(data).all() and np.sqrt(np.mean(data.astype(float)**2))>0.001,(fmt,region)
   dest=out/(f.stem+'-'+str(rate)+'.f32');dest.write_bytes(data.tobytes());row={'file':f.name,'output_rate':rate,'native_rate':lib.gremlin_atari_rate(),'seconds':30,'rms':float(np.sqrt(np.mean(data.astype(float)**2))),'peak':float(np.abs(data).max()),'pcm_file':str(dest.relative_to(ROOT)),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'pass':True};results.append(row);print(row,flush=True)
(ROOT/'native-reference-results.json').write_text(json.dumps({'method':'Native cc -O3 builds of upstream libretro cores plus the same audio bridge; not a recording-based physical-hardware accuracy proof.','results':results},indent=2)+'\n')
