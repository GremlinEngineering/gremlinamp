"""Build actual musical ROM fixtures from TIATracker's Beside by Glafouk.
The imported tracker files remain unchanged, including their original notices.
"""
from pathlib import Path
import subprocess,hashlib,json,argparse,shutil
ROOT=Path(__file__).resolve().parents[1];EX=ROOT/'verification/tiatracker-example';OUT=ROOT/'verification/fixtures';OUT.mkdir(exist_ok=True)
args=argparse.ArgumentParser();args.add_argument('--dasm',type=Path);options=args.parse_args()
dasm=options.dasm or Path(shutil.which('dasm') or ROOT/'runtime/dasm/usr/bin/dasm')
equates='''        processor 6502
AUDC0 = $15
AUDC1 = $16
AUDF0 = $17
AUDF1 = $18
AUDV0 = $19
AUDV1 = $1A
WSYNC = $02
VSYNC = $00
VBLANK = $01
INTIM = $0284
TIM64T = $0296
'''
for system in ['a26','a78']:
 for region in ['ntsc','pal']:
  name='beside-'+system+'-'+region;asm=OUT/(name+'.asm');rom=OUT/(name+'.bin')
  text=equates+'        SEG.U vars\n        ORG '+('$80' if system=='a26' else '$40')+'\n        include "../tiatracker-example/examples/Beside/Beside_variables.asm"\n        SEG code\n        ORG '+('$F000' if system=='a26' else '$E000')+'\nStart:\n        sei\n        cld\n        ldx #$FF\n        txs\n        lda #0\n        ldx #$7F\nClear:\n        sta $80,x\n        dex\n        bpl Clear\n'
  if system=='a78':text+='        ldx #$3F\nClear78:\n        sta $40,x\n        dex\n        bpl Clear78\n        lda #7\n        sta $01\n        lda #$60\n        sta $3C\n'
  text+='        include "../tiatracker-example/examples/Beside/Beside_init.asm"\n'
  if system=='a26':
   text+='''Frame:
        lda #2
        sta VBLANK
        sta VSYNC
        sta WSYNC
        sta WSYNC
        sta WSYNC
        lda #0
        sta VSYNC
        lda #43
        sta TIM64T
        jsr tt_PlayerStart
WaitBlank:
        lda INTIM
        bne WaitBlank
        sta WSYNC
        sta VBLANK
        ldx #192
Visible:
        sta WSYNC
        dex
        bne Visible
        lda #2
        sta VBLANK
'''
   # PAL has 50 additional overscan lines; TIA pitches follow PAL hardware.
   text+='        ldx #'+('50' if region=='pal' else '0')+'\n'
   if region=='pal':text+='ExtraPal:\n        sta WSYNC\n        dex\n        bne ExtraPal\n'
   text+='''        lda #35
        sta TIM64T
WaitOver:
        lda INTIM
        bne WaitOver
        sta WSYNC
        jmp Frame
'''
  else:text+='''Frame:
        lda $28
        bpl Frame
        jsr tt_PlayerStart
WaitVisible:
        lda $28
        bmi WaitVisible
        jmp Frame
'''
  text+='''        include "../tiatracker-example/tiatracker/tiatracker_player.asm"
        rts
        include "../tiatracker-example/examples/Beside/Beside_trackdata.asm"
        ORG $FFFA
        word Start,Start,Start
'''
  asm.write_text(text);r=subprocess.run([str(dasm.resolve()),asm.name,'-f3','-o'+rom.name,'-l'+name+'.lst'],cwd=OUT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(name,r.stdout[-1000:]);assert r.returncode==0
  b=rom.read_bytes();assert len(b)==(4096 if system=='a26' else 8192)
  if system=='a78':
   h=bytearray(128);h[0]=1;h[1:10]=b'ATARI7800';h[17:17+len(b'Beside - Glafouk')]=b'Beside - Glafouk';h[49:53]=len(b).to_bytes(4,'big');h[55]=h[56]=1;h[57]=int(region=='pal');b=bytes(h)+b
  dest=OUT/(name+'.'+system);dest.write_bytes(b)
rows=[{'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'composer':'Glafouk','title':'Beside','source':'TIATracker example, separate music-only test ROM framework','not_catalog_music':True} for f in sorted(OUT.glob('*.a*'))]
(OUT/'fixtures.json').write_text(json.dumps(rows,indent=2)+'\n')
