const fs=require('node:fs'),http=require('node:http'),path=require('node:path');
const {chromium}=require('playwright');
const root=__dirname,site=path.join(root,'test-site');
const html=`<!doctype html><meta charset="utf-8"><script type="module">
import {MusicEngine} from '/music/engine.js';
import {decoderFor} from '/music/decoders.js';
window.engine=new MusicEngine();window.decoderFor=decoderFor;
window.testAtari=async t=>{
 const bytes=await(await fetch('/verify/fixtures/'+t.file)).arrayBuffer();
 if(t.corrupt==='header')new Uint8Array(bytes)[1]=0;
 if(t.corrupt==='length')new Uint8Array(bytes)[52]^=1;
 const expected=t.reference?new Float32Array(await(await fetch('/verify/native-reference/'+t.reference)).arrayBuffer()):null;
 return new Promise(resolve=>{
  const worker=new Worker('/music/atari-worker.js');let info,offset=0,sum=0,errorSum=0,maxError=0,peak=0,finite=true;const n=t.rate*30*2;
  const timer=setTimeout(()=>done({error:'timeout'}),120000);let finished=false;
  function done(value){if(finished)return;finished=true;clearTimeout(timer);worker.terminate();resolve({...value,info});}
  worker.onerror=e=>done({error:e.message});
  worker.onmessage=({data:m})=>{
   if(m.type==='error')return done({error:m.message});
   if(m.type==='ready'){info=m;return worker.postMessage({type:'render',frames:Math.min(t.block||4096,(n-offset)/2)});}
   if(m.type==='pcm'){
    const data=new Float32Array(m.pcm);
    for(let i=0;i<data.length;i++){const x=data[i];finite=finite&&Number.isFinite(x);sum+=x*x;peak=Math.max(peak,Math.abs(x));if(expected){const d=x-expected[offset+i];errorSum+=d*d;maxError=Math.max(maxError,Math.abs(d));}}
    offset+=data.length;
    if(offset>=n)return done({seconds:offset/2/t.rate,rms:Math.sqrt(sum/offset),peak,finite,maxAbsoluteError:maxError,comparisonRMSE:Math.sqrt(errorSum/offset)});
    worker.postMessage({type:'render',frames:Math.min(t.block||4096,(n-offset)/2)});
   }
  };
  worker.postMessage({type:'load',bytes,format:t.format,subsong:t.subsong||0,sampleRate:t.rate,dependencies:t.dependencies||[],atari:t.atari},[bytes]);
 });
};window.ready=true;
</script>`;
(async()=>{
 const server=http.createServer((req,res)=>{
  const name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  if(name==='/'){res.setHeader('Content-Type','text/html');res.end(html);return;}
  let base,relative;if(name.startsWith('/verify/')){base=path.join(root,'verification');relative=name.slice(8);}else{base=site;relative=name.slice(1);}
  const file=path.resolve(base,relative);if(!file.startsWith(base+'/'))return res.writeHead(403).end();
  fs.readFile(file,(e,b)=>{res.writeHead(e?404:200,{'Content-Type':({'.js':'application/javascript','.wasm':'application/wasm'})[path.extname(file)]||'application/octet-stream'});res.end(e?'missing':b)});
 });await new Promise(r=>server.listen(8798,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:path.resolve(root,'../music_player_codecs_0_1/.tools/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
 const page=await browser.newPage(),pageErrors=[];page.on('pageerror',e=>pageErrors.push(e.message));await page.goto('http://127.0.0.1:8798/');await page.waitForFunction(()=>window.ready);
 const references=JSON.parse(fs.readFileSync(root+'/native-reference-results.json')).results;const results=[];
 for(const r of references){const t={file:r.file,format:path.extname(r.file).slice(1),rate:r.output_rate,reference:path.basename(r.pcm_file)};const v=await page.evaluate(t=>testAtari(t),t);const pass=!v.error&&v.finite&&v.rms>0.001&&v.maxAbsoluteError<0.000002;results.push({id:r.file+'-'+t.rate,pass,...v});console.log(JSON.stringify(results.at(-1)));}
 for(const t of [{format:'a78',file:'beside-a78-ntsc.a78',corrupt:'header'},{format:'a78',file:'beside-a78-ntsc.a78',corrupt:'length'},{format:'a26',file:'beside-a26-ntsc.a26',subsong:1},{format:'a26',file:'beside-a26-ntsc.a26',rate:0},{format:'a78',file:'beside-a78-pal.a78',atari:{region:'ntsc'}}]){
  const v=await page.evaluate(t=>testAtari(t),{rate:48000,...t});results.push({id:'reject-'+JSON.stringify(t),pass:!!v.error,...v});
 }
 const chunk=await page.evaluate(t=>testAtari(t),{file:'beside-a78-ntsc.a78',format:'a78',rate:48000,block:997,reference:'beside-a78-ntsc-48000.f32'});results.push({id:'arbitrary-block-boundaries',pass:!chunk.error&&chunk.maxAbsoluteError<0.000002,...chunk});
 const controls=await page.evaluate(async()=>{
  const wait=ms=>new Promise(r=>setTimeout(r,ms));const track=(format,url)=>({backend:'gme',subsong:0,play_ms:30000,fade_ms:0,gain_db:-6,asset:{format,url,bytes:8320,path:url.split('/').pop()}});
  const manifest={id:'atari-controls',manifestURL:location.href,delivery:{preload_budget_bytes:0},tracks:[track('a26','/verify/fixtures/beside-a26-ntsc.a26'),track('a78','/verify/fixtures/beside-a78-ntsc.a78'),track('spc','/fixtures/01%20Main%20Theme.spc')]};
  const audible=async()=>{for(let i=0;i<30;i++){await wait(100);const s=engine.snapshot();if(s.state==='error')throw Error(s.error);if(s.diagnostics.rms>0)return s;}throw Error('silent')};
  await engine.play(manifest,0);const a26=await audible();const gain=engine.context.destination.numberOfInputs;
  engine.pause();const p1=engine.snapshot();await wait(350);const p2=engine.snapshot();await engine.play(manifest,0);const resume=await audible();
  await engine.play(manifest,1);const a78=await audible();await engine.play(manifest,2);const spc=await audible();await engine.play(manifest,0);const back=await audible();
  engine.stop();const stopped=engine.snapshot();const pending=engine.play({...manifest,id:'cancel'},1);engine.stop();await pending;const cancel=engine.snapshot();
  let ambiguous=false;try{decoderFor({format:'bin'})}catch{ambiguous=true;}
  return {a26:a26.state==='playing',a78:a78.state==='playing',spc:spc.state==='playing',back:back.state==='playing',pause:p1.state==='paused'&&p2.seconds===p1.seconds,resume:resume.state==='playing',stop:stopped.state==='idle',cancel:cancel.state==='idle',ambiguous_bin_rejected:ambiguous};
 });results.push({id:'engine-controls-and-format-switches',pass:Object.values(controls).every(Boolean),checks:controls});
 const report={method:'Four real TIATracker music-ROM fixtures, Atari 2600/7800, NTSC/PAL, 30 seconds each at 44100/48000 Hz; PCM compared with separate native cc builds. Controls, block boundaries and invalid inputs checked.',results,pageErrors};fs.writeFileSync(root+'/atari-browser-results.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:results.filter(r=>r.pass).length,total:results.length,pageErrors,controls}));
 await browser.close();await new Promise(r=>server.close(r));if(results.some(r=>!r.pass)||pageErrors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
