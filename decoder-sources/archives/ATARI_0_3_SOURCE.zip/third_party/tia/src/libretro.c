/* SPDX-License-Identifier: GPL-2.0-or-later */

#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <time.h>

#include "compat.h"
#include "libretro.h"
#include "cpu.h"
#include "tia.h"
#include "riot.h"
#include "cart.h"
#include "bus.h"

#ifndef CORE_VERSION
#define CORE_VERSION "0+unknown"
#endif

#define FRAME_WIDTH       TIA_VISIBLE_WIDTH
/* The output is a fixed window into the TIA framebuffer, the way a TV scans a
 * fixed region. The window starts at a constant scanline (WINDOW_TOP) measured
 * from the frame top (the VSYNC boundary), so a game's picture lands at
 * whatever output row its own VBLANK timing puts it: a longer vertical blank
 * sits lower, a shorter one higher, exactly as a real set shows. We do not
 * re-anchor to where the game starts drawing -- that would pin content to a
 * fixed row and erase the vertical timing the hardware would display.
 *
 * WINDOW_TOP sits just above where a standard game's picture begins, so the
 * typical game shows little top border while no real content is clipped. PAL's
 * picture runs lower and longer, so it uses a taller window. */
#define FRAME_HEIGHT_NTSC 228
#define FRAME_HEIGHT_PAL  268
#define WINDOW_TOP_NTSC    34
#define WINDOW_TOP_PAL     44
#define HOVERSCAN_TRIM 8        /* pixels cropped from each side when enabled */
#define MAX_CYCLES_PER_RUN 200000        /* safety cap if VSYNC never fires */
#define AUDIO_BUF_MONO    1024

static retro_environment_t        environ_cb;
static retro_video_refresh_t      video_cb;
static retro_audio_sample_t       audio_cb;
static retro_audio_sample_batch_t audio_batch_cb;
static retro_input_poll_t         input_poll_cb;
static retro_input_state_t        input_state_cb;

static struct retro_log_callback  logging;
static retro_log_printf_t         log_cb;

/* Controller device codes. Paddles and driving are subclasses of ANALOG so
 * the frontend can show them in its core-option menu. The keypad uses the
 * stock RETRO_DEVICE_KEYBOARD. */
#define DEV_JOYPAD  RETRO_DEVICE_JOYPAD
#define DEV_PADDLE  RETRO_DEVICE_SUBCLASS(RETRO_DEVICE_ANALOG, 0)
#define DEV_DRIVING RETRO_DEVICE_SUBCLASS(RETRO_DEVICE_ANALOG, 1)
#define DEV_KEYPAD  RETRO_DEVICE_KEYBOARD

/* Paddle capacitor charge at maximum rotation, in TIA color clocks. Real
 * HW takes roughly one NTSC frame (~59,736 clocks) for the pot's RC
 * network to cross the comparator threshold. We use a slightly generous
 * value so games that expect the full-range dump have headroom. */
#define PADDLE_CHARGE_MAX_CLOCKS 65000u

/* Gray code for driving controller output on SWCHA bits 5:4 (P0) or 1:0
 * (P1). Turning the wheel advances through this table in one direction
 * or the other; games infer direction from the transition pattern. */
static const uint8_t driving_gray[4] = { 0x00, 0x01, 0x03, 0x02 };

static struct {
    struct cpu  cpu;
    struct tia  tia;
    struct riot riot;
    struct cart cart;
    struct bus  bus;
    unsigned    port_device[2];
    bool        loaded;
    /* Console switch state — latched, toggled by button edges. The six
     * switch-setting retropad buttons (L/L2/L3/R/R2/R3) each drive one
     * side of a physical toggle: L sets left-diff A, L2 sets left-diff
     * B, and so on. Initial values match common factory defaults. */
    bool        sw_color;        /* true = color, false = B&W */
    bool        sw_left_diff_a;  /* true = A, false = B */
    bool        sw_right_diff_a;
    /* Power-on RAM mode (tia_ram_init). true = fill with fresh per-boot
     * pseudo-random noise (hardware-like); false = zeroed (matches the
     * reference emulators, deterministic). Read once at load. */
    bool        ram_init_hardware;
    /* Previous-frame button state for edge detection on the six
     * switch-setting buttons (one bit per JOYPAD_L..R3). */
    uint8_t     sw_prev;

    /* Keypad button state for ports in DEV_KEYPAD mode. One bit per key
     * in the order {1,2,3,4,5,6,7,8,9,*,0,#} -> bits 0..11. Bit set =
     * pressed. Updated by poll_inputs, consumed by keypad_update() on
     * every SWCHA/DDR change. */
    uint16_t    keypad_pressed[2];

    /* Region handling. `region_setting` is -1 for auto-detect, or one of
     * the TIA_REGION_* values when forced by the user. `active_region` is
     * what's currently applied (resolves auto → detected). We notify the
     * frontend via SET_SYSTEM_AV_INFO only when active_region changes, so
     * fps/sample-rate renegotiation happens at most once per session
     * (after detection locks) or once per option change. */
    int         region_setting;       /* -1 = auto, else enum tia_region */
    enum tia_region active_region;

    /* Overscan crop. hoverscan trims 8 pixels off each side; voverscan
     * trims N rows off top AND bottom. Geometry changes push new AV
     * info to the frontend. */
    bool        crop_hoverscan;
    uint8_t     crop_voverscan;       /* 0..24, always even */

    /* Paddle tuning (applied when a port is in DEV_PADDLE mode).
     * `paddle_sensitivity` 1..10 scales the analog-stick axis before the
     * charge-time map; 5 is neutral (no scale). Higher = reaches full
     * paddle sweep with less stick movement. `paddle_deadzone_pct` 0..30
     * is a dead zone at the centre of the stick, below which the axis
     * is treated as exactly centred. */
    uint8_t     paddle_sensitivity;
    uint8_t     paddle_deadzone_pct;
} sys;

/* Nominal fps / audio rate per region. Real-hardware rates are irrational
 * (NTSC colour clock / 4 / scanline, etc.); frontends resample so the
 * exact value matters less than being close and stable. */
static double region_fps(enum tia_region r)
{
    switch (r) {
    case TIA_REGION_PAL:   return 50.0;
    case TIA_REGION_SECAM: return 50.0;
    case TIA_REGION_PAL60: return 60.0;
    case TIA_REGION_NTSC:
    default:               return 60.0;
    }
}
static double region_sample_rate(enum tia_region r)
{
    /* TIA colour-clock / 114 per sample. NTSC 3.579545 MHz → 31400 Hz,
     * PAL 3.546894 MHz → 31113 Hz (rounded to 31200). */
    switch (r) {
    case TIA_REGION_PAL:
    case TIA_REGION_SECAM: return 31200.0;
    case TIA_REGION_PAL60:
    case TIA_REGION_NTSC:
    default:               return 31400.0;
    }
}
static uint16_t region_frame_height(enum tia_region r)
{
    return (r == TIA_REGION_PAL || r == TIA_REGION_SECAM)
           ? FRAME_HEIGHT_PAL : FRAME_HEIGHT_NTSC;
}
static uint16_t region_window_top(enum tia_region r)
{
    return (r == TIA_REGION_PAL || r == TIA_REGION_SECAM)
           ? WINDOW_TOP_PAL : WINDOW_TOP_NTSC;
}

static void fallback_log(enum retro_log_level level, const char *fmt, ...)
{
    va_list va;
    (void)level;
    va_start(va, fmt);
    vfprintf(stderr, fmt, va);
    va_end(va);
}

unsigned retro_api_version(void) { return RETRO_API_VERSION; }

/* Core options. Using v2 layout so the frontend can show descriptions;
 * for older frontends we fall back to the legacy SET_VARIABLES path. */
static const struct retro_core_option_v2_definition core_options_v2[] = {
    {
        "tia_region", "Region", NULL,
        "Console region. Selects palette, frame rate, and audio sample "
        "rate. Auto detects NTSC vs PAL from the game's scanline count "
        "over the first few frames.",
        NULL, NULL,
        {
            { "auto",  "Auto" },
            { "ntsc",  "NTSC" },
            { "pal",   "PAL"  },
            { "pal60", "PAL60" },
            { "secam", "SECAM" },
            { NULL, NULL }
        },
        "auto"
    },
    {
        "tia_palette", "Palette", NULL,
        "Colour palette variant. \"standard\" is the default colour set "
        "we ship; \"z26\" is an alternate set originally from the z26 "
        "emulator, closer to the classic TIA colour poster and preferred "
        "by some users.",
        NULL, NULL,
        {
            { "standard", "Standard" },
            { "z26",      "z26"      },
            { NULL, NULL }
        },
        "standard"
    },
    {
        "tia_left_diff", "Left Difficulty (initial)", NULL,
        "Starting position for the left difficulty switch. Runtime "
        "toggles (L/L2 shoulder buttons) still work on top.",
        NULL, NULL,
        {
            { "a", "A" },
            { "b", "B" },
            { NULL, NULL }
        },
        "a"
    },
    {
        "tia_right_diff", "Right Difficulty (initial)", NULL,
        "Starting position for the right difficulty switch. See "
        "\"Left Difficulty\" — same semantics for the right switch.",
        NULL, NULL,
        {
            { "a", "A" },
            { "b", "B" },
            { NULL, NULL }
        },
        "a"
    },
    {
        "tia_color", "TV Type (initial)", NULL,
        "Starting position for the colour / black-and-white TV type "
        "switch. Runtime toggles (L3/R3) still work on top.",
        NULL, NULL,
        {
            { "color", "Color" },
            { "bw",    "Black & White" },
            { NULL, NULL }
        },
        "color"
    },
    {
        "tia_ram_init", "Power-on RAM", NULL,
        "How the console's 128 bytes of RAM come up at cold boot. "
        "\"Hardware-like\" fills it with fresh pseudo-random noise on every "
        "boot, like a real 2600 — a few games read uninitialised RAM, so "
        "their colours or contents vary from boot to boot. \"Zeroed\" clears "
        "it to match reference emulators for deterministic, directly "
        "comparable output.",
        NULL, NULL,
        {
            { "hardware", "Hardware-like" },
            { "zero",     "Zeroed" },
            { NULL, NULL }
        },
        "hardware"
    },
    {
        "tia_dc_block", "Audio DC blocking (high-pass)", NULL,
        "Remove the DC offset from the audio with a gentle ~20 Hz high-pass, "
        "modelling the coupling capacitor in the console's audio path (and the "
        "AC-coupled TV amp) -- i.e. the signal that actually left the console. "
        "Off outputs the raw unipolar TIA DAC, which carries a large "
        "signal-dependent DC offset (Pitfall! sits near 40% of full scale). "
        "Recommended on.",
        NULL, NULL,
        {
            { "on",  "On" },
            { "off", "Off" },
            { NULL, NULL }
        },
        "on"
    },
    {
        "tia_crop_hoverscan", "Crop horizontal overscan", NULL,
        "Trim 8 pixels from each side of the visible area, removing the "
        "leftmost and rightmost columns most 2600 games don't draw into. "
        "Produces a tighter 144×H output.",
        NULL, NULL,
        {
            { "off", "Off" },
            { "on",  "On" },
            { NULL, NULL }
        },
        "off"
    },
    {
        "tia_crop_voverscan", "Crop vertical overscan (rows)", NULL,
        "Trim N rows off the top and N rows off the bottom of the output "
        "frame, removing VBLANK padding that games don't render into.",
        NULL, NULL,
        {
            { "0",  "0" },  { "2",  "2" },  { "4",  "4" },  { "6",  "6" },
            { "8",  "8" },  { "10", "10" }, { "12", "12" }, { "14", "14" },
            { "16", "16" }, { "18", "18" }, { "20", "20" }, { "22", "22" },
            { "24", "24" },
            { NULL, NULL }
        },
        "0"
    },
    {
        "tia_paddle_sensitivity", "Paddle sensitivity", NULL,
        "Analog-stick gain for paddle controllers. 5 is neutral; higher "
        "values reach full paddle sweep with less stick travel.",
        NULL, NULL,
        {
            { "1", "1" }, { "2", "2" }, { "3", "3" }, { "4", "4" },
            { "5", "5 (default)" },
            { "6", "6" }, { "7", "7" }, { "8", "8" }, { "9", "9" },
            { "10", "10" },
            { NULL, NULL }
        },
        "5"
    },
    {
        "tia_paddle_deadzone", "Paddle deadzone (%)", NULL,
        "Analog-stick deadzone for paddle controllers. Values near the "
        "stick centre within this percentage are treated as exactly "
        "centred; useful for sticks that don't self-centre perfectly.",
        NULL, NULL,
        {
            { "0", "0% (off)" }, { "5", "5%" },  { "10", "10%" },
            { "15", "15%" }, { "20", "20%" }, { "25", "25%" }, { "30", "30%" },
            { NULL, NULL }
        },
        "0"
    },
    { NULL, NULL, NULL, NULL, NULL, NULL, {{0}}, NULL }
};
static const struct retro_core_options_v2 core_options_v2_struct = {
    NULL, (struct retro_core_option_v2_definition *)core_options_v2
};
/* Legacy fallback — same keys + value lists, flat format. */
static const struct retro_variable core_options_v0[] = {
    { "tia_region",     "Region; auto|ntsc|pal|pal60|secam" },
    { "tia_palette",    "Palette; standard|z26" },
    { "tia_left_diff",       "Left Difficulty (initial); b|a" },
    { "tia_right_diff",      "Right Difficulty (initial); b|a" },
    { "tia_color",           "TV Type (initial); color|bw" },
    { "tia_ram_init",        "Power-on RAM; hardware|zero" },
    { "tia_dc_block",        "Audio DC blocking (high-pass); on|off" },
    { "tia_crop_hoverscan",  "Crop horizontal overscan; off|on" },
    { "tia_crop_voverscan",  "Crop vertical overscan (rows); 0|2|4|6|8|10|12|14|16|18|20|22|24" },
    { "tia_paddle_sensitivity", "Paddle sensitivity; 1|2|3|4|5|6|7|8|9|10" },
    { "tia_paddle_deadzone",    "Paddle deadzone (%); 0|5|10|15|20|25|30" },
    { NULL, NULL }
};

void retro_set_environment(retro_environment_t cb)
{
    /* Port 0 advertises every 2600 controller type; port 1 omits the
     * single-port-only Driving controller (Indy 500 uses only P0). */
    static const struct retro_controller_description p0_ctrls[] = {
        { "Joystick", DEV_JOYPAD  },
        { "Paddles",  DEV_PADDLE  },
        { "Driving",  DEV_DRIVING },
        { "Keypad",   DEV_KEYPAD  },
    };
    static const struct retro_controller_description p1_ctrls[] = {
        { "Joystick", DEV_JOYPAD  },
        { "Paddles",  DEV_PADDLE  },
        { "Keypad",   DEV_KEYPAD  },
    };
    static const struct retro_controller_info ports[] = {
        { p0_ctrls, 4 },
        { p1_ctrls, 3 },
        { NULL, 0 },
    };

    environ_cb = cb;

    if (cb(RETRO_ENVIRONMENT_GET_LOG_INTERFACE, &logging))
        log_cb = logging.log;
    else
        log_cb = fallback_log;

    cb(RETRO_ENVIRONMENT_SET_CONTROLLER_INFO, (void *)ports);

    {
        unsigned version = 0;
        if (cb(RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION, &version) &&
            version >= 2) {
            cb(RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2,
               (void *)&core_options_v2_struct);
        } else {
            cb(RETRO_ENVIRONMENT_SET_VARIABLES, (void *)core_options_v0);
        }
    }
}

/* Parse the "tia_region" core option and apply it. Returns true if the
 * active region changed (so the caller can push new AV info). */
static bool apply_region_option(void)
{
    struct retro_variable var;
    int new_setting = sys.region_setting;
    enum tia_region new_active = sys.active_region;

    var.key = "tia_region";
    var.value = NULL;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) &&
        var.value) {
        if      (!strcmp(var.value, "ntsc"))  new_setting = TIA_REGION_NTSC;
        else if (!strcmp(var.value, "pal"))   new_setting = TIA_REGION_PAL;
        else if (!strcmp(var.value, "pal60")) new_setting = TIA_REGION_PAL60;
        else if (!strcmp(var.value, "secam")) new_setting = TIA_REGION_SECAM;
        else                                  new_setting = -1;  /* auto */
    }

    if (new_setting < 0) {
        /* Auto: use whatever the TIA has detected (or NTSC pre-detect). */
        new_active = sys.tia.detect_locked
                   ? sys.tia.detected_region : TIA_REGION_NTSC;
    } else {
        new_active = (enum tia_region)new_setting;
    }

    sys.region_setting = new_setting;
    if (new_active != sys.active_region) {
        sys.active_region = new_active;
        if (sys.loaded) tia_set_region(&sys.tia, new_active);
        return true;
    }
    return false;
}

/* Parse the "tia_palette" core option and apply it. Palette changes don't
 * affect timing, so no AV-info refresh is needed. */
static void apply_palette_option(void)
{
    struct retro_variable var;
    enum tia_palette_variant v = TIA_PALETTE_STANDARD;
    var.key = "tia_palette";
    var.value = NULL;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) &&
        var.value && !strcmp(var.value, "z26"))
        v = TIA_PALETTE_Z26;
    if (sys.loaded) tia_set_palette_variant(&sys.tia, v);
    else            sys.tia.palette_variant = v;
}

/* Read a string option. Returns true if the value is exactly `true_val`,
 * false if unset or anything else. */
static bool get_bool_option(const char *key, const char *true_val)
{
    struct retro_variable var;
    var.key = key;
    var.value = NULL;
    if (!environ_cb || !environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) ||
        !var.value)
        return false;
    return strcmp(var.value, true_val) == 0;
}

/* Per-cold-boot entropy seed for the hardware-like RAM init. time() varies
 * between launches; a per-call counter de-dupes boots inside the same second
 * (rapid reload). Only needs to differ boot to boot, not be crypto-grade. */
static uint32_t riot_entropy_seed(void)
{
    static uint32_t counter = 0u;
    counter++;
    /* time() differs across launches; counter de-dupes boots within one
     * loaded core; the address term (ASLR) de-dupes same-second boots even
     * when a fresh process resets counter. */
    return (uint32_t)time(NULL) * 2654435761u
         + counter * 40503u
         + (uint32_t)(size_t)(void *)&counter;
}

/* Parse the paddle tuning options and apply them. No AV refresh needed. */
static void apply_paddle_options(void)
{
    struct retro_variable var;
    int n;

    var.key = "tia_paddle_sensitivity";
    var.value = NULL;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) &&
        var.value) {
        n = atoi(var.value);
        if (n < 1) n = 1;
        if (n > 10) n = 10;
        sys.paddle_sensitivity = (uint8_t)n;
    }

    var.key = "tia_paddle_deadzone";
    var.value = NULL;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) &&
        var.value) {
        n = atoi(var.value);
        if (n < 0) n = 0;
        if (n > 30) n = 30;
        sys.paddle_deadzone_pct = (uint8_t)n;
    }
}

/* Parse the two crop options and apply them. Returns true if either
 * changed (caller pushes new AV info so the frontend picks up the new
 * base width/height). */
static bool apply_crop_options(void)
{
    struct retro_variable var;
    bool new_hover = sys.crop_hoverscan;
    uint8_t new_vover = sys.crop_voverscan;

    var.key = "tia_crop_hoverscan";
    var.value = NULL;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) &&
        var.value)
        new_hover = !strcmp(var.value, "on");

    var.key = "tia_crop_voverscan";
    var.value = NULL;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &var) &&
        var.value) {
        int n = atoi(var.value);
        if (n < 0) n = 0;
        if (n > 24) n = 24;
        new_vover = (uint8_t)n;
    }

    if (new_hover != sys.crop_hoverscan || new_vover != sys.crop_voverscan) {
        sys.crop_hoverscan = new_hover;
        sys.crop_voverscan = new_vover;
        return true;
    }
    return false;
}

/* Apply the difficulty + color-switch initial-position options. Called
 * at load time and on retro_reset; runtime button toggles continue to
 * work on top. Defaults (when the frontend doesn't provide values) are
 * B / B / Color. */
static void apply_switch_initial_options(void)
{
    sys.sw_left_diff_a  = get_bool_option("tia_left_diff",  "a");
    sys.sw_right_diff_a = get_bool_option("tia_right_diff", "a");
    sys.sw_color        = !get_bool_option("tia_color",     "bw");
}

/* Audio DC-block: a first-order high-pass (y = alpha*(y[-1] + x - x[-1]))
 * modelling the coupling capacitor that sits between the TIA DAC and the RF
 * modulator on real hardware. On by default. State persists across frames;
 * reset it on load/reset (see reset_dc_block). */
static int   dc_block_on = 1;
static float dc_block_alpha = 0.996f;   /* recomputed from the sample rate */
static float dc_block_x1 = 0.f, dc_block_y1 = 0.f;

static void apply_audio_options(void)
{
    double fs = region_sample_rate(sys.active_region);
    /* 10 Hz cutoff: below the audible floor and below the TIA's lowest tones
     * (~30 Hz), so it removes only DC/subsonic while leaving audio untouched. */
    const double fc = 10.0;
    dc_block_on    = !get_bool_option("tia_dc_block", "off");   /* default on */
    dc_block_alpha = (float)(1.0 / (1.0 + 2.0 * 3.14159265358979 * fc / fs));
}

static void reset_dc_block(void)
{
    dc_block_x1 = dc_block_y1 = 0.f;
}

void retro_set_video_refresh(retro_video_refresh_t cb)       { video_cb = cb; }
void retro_set_audio_sample(retro_audio_sample_t cb)         { audio_cb = cb; }
void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) { audio_batch_cb = cb; }
void retro_set_input_poll(retro_input_poll_t cb)             { input_poll_cb = cb; }
void retro_set_input_state(retro_input_state_t cb)           { input_state_cb = cb; }

void retro_init(void)
{
    memset(&sys, 0, sizeof(sys));
    sys.port_device[0] = DEV_JOYPAD;
    sys.port_device[1] = DEV_JOYPAD;
    /* Factory defaults for the console toggles: Color on, both
     * difficulty switches B. Players flip them with L/L2/L3/R/R2/R3. */
    sys.sw_color        = true;
    sys.sw_left_diff_a  = false;
    sys.sw_right_diff_a = false;
    /* Default to auto-detect region; pre-detect we show NTSC timing so the
     * frontend has sensible AV info before the first frame completes. */
    sys.region_setting = -1;
    sys.active_region  = TIA_REGION_NTSC;
    /* Paddle tuning defaults: neutral sensitivity (5), no deadzone. */
    sys.paddle_sensitivity = 5;
    sys.paddle_deadzone_pct = 0;
    /* Default power-on RAM: hardware-like (per-boot random). The comparison
     * harness and tests opt into "zero" via the tia_ram_init core option. */
    sys.ram_init_hardware = true;
}
void retro_deinit(void) { }

void retro_get_system_info(struct retro_system_info *info)
{
    memset(info, 0, sizeof(*info));
    info->library_name     = "tia";
    info->library_version  = CORE_VERSION;
    info->need_fullpath    = false;
    info->valid_extensions = "a26|bin";
    info->block_extract    = false;
}

void retro_get_system_av_info(struct retro_system_av_info *info)
{
    uint16_t w = FRAME_WIDTH;
    uint16_t h = region_frame_height(sys.active_region);
    if (sys.crop_hoverscan) w -= 2u * HOVERSCAN_TRIM;
    if (sys.crop_voverscan) h -= (uint16_t)(2u * sys.crop_voverscan);
    memset(info, 0, sizeof(*info));
    info->geometry.base_width   = w;
    info->geometry.base_height  = h;
    info->geometry.max_width    = FRAME_WIDTH;
    info->geometry.max_height   = TIA_MAX_SCANLINES;
    info->geometry.aspect_ratio = 4.0f / 3.0f;
    info->timing.fps            = region_fps(sys.active_region);
    info->timing.sample_rate    = region_sample_rate(sys.active_region);
}

void retro_set_controller_port_device(unsigned port, unsigned device)
{
    if (port < 2) sys.port_device[port] = device;
}

void retro_reset(void)
{
    if (!sys.loaded) return;
    /* Reset the console-switch latches to factory defaults, then re-apply
     * the initial-position core options so a user who picked "A" for a
     * difficulty sees it honoured after every reset. */
    sys.sw_color        = true;
    sys.sw_left_diff_a  = false;
    sys.sw_right_diff_a = false;
    apply_switch_initial_options();
    apply_audio_options();
    reset_dc_block();
    tia_reset(&sys.tia);
    riot_reset(&sys.riot);
    cpu_reset(&sys.cpu);
}

static int16_t js(unsigned port, unsigned id)
{
    return input_state_cb(port, RETRO_DEVICE_JOYPAD, 0, id);
}

static int16_t ax(unsigned port, unsigned idx, unsigned id)
{
    return input_state_cb(port, RETRO_DEVICE_ANALOG, idx, id);
}

/* Set `pa` nibble for port `port` (high nibble if port==0, low if port==1)
 * from a joystick's direction bits + fire. 4 bits active-low. */
static uint8_t pa_bits_joypad(uint8_t pa, unsigned port)
{
    unsigned shift = (port == 0) ? 4 : 0;
    if (js(port, RETRO_DEVICE_ID_JOYPAD_RIGHT)) pa &= (uint8_t)~(0x08u << shift);
    if (js(port, RETRO_DEVICE_ID_JOYPAD_LEFT))  pa &= (uint8_t)~(0x04u << shift);
    if (js(port, RETRO_DEVICE_ID_JOYPAD_DOWN))  pa &= (uint8_t)~(0x02u << shift);
    if (js(port, RETRO_DEVICE_ID_JOYPAD_UP))    pa &= (uint8_t)~(0x01u << shift);
    return pa;
}

/* Paddle mode: two paddles per port share SWCHA's direction bits for their
 * fire triggers. Layout per nibble: paddle-A trigger = bit 3 of nibble
 * (where joystick RIGHT lived), paddle-B trigger = bit 2 (joystick LEFT).
 * Bits 1,0 (DOWN/UP) stay high. Map RETRO A button to paddle-A fire and
 * RETRO B button to paddle-B fire so the common case — one-paddle games
 * like Kaboom — works from either A or B. */
static uint8_t pa_bits_paddle(uint8_t pa, unsigned port)
{
    unsigned shift = (port == 0) ? 4 : 0;
    int fire_a = js(port, RETRO_DEVICE_ID_JOYPAD_A)
              || js(port, RETRO_DEVICE_ID_JOYPAD_R);
    int fire_b = js(port, RETRO_DEVICE_ID_JOYPAD_B)
              || js(port, RETRO_DEVICE_ID_JOYPAD_L);
    if (fire_a) pa &= (uint8_t)~(0x08u << shift);
    if (fire_b) pa &= (uint8_t)~(0x04u << shift);
    return pa;
}

/* Convert a libretro analog axis [-32768, 32767] to a paddle charge-target
 * in TIA color clocks. 0 resistance (fully left) yields a 0-clock charge
 * (bit 7 flips high immediately). Max resistance (fully right) takes
 * PADDLE_CHARGE_MAX_CLOCKS clocks.
 *
 * Applies the two user-configurable tuning options:
 *   paddle_deadzone_pct — snap near-centre values to 0 (eliminates jitter
 *       from analog sticks that don't self-centre perfectly).
 *   paddle_sensitivity — linear gain on the axis (5 = 1×; 10 = 2×).
 *       Higher values reach full paddle sweep with less stick travel. */
static uint16_t paddle_charge_from_axis(int16_t axis)
{
    int a = axis;
    int dz, v;
    unsigned long scaled;
    /* Apply deadzone first (on the pre-scale axis). */
    dz = (int)sys.paddle_deadzone_pct * 32768 / 100;
    if (a > -dz && a < dz) a = 0;
    /* Apply sensitivity. 5 is neutral. */
    a = a * (int)sys.paddle_sensitivity / 5;
    if (a >  32767) a =  32767;
    if (a < -32768) a = -32768;
    v = a + 32768;                  /* 0..65535 */
    scaled = (unsigned long)v * PADDLE_CHARGE_MAX_CLOCKS / 65536ul;
    if (scaled > 0xFFFF) scaled = 0xFFFF;
    return (uint16_t)scaled;
}

/* Driving controller (Indy 500, P0 only). Libretro analog X is mapped to
 * a continuous rotation, and SWCHA bits 5:4 are set to the Gray code of
 * the current step. The game infers direction from bit-pair transitions,
 * not from absolute position. */
static uint8_t pa_bits_driving(uint8_t pa)
{
    int16_t axis = ax(0, RETRO_DEVICE_INDEX_ANALOG_LEFT, RETRO_DEVICE_ID_ANALOG_X);
    /* 4 Gray-code steps per full libretro sweep. Multiply by a larger
     * factor to get one step per small wheel twitch; 64 here means the
     * full [-32768, 32767] range advances the wheel through 128 clicks,
     * which feels reasonable for Indy 500's steering sensitivity. */
    unsigned step = ((unsigned)(axis + 32768) / 512u) & 3u;
    uint8_t gray  = driving_gray[step];     /* bits 0:1 = gray pair */
    /* Drop the current bits 4,5 and overlay gray pair there. */
    pa &= (uint8_t)~0x30u;
    pa |= (uint8_t)((gray & 1u) << 4) | (uint8_t)(((gray >> 1) & 1u) << 5);
    return pa;
}

/* Notify the frontend's OSD that a console toggle changed. Prefers the
 * richer _EXT variant; falls back to the legacy one so old RetroArch
 * builds still see something. */
static void notify_switch_change(const char *text)
{
    struct retro_message_ext ext;
    struct retro_message     legacy;
    ext.msg      = text;
    ext.duration = 2000;                 /* ms */
    ext.priority = 1;
    ext.level    = RETRO_LOG_INFO;
    ext.target   = RETRO_MESSAGE_TARGET_OSD;
    ext.type     = RETRO_MESSAGE_TYPE_NOTIFICATION;
    ext.progress = -1;
    if (environ_cb && environ_cb(RETRO_ENVIRONMENT_SET_MESSAGE_EXT, &ext))
        return;
    legacy.msg    = text;
    legacy.frames = 120;                 /* ~2 s at 60 Hz */
    if (environ_cb) environ_cb(RETRO_ENVIRONMENT_SET_MESSAGE, &legacy);
}

/* Flip a switch latch, but only notify when the requested position differs
 * from the current one — mirrors physical-switch semantics (pushing the
 * lever up when it's already up is a no-op). Pass msg==NULL to toggle
 * silently (the TV-type change is visible on screen and doesn't need a
 * notification). */
static void switch_set(bool *latch, bool value, const char *msg)
{
    if (*latch == value) return;
    *latch = value;
    if (msg) notify_switch_change(msg);
}

/* --- Keypad controller ---
 *
 * The Atari keypad is a 12-button 4-row × 3-column matrix:
 *    1  2  3
 *    4  5  6
 *    7  8  9
 *    *  0  #
 *
 * Row drivers are on SWCHA's output bits (the same bits that drive the
 * joystick direction pins). Column sense lines are on INPT0-3 / INPT4-5:
 *   Port 0 (left):  col 0 → INPT0,  col 1 → INPT1,  col 2 → INPT4
 *   Port 1 (right): col 0 → INPT2,  col 1 → INPT3,  col 2 → INPT5
 *
 * SWCHA output bits, per port, are (from row 0 to row 3):
 *   Port 0 rows: bit 7, bit 6, bit 5, bit 4   (high nibble)
 *   Port 1 rows: bit 3, bit 2, bit 1, bit 0   (low nibble)
 * When a row driver is pulled LOW (output 0) AND a button in that row is
 * pressed, that button's column pin reads LOW. Otherwise column reads HIGH.
 *
 * Retropad binding (our design; 12 buttons total, grouping the D-pad on
 * keypad 2/4/6/8 — the "arrow keys" of a phone keypad — so center button
 * "5" sits naturally on the primary action button):
 *   Keypad  Retropad        Column Row
 *     1     Y               0      0
 *     2     UP              1      0
 *     3     L               2      0
 *     4     LEFT            0      1
 *     5     A               1      1
 *     6     RIGHT           2      1
 *     7     X               0      2
 *     8     DOWN            1      2
 *     9     L2              2      2
 *     *     L3              0      3
 *     0     B               1      3
 *     #     R               2      3
 * START remains free as the console Reset button (so games like Star
 * Raiders can be (re)started from the keypad overlay without switching
 * back to the joystick overlay). SELECT, R2, R3 are unbound on the
 * keypad overlay. */
#define KP_1  0
#define KP_2  1
#define KP_3  2
#define KP_4  3
#define KP_5  4
#define KP_6  5
#define KP_7  6
#define KP_8  7
#define KP_9  8
#define KP_ST 9   /* * */
#define KP_0  10
#define KP_HS 11  /* # */

static const struct {
    uint8_t retro_id;
    uint8_t bit;
} keypad_map[12] = {
    { RETRO_DEVICE_ID_JOYPAD_Y,     KP_1  },
    { RETRO_DEVICE_ID_JOYPAD_UP,    KP_2  },
    { RETRO_DEVICE_ID_JOYPAD_L,     KP_3  },
    { RETRO_DEVICE_ID_JOYPAD_LEFT,  KP_4  },
    { RETRO_DEVICE_ID_JOYPAD_A,     KP_5  },
    { RETRO_DEVICE_ID_JOYPAD_RIGHT, KP_6  },
    { RETRO_DEVICE_ID_JOYPAD_X,     KP_7  },
    { RETRO_DEVICE_ID_JOYPAD_DOWN,  KP_8  },
    { RETRO_DEVICE_ID_JOYPAD_L2,    KP_9  },
    { RETRO_DEVICE_ID_JOYPAD_L3,    KP_ST },
    { RETRO_DEVICE_ID_JOYPAD_B,     KP_0  },
    { RETRO_DEVICE_ID_JOYPAD_R,     KP_HS },
};

/* Which column contains each key (indexed by KP_*). */
static const uint8_t kp_col[12] = {
    0, 1, 2,  /* 1, 2, 3 */
    0, 1, 2,  /* 4, 5, 6 */
    0, 1, 2,  /* 7, 8, 9 */
    0, 1, 2,  /* *, 0, # */
};
/* Which row contains each key (indexed by KP_*). */
static const uint8_t kp_row[12] = {
    0, 0, 0,
    1, 1, 1,
    2, 2, 2,
    3, 3, 3,
};

/* Update INPT bits for any keypad-mode port, based on current SWCHA
 * output state + keypad button state. Called from riot_write's pa_changed
 * callback whenever the CPU strobes SWCHA or changes its DDR, and also
 * directly from poll_inputs (once per frame) to seed the initial state. */
static void keypad_update(void)
{
    unsigned p;
    uint8_t  pa_effective;
    /* Effective Port A pin state: bits with DDR=output reflect pa_out;
     * bits with DDR=input float high (1). */
    pa_effective = (uint8_t)((sys.riot.pa_out & sys.riot.pa_ddr)
                 | (uint8_t)~sys.riot.pa_ddr);

    for (p = 0; p < 2; p++) {
        uint8_t  col_inpt[3];   /* col0, col1, col2: default HIGH (not pressed) */
        unsigned col;
        int      key;
        uint8_t  row_mask[4];   /* 1 if that row's driver is pulled LOW */
        int      r;

        if (sys.port_device[p] != DEV_KEYPAD) continue;

        col_inpt[0] = 0x80;
        col_inpt[1] = 0x80;
        col_inpt[2] = 0x80;

        /* Row r (0..3) is driven by DB-9 Pins One through Four.
         * Pin One = UP   = SWCHA bit 4 (port 0) / bit 0 (port 1)
         * Pin Two = DOWN = bit 5 / bit 1
         * Pin Three = LEFT = bit 6 / bit 2
         * Pin Four = RIGHT = bit 7 / bit 3
         * So row r maps to bit (4+r) for port 0, bit r for port 1. */
        for (r = 0; r < 4; r++) {
            uint8_t bit_idx = (uint8_t)((p ? 0 : 4) + r);
            uint8_t bit = (uint8_t)(1u << bit_idx);
            row_mask[r] = ((pa_effective & bit) == 0) ? 1 : 0;
        }

        for (key = 0; key < 12; key++) {
            if (!(sys.keypad_pressed[p] & (1u << key))) continue;
            if (!row_mask[kp_row[key]]) continue;
            col = kp_col[key];
            col_inpt[col] = 0x00;   /* column pulled LOW */
        }

        /* Map columns to INPT indices. */
        if (p == 0) {
            sys.tia.inpt[0] = col_inpt[0];
            sys.tia.inpt[1] = col_inpt[1];
            sys.tia.inpt[4] = col_inpt[2];
        } else {
            sys.tia.inpt[2] = col_inpt[0];
            sys.tia.inpt[3] = col_inpt[1];
            sys.tia.inpt[5] = col_inpt[2];
        }
    }
}

static void poll_inputs(void)
{
    uint8_t pa = 0xFF;
    uint8_t pb;
    unsigned p;

    /* SWCHA: each port contributes a nibble. High nibble (bits 4-7) = port 0,
     * low nibble (bits 0-3) = port 1. Active-low throughout. */
    for (p = 0; p < 2; p++) {
        switch (sys.port_device[p]) {
        case DEV_PADDLE:
            pa = pa_bits_paddle(pa, p);
            break;
        case DEV_DRIVING:
            /* Driving is P0-only. On port 1 it falls back to joypad. */
            if (p == 0) pa = pa_bits_driving(pa);
            else        pa = pa_bits_joypad(pa, p);
            break;
        case DEV_KEYPAD:
            /* Keypad leaves SWCHA high nibble (port 0) / low nibble (port 1)
             * untouched — the console drives rows by writing SWCHA, and the
             * keypad reports columns via INPT, not via SWCHA reads. The
             * per-port nibble here stays active-high (no movement bits). */
            break;
        case DEV_JOYPAD:
        default:
            pa = pa_bits_joypad(pa, p);
            break;
        }
    }
    sys.riot.pa_in = pa;

    /* SWCHB: console switches. Read from port 0 regardless of active
     * controller — these are on the console, not the controller.
     *   bit 0: Reset   (active-low; 0 = pressed)
     *   bit 1: Select  (active-low)
     *   bit 2: unused, reads as 1
     *   bit 3: Color/B&W           (1 = Color)
     *   bits 4-5: unused, read as 1
     *   bit 6: Left Difficulty     (1 = A)
     *   bit 7: Right Difficulty    (1 = A)
     *
     * The three toggle switches are state machines driven by button edges.
     * Button → switch assignment follows the common 2600 touchscreen overlay
     * (common-overlays/gamepads/Named_Overlays/Atari - 2600.cfg): each switch
     * gets an adjacent row-pair (L/R for left-diff, L2/R2 for right-diff,
     * L3/R3 for TV type), upper = A, lower = B.
     *
     * Skip when port 0 is in keypad mode — L, R, L2, L3 are keypad keys
     * in that configuration and pressing them should NOT toggle the console
     * switches. Users can switch back to the joystick overlay to reach the
     * toggles, or use a physical gamepad whose shoulder buttons aren't
     * consumed by the keypad overlay. */
    if (sys.port_device[0] != DEV_KEYPAD)
    {
        uint8_t edge_now = 0;
        if (js(0, RETRO_DEVICE_ID_JOYPAD_L))  edge_now |= 0x01;
        if (js(0, RETRO_DEVICE_ID_JOYPAD_R))  edge_now |= 0x02;
        if (js(0, RETRO_DEVICE_ID_JOYPAD_L2)) edge_now |= 0x04;
        if (js(0, RETRO_DEVICE_ID_JOYPAD_R2)) edge_now |= 0x08;
        if (js(0, RETRO_DEVICE_ID_JOYPAD_L3)) edge_now |= 0x10;
        if (js(0, RETRO_DEVICE_ID_JOYPAD_R3)) edge_now |= 0x20;
        /* Rising-edge only, so holding doesn't chatter the latch. On an
         * actual state change the OSD notifies the user so they see what
         * they just toggled (console switches are easy to hit by accident
         * and hard to diagnose otherwise). A/B are just the switch
         * positions; their meaning is game-specific (e.g. A is *harder*
         * in Adventure but easier in Combat). */
        {
            uint8_t rising = (uint8_t)(edge_now & ~sys.sw_prev);
            if (rising & 0x01) switch_set(&sys.sw_left_diff_a,  true,
                                "Left Difficulty: A");
            if (rising & 0x02) switch_set(&sys.sw_left_diff_a,  false,
                                "Left Difficulty: B");
            if (rising & 0x04) switch_set(&sys.sw_right_diff_a, true,
                                "Right Difficulty: A");
            if (rising & 0x08) switch_set(&sys.sw_right_diff_a, false,
                                "Right Difficulty: B");
            if (rising & 0x10) switch_set(&sys.sw_color,        true,  NULL);
            if (rising & 0x20) switch_set(&sys.sw_color,        false, NULL);
        }
        sys.sw_prev = edge_now;
    }
    pb = 0x3F;                                          /* unused bits high */
    if (js(0, RETRO_DEVICE_ID_JOYPAD_START))  pb &= (uint8_t)~0x01;
    if (js(0, RETRO_DEVICE_ID_JOYPAD_SELECT)) pb &= (uint8_t)~0x02;
    if (!sys.sw_color)       pb &= (uint8_t)~0x08;
    if (!sys.sw_left_diff_a)  pb |= 0x40;
    if (!sys.sw_right_diff_a) pb |= 0x80;
    sys.riot.pb_in = pb;

    /* Read retropad → keypad button state for any keypad-mode port. The
     * actual INPT bits get computed by keypad_update() after we finish
     * updating the pressed-key bitmap, and again whenever the CPU writes
     * SWCHA / SWACNT (via the riot pa_changed callback). */
    for (p = 0; p < 2; p++) {
        if (sys.port_device[p] != DEV_KEYPAD) { sys.keypad_pressed[p] = 0; continue; }
        {
            uint16_t m = 0;
            int      k;
            for (k = 0; k < 12; k++)
                if (js(p, keypad_map[k].retro_id))
                    m |= (uint16_t)(1u << keypad_map[k].bit);
            sys.keypad_pressed[p] = m;
        }
    }

    /* INPT4/5: joystick/driving fire buttons (bit 7 only; rest are 0).
     * Paddles don't use INPT4/5 (their triggers are on SWCHA). Keypad
     * mode uses INPT4/5 as its column-2 sense line; that's set below by
     * keypad_update(). */
    for (p = 0; p < 2; p++) {
        unsigned idx = 4 + p;
        switch (sys.port_device[p]) {
        case DEV_PADDLE:
            sys.tia.inpt[idx] = 0x80;       /* unused in paddle mode */
            break;
        case DEV_DRIVING:
            sys.tia.inpt[idx] = (p == 0 && js(p, RETRO_DEVICE_ID_JOYPAD_B))
                              ? 0x00 : 0x80;
            break;
        case DEV_KEYPAD:
            /* set by keypad_update() below */
            break;
        case DEV_JOYPAD:
        default:
            sys.tia.inpt[idx] = js(p, RETRO_DEVICE_ID_JOYPAD_B) ? 0x00 : 0x80;
            break;
        }
    }

    /* Compute keypad INPT bits with the freshly-polled button state. */
    keypad_update();

    /* INPT0-3: paddle potentiometer capacitor dumps. Each port contributes
     * two paddles (A = LEFT stick X, B = RIGHT stick X) when in paddle
     * mode; otherwise the charge target is 0 so bit 7 stays high. */
    {
        unsigned slot = 0;
        for (p = 0; p < 2; p++) {
            if (sys.port_device[p] == DEV_PADDLE) {
                int16_t a_axis = ax(p, RETRO_DEVICE_INDEX_ANALOG_LEFT,
                                       RETRO_DEVICE_ID_ANALOG_X);
                int16_t b_axis = ax(p, RETRO_DEVICE_INDEX_ANALOG_RIGHT,
                                       RETRO_DEVICE_ID_ANALOG_X);
                sys.tia.paddle_charge_max[slot + 0] = paddle_charge_from_axis(a_axis);
                sys.tia.paddle_charge_max[slot + 1] = paddle_charge_from_axis(b_axis);
            } else {
                sys.tia.paddle_charge_max[slot + 0] = 0;
                sys.tia.paddle_charge_max[slot + 1] = 0;
            }
            slot += 2;
        }
    }
}

/* Push updated fps/sample_rate to the frontend. Called when the region
 * changes (either user toggled the option, or auto-detect just locked). */
static void push_av_info(void)
{
    struct retro_system_av_info info;
    retro_get_system_av_info(&info);
    if (environ_cb)
        environ_cb(RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO, &info);
}

void retro_run(void)
{
    int cycles = 0;
    bool update = false;
    if (!sys.loaded) return;

    /* Pick up option changes the user made mid-run. */
    if (environ_cb &&
        environ_cb(RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE, &update) && update) {
        bool geom_changed = false;
        if (apply_region_option()) geom_changed = true;
        if (apply_crop_options())  geom_changed = true;
        if (geom_changed) push_av_info();
        apply_palette_option();
        apply_paddle_options();
        apply_audio_options();
    }
    /* If we're in auto mode and detection just locked this frame, apply. */
    if (sys.region_setting < 0 && sys.tia.detect_locked &&
        sys.active_region != sys.tia.detected_region) {
        sys.active_region = sys.tia.detected_region;
        tia_set_region(&sys.tia, sys.active_region);
        push_av_info();
    }

    input_poll_cb();
    poll_inputs();

    while (!sys.tia.frame_ready && !sys.cpu.halted && cycles < MAX_CYCLES_PER_RUN) {
        cpu_step(&sys.cpu);
        cycles++;
    }
    sys.tia.frame_ready = false;

    {
        /* Fixed window: start at the region's constant top scanline and ship a
         * constant height. The game's picture lands wherever its VBLANK timing
         * puts it within the window. */
        uint16_t offset  = region_window_top(sys.active_region);
        uint16_t height  = region_frame_height(sys.active_region);
        uint16_t width   = FRAME_WIDTH;
        uint16_t x_off   = 0;
        if (offset + height > TIA_MAX_SCANLINES)
            height = (uint16_t)(TIA_MAX_SCANLINES - offset);
        /* Apply user-configured overscan crop. hoverscan shifts the row
         * pointer right by HOVERSCAN_TRIM pixels and narrows width;
         * voverscan shifts offset down by N rows and shortens height by 2N. */
        if (sys.crop_hoverscan) {
            x_off = HOVERSCAN_TRIM;
            width = (uint16_t)(FRAME_WIDTH - 2u * HOVERSCAN_TRIM);
        }
        if (sys.crop_voverscan) {
            uint16_t v = sys.crop_voverscan;
            offset = (uint16_t)(offset + v);
            height = (uint16_t)(height - 2u * v);
        }
        video_cb(sys.tia.fb + (size_t)offset * FRAME_WIDTH + x_off,
                 width, height,
                 FRAME_WIDTH * sizeof(uint32_t));
    }

    {
        int16_t mono[AUDIO_BUF_MONO];
        int16_t stereo[AUDIO_BUF_MONO * 2];
        size_t n = tia_drain_audio(&sys.tia, mono, AUDIO_BUF_MONO);
        size_t i;
        /* DC block: first-order high-pass, models the coupling capacitor in
         * the real console's audio path. Converts the unipolar DAC (0..+FS)
         * to a centred signal so the constant offset (e.g. Pitfall!'s ~40% FS)
         * doesn't reach full-range playback. */
        if (dc_block_on) {
            for (i = 0; i < n; i++) {
                float x = (float)mono[i];
                float y = dc_block_alpha * (dc_block_y1 + x - dc_block_x1);
                dc_block_x1 = x;
                dc_block_y1 = y;
                if (y > 32767.f) y = 32767.f;
                else if (y < -32768.f) y = -32768.f;
                mono[i] = (int16_t)y;
            }
        }
        for (i = 0; i < n; i++) {
            stereo[i * 2]     = mono[i];
            stereo[i * 2 + 1] = mono[i];
        }
        if (n > 0) audio_batch_cb(stereo, n);
    }
}

bool retro_load_game(const struct retro_game_info *info)
{
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_XRGB8888;

    if (!info || !info->data) return false;

    if (!environ_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) {
        log_cb(RETRO_LOG_ERROR, "XRGB8888 is not supported.\n");
        return false;
    }

    if (!cart_load(&sys.cart, info->data, info->size)) {
        log_cb(RETRO_LOG_ERROR, "Unsupported ROM size %zu (only 2048 or 4096).\n",
               info->size);
        return false;
    }

    {
        /* Button assignments follow the common 2600 touchscreen overlay
         * (common-overlays: "Atari - 2600.cfg"): each toggle switch gets a
         * dedicated row-pair of shoulder buttons. Console switches live on
         * port 0 only — they're on the console, not the controller. */
        static const struct retro_input_descriptor desc[] = {
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP,     "Up" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN,   "Down" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT,   "Left" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT,  "Right" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_B,      "Fire" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_START,  "Reset" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_SELECT, "Select" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L,      "Left Difficulty A" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_R,      "Left Difficulty B" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L2,     "Right Difficulty A" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_R2,     "Right Difficulty B" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_L3,     "Color" },
            { 0, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_R3,     "Black/White" },
            { 1, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_UP,     "Up" },
            { 1, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_DOWN,   "Down" },
            { 1, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_LEFT,   "Left" },
            { 1, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_RIGHT,  "Right" },
            { 1, RETRO_DEVICE_JOYPAD, 0, RETRO_DEVICE_ID_JOYPAD_B,      "Fire" },
            { 0, 0, 0, 0, NULL }
        };
        environ_cb(RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS, (void *)desc);
    }

    tia_init(&sys.tia);
    /* Apply region + palette options before the CPU starts: if the user
     * forced a region, auto-detect never runs and the correct palette is
     * in place from cold boot. Auto mode leaves active_region as NTSC
     * until the detector locks a few frames in. Palette variant must be
     * set first so the region switch picks the right table. */
    apply_palette_option();
    apply_region_option();
    apply_crop_options();
    apply_switch_initial_options();
    apply_paddle_options();
    apply_audio_options();
    reset_dc_block();
    sys.ram_init_hardware = !get_bool_option("tia_ram_init", "zero");
    tia_set_region(&sys.tia, sys.active_region);
    riot_init(&sys.riot);
    if (sys.ram_init_hardware)
        riot_randomize_ram(&sys.riot, riot_entropy_seed());
    sys.riot.pa_changed     = keypad_update;
    bus_init(&sys.bus, &sys.cpu, &sys.tia, &sys.riot, &sys.cart);
    {
        struct cpu_bus cb;
        cb.read  = bus_read;
        cb.write = bus_write;
        cb.ctx   = &sys.bus;
        cpu_init(&sys.cpu, cb);
    }
    sys.cart.cpu_cycles = &sys.cpu.cycles;
    cpu_reset(&sys.cpu);
    sys.loaded = true;
    return true;
}

bool retro_load_game_special(unsigned type, const struct retro_game_info *info, size_t num)
{
    (void)type; (void)info; (void)num;
    return false;
}

void retro_unload_game(void) { sys.loaded = false; }

/* PAL60 reports NTSC because its timing is NTSC (60 Hz); SECAM reports
 * PAL because SECAM consoles run at 50 Hz. */
unsigned retro_get_region(void)
{
    switch (sys.active_region) {
    case TIA_REGION_PAL:
    case TIA_REGION_SECAM: return RETRO_REGION_PAL;
    case TIA_REGION_NTSC:
    case TIA_REGION_PAL60:
    default:               return RETRO_REGION_NTSC;
    }
}

/* Cart serialise layout: full ROM (CART_MAX_SIZE) + 4-byte size + 1 mapper +
 * 1 bank + 4 e0_slots + CART_SC_RAM_SIZE sc_ram + 1 sc_enabled flag.
 * Serialising the full ROM at max size (not just sys.cart.size) keeps the
 * serialize_size constant, which libretro prefers — the frontend only calls
 * retro_serialize_size once, then reuses the buffer. */
/* DPC state: 8 tops + 8 bottoms + 16 counter bytes + 8 flags + 3 music
 * mode + 1 random + 8 audio_cycles + 8 frac_clocks = 60 bytes. */
#define CART_DPC_SER_BYTES 60
/* FA (256 RAM) + E7 (2048 RAM + 1 packed byte for lower-ram-flag | upper-bank) */
#define CART_FA_SER_BYTES  CART_FA_RAM_SIZE
#define CART_E7_SER_BYTES (CART_E7_RAM_SIZE + 1)
#define CART_SER_BYTES (CART_MAX_SIZE + 4 + 1 + 1 + 4 + CART_SC_RAM_SIZE + 1 + 1 \
                      + CART_DPC_SER_BYTES + CART_FA_SER_BYTES + CART_E7_SER_BYTES)
#define SYS_SER_BYTES  1                /* packed console-switch state */

size_t retro_serialize_size(void)
{
    return cpu_serialize_size()
         + riot_serialize_size()
         + tia_serialize_size()
         + CART_SER_BYTES
         + SYS_SER_BYTES;
}

bool retro_serialize(void *data, size_t size)
{
    uint8_t *p = (uint8_t *)data;
    size_t need = retro_serialize_size();
    if (size < need) return false;
    cpu_serialize(&sys.cpu, p);   p += cpu_serialize_size();
    riot_serialize(&sys.riot, p); p += riot_serialize_size();
    tia_serialize(&sys.tia, p);   p += tia_serialize_size();

    memcpy(p, sys.cart.data, CART_MAX_SIZE);     p += CART_MAX_SIZE;
    p[0] = (uint8_t)(sys.cart.size & 0xFF);
    p[1] = (uint8_t)((sys.cart.size >>  8) & 0xFF);
    p[2] = (uint8_t)((sys.cart.size >> 16) & 0xFF);
    p[3] = (uint8_t)((sys.cart.size >> 24) & 0xFF);
    p += 4;
    *p++ = sys.cart.mapper;
    *p++ = sys.cart.bank;
    memcpy(p, sys.cart.e0_slots, 4);             p += 4;
    memcpy(p, sys.cart.sc_ram, CART_SC_RAM_SIZE); p += CART_SC_RAM_SIZE;
    *p++ = sys.cart.sc_enabled ? 1u : 0u;
    *p++ = sys.cart.fe_pending ? 1u : 0u;

    /* DPC state */
    memcpy(p, sys.cart.dpc_tops, 8);     p += 8;
    memcpy(p, sys.cart.dpc_bottoms, 8);  p += 8;
    { int i; for (i = 0; i < 8; i++) {
        p[0] = (uint8_t)(sys.cart.dpc_counters[i] & 0xFF);
        p[1] = (uint8_t)(sys.cart.dpc_counters[i] >> 8);
        p += 2;
    }}
    memcpy(p, sys.cart.dpc_flags, 8);    p += 8;
    p[0] = sys.cart.dpc_music_mode[0] ? 1u : 0u;
    p[1] = sys.cart.dpc_music_mode[1] ? 1u : 0u;
    p[2] = sys.cart.dpc_music_mode[2] ? 1u : 0u;
    p += 3;
    *p++ = sys.cart.dpc_random;
    { int i; for (i = 0; i < 8; i++) {
        p[i] = (uint8_t)(sys.cart.dpc_audio_cycles >> (i * 8));
    } p += 8; }
    memcpy(p, &sys.cart.dpc_frac_clocks, 8); p += 8;

    /* FA (CBS RAM+) + E7 (M-Network) state. Both blocks are emitted
     * unconditionally so serialize_size stays constant across mappers. */
    memcpy(p, sys.cart.fa_ram, CART_FA_RAM_SIZE); p += CART_FA_RAM_SIZE;
    memcpy(p, sys.cart.e7_ram, CART_E7_RAM_SIZE); p += CART_E7_RAM_SIZE;
    *p++ = (uint8_t)((sys.cart.e7_lower_ram ? 0x80u : 0u)
                   | (sys.cart.e7_upper_bank & 0x03u));

    *p++ = (uint8_t)((sys.sw_color        ? 0x01u : 0u)
                   | (sys.sw_left_diff_a  ? 0x02u : 0u)
                   | (sys.sw_right_diff_a ? 0x04u : 0u));
    return true;
}

bool retro_unserialize(const void *data, size_t size)
{
    const uint8_t *p = (const uint8_t *)data;
    size_t need = retro_serialize_size();
    if (size < need) return false;
    if (!cpu_deserialize(&sys.cpu,  p, cpu_serialize_size()))  return false;
    p += cpu_serialize_size();
    if (!riot_deserialize(&sys.riot, p, riot_serialize_size())) return false;
    p += riot_serialize_size();
    if (!tia_deserialize(&sys.tia,  p, tia_serialize_size()))  return false;
    p += tia_serialize_size();

    memcpy(sys.cart.data, p, CART_MAX_SIZE); p += CART_MAX_SIZE;
    sys.cart.size = (uint32_t)p[0]
                  | ((uint32_t)p[1] << 8)
                  | ((uint32_t)p[2] << 16)
                  | ((uint32_t)p[3] << 24);
    p += 4;
    sys.cart.mapper = *p++;
    sys.cart.bank   = *p++;
    memcpy(sys.cart.e0_slots, p, 4);            p += 4;
    memcpy(sys.cart.sc_ram, p, CART_SC_RAM_SIZE); p += CART_SC_RAM_SIZE;
    sys.cart.sc_enabled = *p++ != 0;
    sys.cart.fe_pending = *p++ != 0;

    /* DPC state */
    memcpy(sys.cart.dpc_tops, p, 8);     p += 8;
    memcpy(sys.cart.dpc_bottoms, p, 8);  p += 8;
    { int i; for (i = 0; i < 8; i++) {
        sys.cart.dpc_counters[i] = (uint16_t)(p[0] | ((uint16_t)p[1] << 8));
        p += 2;
    }}
    memcpy(sys.cart.dpc_flags, p, 8);    p += 8;
    sys.cart.dpc_music_mode[0] = p[0] != 0;
    sys.cart.dpc_music_mode[1] = p[1] != 0;
    sys.cart.dpc_music_mode[2] = p[2] != 0;
    p += 3;
    sys.cart.dpc_random = *p++;
    { int i; sys.cart.dpc_audio_cycles = 0;
      for (i = 0; i < 8; i++)
        sys.cart.dpc_audio_cycles |= ((uint64_t)p[i] << (i * 8));
      p += 8;
    }
    memcpy(&sys.cart.dpc_frac_clocks, p, 8); p += 8;

    memcpy(sys.cart.fa_ram, p, CART_FA_RAM_SIZE); p += CART_FA_RAM_SIZE;
    memcpy(sys.cart.e7_ram, p, CART_E7_RAM_SIZE); p += CART_E7_RAM_SIZE;
    {
        uint8_t b = *p++;
        sys.cart.e7_lower_ram  = (b & 0x80) != 0;
        sys.cart.e7_upper_bank = (uint8_t)(b & 0x03);
    }

    {
        uint8_t sw = *p++;
        sys.sw_color        = (sw & 0x01) != 0;
        sys.sw_left_diff_a  = (sw & 0x02) != 0;
        sys.sw_right_diff_a = (sw & 0x04) != 0;
        /* sw_prev is transient frame state, not saved. Reset so the first
         * post-load poll doesn't mis-fire a rising-edge. */
        sys.sw_prev = 0;
    }
    return true;
}

void *retro_get_memory_data(unsigned id)
{
    if (id == RETRO_MEMORY_SYSTEM_RAM) return sys.riot.ram;
    return NULL;
}

size_t retro_get_memory_size(unsigned id)
{
    if (id == RETRO_MEMORY_SYSTEM_RAM) return 128;
    return 0;
}

void retro_cheat_reset(void) { }
void retro_cheat_set(unsigned index, bool enabled, const char *code)
{
    (void)index; (void)enabled; (void)code;
}
