from pathlib import Path
import subprocess,os,json,hashlib
R=Path(__file__).resolve().parent;S=R/'source';SDK=R.parent/'work-040/references/emsdk';B=R/'build-wasm';B.mkdir(exist_ok=True);O=R/'built';O.mkdir(exist_ok=True);env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten')};objects=[]
files=['astro_core.cpp','astrocade.cpp','hash/sha256.cpp']
for name in files:
 obj=B/(name.replace('/','_')+'.o');cpp=name.endswith('.cpp');compiler=SDK/'install/emscripten'/('em++.py'if cpp else'emcc.py');flags=['-O3','-fwrapv','-ffp-contract=off','-fwasm-exceptions','-DINLINE=inline','-I'+str(S),'-I'+str(S/'hash')]+(['-std=c++17']if cpp else['-std=c11'])
 with(B/(obj.name+'.log')).open('w')as log:subprocess.run(['python3',str(compiler),*flags,'-c',str(S/name),'-o',str(obj)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 objects.append(obj)
exports=['_gremlin_acm_load','_gremlin_acm_render','_gremlin_acm_close','_gremlin_acm_error','_gremlin_acm_devices','_malloc','_free'];cmd=['python3',str(SDK/'install/emscripten/em++.py'),'-O3','-fwasm-exceptions','-sSUPPORT_LONGJMP=wasm',*[str(x)for x in objects],'--no-entry','-sMODULARIZE=1','-sEXPORT_NAME=GremlinAstrocadeMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=67108864','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(O/'gremlin-acm.js')]
with(B/'link.log').open('w')as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
result={'player':'0.18','compiler':'Emscripten6.0.13','profile':1,'format':'ACM1/ACZ exact original Astrocade state plus original timed chip writes; no game ROM or rendered audio','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in O.glob('gremlin-acm.*')]};(O/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
