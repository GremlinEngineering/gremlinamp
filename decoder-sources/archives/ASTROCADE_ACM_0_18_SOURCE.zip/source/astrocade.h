// license:BSD-3-Clause
// copyright-holders:Aaron Giles,Frank Palazzolo
#pragma once
#include <cstdint>
#include <cstring>
#include <algorithm>
using s32=int32_t;using offs_t=uint32_t;
struct sound_stream{using sample_t=float;float*out=nullptr;int count=0;int samples()const{return count;}void update(){}void fill(int,float value,int at,int n){std::fill_n(out+at,n,value);}};
class astrocade_io_device {public:
 astrocade_io_device(){device_reset();m_stream=&stream;for(unsigned i=0;i<256;i++){unsigned v=0;for(unsigned b=0;b<8;b++)v|=((i>>b)&1)<<(7-b);m_bitswap[i]=v;}}
 sound_stream stream;
 void device_reset();void sound_stream_update(sound_stream&);void write(offs_t,uint8_t);
 void render(float*out,unsigned n){stream.out=out;stream.count=n;sound_stream_update(stream);}
 void snapshot(uint8_t*p)const{memset(p,0,32);memcpy(p,m_reg,8);p[8]=m_master_count;p[9]=m_noise_clock;p[10]=m_vibrato_clock;p[11]=m_vibrato_clock>>8;p[12]=m_noise_state;p[13]=m_noise_state>>8;p[14]=m_a_count;p[15]=m_a_state;p[16]=m_b_count;p[17]=m_b_state;p[18]=m_c_count;p[19]=m_c_state;}
 void restore(const uint8_t*p){memcpy(m_reg,p,8);m_master_count=p[8];m_noise_clock=p[9];m_vibrato_clock=p[10]|p[11]<<8;m_noise_state=p[12]|p[13]<<8;m_a_count=p[14];m_a_state=p[15];m_b_count=p[16];m_b_state=p[17];m_c_count=p[18];m_c_state=p[19];}
	sound_stream *m_stream;       /* sound stream */

	uint8_t       m_reg[8];         /* 8 control registers */

	uint8_t       m_master_count;   /* current master oscillator count */
	uint16_t      m_vibrato_clock;  /* current vibrato clock */

	uint8_t       m_noise_clock;    /* current noise generator clock */
	uint16_t      m_noise_state;    /* current noise LFSR state */

	uint8_t       m_a_count;        /* current tone generator A count */
	uint8_t       m_a_state;        /* current tone generator A state */

	uint8_t       m_b_count;        /* current tone generator B count */
	uint8_t       m_b_state;        /* current tone generator B state */

	uint8_t       m_c_count;        /* current tone generator C count */
	uint8_t       m_c_state;        /* current tone generator C state */

	uint8_t       m_bitswap[256];   /* bitswap table */

};
