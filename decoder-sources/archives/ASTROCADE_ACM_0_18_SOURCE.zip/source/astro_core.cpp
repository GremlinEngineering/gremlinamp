#include "astro_trace.h"
#include "hash/mednafen/mednafen.h"
#include "hash/sha256.h"
#include <deque>
#include <string>
static AstroTrace original;static bool loaded=false;static std::string error_text,device_text;
static unsigned output_rate=0,fraction=0;static uint64_t at=0,base=0;static std::deque<std::array<float,2>>pcm;
static uint32_t r32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static void ensure(){if(pcm.empty()){float f[2048];original.render(f,1024);for(unsigned i=0;i<1024;i++)pcm.push_back({f[i*2],f[i*2+1]});}}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_acm_close(){loaded=false;original.events.clear();pcm.clear();output_rate=fraction=0;at=base=0;}
API const char*gremlin_acm_error(){return error_text.c_str();}
API const char*gremlin_acm_devices(){return device_text.c_str();}
API int gremlin_acm_load(const uint8_t*b,uint32_t length,uint32_t rate,uint32_t subsong){
 gremlin_acm_close();error_text.clear();device_text.clear();try{
  if(!b||length<160||memcmp(b,"ACM\x1a",4)||r32(b+4)!=1||r32(b+8)!=1789772||r32(b+12)!=2||r32(b+20)!=160||r32(b+28)!=96||r32(b+32)!=160||r32(b+36)!=1||rate<8000||rate>192000||subsong!=0)throw std::runtime_error("Invalid ACM1 Astrocade profile");
  uint32_t count=r32(b+16),duration=r32(b+24);if(!duration||duration>1789772u*600||count>1000000||160+uint64_t(count)*12!=length)throw std::runtime_error("Invalid ACM1 event bounds");
  for(unsigned j=40;j<48;j++)if(b[j])throw std::runtime_error("Unsupported ACM flags");for(unsigned j=80;j<96;j++)if(b[j])throw std::runtime_error("Unsupported ACM header data");
  auto h=Mednafen::sha256(b+96,length-96);if(memcmp(h.data(),b+48,32))throw std::runtime_error("ACM original state/event hash differs");
  for(unsigned i=0;i<2;i++){const auto*p=b+96+i*32;if(p[9]>=64||p[15]>1||p[17]>1||p[19]>1)throw std::runtime_error("Invalid original Astrocade counters");for(unsigned j=20;j<32;j++)if(p[j])throw std::runtime_error("Unsupported Astrocade state extension");}
  std::vector<AstroEvent>events;events.reserve(count);uint32_t prior=0;
  for(unsigned i=0;i<count;i++){const auto*p=b+160+i*12;uint32_t cycle=r32(p);if(cycle<prior||cycle>=duration||p[4]>=2||p[5]>=8||p[7]||r32(p+8))throw std::runtime_error("Invalid ACM chip write");events.push_back({cycle,p[4],p[5],p[6]});prior=cycle;}
  original.open(std::move(events),duration,b+96);output_rate=rate;loaded=true;device_text="[{\"type\":\"astrocade\",\"instances\":2,\"clock_hz\":1789772,\"core\":\"unaltered pinned MAME chip methods\",\"routes\":\"chip0 left,chip1 right,x0.35\",\"resampler\":\"exact clock-cell area averaging\",\"game_rom_or_bios_dependency\":false}]";return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_acm_close();return 1;}
}
API uint32_t gremlin_acm_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*8);if(!loaded)return 0;
 try{for(unsigned i=0;i<frames;i++){uint64_t left=1789772;double sum[2]={};while(left){ensure();unsigned units=unsigned(std::min<uint64_t>(output_rate-fraction,left));for(unsigned c=0;c<2;c++)sum[c]+=double(pcm.front()[c])*units;fraction+=units;left-=units;if(fraction==output_rate){fraction=0;pcm.pop_front();at++;}}for(unsigned c=0;c<2;c++)out[i*2+c]=float(sum[c]/1789772.0);}return frames;}catch(const std::exception&e){error_text=e.what();gremlin_acm_close();return 0;}
}
}
