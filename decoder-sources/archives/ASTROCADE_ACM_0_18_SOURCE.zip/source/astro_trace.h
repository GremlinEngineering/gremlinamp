#pragma once
#include "astrocade.h"
#include <vector>
#include <array>
#include <stdexcept>
struct AstroEvent{uint32_t cycle;uint8_t chip,reg,data;};
class AstroTrace{public:
 astrocade_io_device chips[2];std::vector<AstroEvent>events;size_t event_at=0;uint64_t position=0,end=0;
 void open(std::vector<AstroEvent>v,uint64_t limit,const uint8_t*state=nullptr){events=std::move(v);event_at=0;position=0;end=limit;for(unsigned i=0;i<2;i++){chips[i].device_reset();if(state)chips[i].restore(state+i*32);}}
 unsigned render(float*out,unsigned request){unsigned n=0;
  while(n<request){
   while(event_at<events.size()&&events[event_at].cycle<=position){const auto&e=events[event_at++];chips[e.chip].write(e.reg,e.data);}
   unsigned count=std::min<unsigned>(request-n,1024);if(position<end){count=std::min<uint64_t>(count,end-position);if(event_at<events.size())count=std::min<uint64_t>(count,events[event_at].cycle-position);float l[1024],r[1024];chips[0].render(l,count);chips[1].render(r,count);for(unsigned j=0;j<count;j++){out[(n+j)*2]=l[j]*.35f;out[(n+j)*2+1]=r[j]*.35f;}}else{for(unsigned j=0;j<count*2;j++)out[n*2+j]=0;}
   if(!count)throw std::runtime_error("Astrocade event ordering failure");position+=count;n+=count;
  }
  return n;
 }
 void skip(uint64_t count){float f[2048];while(count){unsigned n=std::min<uint64_t>(count,1024);render(f,n);count-=n;}}
};
