#include "source/astro_trace.h"
#include "source/hash/mednafen/mednafen.h"
#include "source/hash/sha256.h"
#include <fstream>
#include <cstdio>
#include <cstdlib>
static std::vector<AstroEvent>raw(const char*p){std::ifstream f(p,std::ios::binary);uint32_t row[6];std::vector<AstroEvent>v;uint32_t prior=0;while(f.read((char*)row,24)){if(row[0]<prior||row[1]>1)throw std::runtime_error("Raw events unordered");unsigned port=row[2],reg=port&8?(port>>8)&7:port&7;v.push_back({row[0],uint8_t(row[1]),uint8_t(reg),uint8_t(row[3])});prior=row[0];}if(!f.eof())throw std::runtime_error("Raw trace read");return v;}
static void put32(uint8_t*p,uint32_t v){for(unsigned j=0;j<4;j++)p[j]=v>>(j*8);}
int main(int argc,char**argv){
 try{
  if(argc<6)return 2;auto events=raw(argv[2]);uint32_t start=strtoul(argv[3],nullptr,0),end=strtoul(argv[4],nullptr,0);if(end<=start)return 2;AstroTrace original;original.open(events,end);original.skip(start);
  if(!strcmp(argv[1],"pack")){
   std::vector<uint8_t>b(160);memcpy(b.data(),"ACM\x1a",4);put32(b.data()+4,1);put32(b.data()+8,1789772);put32(b.data()+12,2);put32(b.data()+20,160);put32(b.data()+24,end-start);put32(b.data()+28,96);put32(b.data()+32,160);put32(b.data()+36,1);for(unsigned i=0;i<2;i++)original.chips[i].snapshot(b.data()+96+i*32);
   unsigned count=0;uint8_t previous[2][8];for(unsigned i=0;i<2;i++)memcpy(previous[i],original.chips[i].m_reg,8);
   for(const auto&e:events){if(e.cycle<start||e.cycle>=end)continue;if(previous[e.chip][e.reg]==e.data)continue;previous[e.chip][e.reg]=e.data;size_t pos=b.size();b.resize(pos+12);put32(b.data()+pos,e.cycle-start);b[pos+4]=e.chip;b[pos+5]=e.reg;b[pos+6]=e.data;count++;}
   put32(b.data()+16,count);auto h=Mednafen::sha256(b.data()+96,b.size()-96);memcpy(b.data()+48,h.data(),32);std::ofstream f(argv[5],std::ios::binary);f.write((char*)b.data(),b.size());printf("{\"original_events\":%zu,\"native_changes\":%u,\"start_cycle\":%u,\"end_cycle\":%u,\"seconds\":%.9f,\"raw_bytes\":%zu}\n",events.size(),count,start,end,double(end-start)/1789772,b.size());
  }else if(!strcmp(argv[1],"render")){
   if(argc!=8)return 2;unsigned rate=strtoul(argv[5],nullptr,0);uint64_t frames=uint64_t(atof(argv[6])*rate);FILE*f=fopen(argv[7],"wb");if(!f)return 2;float block[2048];unsigned index=1024,fraction=0;
   for(uint64_t i=0;i<frames;i++){uint64_t remaining=1789772;double sum[2]={};while(remaining){if(index==1024){original.render(block,1024);index=0;}unsigned weight=std::min<uint64_t>(rate-fraction,remaining);sum[0]+=double(block[index*2])*weight;sum[1]+=double(block[index*2+1])*weight;fraction+=weight;remaining-=weight;if(fraction==rate){fraction=0;index++;}}float result[]={float(sum[0]/1789772.0),float(sum[1]/1789772.0)};fwrite(result,4,2,f);}fclose(f);
  }else return 2;
  return 0;
 }catch(const std::exception&e){fprintf(stderr,"%s\n",e.what());return 1;}
}
