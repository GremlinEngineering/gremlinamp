from pathlib import Path
import re,json,hashlib
R=Path(__file__).resolve().parent;Q=R.parent/'work-040/references';S=R/'source';S.mkdir(exist_ok=True);c=(Q/'mame-astrocade-sound.cpp').read_text();h=(Q/'mame-astrocade-sound.h').read_text()
def method(n):
 m=re.search(r'^void astrocade_io_device::'+n+r'\([^\n]*\)\n\{',c,re.M);assert m,n;p=c.index('{',m.start());i=p+1;depth=1
 while depth:
  if c[i]=='{':depth+=1
  if c[i]=='}':depth-=1
  i+=1
 return c[m.start():i]
names=['sound_stream_update','device_reset','write'];methods=[method(n)for n in names]
fields=h[h.index('\tsound_stream *m_stream;'):h.index('\tdevcb_read8')]
shim='''// license:BSD-3-Clause
// copyright-holders:Aaron Giles,Frank Palazzolo
#pragma once
#include <cstdint>
#include <cstring>
#include <algorithm>
using s32=int32_t;using offs_t=uint32_t;
struct sound_stream{using sample_t=float;float*out=nullptr;int count=0;int samples()const{return count;}void update(){}void fill(int,float value,int at,int n){std::fill_n(out+at,n,value);}};
class astrocade_io_device {public:
 astrocade_io_device(){device_reset();m_stream=&stream;for(unsigned i=0;i<256;i++){unsigned v=0;for(unsigned b=0;b<8;b++)v|=((i>>b)&1)<<(7-b);m_bitswap[i]=v;}}
 sound_stream stream;
 void device_reset();void sound_stream_update(sound_stream&);void write(offs_t,uint8_t);
 void render(float*out,unsigned n){stream.out=out;stream.count=n;sound_stream_update(stream);}
 void snapshot(uint8_t*p)const{memset(p,0,32);memcpy(p,m_reg,8);p[8]=m_master_count;p[9]=m_noise_clock;p[10]=m_vibrato_clock;p[11]=m_vibrato_clock>>8;p[12]=m_noise_state;p[13]=m_noise_state>>8;p[14]=m_a_count;p[15]=m_a_state;p[16]=m_b_count;p[17]=m_b_state;p[18]=m_c_count;p[19]=m_c_state;}
 void restore(const uint8_t*p){memcpy(m_reg,p,8);m_master_count=p[8];m_noise_clock=p[9];m_vibrato_clock=p[10]|p[11]<<8;m_noise_state=p[12]|p[13]<<8;m_a_count=p[14];m_a_state=p[15];m_b_count=p[16];m_b_state=p[17];m_c_count=p[18];m_c_state=p[19];}
'''
(S/'astrocade.h').write_text(shim+fields+'};\n');(S/'astrocade.cpp').write_text('#include "astrocade.h"\n'+'\n\n'.join(methods)+'\n');(R/'method-identities.json').write_text(json.dumps({'mame_pin':'40d0f1125befade5edc08ec5699442ca3a229c01','source_sha256':hashlib.sha256(c.encode()).hexdigest(),'methods':[{'name':n,'sha256':hashlib.sha256(v.encode()).hexdigest(),'verbatim':True}for n,v in zip(names,methods)]},indent=2)+'\n')
