//
// DSP core
//
// Originally by David Raingeard
// GCC/SDL port by Niels Wagenaar (Linux/WIN32) and Caz (BeOS)
// Extensive cleanups/rewrites by James Hammons
// (C) 2010 Underground Software
//
// JLH = James Hammons <jlhamm@acm.org>
//
// Who  When        What
// ---  ----------  -------------------------------------------------------------
// JLH  01/16/2010  Created this log ;-)
// JLH  11/26/2011  Added fixes for LOAD/STORE alignment issues
//

#include <compat/msvc.h>  /* snprintf shim for MSVC < 2015 (buildbot msvc05/10) */
#include "dsp.h"
#include "dsp_acc40.h"
#include "risc_div.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dac.h"
#include "gpu.h"
#include "jaguar.h"
#include "jerry.h"
#include "log.h"
#include "m68000/m68kinterface.h"
#include "settings.h"
#include "tom.h"
#include "blit_memo.h"
#include "bus_arbiter.h"
#include "../core/vjtrace.h"
#include "perf_iface.h"
#include "gdbstub.h"

// Seems alignment in loads & stores was off...
#define DSP_CORRECT_ALIGNMENT
#define DSP_CORRECT_ALIGNMENT_STORE

#define NEW_SCOREBOARD

// Pipeline structures

const bool affectsScoreboard[64] =
{
	 true,  true,  true,  true,
	 true,  true,  true,  true,
	 true,  true,  true,  true,
	 true, false,  true,  true,

	 true,  true, false,  true,
	false,  true,  true,  true,
	 true,  true,  true,  true,
	 true,  true, false, false,

	 true,  true,  true,  true,
	false,  true,  true,  true,
	 true,  true,  true,  true,
	 true, false, false, false,

	 true, false, false,  true,
	false, false,  true,  true,
	 true, false,  true,  true,
	false, false, false,  true
};

struct PipelineStage
{
	uint16_t instruction;
	uint8_t opcode, operand1, operand2;
	uint32_t reg1, reg2, areg1, areg2;
	uint32_t result;
	uint8_t writebackRegister;
	// General memory store...
	uint32_t address;
	uint32_t value;
	uint8_t type;
};

#define TYPE_BYTE			0
#define TYPE_WORD			1
#define TYPE_DWORD			2
#define PIPELINE_STALL		64						// Set to # of opcodes + 1
#ifndef NEW_SCOREBOARD
bool scoreboard[32];
#else
uint8_t scoreboard[32];
#endif
uint8_t plPtrFetch, plPtrRead, plPtrExec, plPtrWrite;
struct PipelineStage pipeline[4];
bool IMASKCleared = false;

// DSP flags (old--have to get rid of this crap)

#define CINT0FLAG			0x00200
#define CINT1FLAG			0x00400
#define CINT2FLAG			0x00800
#define CINT3FLAG			0x01000
#define CINT4FLAG			0x02000
#define CINT04FLAGS			(CINT0FLAG | CINT1FLAG | CINT2FLAG | CINT3FLAG | CINT4FLAG)
#define CINT5FLAG			0x20000		/* DSP only */

// DSP_FLAGS bits

#define ZERO_FLAG		0x00001
#define CARRY_FLAG		0x00002
#define NEGA_FLAG		0x00004
#define IMASK			0x00008
#define INT_ENA0		0x00010
#define INT_ENA1		0x00020
#define INT_ENA2		0x00040
#define INT_ENA3		0x00080
#define INT_ENA4		0x00100
#define INT_CLR0		0x00200
#define INT_CLR1		0x00400
#define INT_CLR2		0x00800
#define INT_CLR3		0x01000
#define INT_CLR4		0x02000
#define REGPAGE			0x04000
#define DMAEN			0x08000
#define INT_ENA5		0x10000
#define INT_CLR5		0x20000

// DSP_CTRL bits

#define DSPGO			0x00001
#define CPUINT			0x00002
#define DSPINT0			0x00004
#define SINGLE_STEP		0x00008
#define SINGLE_GO		0x00010
// Bit 5 is unused!
#define INT_LAT0		0x00040
#define INT_LAT1		0x00080
#define INT_LAT2		0x00100
#define INT_LAT3		0x00200
#define INT_LAT4		0x00400
#define BUS_HOG			0x00800
#define VERSION			0x0F000
#define INT_LAT5		0x10000

// HLE auto-ack: BIOS sound engine command area in DSP RAM
// ($F1B9D0-$F1B9DF absolute; offsets relative to DSP_WORK_RAM_BASE)
#define DSP_SOUND_CMD_BASE	0x9D0
#define DSP_SOUND_CMD_END	0x9E0
// Tight-poll detection: auto-clear DSPGO after this many consecutive
// 68K reads without an intervening DSP_CTRL write.  A tight boot-time
// poll loop does ~44000 reads/frame; normal gameplay does ~1-10/frame.
#define DSPGO_POLL_THRESHOLD	8192
#define DSP_RAM_SIZE		8192

void DSPHandleIRQsNP(void);

// Is opcode 62 *really* a NOP? Seems like it...
INLINE static void dsp_opcode_abs(void);
INLINE static void dsp_opcode_add(void);
INLINE static void dsp_opcode_addc(void);
INLINE static void dsp_opcode_addq(void);
INLINE static void dsp_opcode_addqmod(void);
INLINE static void dsp_opcode_addqt(void);
INLINE static void dsp_opcode_and(void);
INLINE static void dsp_opcode_bclr(void);
INLINE static void dsp_opcode_bset(void);
INLINE static void dsp_opcode_btst(void);
INLINE static void dsp_opcode_cmp(void);
INLINE static void dsp_opcode_cmpq(void);
INLINE static void dsp_opcode_div(void);
INLINE static void dsp_opcode_imacn(void);
INLINE static void dsp_opcode_imult(void);
INLINE static void dsp_opcode_imultn(void);
INLINE static void dsp_opcode_jr(void);
INLINE static void dsp_opcode_jump(void);
INLINE static void dsp_opcode_load(void);
INLINE static void dsp_opcode_loadb(void);
INLINE static void dsp_opcode_loadw(void);
INLINE static void dsp_opcode_load_r14_indexed(void);
INLINE static void dsp_opcode_load_r14_ri(void);
INLINE static void dsp_opcode_load_r15_indexed(void);
INLINE static void dsp_opcode_load_r15_ri(void);
INLINE static void dsp_opcode_mirror(void);
INLINE static void dsp_opcode_mmult(void);
INLINE static void dsp_opcode_move(void);
INLINE static void dsp_opcode_movei(void);
INLINE static void dsp_opcode_movefa(void);
INLINE static void dsp_opcode_move_pc(void);
INLINE static void dsp_opcode_moveq(void);
INLINE static void dsp_opcode_moveta(void);
INLINE static void dsp_opcode_mtoi(void);
INLINE static void dsp_opcode_mult(void);
INLINE static void dsp_opcode_neg(void);
INLINE static void dsp_opcode_nop(void);
INLINE static void dsp_opcode_normi(void);
INLINE static void dsp_opcode_not(void);
INLINE static void dsp_opcode_or(void);
INLINE static void dsp_opcode_resmac(void);
INLINE static void dsp_opcode_ror(void);
INLINE static void dsp_opcode_rorq(void);
INLINE static void dsp_opcode_xor(void);
INLINE static void dsp_opcode_sat16s(void);
INLINE static void dsp_opcode_sat32s(void);
INLINE static void dsp_opcode_sh(void);
INLINE static void dsp_opcode_sha(void);
INLINE static void dsp_opcode_sharq(void);
INLINE static void dsp_opcode_shlq(void);
INLINE static void dsp_opcode_shrq(void);
INLINE static void dsp_opcode_store(void);
INLINE static void dsp_opcode_storeb(void);
INLINE static void dsp_opcode_storew(void);
INLINE static void dsp_opcode_store_r14_indexed(void);
INLINE static void dsp_opcode_store_r14_ri(void);
INLINE static void dsp_opcode_store_r15_indexed(void);
INLINE static void dsp_opcode_store_r15_ri(void);
INLINE static void dsp_opcode_sub(void);
INLINE static void dsp_opcode_subc(void);
INLINE static void dsp_opcode_subq(void);
INLINE static void dsp_opcode_subqmod(void);
INLINE static void dsp_opcode_subqt(void);
INLINE static void dsp_opcode_illegal(void);
INLINE static void dsp_executeOpcode(uint32_t index);

//Here's a QnD kludge...
//This is wrong, wrong, WRONG, but it seems to work for the time being...
//(That is, it fixes Flip Out which relies on GPU timing rather than semaphores. Bad developers! Bad!)
//What's needed here is a way to take pipeline effects into account (including pipeline stalls!)...
// Yup, without cheating like this, the sound in things like Rayman, FACTS, &
// Tripper Getem get starved for time and sounds like crap. So we have to figure
// out how to fix that. :-/
uint8_t dsp_opcode_cycles[64] =
{
	1,  1,  1,  1,  1,  1,  1,  1,
	1,  1,  1,  1,  1,  1,  1,  1,
	1,  1,  1,  1,  1,  9,  1,  1,
	1,  1,  1,  1,  1,  1,  1,  1,
	1,  1,  1,  1,  1,  1,  1,  2,
	2,  2,  2,  3,  3,  1,  1,  1,
	1,  1,  1,  1,  1,  1,  4,  1,
	1,  1,  3,  3,  1,  1,  1,  1
};//*/

void (* dsp_opcode[64])() =
{
	dsp_opcode_add,					dsp_opcode_addc,				dsp_opcode_addq,				dsp_opcode_addqt,
	dsp_opcode_sub,					dsp_opcode_subc,				dsp_opcode_subq,				dsp_opcode_subqt,
	dsp_opcode_neg,					dsp_opcode_and,					dsp_opcode_or,					dsp_opcode_xor,
	dsp_opcode_not,					dsp_opcode_btst,				dsp_opcode_bset,				dsp_opcode_bclr,
	dsp_opcode_mult,				dsp_opcode_imult,				dsp_opcode_imultn,				dsp_opcode_resmac,
	dsp_opcode_imacn,				dsp_opcode_div,					dsp_opcode_abs,					dsp_opcode_sh,
	dsp_opcode_shlq,				dsp_opcode_shrq,				dsp_opcode_sha,					dsp_opcode_sharq,
	dsp_opcode_ror,					dsp_opcode_rorq,				dsp_opcode_cmp,					dsp_opcode_cmpq,
	dsp_opcode_subqmod,				dsp_opcode_sat16s,				dsp_opcode_move,				dsp_opcode_moveq,
	dsp_opcode_moveta,				dsp_opcode_movefa,				dsp_opcode_movei,				dsp_opcode_loadb,
	dsp_opcode_loadw,				dsp_opcode_load,				dsp_opcode_sat32s,				dsp_opcode_load_r14_indexed,
	dsp_opcode_load_r15_indexed,	dsp_opcode_storeb,				dsp_opcode_storew,				dsp_opcode_store,
	dsp_opcode_mirror,				dsp_opcode_store_r14_indexed,	dsp_opcode_store_r15_indexed,	dsp_opcode_move_pc,
	dsp_opcode_jump,				dsp_opcode_jr,					dsp_opcode_mmult,				dsp_opcode_mtoi,
	dsp_opcode_normi,				dsp_opcode_nop,					dsp_opcode_load_r14_ri,			dsp_opcode_load_r15_ri,
	dsp_opcode_store_r14_ri,		dsp_opcode_store_r15_ri,		dsp_opcode_illegal,				dsp_opcode_addqmod,
};


uint32_t dsp_pc;
static uint64_t dsp_acc;								// 40 bit register, NOT 32!
static uint32_t dsp_remain;
static uint32_t dsp_modulo;
static uint32_t dsp_flags;
static uint32_t dsp_matrix_control;
static uint32_t dsp_pointer_to_matrix;
static uint32_t dsp_data_organization;
uint32_t dsp_control;
static uint32_t dsp_div_control;
static uint8_t dsp_flag_z, dsp_flag_n, dsp_flag_c;
static uint32_t * dsp_reg = NULL, * dsp_alternate_reg = NULL;
uint32_t dsp_reg_bank_0[32], dsp_reg_bank_1[32];

static uint32_t dsp_opcode_first_parameter;
static uint32_t dsp_opcode_second_parameter;

#define DSP_RUNNING			(dsp_control & 0x01)

#define RM					dsp_reg[dsp_opcode_first_parameter]
#define RN					dsp_reg[dsp_opcode_second_parameter]
#define ALTERNATE_RM		dsp_alternate_reg[dsp_opcode_first_parameter]
#define ALTERNATE_RN		dsp_alternate_reg[dsp_opcode_second_parameter]
#define IMM_1				dsp_opcode_first_parameter
#define IMM_2				dsp_opcode_second_parameter

#define CLR_Z				(dsp_flag_z = 0)
#define CLR_ZN				(dsp_flag_z = dsp_flag_n = 0)
#define CLR_ZNC				(dsp_flag_z = dsp_flag_n = dsp_flag_c = 0)
#define SET_Z(r)			(dsp_flag_z = ((r) == 0))
#define SET_N(r)			(dsp_flag_n = (((uint32_t)(r) >> 31) & 0x01))
#define SET_C_ADD(a,b)		(dsp_flag_c = ((uint32_t)(b) > (uint32_t)(~(a))))
#define SET_C_SUB(a,b)		(dsp_flag_c = ((uint32_t)(b) > (uint32_t)(a)))
#define SET_ZN(r)			SET_N(r); SET_Z(r)
#define SET_ZNC_ADD(a,b,r)	SET_N(r); SET_Z(r); SET_C_ADD(a,b)
#define SET_ZNC_SUB(a,b,r)	SET_N(r); SET_Z(r); SET_C_SUB(a,b)

uint32_t dsp_convert_zero[32] = {
	32, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
	17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31
};

uint8_t dsp_branch_condition_table[32 * 8];
static uint16_t mirror_table[65536];
static uint8_t dsp_ram_8[0x2000];

/* Late write-back of an external load (issue #811) -- the DSP side of
 * gpu_ldx_slot in src/tom/gpu.c, which carries the full rationale.
 * JTRM Rev 8 p.136, TOM/JERRY bug 13 "Scoreboard failure on successive
 * writes" ("This bug applies to both Tom & Jerry"): after
 * `load (r3),r2 / moveq 3,r2` the load data is written into r2 AFTER the
 * moveq.  Xenowings' DSP joypad reader does `load (r0=JOYSTICK),r1 /
 * moveq #0,r1`; letting the moveq win threw away the joypad row that
 * was just read.  The DSP's local bus holds F1A000-F1A1FF (control
 * registers), F1B000-F1CFFF (RAM) and F1D000-F1DFFF (wave table ROM) --
 * JTRM p.98; the whole F1A000-F1DFFF span is treated as local here, so
 * the unlisted F1A200-F1AFFF gap never arms the fix-up.  Everything else
 * goes through the external gateway (JTRM p.36-37, "Memory Interface",
 * shared with the DSP per p.97), the joystick included: a JOY1 read
 * enables the external joystick input buffers (p.95). */
static uint32_t *dsp_ldx_slot = NULL;
/* Diagnostics (test ABI): late write-backs applied since DSPReset.
 * Monotonic, not serialized. */
uint64_t dsp_load_wb_fixups = 0;

static void DSPLoadNoteExternal(uint32_t addr)
{
	addr &= 0xFFFFFF;
	if (addr < 0xF1A000 || addr > 0xF1DFFF)
		dsp_ldx_slot = &dsp_reg[dsp_opcode_second_parameter];
}

/* Called right after an external load executed (dsp_ldx_slot set).
 * Returns the load's register slot if the next instruction (at dsp_pc)
 * writes that register without reading it and is not a load/store, else
 * NULL.  Pure field-2 writers (same opcode numbers as the GPU): resmac
 * 19, move 34, moveq 35, movefa 37, movei 38, move pc 51, mtoi 55,
 * normi 56; move/mtoi/normi also read field 1.  Only peeks DSP local
 * RAM, so the fetch has no bus side effects. */
static uint32_t *DSPLoadOverwritePeek(uint32_t *val, uint32_t *pc)
{
	uint32_t off, n, p1, p2;
	uint16_t op;

	if (dsp_pc < DSP_WORK_RAM_BASE || dsp_pc >= DSP_WORK_RAM_BASE + 0x2000 - 1)
		return NULL;
	off = dsp_pc - DSP_WORK_RAM_BASE;
	op  = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
	n   = op >> 10;
	p1  = (op >> 5) & 0x1F;
	p2  = op & 0x1F;
	if (n != 19 && n != 34 && n != 35 && n != 37 && n != 38
	      && n != 51 && n != 55 && n != 56)
		return NULL;
	if ((n == 34 || n == 55 || n == 56) && p1 == p2)
		return NULL;
	if (&dsp_reg[p2] != dsp_ldx_slot)
		return NULL;
	*val = *dsp_ldx_slot;
	*pc  = dsp_pc;
	return dsp_ldx_slot;
}

/* Indexed store of a divide's result (issues #811, #895).  JTRM Rev 8
 * p.134, TOM/JERRY bug 2 "Scoreboard Failure on Indexed Addressing Mode
 * Stores" ("applies to both Tom & Jerry"): the data of store
 * instructions 49, 50, 60 and 61 is not scoreboarded, so when it is the
 * result of a divide still in flight the store writes the register's OLD
 * contents; the address registers stay fully protected.
 *
 * Which registers ARE protected comes from the netlists (jag_sim
 * netlists/jerry, identical to tom/; docs/jtrm-errata.md bug 2):
 *   - on the store's first tick the destination port carries the
 *     implicit base r14/r15 (DSP_EXEC.NET Impdai/Danwsel1/Dstanwi) and
 *     the source port the raw field-1 bits (Srcanwi := JOIN (srcopin,
 *     srctopi)); SBOARD.NET:127-130 compares both against pending
 *     writes, with the source compare enabled by `srcrrd + precomp`, so
 *     for the immediate forms 49/50 the 5-bit OFFSET is compared as if
 *     it named a register;
 *   - a match against the divide target holds the store until the
 *     quotient is written back (SBOARD.NET:380-384 Divdwait);
 *   - the data register is read one tick later on the compdld wait
 *     state (EXECON.NET:173-189), which no scoreboard term checks.
 * So the store sees the old value unless its base register, or its
 * field 1 -- index register or immediate offset -- names the divide's
 * destination.  Xenowings relies on both outcomes: the joypad reader's
 * `div r9,r8 / store r8,(r14+1)` stores the joypad bits (field 1 = 1),
 * its sound-effect setup's `div r12,r7 / store r7,(r14+7)` stores the
 * quotient (field 1 = 7 = r7: interlocked).
 * Modeled for the instruction immediately after the divide only (the
 * documented pattern; an intervening instruction may be the manual's
 * dependent "protection instruction", which this does not decode).
 * Diagnostics (test ABI): stale-data stores applied since DSPReset.
 * Monotonic, not serialized. */
uint64_t dsp_div_store_fixups = 0;

/* Called right after a divide executed, dsp_pc at the next instruction.
 * Returns the divide's destination slot if that instruction is an
 * indexed store whose data register is that slot and which the
 * scoreboard does not hold up (base register and field 1 both differ
 * from it -- see above), else NULL.  Only peeks DSP local RAM. */
static uint32_t *DSPDivStorePeek(uint32_t *divDst, uint32_t *pc)
{
	uint32_t off, n, p1, p2;
	uint16_t op;

	if (dsp_pc < DSP_WORK_RAM_BASE || dsp_pc >= DSP_WORK_RAM_BASE + 0x2000 - 1)
		return NULL;
	off = dsp_pc - DSP_WORK_RAM_BASE;
	op  = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
	n   = op >> 10;
	p1  = (op >> 5) & 0x1F;
	p2  = op & 0x1F;
	if (n != 49 && n != 50 && n != 60 && n != 61)
		return NULL;
	if (&dsp_reg[p2] != divDst)
		return NULL;
	/* Base register is the divide target, or field 1 (index register
	 * or raw immediate offset, compared as a register number) is: the
	 * store waits for the quotient and stores it. */
	if (((n == 49 || n == 60) && p2 == 14)
	      || ((n == 50 || n == 61) && p2 == 15)
	      || p1 == p2)
		return NULL;
	*pc = dsp_pc;
	return divDst;
}

static uint32_t dspgo_poll_count;

#define BRANCH_CONDITION(x)		dsp_branch_condition_table[(x) + ((jaguar_flags & 7) << 5)]

static uint32_t dsp_in_exec = 0;
static int32_t dspSliceBudget;
static int32_t dspSliceSpent;
static uint32_t dsp_releaseTimeSlice_flag = 0;
/* DSP execution liveness counter for the crash watchdog's wedge
 * predicate -- see gpu.c gpu_exec_opcode_count for rationale and the
 * delay-slot caveat (PC sampling aliases on idle JR/wait loops, which
 * DSP audio engines sit in constantly). */
uint32_t dsp_exec_opcode_count = 0;

/* Instruction slots a DSP-issued D_FLAGS store waits out before it
 * retires: the slot holding the store itself, plus the one instruction
 * already past Read Operands behind it in the pipeline.  While the delay
 * is outstanding a cleared IMASK cannot yet let an interrupt in, and the
 * register-bank switch the store selects has not happened yet: dsp_reg /
 * dsp_alternate_reg still point at the bank that was live when the store
 * issued, so EVERY register operand of the instruction behind it -- source
 * and destination alike -- uses the pre-store bank.  The switch is
 * committed (DSPUpdateRegisterBanks) when the delay reaches zero, at the
 * redirect of a taken jump/jr, or by an interrupt.  See the D_FLAGS case in
 * DSPWriteLong for the hardware citation (issues #853, d220aa2). */
#define DSP_FLAGS_RETIRE_DELAY 2
static uint32_t dspFlagsRetireDelay = 0;

/* ------------------------------------------------------------------ *
 * DSP pipeline / external-gateway timing model (issue #313 remainder,
 * timing-campaign S1; core option virtualjaguar_gpu_pipeline_timing,
 * default off -- the one option now covers both RISC cores).
 *
 * The DSP "is a variant of the GPU within Tom" with the same
 * pipe-lining (JTRM v8 p.97: "Pipe-Lining -- Refer to the 'Pipe-Lining'
 * section on the GPU description").  The netlists agree at the gate
 * level: jag_sim netlists/jerry/SBOARD.NET and EXECON.NET are
 * byte-identical to netlists/tom/SBOARD.NET and EXECON.NET, the local
 * memory arbitration in jerry/DSP_MEM.NET matches tom/GPU_MEM.NET, and
 * jerry/DSP_GATE.NET is the GPU gateway state machine minus the
 * 64-bit/phrase path.  So the scoreboard, write-back and gateway rules
 * of the GPU model in src/tom/gpu.c -- pinned against the netlists
 * (docs/gpu-timing-spec.md R2/R3/R5/R9/R15/R16) and by Verilator on the
 * GPU island (§14: write-back port conflict, L = 7 + D) -- carry over
 * by netlist identity.  The model below is that code with three DSP
 * differences, each cited where it is applied:
 *
 *   - local space is $F18000-$F1FFFF (DSP_MEM.NET), so GPU RAM is an
 *     external transaction for the DSP;
 *   - external memory sits behind JERRY's 16-bit interface (JTRM v8
 *     p.97), so a long transfer is two word cycles (JMEM.NET), priced
 *     by bus_arbiter_dsp_access();
 *   - indexed-store DATA is not score-boarded (TOM/JERRY bug 2, JTRM v8
 *     p.134; already modeled for its data effect by
 *     dsp_div_store_fixups), so it never waits on a pending result --
 *     but field 1 of every indexed op is (SBOARD.NET:130, see
 *     dsp_div_store_fixups): an index register, or for 43/44/49/50 the
 *     immediate offset compared as a register number.
 *
 * Constants: everything in CORE time is netlist-identical to the GPU
 * and inherits its pins.  INFERRED (not simulated -- no JERRY Verilator
 * rig exists): the JERRY<->TOM bus handshake is taken to cost what the
 * GPU's idle-bus grant costs (DSP_PIPE_GRANT_CLKS), and the split
 * transfer's pause state one clock (bus_arbiter.c).
 *
 * With the model on, every opcode's base cost is 1 tick (R1) instead of
 * the legacy dsp_opcode_cycles[] table, whose 2/3/9/4-cycle entries for
 * loads, indexed loads, DIV and MMULT are the hand-tuned stand-ins for
 * exactly what R5/R6/R9/R15 now model -- keeping both would double-
 * count.  MMULT (R17, per-element cost unpinned) is charged 1, the same
 * as the GPU model.  The table still drives the default path, which is
 * byte-identical with the option off.
 *
 * Cycle domains follow the bus_arbiter.h contract, as in gpu.c:
 * dsp_bus_stall is WALL time (gateway waits, pending external loads,
 * DRAM/ROM/I/O access) and is rescaled under risc_clock_scale;
 * dsp_pipe_core_stall is CORE time and is deducted unscaled.
 *
 * All model state is transient (bounded by one external transfer plus
 * one divide): never serialized, zeroed on DSPReset, interrupt dispatch
 * (bank switch) and option toggle -- the GPU model's convention. */
#define DSP_PIPE_GRANT_CLKS   2u   /* GPU idle-bus grant (ARB.NET); INFERRED for JERRY */
#define DSP_PIPE_EXT_ISSUE    2u   /* gateway issue phase (DSP_GATE.NET == GATEWAY.NET) */
#define DSP_PIPE_EXT_RETURN   3u   /* load data return + scoreboard write */
#define DSP_PIPE_LOCAL_LOAD   3u   /* local-RAM load latency (SBOARD.NET) */
#define DSP_PIPE_LOCAL_REPEAT 2u   /* local load engine: one op per 2 ticks */
#define DSP_PIPE_DIV_TICKS    16u  /* 32-bit quotient at 2 bits/tick (DIVIDE.NET) */
#define DSP_PIPE_LOCAL_LO     0xF18000u
#define DSP_PIPE_LOCAL_HI     0xF1FFFFu

/* Per-instruction stall accumulators (see the domain note above).
 * dsp_bus_stall also carries the dram_timing self-cost with the model
 * off; it is only ever nonzero when one of the two options is on. */
static uint32_t dsp_bus_stall;
static uint32_t dsp_pipe_core_stall;
/* Sub-cycle remainder of the wall->scaled conversion of dsp_bus_stall
 * (sysclk-hundredths, modulo 100); always 0 at stock scale.  Not
 * serialized -- same precedent as gpu_stall_scale_accum. */
static uint32_t dsp_stall_scale_accum;

static uint64_t dsp_pipe_clock;        /* cycles executed since reset */
static uint64_t dsp_ext_done[2];       /* split-transaction load/store slots */
static uint64_t dsp_gate_issue_free;   /* gateway issue-phase serialization */
static uint64_t dsp_local_busy_until;  /* local load engine */
static uint64_t dsp_reg_ready[32];     /* pending load/div result per reg */
static uint8_t  dsp_reg_ready_ext[32]; /* nonzero = that wait is wall time */
static uint8_t  dsp_pipe_prev_dest = 0xFF; /* prev instr's ALU dest, 0xFF none */
static uint8_t  dsp_pipe_prev_flags = 0;   /* prev instr set the flags */

/* Diagnostics (test ABI): stall cycles charged and external transfers
 * issued by the model.  Monotonic since DSPReset (NOT cleared by
 * DSPPipeTimingReset, which also runs on every interrupt), not
 * serialized -- same convention as gpu_pipe_stall_total. */
uint64_t dsp_pipe_stall_total = 0;
uint64_t dsp_pipe_ext_total   = 0;

/* Operand classification per DSP opcode.  Bit 0: field 1 names a
 * register this op reads.  Bit 1: field 2 names a register this op
 * reads.  Bit 2: this op writes the field-2 register.  Bit 3: the
 * field-2 read is NOT score-boarded (indexed-store data, TOM/JERRY bug
 * 2) -- it still occupies a register-file read port for the write-back
 * rule.  Bit 4: field 1 is an immediate offset that the score-board
 * nevertheless compares as a register number (43/44/49/50:
 * Srca_reg_ena := OR2 (srcrrd, precomp), SBOARD.NET:130) -- it waits on
 * that register like a read but takes no read port.  Same encoding as
 * gpu_pipe_flags[] (which has no bit 3/4 terms); the DSP-only opcodes
 * (32 subqmod, 33 sat16s, 42 sat32s, 48 mirror, 62 illegal, 63 addqmod)
 * differ from the GPU map.  moveta/movefa's alternate-bank operand and
 * the implicit R14/R15 base of the indexed forms are not tracked, as on
 * the GPU. */
static const uint8_t dsp_pipe_flags[64] = {
   7, 7, 6, 6, 7, 7, 6, 6,     /* add addc addq addqt sub subc subq subqt */
   6, 7, 7, 7, 6, 2, 6, 6,     /* neg and or xor not btst bset bclr */
   7, 7, 3, 4, 3, 7, 6, 7,     /* mult imult imultn resmac imacn div abs sh */
   6, 6, 7, 6, 7, 6, 3, 2,     /* shlq shrq sha sharq ror rorq cmp cmpq */
   6, 6, 5, 4, 1, 4, 4, 5,     /* subqmod sat16s move moveq moveta movefa movei loadb */
   5, 5, 6, 20, 20, 3, 3, 3,   /* loadw load sat32s load_r14_ix load_r15_ix storeb storew store */
   6, 26, 26, 4, 1, 0, 6, 5,   /* mirror store_r14_ix store_r15_ix move_pc jump jr mmult mtoi */
   5, 0, 5, 5, 11, 11, 0, 6    /* normi nop load_r14_ri load_r15_ri store_r14_ri store_r15_ri illegal addqmod */
};

/* Flag-setting opcodes: the GPU table for the shared opcodes, plus the
 * DSP-only ones that set Z/N(/C) in this core (subqmod, sat16s,
 * sat32s, mirror, addqmod). */
static const uint8_t dsp_pipe_sets_flags[64] = {
   1,1,1,0,1,1,1,0, 1,1,1,1,1,1,1,1,       /* add..bclr (addqt/subqt no) */
   1,1,0,0,0,1,1,1, 1,1,1,1,1,1,1,1,       /* mult..cmpq (imultn/imacn/resmac no) */
   1,1,0,0,0,0,0,0, 0,0,1,0,0,0,0,0,       /* subqmod,sat16s; sat32s; moves/loads no */
   1,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,1        /* mirror; addqmod */
};

void DSPPipeTimingReset(void)
{
	unsigned i;
	dsp_pipe_clock       = 0;
	dsp_bus_stall        = 0;
	dsp_pipe_core_stall  = 0;
	dsp_ext_done[0]      = 0;
	dsp_ext_done[1]      = 0;
	dsp_gate_issue_free  = 0;
	dsp_local_busy_until = 0;
	dsp_pipe_prev_dest   = 0xFF;
	dsp_pipe_prev_flags  = 0;
	for (i = 0; i < 32; i++)
	{
		dsp_reg_ready[i]     = 0;
		dsp_reg_ready_ext[i] = 0;
	}
}

void DSPClockScaleReset(void)
{
	dsp_stall_scale_accum = 0;
}

/* Score-board check before dispatch -- GPUPipeCheckUse() with the
 * bug-2 exemption.  The charge is the MAX of the overlapping wait
 * sources (pending load/div result R5/R9/R15, one-deep ALU result-use
 * interlock R2, write-back port conflict §14, flags interlock R3);
 * fixed issue extras (MOVEI +2 R16, indexed load +2 R6, indexed store
 * +1 R7) are added on top. */
static void DSPPipeCheckUse(uint32_t index)
{
	uint8_t f = dsp_pipe_flags[index];
	uint64_t ready = dsp_pipe_clock;
	uint32_t wait, extra;
	int wait_is_ext = 0;
	int sb2 = (f & 2) && !(f & 8);     /* field-2 read is score-boarded */
	int sb1 = (f & 1) || (f & 16);     /* field 1 is score-board compared */

	if (sb1)
	{
		uint64_t r = dsp_reg_ready[dsp_opcode_first_parameter];
		if (r > ready)
		{
			ready = r;
			wait_is_ext = dsp_reg_ready_ext[dsp_opcode_first_parameter];
		}
	}
	if (sb2)
	{
		uint64_t r = dsp_reg_ready[dsp_opcode_second_parameter];
		if (r > ready)
		{
			ready = r;
			wait_is_ext = dsp_reg_ready_ext[dsp_opcode_second_parameter];
		}
	}
	wait = (uint32_t)(ready - dsp_pipe_clock);
	if (wait < 1 && dsp_pipe_prev_dest != 0xFF)
	{
		if ((sb1 && dsp_opcode_first_parameter == dsp_pipe_prev_dest)
		 || (sb2 && dsp_opcode_second_parameter == dsp_pipe_prev_dest))
			wait = 1;                       /* ALU RAW interlock (R2) */
		else if ((f & 1) && (f & 2)
		      && !((f & 8) && dsp_opcode_second_parameter == dsp_pipe_prev_dest))
			/* Write-back port conflict (JTRM v8 p.35 "Register
			 * Write-Back"; Verilator §14): two register reads, neither
			 * the pending write-back target.  An unscoreboarded read of
			 * the target still conceals the write-back -- the port rule
			 * is about addresses, not the scoreboard. */
			wait = 1;
	}
	if (wait < 1 && dsp_pipe_prev_flags)
	{
		/* addc(1)/subc(5) always read carry; jump(52)/jr(53) read the
		 * flags only for a real condition (cc field != 0). */
		if (index == 1 || index == 5
		   || ((index == 52 || index == 53) && dsp_opcode_second_parameter != 0))
			wait = 1;                       /* flags interlock (R3) */
	}
	extra = 0;
	if (index == 38)                          extra = 2;  /* movei: 3 ticks */
	else if (index == 43 || index == 44
	      || index == 58 || index == 59)      extra = 2;  /* indexed load */
	else if (index == 49 || index == 50
	      || index == 60 || index == 61)      extra = 1;  /* indexed store */
	if (wait)
	{
		if (wait_is_ext)
			dsp_bus_stall += wait;
		else
			dsp_pipe_core_stall += wait;
		dsp_pipe_stall_total += wait;
	}
	if (extra)
	{
		dsp_pipe_core_stall += extra;
		dsp_pipe_stall_total += extra;
	}
}

/* A load/store opcode touched `addr` -- GPUPipeMemAccess() with the
 * DSP's local decode and JERRY's 16-bit external interface.  Local
 * space never uses the gateway (3-tick non-blocking load, engine takes
 * one op per 2 ticks); anything else is a split-transaction external
 * transfer with two pending slots, a store first drains pending loads,
 * the issue phase serializes back-to-back memops, and only USE of the
 * result (or slot exhaustion) blocks. */
static void DSPPipeMemAccess(uint32_t addr, int isLoad, int isLong)
{
	uint64_t t, t0, done;
	uint32_t cost;
	int slot;

	addr &= 0xFFFFFF;
	t0 = dsp_pipe_clock + dsp_bus_stall + dsp_pipe_core_stall;
	t  = t0;
	if (addr >= DSP_PIPE_LOCAL_LO && addr <= DSP_PIPE_LOCAL_HI)
	{
		if (dsp_local_busy_until > t)
			t = dsp_local_busy_until;
		dsp_local_busy_until = t + DSP_PIPE_LOCAL_REPEAT;
		if (isLoad)
		{
			dsp_reg_ready[dsp_opcode_second_parameter] = t + DSP_PIPE_LOCAL_LOAD;
			dsp_reg_ready_ext[dsp_opcode_second_parameter] = 0;
		}
		/* Local RAM is clocked at the DSP clock: core time. */
		if (t > t0)
		{
			dsp_pipe_core_stall += (uint32_t)(t - t0);
			dsp_pipe_stall_total += t - t0;
		}
		return;
	}
	dsp_pipe_ext_total++;
	if (!isLoad)
	{
		/* Store: wait out every pending load first. */
		if (dsp_ext_done[0] > t) t = dsp_ext_done[0];
		if (dsp_ext_done[1] > t) t = dsp_ext_done[1];
	}
	else if (dsp_ext_done[0] > t && dsp_ext_done[1] > t)
	{
		/* Both slots pending: third load waits for the earlier one. */
		t = (dsp_ext_done[0] < dsp_ext_done[1]) ? dsp_ext_done[0]
		                                        : dsp_ext_done[1];
	}
	if (dsp_gate_issue_free > t)
		t = dsp_gate_issue_free;
	if (t > t0)
	{
		dsp_bus_stall += (uint32_t)(t - t0);
		dsp_pipe_stall_total += t - t0;
	}
	cost = bus_arbiter_dsp_access(addr, isLong);
	done = t + DSP_PIPE_EXT_ISSUE + DSP_PIPE_GRANT_CLKS + cost
	     + (isLoad ? DSP_PIPE_EXT_RETURN : 0);
	dsp_gate_issue_free = t + DSP_PIPE_EXT_ISSUE;
	slot = (dsp_ext_done[0] <= dsp_ext_done[1]) ? 0 : 1;
	dsp_ext_done[slot] = done;
	if (isLoad)
	{
		dsp_reg_ready[dsp_opcode_second_parameter] = done;
		dsp_reg_ready_ext[dsp_opcode_second_parameter] = 1;
	}
}

/* Which timing model the current timed slice runs: 1 dram_timing
 * self-cost, 2 the pipeline model.  Latched at DSPExecTimed() entry from
 * the two options, which only check_variables() changes between
 * retro_run() calls (the #532 reasoning).  Read only on the timed path;
 * the untimed DSPExec() loop never touches it. */
static uint8_t dsp_mem_timed = 0;

#if defined(__GNUC__) || defined(__clang__)
#define DSP_NOINLINE __attribute__((noinline))
#elif defined(_MSC_VER) && _MSC_VER >= 1400
#define DSP_NOINLINE __declspec(noinline)
#else
#define DSP_NOINLINE
#endif

/* Model on: gateway + scoreboard semantics above (the access runs in
 * the background).  dram_timing only: the immediate self-cost the GPU
 * pays in the same configuration (GPU_EXT_ACCESS). */
static DSP_NOINLINE void DSPMemTimed(uint32_t addr, int isLoad, int isLong)
{
	if (dsp_mem_timed == 2)
		DSPPipeMemAccess(addr, isLoad, isLong);
	else
		dsp_bus_stall += bus_arbiter_dsp_access(addr, isLong);
}


/* Cycles to deduct for the instruction that just executed on a timed
 * slice (dsp_mem_timed != 0).  Kept out of DSPExec's loop so the
 * untimed path there is exactly the legacy table lookup. */
static DSP_NOINLINE int32_t DSPTimedCharge(uint32_t index, uint32_t riscScale)
{
	uint32_t bus = dsp_bus_stall;
	int32_t cost;

	if (dsp_mem_timed == 2)
	{
		/* Base cost 1 (R1) replaces the legacy table under the model
		 * -- see the model header.  Core stalls are already in the
		 * DSP's own cycle domain; bus stalls are wall time and are
		 * rescaled under risc_clock_scale (bus_arbiter.h contract). */
		dsp_pipe_clock += 1u + (uint64_t)dsp_bus_stall + dsp_pipe_core_stall;
		dsp_pipe_prev_dest =
			(dsp_pipe_flags[index] & 4) ? (uint8_t)dsp_opcode_second_parameter
			                            : (uint8_t)0xFF;
		dsp_pipe_prev_flags = dsp_pipe_sets_flags[index];
		/* DIV runs 16 background ticks; only USE of the quotient
		 * blocks (R15). */
		if (index == 21)
		{
			dsp_reg_ready[dsp_opcode_second_parameter] =
				dsp_pipe_clock + DSP_PIPE_DIV_TICKS;
			dsp_reg_ready_ext[dsp_opcode_second_parameter] = 0;
		}
		cost = 1 + (int32_t)dsp_pipe_core_stall;
	}
	else
		cost = dsp_opcode_cycles[index];   /* dram_timing: legacy base */
	if (bus != 0 && riscScale != 100u)
	{
		dsp_stall_scale_accum += bus * riscScale;
		bus = dsp_stall_scale_accum / 100u;
		dsp_stall_scale_accum %= 100u;
	}
	dsp_bus_stall = 0;
	dsp_pipe_core_stall = 0;
	return cost + (int32_t)bus;
}



// Private function prototypes

void FlushDSPPipeline(void);


void dsp_reset_stats(void)
{
}

void DSPReleaseTimeslice(void)
{
	dsp_releaseTimeSlice_flag = 1;
}

void dsp_build_branch_condition_table(void)
{
   unsigned i, j;

	/* Fill in the mirror table */

	for(i=0; i<65536; i++)
	{
		mirror_table[i] = ((i >> 15) & 0x0001) | ((i >> 13) & 0x0002)
			| ((i >> 11) & 0x0004) | ((i >> 9)  & 0x0008)
			| ((i >> 7)  & 0x0010) | ((i >> 5)  & 0x0020)
			| ((i >> 3)  & 0x0040) | ((i >> 1)  & 0x0080)
			| ((i << 1)  & 0x0100) | ((i << 3)  & 0x0200)
			| ((i << 5)  & 0x0400) | ((i << 7)  & 0x0800)
			| ((i << 9)  & 0x1000) | ((i << 11) & 0x2000)
			| ((i << 13) & 0x4000) | ((i << 15) & 0x8000);
	}

	// Fill in the condition table
	for(i=0; i<8; i++)
	{
		for(j=0; j<32; j++)
		{
			int result = 1;

			if ((j & 1) && (i & ZERO_FLAG))
				result = 0;

			if ((j & 2) && (!(i & ZERO_FLAG)))
				result = 0;

			if ((j & 4) && (i & (CARRY_FLAG << (j >> 4))))
				result = 0;

			if ((j & 8) && (!(i & (CARRY_FLAG << (j >> 4)))))
				result = 0;

			dsp_branch_condition_table[i * 32 + j] = result;
		}
	}
}

uint8_t DSPReadByte(uint32_t offset, uint32_t who/*=UNKNOWN*/)
{
	if (offset >= DSP_WORK_RAM_BASE && offset <= (DSP_WORK_RAM_BASE + 0x1FFF))
		return dsp_ram_8[offset - DSP_WORK_RAM_BASE];

	if (offset >= DSP_CONTROL_RAM_BASE && offset <= (DSP_CONTROL_RAM_BASE + 0x1F))
	{
		uint32_t data = DSPReadLong(offset & 0xFFFFFFFC, who);

		if ((offset&0x03)==0)
			return(data>>24);
		else
		if ((offset&0x03)==1)
			return((data>>16)&0xff);
		else
		if ((offset&0x03)==2)
			return((data>>8)&0xff);
		else
		if ((offset&0x03)==3)
			return(data&0xff);
	}

	return JaguarReadByte(offset, who);
}

uint16_t DSPReadWord(uint32_t offset, uint32_t who/*=UNKNOWN*/)
{
	offset &= 0xFFFFFFFE;

	if (offset >= DSP_WORK_RAM_BASE && offset <= DSP_WORK_RAM_BASE+0x1FFF)
	{
		uint16_t val;
		offset -= DSP_WORK_RAM_BASE;
		val = GET16(dsp_ram_8, offset);

		/* HLE sound-engine auto-ack (see DSPReadLong for details). */
		if (val != 0 && who == M68K && !DSP_RUNNING
				&& !vjs.useJaguarBIOS
				&& offset >= DSP_SOUND_CMD_BASE && offset < DSP_SOUND_CMD_END)
		{
			SET16(dsp_ram_8, offset, 0);
			return 0;
		}

		return val;
	}
	else if ((offset>=DSP_CONTROL_RAM_BASE)&&(offset<DSP_CONTROL_RAM_BASE+0x20))
	{
		uint32_t data = DSPReadLong(offset & 0xFFFFFFFC, who);

		if (offset & 0x03)
			return data & 0xFFFF;
      return data >> 16;
	}

	return JaguarReadWord(offset, who);
}

uint32_t DSPReadLong(uint32_t offset, uint32_t who/*=UNKNOWN*/)
{
   offset &= 0xFFFFFFFC;

   if (offset >= DSP_WORK_RAM_BASE && offset <= DSP_WORK_RAM_BASE + 0x1FFF)
   {
      uint32_t val;
      offset -= DSP_WORK_RAM_BASE;
      val = GET32(dsp_ram_8, offset);

      /* HLE sound-engine auto-ack:
       *
       * The real Jaguar BIOS loads a DSP sound engine into DSP RAM at
       * boot; that engine acknowledges command words by clearing flag
       * long words in the DSP_SOUND_CMD_BASE..DSP_SOUND_CMD_END region.
       * Cart-side audio code writes a non-zero command, then polls the
       * same word for it to go back to zero before issuing the next
       * one.  In HLE mode the BIOS engine isn't loaded and the DSP may
       * not even be running, so the cart spins forever polling
       * non-zero values.
       *
       * This is a workaround, NOT a real fix: it satisfies the polling
       * loop at the cost of dropping every command word the cart ever
       * writes (the engine never gets to mix anything because the
       * engine isn't there).  Audio is silent, but the game proceeds
       * past sound-init.
       *
       * Conditions:
       *   - val != 0    : only clear actual pending writes, not idle reads
       *   - who == M68K : only the cart's polling, not internal accesses
       *   - !DSP_RUNNING: the engine is absent / not consuming the cmd
       *   - !useJaguarBIOS: real BIOS path runs the engine, so don't
       *                     interfere there
       *   - offset in command range
       *
       * TODO(v2.3): remove this once the BIOS DSP audio engine is
       * properly replicated in HLE (Wolf3D / Skyhammer / IS2 family in
       * docs/emulation-bug-hunt-todos.md).  At that point the engine
       * will clear these words for real and we won't need the stub. */
      if (val != 0 && who == M68K && !DSP_RUNNING
            && !vjs.useJaguarBIOS
            && offset >= DSP_SOUND_CMD_BASE && offset < DSP_SOUND_CMD_END)
      {
         SET32(dsp_ram_8, offset, 0);
         return 0;
      }

      return val;
   }
   if (offset >= DSP_CONTROL_RAM_BASE && offset <= DSP_CONTROL_RAM_BASE + 0x23)
   {
      offset &= 0x3F;
      switch (offset)
      {
         case 0x00:
            dsp_flags = (dsp_flags & 0xFFFFFFF8) | (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;
            return dsp_flags & 0xFFFFC1FF;
         case 0x04:
            return dsp_matrix_control;
         case 0x08:
            return dsp_pointer_to_matrix;
         case 0x0C:
            return dsp_data_organization;
         case 0x10:
            return dsp_pc;
         case 0x14:
            /* HLE: When the 68K tight-polls DSPGO, auto-clear it.
             * The real BIOS+I2S infrastructure lets DSP programs
             * finish during SoundCallback; in HLE mode the DSP may
             * not terminate because it depends on BIOS-initialized
             * state.  A threshold of 8192 catches tight boot-time
             * poll loops (tens of thousands of reads/frame) while
             * ignoring normal gameplay status checks (~1-10/frame).
             *
             * Exception: if the DSP is actively producing audio
             * (non-zero LTXD/RTXD samples beyond the DACPrepareFrame
             * seed), it is running a legitimate audio mixer (e.g.
             * Doom) and must not be killed.  Issue #181 (Battle
             * Sphere): the silenced/escaped DSP still issues STORE
             * 0,RTXD per loop iteration, so we gate on non-zero
             * sample count, not raw write count. */
            if (who == M68K && DSP_RUNNING && !vjs.useJaguarBIOS)
            {
               /* "Real audio" gate: a DSP that's mixing for the user
                * writes non-zero LTXD/RTXD samples.  The non-zero
                * counter is reset to 0 at every DACPrepareFrame
                * (unlike i2sWriteCount which is seeded to 2 for the
                * resampler), so any non-zero sample this frame is
                * enough to declare the engine alive.  A DSP that
                * wrote only silence -- Battle Sphere with an escaped
                * DSP still issuing STORE 0,RTXD per loop iteration --
                * stays at 0 and the auto-clear correctly fires.
                * Counter ticks when either channel is non-zero. */
               if (DACGetI2SNonZeroCount() > 0)
                  dspgo_poll_count = 0;
               else
               {
                  dspgo_poll_count++;
                  if (dspgo_poll_count > DSPGO_POLL_THRESHOLD)
                  {
                     dsp_control &= ~0x01;
                     dspgo_poll_count = 0;
                  }
               }
            }
            else
               dspgo_poll_count = 0;
            return dsp_control;
         case 0x18:
            return dsp_modulo;
         case 0x1C:
            return dsp_remain;
         case 0x20:
            return (int32_t)((int8_t)(dsp_acc >> 32));	// Top 8 bits of 40-bit accumulator, sign extended
      }
      // unaligned long read-- !!! FIX !!!
      return 0xFFFFFFFF;
   }

   return JaguarReadLong(offset, who);
}

void DSPWriteByte(uint32_t offset, uint8_t data, uint32_t who/*=UNKNOWN*/)
{
   if ((offset >= DSP_WORK_RAM_BASE) && (offset < DSP_WORK_RAM_BASE+0x2000))
   {
      offset -= DSP_WORK_RAM_BASE;
      dsp_ram_8[offset] = data;
      return;
   }
   if ((offset >= DSP_CONTROL_RAM_BASE) && (offset < DSP_CONTROL_RAM_BASE+0x20))
   {
      uint32_t reg = offset & 0x1C;
      int bytenum = offset & 0x03;

      if ((reg >= 0x1C) && (reg <= 0x1F))
         dsp_div_control = (dsp_div_control & (~(0xFF << (bytenum << 3)))) | (data << (bytenum << 3));
      else
      {
         //This looks funky. !!! FIX !!!
         uint32_t old_data = DSPReadLong(offset&0xFFFFFFC, who);
         bytenum = 3 - bytenum; // convention motorola !!!
         old_data = (old_data & (~(0xFF << (bytenum << 3)))) | (data << (bytenum << 3));
         DSPWriteLong(offset & 0xFFFFFFC, old_data, who);
      }
      return;
   }

   JaguarWriteByte(offset, data, who);
}

void DSPWriteWord(uint32_t offset, uint16_t data, uint32_t who/*=UNKNOWN*/)
{
   offset &= 0xFFFFFFFE;

   if ((offset >= DSP_WORK_RAM_BASE) && (offset < DSP_WORK_RAM_BASE+0x2000))
   {
      /* CDDA-DIAG: see DSPWriteLong -- Primal Rage synth mailbox.
       * Rate-capped: other titles may use this RAM range as data. */
      if (offset >= 0xF1B270 && offset <= 0xF1B277)
      {
         static uint32_t mboxWrites = 0;
         mboxWrites++;
         if (mboxWrites <= 40 || (mboxWrites % 10000) == 0)
            LOG_DBG("[CDDA] DSP mailbox write.w $%06X = $%04X who=%u 68kpc=$%06X\n",
                    offset, data, who, m68k_get_reg(NULL, M68K_REG_PC));
         /* One-shot main-RAM snapshot at the mix-ON edge so the transient
          * music-player overlay around the writer PC can be disassembled.
          * Enabled only when VJ_CDDA_SNAPDIR is set (diagnostic builds). */
         if (offset == 0xF1B276 && data == 0x0001)
         {
            const char *dir = getenv("VJ_CDDA_SNAPDIR");
            static int snapped = 0;
            if (dir && !snapped)
            {
               char path[1024];
               FILE *f;
               snapped = 1;
               snprintf(path, sizeof(path), "%s/mixon_mainram.bin", dir);
               f = fopen(path, "wb");
               if (f)
               {
                  fwrite(jaguarMainRAM, 1, 0x200000, f);
                  fclose(f);
                  LOG_DBG("[CDDA] snapshot: %s\n", path);
               }
            }
         }
      }
      offset -= DSP_WORK_RAM_BASE;
      dsp_ram_8[offset] = data >> 8;
      dsp_ram_8[offset+1] = data & 0xFF;
      //CC only!
      return;
   }
   else if ((offset >= DSP_CONTROL_RAM_BASE) && (offset < DSP_CONTROL_RAM_BASE+0x20))
   {
      if ((offset & 0x1C) == 0x1C)
      {
         if (offset & 0x03)
            dsp_div_control = (dsp_div_control & 0xFFFF0000) | (data & 0xFFFF);
         else
            dsp_div_control = (dsp_div_control & 0xFFFF) | ((data & 0xFFFF) << 16);
      }
      else
      {
         uint32_t old_data = DSPReadLong(offset & 0xFFFFFFC, who);

         if (offset & 0x03)
            old_data = (old_data & 0xFFFF0000) | (data & 0xFFFF);
         else
            old_data = (old_data & 0xFFFF) | ((data & 0xFFFF) << 16);

         DSPWriteLong(offset & 0xFFFFFFC, old_data, who);
      }

      return;
   }

   JaguarWriteWord(offset, data, who);
}

void DSPWriteLong(uint32_t offset, uint32_t data, uint32_t who/*=UNKNOWN*/)
{
   offset &= 0xFFFFFFFC;

   if (offset >= DSP_WORK_RAM_BASE && offset <= DSP_WORK_RAM_BASE + 0x1FFF)
   {
      /* CDDA-DIAG: Primal Rage's synth-DSP command mailbox lives at
       * $F1B274 (cmd 1 = CD mix ON, 2 = OFF, 3 = reset, 4 = exit) --
       * log external writes so we can see who opens the mix gate.
       * Rate-capped: other titles may use this RAM range as data. */
      if (offset >= 0xF1B270 && offset <= 0xF1B277)
      {
         static uint32_t mboxWritesL = 0;
         mboxWritesL++;
         if (mboxWritesL <= 40 || (mboxWritesL % 10000) == 0)
            LOG_DBG("[CDDA] DSP mailbox write $%06X = $%08X who=%u 68kpc=$%06X\n",
                    offset, data, who, m68k_get_reg(NULL, M68K_REG_PC));
      }
      offset -= DSP_WORK_RAM_BASE;
      SET32(dsp_ram_8, offset, data);
      //CC only!
      return;
   }
   else if (offset >= DSP_CONTROL_RAM_BASE && offset <= (DSP_CONTROL_RAM_BASE + 0x1F))
   {
      offset &= 0x1F;
      switch (offset)
      {
         case 0x00:
            {
               /* OR, not assign: a host write to D_FLAGS must not drop
                * an interrupt DSPSetIRQLine latched for the next
                * instruction boundary.  Re-checking is always safe --
                * DSPHandleIRQsNP takes nothing that is masked, disabled
                * or not latched. */
               IMASKCleared = IMASKCleared
                  || ((dsp_flags & IMASK) && !(data & IMASK));
               dsp_flags = (data & ~IMASK) | ((data & IMASK) ? (dsp_flags & IMASK) : 0);
               dsp_flag_z = dsp_flags & 0x01;
               dsp_flag_c = (dsp_flags >> 1) & 0x01;
               dsp_flag_n = (dsp_flags >> 2) & 0x01;
               /* A D_FLAGS store issued by the DSP itself does not retire
                * until the instruction behind it is already past Read
                * Operands.  JTRM (docs/jtrm-gpu-dsp.md, "Pipeline") gives
                * the RISC core four stages -- Decode, Read Operands,
                * Compute, Write-back -- and JTRM v8 p.109 (p.59 for the
                * GPU) warns that "writing a value to the flag bits and
                * making use of those flag bits in the following
                * instruction will not work properly due to pipe-lining
                * effects", asking for at least one other instruction in
                * between.  So the instruction already in flight behind
                * the store still runs with the OLD flags:
                *
                *  - Its register operands, sources AND destination, are in
                *    the PRE-store bank.  The bank switch is deferred here
                *    and committed by DSPExec once the delay runs out, so
                *    nothing per-operand is needed.  Two shipped shapes
                *    depend on it:
                *      Wolfenstein 3D's I2S epilogue at $F1B24E
                *        store  r0,(r1)     ; r1 = $F1A100, clears IMASK
                *        jump   (r3)        ; r3 = bank-0 return address
                *      with its main loop in bank 1 (REGPAGE set): reading
                *      bank 1's r3 == 0 returned the DSP to PC $000000.
                *      Music Demo (ScatoLOGIC) entry at $F1B020 (#853)
                *        store  rX,(rY)     ; D_FLAGS: REGPAGE=1, I2S enable
                *        movei  #$F1B00C,r31
                *      whose I2S ISR then does `load (r31),r28` in bank 0:
                *      writing the movei into bank 1 left bank-0 r31 == 0,
                *      the first interrupt pushed to $FFFFFFFC and the DSP
                *      escaped at frame 5.
                *
                *  - IMASK is not really clear until the store retires
                *    either, so that same slot still runs masked and cannot
                *    be preempted.  Wolf3D's outer epilogue at
                *    $F1B128-$F1B12A has the same store/jump shape; letting
                *    an I2S interrupt in between the two made the handler
                *    push the store's own address as the return address.
                *
                * A taken branch commits the switch at its redirect
                * (dsp_opcode_jump/jr): the inline delay slot is already
                * the second instruction behind the store, and Doom's
                * epilogue puts the D_FLAGS store IN the delay slot of
                * `jump (r15)` at $F1B028, so the branch target at $F1B6B2
                * -- a `movei` whose write-back follows the store's --
                * must land in the NEW bank.
                *
                * WINDOW LENGTH: the store plus ONE instruction
                * (DSP_FLAGS_RETIRE_DELAY = 2), i.e. JTRM v8's "at least
                * one other instruction".  The stricter counts -- Software
                * Reference v2.4 p.46 "two, or four for an indexed STORE",
                * Hardware Bugs & Warnings #11 "two NOPs" -- are read as
                * programmer safety margins, not as the modelled latency:
                * this is the length d220aa2 validated on Wolf3D and Doom,
                * Music Demo needs exactly one slot, and no title so far
                * needs a second.  The extra latency of an indexed store
                * is not modelled.
                *
                * CAVEAT on the derivation: nothing in docs/jtrm-*.md
                * describes the taken-branch refill cost that lets a
                * delay-slot store retire before the branch target reads
                * registers, and dsp_opcode_cycles[] charges jump/jr only
                * 1 cycle.  The branch rule is inferred from behaviour: it
                * is the only composite that satisfies Wolf3D's
                * `store; jump (Rn)` and Doom's `jump (Rn); store` at once.
                * Revisit if primary JTRM pipeline timing contradicts it.
                *
                * Host (68K/GPU) writes are not in the DSP pipeline and
                * switch the bank at once. */
               if (who == DSP)
                  dspFlagsRetireDelay = DSP_FLAGS_RETIRE_DELAY;
               else
               {
                  DSPUpdateRegisterBanks();
                  dspFlagsRetireDelay = 0;
               }
               dsp_control &= ~((dsp_flags & CINT04FLAGS) >> 3);
               dsp_control &= ~((dsp_flags & CINT5FLAG) >> 1);
               break;
            }
         case 0x04:
            dsp_matrix_control = data;
            break;
         case 0x08:
            // According to JTRM, only lines 2-11 are addressable, the rest being
            // hardwired to $F1Bxxx.
            dsp_pointer_to_matrix = 0xF1B000 | (data & 0x000FFC);
            break;
         case 0x0C:
            dsp_data_organization = data;
            break;
         case 0x10:
            dsp_pc = data;
            //CC only!
            //!!!!!!!!
            break;
         case 0x14:
            {
               uint32_t mask;
               bool wasRunning = DSP_RUNNING;
               dspgo_poll_count = 0;
               // Check for DSP -> CPU interrupt
               if (data & CPUINT)
               {
                  if (JERRYIRQEnabled(IRQ2_DSP))
                  {
                     JERRYSetPendingIRQ(IRQ2_DSP);
                     DSPReleaseTimeslice();
                     /* JERRY has no wire of its own to the 68K: the DSP
                        interrupt merges with every other JERRY source
                        onto DINT, which enters TOM as INT1 bit 4
                        (C_JERENA).  The latch above stays outside this
                        gate, so a later C_JERENA write still delivers
                        via TOMWriteByte's newlyEnabled & TOMPendingMask()
                        path -- withheld, not lost.  Same gate as
                        JERRYPIT1Callback/JERRYPIT2Callback and
                        UARTRaiseIRQ. */
                     if (TOMIRQEnabled(IRQ_DSP))
                        m68k_set_irq(2);		// Set 68000 IPL 2...
                  }
                  data &= ~CPUINT;
               }
               // Check for CPU -> DSP interrupt
               if (data & DSPINT0)
               {
                  /* Only deliver a CPU->DSP interrupt when the DSP is
                   * actually RUNNING (issue #635, White Men Can't Jump).
                   *
                   * The game stops its DSP by raising DSPINT0 -- its INT0
                   * handler is a shutdown routine ($F1B76A: disable
                   * INT_ENA0/1, clear the latches, write $20 to D_CTRL so
                   * DSPGO clears).  Its reload sequence is: stop, copy a
                   * fresh 2.5KB program over DSP RAM, set D_PC, set DSPGO.
                   *
                   * At the stop, DSPGO is ALREADY clear (the traced write
                   * is OR.L #4 over a prior value of $820, bit 0 = 0), so
                   * there is no running program to consume the interrupt.
                   * Delivered unconditionally, the latch survives into the
                   * NEWLY started program, which enables INT_ENA0/1 during
                   * its own init and immediately services it -- running the
                   * shutdown handler and stopping itself after ~1,319
                   * opcodes.  The 68K then posts command $0D to the mailbox
                   * at $F1B2C0, nothing ever consumes it, and the next
                   * caller spins forever at $01C306 waiting for it to clear.
                   * The GPU stops being fed and the picture freezes.
                   *
                   * The game cannot rely on the latch being cleared later:
                   * its start routine writes D_FLAGS <- 0, and JTRM Rev 8 is
                   * explicit that "writing a zero leaves them unchanged".
                   *
                   * JTRM Rev 8 does NOT state whether a CPU interrupt raised
                   * while the DSP is stopped latches -- the interrupt
                   * section describes the latches without reference to
                   * DSPGO.  This gate is therefore argued from behaviour,
                   * not from a manual line: the title demonstrably works on
                   * hardware, and it cannot if a stop-interrupt is still
                   * pending when its replacement program starts.  Worth
                   * confirming against hardware if anyone can. */
                  if (DSP_RUNNING)
                  {
                     m68k_end_timeslice();
                     DSPReleaseTimeslice();
                     DSPSetIRQLine(DSPIRQ_CPU, ASSERT_LINE);
                  }
                  data &= ~DSPINT0;
               }
               // Protect writes to VERSION and the interrupt latches...
               mask        = VERSION | INT_LAT0 | INT_LAT1 | INT_LAT2 | INT_LAT3 | INT_LAT4 | INT_LAT5;
               dsp_control = (dsp_control & mask) | (data & ~mask);

               if (DSP_RUNNING)
               {
                  if (who == M68K)
                     m68k_end_timeslice();
                  else if (who == DSP)
                     DSPReleaseTimeslice();

                  if (!wasRunning)
                     FlushDSPPipeline();
               }
               break;
            }
         case 0x18:
            dsp_modulo = data;
            break;
         case 0x1C:
            dsp_div_control = data;
            break;
      }
      return;
   }

   JaguarWriteLong(offset, data, who);
}

/* Update the DSP register file pointers depending on REGPAGE bit */
void DSPUpdateRegisterBanks(void)
{
	int bank = (dsp_flags & REGPAGE);

	if (dsp_flags & IMASK)
		bank = 0;							// IMASK forces main bank to be bank 0

	if (bank)
		dsp_reg = dsp_reg_bank_1, dsp_alternate_reg = dsp_reg_bank_0;
	else
		dsp_reg = dsp_reg_bank_0, dsp_alternate_reg = dsp_reg_bank_1;
}

/* Check for and handle any asserted DSP IRQs. */
void DSPHandleIRQsNP(void)
{
   uint32_t bits;
   uint32_t mask;
   int which = 0;									// Determine which interrupt
	if (dsp_flags & IMASK) 							// Bail if we're already inside an interrupt
		return;

	/* IMASK reads clear the moment the D_FLAGS store is decoded, but the
	 * store has not retired yet -- the instruction behind it is already
	 * past Read Operands and still runs masked (see DSPWriteLong).  DSPExec's
	 * loop-top caller already waits out the hold-off; this used to be
	 * reached asynchronously from DSPSetIRQLine too (no longer, #744), and
	 * stays as a guard for any caller outside that loop.  Leave the
	 * latch standing in dsp_control and IMASKCleared unconsumed: DSPExec
	 * dispatches it once the delay expires, at most two slots later.
	 *
	 * Without this, Wolfenstein 3D's I2S handler was re-entered between
	 * `store r0,(r1)` at $F1B24E and `jump (r3)` at $F1B250, so the nested
	 * handler returned to $F1B250 a slot late and `jump (r3)` read the
	 * post-store bank -- PC $000005, DSP off the rails at frame 2553. */
	if (dspFlagsRetireDelay && IMASKCleared)
		return;

	// Get the active interrupt bits (latches) & interrupt mask (enables)
	// INT_LAT5 is at dsp_control bit 16 (non-contiguous with LAT0-4 at bits 6-10)
	bits = ((dsp_control >> 11) & 0x20) | ((dsp_control >> 6) & 0x1F);
	mask = ((dsp_flags >> 11) & 0x20) | ((dsp_flags >> 4) & 0x1F);

	bits &= mask;

	if (!bits)										// Bail if nothing is enabled
		return;

	if (bits & 0x01)
		which = 0;
	if (bits & 0x02)
		which = 1;
	if (bits & 0x04)
		which = 2;
	if (bits & 0x08)
		which = 3;
	if (bits & 0x10)
		which = 4;
	if (bits & 0x20)
		which = 5;

	dsp_flags |= IMASK;		// Force Bank #0
	/* Taking an interrupt flushes the pipeline, so an un-retired D_FLAGS
	 * store from before the vector fetch has no in-flight successor left
	 * to shadow -- retire it rather than let it reach into the handler. */
	dspFlagsRetireDelay = 0;
	DSPUpdateRegisterBanks();

	/* Bank switch: the pipeline model tracks pending results per
	 * register number in the CURRENT bank, so dispatching into the
	 * other bank invalidates it (bounded, see the model header). */
	if (vjs.gpuPipelineTiming)
		DSPPipeTimingReset();

	dsp_reg[31] -= 4;
	dsp_reg[30] = dsp_pc - 2; // -2 because we've executed the instruction already

	DSPWriteLong(dsp_reg[31], dsp_reg[30], DSP);

	dsp_pc = dsp_reg[30] = DSP_WORK_RAM_BASE + (which * 0x10);
}

//
// Set the specified DSP IRQ line to a given state
//
void DSPSetIRQLine(int irqline, int state)
{
	uint32_t mask = (irqline < 5) ? (INT_LAT0 << irqline) : INT_LAT5;
	dsp_control &= ~mask;

	if (state)
	{
		dsp_control |= mask;
		/* Latch now, vector later: the DSP takes the interrupt itself at
		 * its next instruction boundary (DSPExec's loop-top re-check),
		 * not here.  JTRM Rev 8 p.38: an interrupt "forces a call" into
		 * the instruction stream and pushes "the address of the last
		 * instruction to be executed before the interrupt occurred" --
		 * it is something the running DSP does, so a stopped DSP takes
		 * nothing until DSPGO and an event callback must not move the
		 * PC on its behalf.
		 *
		 * Vectoring synchronously from the event (JERRY I2S/PIT
		 * callbacks run between scheduler slices) made the interrupt
		 * visible to the 68000 for its entire next slice before the DSP
		 * had executed a single cycle of the handler.  Club Drive
		 * (#744) rewrites D_PC to $F1B030 from the 68000 at $807CE8
		 * while DSPGO=1 (JTRM Rev 8 p.110 only promises D_PC writes
		 * "whenever the DSP is idle"); when that write landed in the slice right
		 * after an I2S event it found PC parked on the $F1B010 vector
		 * with IMASK set, restarted the DSP's init with IMASK still
		 * set (the init's read-modify-write of D_FLAGS writes the 1
		 * back), and no interrupt was ever serviced again: LTXD stayed
		 * 0 forever.  Which I2S phase the HLE boot happened to have
		 * decided it -- 5 of 97 swept phases were silent, and the BIOS
		 * boot merely had a lucky one.  For a running DSP the loop-top
		 * re-check normally runs at the same DSP time the synchronous
		 * call used to, with the same return address (dsp_pc - 2).  Two
		 * exceptions: a deferred interrupt waits out an in-flight
		 * DSP-issued D_FLAGS store (at most one instruction in real
		 * code, see DSP_FLAGS_RETIRE_DELAY), and a stopped DSP is not
		 * vectored until DSPGO.
		 *
		 * IMASKCleared doubles as "re-check pending interrupts at the
		 * next boundary"; it already respects the D_FLAGS retire
		 * hold-off, already gates the #569 idle-loop probe, and is
		 * already in the savestate, so a latch raised in the last event
		 * of a frame survives serialization. */
		IMASKCleared = true;
	}
}

bool DSPIsRunning(void)
{
	return (DSP_RUNNING ? true : false);
}

uint8_t * DSPGetRAM(void)
{
	return dsp_ram_8;
}

uint32_t DSPGetFlags(void)
{
	return dsp_flags;
}

/* Write side of DSPGetFlags, added for the GDB stub (issue #652). A raw
 * poke of dsp_flags -- see GPUSetFlags in src/tom/gpu.c for why this
 * bypasses the D_FLAGS MMIO write path (interrupt-mask side effects a
 * debugger write should not trigger as a side effect of merely wanting
 * to see a different N/C/Z combination). */
void DSPSetFlags(uint32_t v)
{
	dsp_flags = v;
}

/* DSPGetPC/DSPSetPC, added for the GDB stub (issue #652): dsp_pc had no
 * accessor at all before this (GPU's equivalent, GPUGetPC, predates
 * vjtrace -- issue #406). Raw poke on the write side, like GPUSetPC. */
uint32_t DSPGetPC(void)
{
	return dsp_pc;
}

void DSPSetPC(uint32_t pc)
{
	dsp_pc = pc;
}

/* Diagnostic-only accessor, added for `monitor regs dsp` (the GDB stub,
 * issue #652): the raw D_CTRL value, read-only -- see GPUGetControl in
 * src/tom/gpu.c for why the write side is not exposed. */
uint32_t DSPGetControl(void)
{
	return dsp_control;
}

/* Originally vjtrace-only (#408) and gated behind VJ_TRACE, like GPU's
 * GPUGetReg was NOT (issue #406, pre-existing). The GDB stub (issue
 * #652) needs DSPGetReg in every build (shipped-by-default, off by
 * default -- see docs/gdb-stub-design.md), so it is unconditional now,
 * matching GPUGetReg. This does not change the shipped dylib's exported
 * symbol list -- production links still use exports.list, which never
 * listed either accessor. */
uint32_t DSPGetReg(int n)
{
	if (n < 0 || n > 31)
		return 0;
	return dsp_reg[n];
}

/* Write side of DSPGetReg, added for the GDB stub (issue #652). Pokes
 * the ACTIVE bank directly, mirroring GPUSetReg's reasoning in
 * src/tom/gpu.c: the $F1A000-range MMIO register window addresses both
 * banks unconditionally by register number, which is NOT what "the
 * current register file" means once REGPAGE has flipped. */
void DSPSetReg(int n, uint32_t v)
{
	if (n < 0 || n > 31)
		return;
	dsp_reg[n] = v;
}

void DSPInit(void)
{
	dsp_build_branch_condition_table();
	DSPReset();
}

void DSPReset(void)
{
   unsigned i;

	dsp_pc				  = 0x00F1B000;
	dspgo_poll_count	  = 0;
	dsp_load_wb_fixups	  = 0;
	dsp_div_store_fixups  = 0;
	DSPPipeTimingReset();
	dsp_pipe_stall_total  = 0;
	dsp_pipe_ext_total    = 0;
	dsp_ldx_slot		  = NULL;
	dsp_acc				  = 0x00000000;
	dsp_remain			  = 0x00000000;
	dsp_modulo			  = 0xFFFFFFFF;
	dsp_flags			  = 0x00040000;
	dsp_matrix_control    = 0x00000000;
	dsp_pointer_to_matrix = 0x00000000;
	dsp_data_organization = 0xFFFFFFFF;
	dsp_control			  = 0x00002000;				// Report DSP version 2
	dsp_div_control		  = 0x00000000;
	dsp_in_exec			  = 0;
	dspSliceBudget		  = 0;
	dspSliceSpent		  = 0;

	dsp_reg = dsp_reg_bank_0;
	dsp_alternate_reg = dsp_reg_bank_1;

	for(i=0; i<32; i++)
		dsp_reg[i] = dsp_alternate_reg[i] = 0x00000000;

	CLR_ZNC;
	IMASKCleared = false;
	dspFlagsRetireDelay = 0;
	FlushDSPPipeline();
	dsp_reset_stats();

	// Contents of local RAM are quasi-stable; we simulate this by randomizing RAM contents.
	// In HLE mode, zero-fill instead: the real BIOS loads a DSP sound engine that
	// initializes most of DSP RAM, and games may read locations they didn't write.
	if (vjs.useJaguarBIOS)
	{
		for(i=0; i<DSP_RAM_SIZE; i+=4)
		{
			uint32_t r = JaguarRand();
			memcpy(&dsp_ram_8[i], &r, sizeof(r));
		}
	}
	else
	{
		memset(dsp_ram_8, 0, DSP_RAM_SIZE);
	}
}

void DSPDone(void)
{
}

void DSPBeginSlice(uint32_t riscCycles)
{
	dspSliceBudget = (int32_t)riscCycles;
	dspSliceSpent  = 0;
}

int32_t DSPSliceRemaining(void)
{
	int32_t left = dspSliceBudget - dspSliceSpent;
	return (left > 0 ? left : 0);
}

/* Advance the DSP to the 68000's position inside the current slice.
 * Mirror of GPUSyncToM68K (issue #406 / PR #445): without this a 68K
 * poll of a DSP mailbox samples stale state from the previous slice,
 * which is #408 H3 and issue #456.  Same 2:1 RISC:68K clock ratio. */
void DSPSyncToM68K(void)
{
	int32_t target, run;

	if (!DSP_RUNNING || dsp_in_exec)
		return;

	target = (int32_t)(((int64_t)m68k_cycles_run() * 2 * riscClockScalePct)
	                   / m68kClockScalePct);
	if (target > dspSliceBudget)
		target = dspSliceBudget;

	run = target - dspSliceSpent;
	if (run <= 0)
		return;

	/* Mirror of GPUSyncToM68K's probe -- see perf_iface.h. */
	dspSliceSpent += run;
	VJP_ENTER(VJP_DSP_SYNC);
	DSPExec(run);
	VJP_LEAVE(VJP_DSP_SYNC);
}

/* ==================================================================
 * Cycle-exact idle-loop fast-forward   (issue #569, perf audit P1)
 * ==================================================================
 *
 * Commercial titles park the DSP in a 3-5 instruction wait loop for
 * 74-99.7% of every frame while it still burns its whole 26.6 MHz
 * budget interpreting that loop (docs/perf-audit-2026-08.md, P1).  This
 * skips the provably redundant iterations.  It is NOT an approximation:
 * the registers, the flags, the PC, the cycles charged and
 * dsp_exec_opcode_count all end up exactly where the interpreter would
 * have left them.  Run-ahead, netplay and savestates depend on that.
 *
 * ---- SAFETY THEOREM (verified against this tree, not assumed) -------
 *
 * (Line numbers below are pre-patch, i.e. as of the parent commit, so
 * they line up with the file this block was written against.)
 *
 * (1) Nothing else in the machine executes inside one DSPExec() call.
 *     The slice budget is "time until the next scheduled event":
 *     JaguarExecuteNew() (src/core/jaguar.c:1683-1752) computes
 *     GetTimeToNextEvent(), runs the 68K and the GPU, then calls
 *     DSPExec(DSPSliceRemaining()); SubtractEventTimes() and
 *     HandleNextEvent() only run AFTER DSPExec returns.  The OP runs
 *     from a halfline event, i.e. also outside.  DSPSyncToM68K()
 *     (dsp.c:1045-1066) is a different, EARLIER DSPExec call with its
 *     own budget, not a re-entry -- it bails on dsp_in_exec.
 *
 * (2) No DSP interrupt can be dispatched mid-call for an admitted body.
 *     NOTE: unlike GPUExec, DSPExec has no slice-entry DSPHandleIRQs
 *     call at all.  The only in-loop dispatch is the
 *     `IMASKCleared && dspFlagsRetireDelay == 0` re-check at the top of
 *     DSPExec's loop below.  IMASKCleared is set by a store to
 *     D_FLAGS (dsp.c:698) -- which the admission rule excludes -- or by
 *     DSPSetIRQLine latching an interrupt (since #744 it no longer
 *     vectors there itself), reached from event callbacks between
 *     slices, per (1), or from a D_CTRL DSPINT0 store -- again a store.  The probe additionally requires
 *     IMASKCleared == false and dspFlagsRetireDelay == 0, so neither
 *     the pending-IRQ path nor the D_FLAGS retire countdown is live.
 *
 * (3) The register banks cannot move.  dsp_reg / dsp_alternate_reg are
 *     repointed only by DSPUpdateRegisterBanks(), reachable from a
 *     D_FLAGS write (dsp.c:756), from taking an interrupt
 *     (dsp.c:911), or from retiring a DSP-issued D_FLAGS store (the
 *     DSPExec countdown and the jump/jr redirect, #853) -- all excluded
 *     by (2), the last because it needs dspFlagsRetireDelay != 0.  The
 *     probe records the bank
 *     pointer at the first snapshot and re-checks it at the third.
 *
 * (4) DSP-side reads are pure.  The HLE sound-engine auto-ack in
 *     DSPReadWord/DSPReadLong (dsp.c:423/484) are gated `who == M68K`.
 *     The DSPGO poll auto-clear (dsp.c:526) tests `who == M68K` on the
 *     clearing branch but resets dspgo_poll_count on its `else`, so a
 *     DSP-side read of $F1A114 would touch that counter -- unreachable
 *     here, because the load-EA rule admits DSP local SRAM and DRAM
 *     only, never DSP_CONTROL_RAM_BASE.  Reads of
 *     main DRAM take JaguarReadLong's `addr < 0x800000` fast path
 *     (src/core/jaguar.c:1131-1141) whose only side effects are
 *     VJT_WATCH_RD (compiled out unless VJ_TRACE) and BlitMemoNoteRead
 *     (gated on blitMemoRecording); both are hard gates below.
 *     busArbiter is charged there only for `who == OP`.
 *
 * Therefore: if a loop body performs no store and reads only plain RAM,
 * every value it reads is constant for the remainder of the call, and
 * one iteration is a pure function of (register file, flags).
 *
 * NOTE the premise is about the instructions the machine ACTUALLY
 * executed between two arrivals at the loop head, not about the ones the
 * decoder walked.  Those are not the same thing for free: the probe is
 * only hooked on a taken backward jr, so a not-taken jr, a `jump` or
 * plain fall-through can carry execution back to `head` without the
 * probe ever seeing it.  The opcode-count identity in the proof below
 * (opcost == idleBodyCount + 1) is what closes that gap; without it a
 * compound period containing an undecoded store could satisfy every
 * other condition here.
 *
 * ---- ADMISSION RULE ------------------------------------------------
 *
 * Candidate: a TAKEN backward (or self-targeting) `jr` whose target is
 * at most 15 words behind (the jr's full reach), with the whole body
 * inside DSP local RAM.
 * Body = target .. jr inclusive, plus the inlined delay-slot
 * instruction.  Static decode (register-independent) requires:
 *   - every opcode on the whitelist below (no store of any kind, no
 *     accumulator/latency opcode, no `jump`), except that the body may
 *     contain EXIT branches: a `jr` before the loop-closing one whose
 *     target lies past the closing jr's delay slot (#952 -- Cybermorph
 *     polls two bits of a register with `btst ; jr NE,out ; nop ;
 *     btst ; jr EQ,head`).  An exit that is never taken leaves the
 *     body straight-line; the probe proves it was not taken (see the
 *     EXIT-BRANCH CHECK in DSPIdleLoopProbe) and the fixed-point proof
 *     below then proves it never will be;
 *   - or ONE internal forward jr instead of exits (#952, Iron Soldier 2:
 *     `sub r31,r28 ; jr NN,+2 ; sharq #2,r28 ; addq #31,r28`), whose
 *     target is an instruction after its delay slot and at most the
 *     closing jr, and whose delay slot is neither a movei nor a jr.  It
 *     splits the body into two routes, which the probe tells apart (see
 *     the INTERNAL-BRANCH CHECK); the fixed-point proof below makes it
 *     go the same way on every iteration;
 *   - the decode walk lands exactly on the jr, so every instruction is
 *     decoded (movei carries a 32-bit immediate, i.e. 3 words);
 *   - no movei in the delay slot (its immediate would be fetched from
 *     past the branch).
 * Register-dependent checks are deliberately deferred to the third
 * snapshot: control can enter a loop body part-way through, so at the
 * first snapshot a register written only in the early part of the body
 * may still hold pre-loop garbage, and a load EA computed from it would
 * be meaningless.  After two complete iterations the head state is
 * steady-state and the checks are authoritative.
 *
 * ---- FIXED-POINT PROOF ---------------------------------------------
 *
 * Snapshots S0/S1/S2 are taken at the loop head (immediately after the
 * taken jr's delay slot) on three consecutive arrivals, driven from
 * DSPExec's own loop -- the probe iterations are ordinary interpreted
 * execution, so no semantics are duplicated anywhere.  Extrapolate only
 * when all of:
 *   - the branch was taken all three times and landed on the same head
 *     from the same jr (a different loop appearing mid-probe aborts it);
 *   - elementwise S2-S1 == S1-S0 across BOTH register banks;
 *   - dsp_flag_z/n/c identical in S0, S1 and S2;
 *   - the measured cycle cost of iteration 1 equals iteration 2 (taken
 *     as the delta of `cycles`, never recomputed from
 *     dsp_opcode_cycles[] -- the inlined delay slot is not charged);
 *   - likewise the measured dsp_exec_opcode_count delta;
 *   - that measured opcode delta, together with the number of taken jrs
 *     per iteration, matches a route through the decoded body EXACTLY
 *     (idleBodyCount + 1 with one taken jr; with an internal jr, also
 *     K fewer with two) -- this is the executed-path check, see the
 *     comment at the test itself;
 *   - every register with a NONZERO per-iteration delta is read and
 *     written only by an addqt/subqt whose destination is that same
 *     register, or by an addq/subq onto itself whose flags are dead:
 *     fully overwritten on every route before anything reads a flag
 *     (dsp_idle_flags_dead).
 *
 * That last rule is what makes the branch unable to flip.  It is
 * strictly stronger than "the last flag-setting instruction reads only
 * zero-delta registers": addqt/subqt write no flags, and a dead-flag
 * addq/subq writes flags no instruction ever reads, so every flag value
 * that IS read comes from zero-delta operands, AND so does every load
 * base and every shift/rotate count.  Proof that the loop is then
 * affine forever: memory is constant by the theorem, so with all
 * zero-delta registers holding their S1 values and the flags holding
 * their S1 values, every instruction that does not touch a counter
 * register recomputes exactly the iteration-1 result -- hence flags and
 * zero-delta registers stay put -- while each counter register is only
 * ever incremented by a constant.  So iteration k's state is
 * S1 + (k-1)*delta for all k, and the branch condition never changes.
 * The same holds at every point INSIDE the body, so an exit jr sees the
 * same flags on every iteration: not taken from S1 to S2 (the probe
 * checks that) means not taken on any extrapolated iteration either, and
 * an internal jr goes the same way as it did from S1 to S2.
 *
 * Then n = (cycles_remaining / cost) - 1 (always leave one full
 * iteration to execute normally), reg += n*delta, cycles -= n*cost,
 * dsp_exec_opcode_count += n*opcodes (crash_detect's wedge predicate
 * reads that counter -- src/core/crash_detect.c:470-482 -- so a skipped
 * loop must still look like progress).  Flags and PC are already
 * correct by construction.  Nothing else is touched.
 *
 * Exit is automatic: the I2S/timer callback that eventually changes the
 * polled location runs between slices, the next probe fails, and normal
 * interpretation resumes.  No savestate impact -- every byte of probe
 * state is re-derived from scratch inside each DSPExec call.
 */

/* Longest body accepted, in instructions before the closing jr.  The
 * caller's `pcThis - dsp_pc <= 30` filter is the jr's full backward reach
 * (offset -16), which caps [head, jr) at 15 words (#952: Iron Soldier 2's
 * wait loop is 12), so this bound never binds. */
#define DSP_IDLE_MAX_BODY	15
/* Body instruction slots: <= 15 before the jr, plus the delay slot. */
#define DSP_IDLE_MAX_INSN	16
/* Per-slice reject memo: without it a loop that fails the fixed-point
 * test would be re-probed every three iterations for the whole slice. */
#define DSP_IDLE_MEMO		16

/* Effective addresses we will admit for a load: DSP local SRAM (the
 * range DSPReadLong itself serves out of dsp_ram_8 -- $F1B000-$F1CFFF,
 * note this is the full 8K, not the $F1BFFF the task brief quoted) or
 * main DRAM below the 2 MB aperture, where JaguarReadLong is a plain
 * GET32 of jaguarMainRAM. */
#define DSP_IDLE_EA_OK(ea) \
	(((ea) >= DSP_WORK_RAM_BASE && (ea) <= DSP_WORK_RAM_BASE + 0x1FFF) \
	 || ((ea) < 0x200000))

#define DSP_IDLE_FETCH(a) \
	((uint16_t)(((uint16_t)dsp_ram_8[(a) - DSP_WORK_RAM_BASE] << 8) \
	            | (uint16_t)dsp_ram_8[(a) - DSP_WORK_RAM_BASE + 1]))

/* Option gate (libretro `virtualjaguar_risc_idle_skip`) lives in vjs. */
/* Diagnostics: counted only on the cold probe path, never per opcode. */
uint32_t dsp_idle_skip_fires   = 0;		/* successful extrapolations */
uint32_t dsp_idle_skip_rejects = 0;		/* candidate loops turned down */
uint32_t dsp_idle_skip_iters   = 0;		/* iterations actually skipped */
uint32_t dsp_idle_skip_opcodes = 0;		/* opcodes NOT interpreted -- the
										 * honest, host-independent measure:
										 * dsp_exec_opcode_count is advanced
										 * over a skip on purpose, so it does
										 * NOT show the saving. */

/* Every taken `jr`, counted inside dsp_opcode_jr's taken branch rather
 * than in DSPExec's loop: a test there changed the loop's code generation
 * and cost Iron Soldier 2 +0.7% host instructions per frame (#952).  Here
 * it measured +0.35% on Iron Soldier 2 (jr-heavy DSP, no idle skip to win
 * back) and +0.09% on Doom.  Only differences are read, so it never needs
 * a reset. */
static uint32_t  dsp_jr_taken;

static int       idleProbeStage;		/* 0 = none, 1 = have S0, 2 = have S1 */
static uint32_t  idleProbeHead;
static uint32_t  idleProbeJr;
static uint32_t *idleProbeBank;			/* dsp_reg at S0 -- see theorem (3) */
static int32_t   idleProbeCyc0, idleProbeCyc1;
static uint32_t  idleProbeOpc0, idleProbeOpc1;
static uint32_t  idleProbeS0[64], idleProbeS1[64];
static uint32_t  idleProbeJrt0, idleProbeJrt1;	/* dsp_jr_taken at S0/S1 */
static uint64_t  idleProbeLdxFix;		/* dsp_load_wb_fixups at S0 */
static uint64_t  idleProbeDivFix;		/* dsp_div_store_fixups at S0 */
static uint8_t   idleProbeFz0, idleProbeFn0, idleProbeFc0;
static uint8_t   idleProbeFz1, idleProbeFn1, idleProbeFc1;

static uint8_t   idleBodyIdx[DSP_IDLE_MAX_INSN];
static uint8_t   idleBodyP1[DSP_IDLE_MAX_INSN];
static uint8_t   idleBodyP2[DSP_IDLE_MAX_INSN];
static uint32_t  idleBodyImm[DSP_IDLE_MAX_INSN];
static int       idleBodyCount;
/* The body's one INTERNAL forward jr (#952), or -1: idleIntJr is its body
 * index, and [idleIntFrom, idleIntTo) the body indices it jumps over when
 * taken (its delay slot, idleIntJr + 1, runs on both routes). */
static int       idleIntJr;
static int       idleIntFrom, idleIntTo;

static uint32_t  idleMemoHead[DSP_IDLE_MEMO];
static uint32_t  idleMemoJr[DSP_IDLE_MEMO];
static int       idleMemoCount;
static int       idleMemoNext;
/* The memo entry hit or added last.  Only trusted while idleMemoCount is
 * nonzero: it is written together with a memo insert or hit, so after the
 * per-slice memo reset it cannot name a loop until the memo holds that
 * loop again.  Lets the common case -- the same rejected loop coming
 * round again -- skip the scan (#952: probing every jr up to 15 words
 * back cost Doom +0.25% host instructions without it). */
static uint32_t  idleMemoLastHead, idleMemoLastJr;

/* Opcode whitelist.  Admit only what has been reasoned about; anything
 * absent is rejected, including every store (45/46/47/49/50/60/61), the
 * accumulator and long-latency opcodes (16-21, 23, 26, 54-56, 63, 32)
 * and both branches (52/53 -- the loop's own jr is handled separately).
 * sat32s (42) is rejected because it reads dsp_acc, which the snapshot
 * does not model; sat16s (33) is a pure RN->RN saturate and is admitted.
 * mirror (48) and move_pc (51) are pure too but are left out to keep the
 * whitelist to opcodes the audit actually observed in wait loops. */
static int dsp_idle_op_admitted(uint32_t idx)
{
	switch (idx)
	{
	case  0: case  1: case  2: case  3:		/* add addc addq addqt */
	case  4: case  5: case  6: case  7:		/* sub subc subq subqt */
	case  8: case  9: case 10: case 11:		/* neg and or xor */
	case 12: case 13: case 14: case 15:		/* not btst bset bclr */
	case 22:								/* abs */
	case 24: case 25: case 27:				/* shlq shrq sharq */
	case 28: case 29:						/* ror rorq */
	case 30: case 31:						/* cmp cmpq */
	case 33:								/* sat16s */
	case 34: case 35: case 36: case 37:		/* move moveq moveta movefa */
	case 38:								/* movei */
	case 39: case 40: case 41:				/* loadb loadw load */
	case 43: case 44:						/* load_r14/15_indexed */
	case 57:								/* nop */
	case 58: case 59:						/* load_r14/15_ri */
		return 1;
	/* 52 (jump) and 53 (jr) are deliberately absent: excluding every
	 * PC-modifying opcode but the loop-closing jr itself is load-bearing
	 * for the executed-path check below (idleBodyCount forces exactly
	 * one route from head to jrAddr), not only for the store-freedom
	 * this whitelist was originally written to guarantee.  The two
	 * exceptions, forward exit jrs and one internal forward jr, are
	 * admitted by dsp_idle_decode itself and backed by the probe's
	 * EXIT-BRANCH CHECK. */
	default:
		return 0;
	}
}

/* Register operands of an admitted opcode, as indices into the 64-entry
 * snapshot (0..31 = dsp_reg_bank_0, 32..63 = dsp_reg_bank_1).  `cur` is
 * the base of the bank dsp_reg points at, `alt` the other one -- the
 * bank split matters: moveta writes ALTERNATE_RN and movefa reads
 * ALTERNATE_RM, which is exactly what Iron Soldier's wait loop polls.
 * *dst is -1 when the instruction writes no register. */
static int dsp_idle_operands(uint32_t idx, uint32_t p1, uint32_t p2,
                             int cur, int alt, int *src, int *nsrc, int *dst)
{
	*nsrc = 0;
	*dst  = -1;

	switch (idx)
	{
	case  0: case  1: case  4: case  5:		/* add addc sub subc */
	case  9: case 10: case 11:				/* and or xor */
	case 28:								/* ror  (RM = count) */
		src[(*nsrc)++] = cur + (int)p1;
		src[(*nsrc)++] = cur + (int)p2;
		*dst = cur + (int)p2;
		return 1;
	case 30:								/* cmp -- flags only */
		src[(*nsrc)++] = cur + (int)p1;
		src[(*nsrc)++] = cur + (int)p2;
		return 1;
	case  2: case  3: case  6: case  7:		/* addq addqt subq subqt */
	case  8: case 12: case 14: case 15:		/* neg not bset bclr */
	case 22: case 24: case 25: case 27:		/* abs shlq shrq sharq */
	case 29: case 33:						/* rorq sat16s */
		src[(*nsrc)++] = cur + (int)p2;
		*dst = cur + (int)p2;
		return 1;
	case 13: case 31:						/* btst cmpq -- flags only */
		src[(*nsrc)++] = cur + (int)p2;
		return 1;
	case 34:								/* move   RN = RM */
	case 39: case 40: case 41:				/* loadb loadw load: RM = base */
		src[(*nsrc)++] = cur + (int)p1;
		*dst = cur + (int)p2;
		return 1;
	case 35: case 38:						/* moveq / movei -- immediate */
		*dst = cur + (int)p2;
		return 1;
	case 36:								/* moveta  ALT_RN = RM */
		src[(*nsrc)++] = cur + (int)p1;
		*dst = alt + (int)p2;
		return 1;
	case 37:								/* movefa  RN = ALT_RM */
		src[(*nsrc)++] = alt + (int)p1;
		*dst = cur + (int)p2;
		return 1;
	case 43:								/* load_r14_indexed */
		src[(*nsrc)++] = cur + 14;
		*dst = cur + (int)p2;
		return 1;
	case 44:								/* load_r15_indexed */
		src[(*nsrc)++] = cur + 15;
		*dst = cur + (int)p2;
		return 1;
	case 58:								/* load_r14_ri */
		src[(*nsrc)++] = cur + 14;
		src[(*nsrc)++] = cur + (int)p1;
		*dst = cur + (int)p2;
		return 1;
	case 59:								/* load_r15_ri */
		src[(*nsrc)++] = cur + 15;
		src[(*nsrc)++] = cur + (int)p1;
		*dst = cur + (int)p2;
		return 1;
	case 53:								/* exit jr -- reads flags only */
	case 57:								/* nop */
		return 1;
	default:
		return 0;
	}
}

static int dsp_idle_memo_hit(uint32_t head, uint32_t jr)
{
	int i;

	for (i = 0; i < idleMemoCount; i++)
		if (idleMemoHead[i] == head && idleMemoJr[i] == jr)
		{
			idleMemoLastHead = head;
			idleMemoLastJr   = jr;
			return 1;
		}
	return 0;
}

static void dsp_idle_memo_reject(uint32_t head, uint32_t jr)
{
	if (dsp_idle_memo_hit(head, jr))
		return;
	idleMemoHead[idleMemoNext] = head;
	idleMemoJr[idleMemoNext]   = jr;
	idleMemoLastHead = head;
	idleMemoLastJr   = jr;
	idleMemoNext = (idleMemoNext + 1) % DSP_IDLE_MEMO;
	if (idleMemoCount < DSP_IDLE_MEMO)
		idleMemoCount++;
	dsp_idle_skip_rejects++;
}

/* Register-independent decode of target..jr plus the delay slot. */
static int dsp_idle_decode(uint32_t head, uint32_t jrAddr)
{
	uint32_t pc = head;
	uint32_t pcAt[DSP_IDLE_MAX_INSN];
	uint32_t intTarget = 0;
	uint16_t op;
	uint32_t idx;
	int n = 0, exits = 0, j;

	idleBodyCount = 0;
	idleIntJr = -1;

	while (pc < jrAddr)
	{
		if (n >= DSP_IDLE_MAX_BODY)
			return 0;
		op  = DSP_IDLE_FETCH(pc);
		idx = (uint32_t)(op >> 10);
		if (idx == 53)
		{
			/* A jr before the closing one is either an EXIT branch,
			 * landing past the closing jr's delay slot, or the body's one
			 * INTERNAL forward branch (#952, Iron Soldier 2), landing on
			 * an instruction after its own delay slot and no later than
			 * the closing jr.  Anything else -- backward, onto its own
			 * delay slot or onto the closing jr's -- would make a route
			 * around the loop the probe cannot account for. */
			int32_t off = (int32_t)((op >> 5) & 0x1F);
			uint32_t target;
			if (off & 0x10)
				off -= 0x20;
			target = pc + 2 + (uint32_t)(off * 2);
			if (target > jrAddr + 2)
				exits++;
			else if (idleIntJr < 0 && target >= pc + 6 && target <= jrAddr)
			{
				idleIntJr = n;
				intTarget = target;
			}
			else
				return 0;
		}
		else if (!dsp_idle_op_admitted(idx))
			return 0;
		pcAt[n] = pc;
		idleBodyIdx[n] = (uint8_t)idx;
		idleBodyP1[n]  = (uint8_t)((op >> 5) & 0x1F);
		idleBodyP2[n]  = (uint8_t)(op & 0x1F);
		idleBodyImm[n] = 0;
		if (idx == 38)						/* movei: opcode + LSW + MSW */
		{
			if (pc + 6 > jrAddr)			/* immediate would overrun the jr */
				return 0;
			idleBodyImm[n] = (uint32_t)DSP_IDLE_FETCH(pc + 2)
			               | ((uint32_t)DSP_IDLE_FETCH(pc + 4) << 16);
			pc += 6;
		}
		else
			pc += 2;
		n++;
	}

	if (pc != jrAddr)						/* decode fell out of step */
		return 0;

	if (idleIntJr >= 0)
	{
		/* Exit and internal branches together would let a taken exit
		 * plus a `jump` back show the same taken-jr count as a taken
		 * internal skip, which is what the probe tells them apart by. */
		if (exits)
			return 0;
		/* Its delay slot must be in the body and be neither a movei
		 * (immediate fetched past the branch) nor another jr. */
		if (idleIntJr + 1 >= n || idleBodyIdx[idleIntJr + 1] == 38
		    || idleBodyIdx[idleIntJr + 1] == 53)
			return 0;
		/* The target must start an instruction, not a movei immediate;
		 * the closing jr itself counts as index n (the join then falls
		 * just before its delay slot, which is the same thing). */
		idleIntFrom = idleIntJr + 2;
		idleIntTo   = -1;
		if (intTarget == jrAddr)
			idleIntTo = n;
		for (j = idleIntFrom; j < n; j++)
			if (pcAt[j] == intTarget)
				idleIntTo = j;
		if (idleIntTo <= idleIntFrom)		/* not a start, or skips nothing */
			return 0;
	}

	/* The inlined delay slot at jr+2 runs on every iteration too.  A
	 * movei there would fetch its immediate from past the branch, so
	 * reject it rather than model it. */
	op  = DSP_IDLE_FETCH(jrAddr + 2);
	idx = (uint32_t)(op >> 10);
	if (idx == 38 || !dsp_idle_op_admitted(idx))
		return 0;
	idleBodyIdx[n] = (uint8_t)idx;
	idleBodyP1[n]  = (uint8_t)((op >> 5) & 0x1F);
	idleBodyP2[n]  = (uint8_t)(op & 0x1F);
	idleBodyImm[n] = 0;
	n++;

	idleBodyCount = n;
	return 1;
}

/* Is the Z/N/C written by body instruction j dead -- overwritten in full
 * on every route before any instruction reads a flag?  Lets a counter
 * use the flag-setting addq/subq (#952: Iron Soldier 2's `addq #1,r19`,
 * whose flags `sub r31,r28` replaces two instructions later), since flags
 * that are never read cannot carry the counter's growth anywhere.
 *
 * Flag behavior is taken from the dsp_opcode_* bodies, not assumed:
 *   - write all of Z, N and C without reading a flag ("killers"):
 *     add addq sub subq neg abs shlq shrq sharq ror rorq cmp cmpq;
 *   - read no flag, so the scan passes them: addqt subqt (write none),
 *     and or xor not bset bclr (Z and N only), btst (Z only), the moves,
 *     movei, the loads and nop;
 *   - everything else ends the scan as a reader: the internal jr,
 *     addc / subc (read C), and sat16s, treated as a reader rather than
 *     audited.
 * The closing jr reads the flags too.  It has no entry of its own in
 * idleBodyIdx, but its delay slot is the last entry, so the scan stops
 * short of that slot: a killer there runs after the branch has already
 * read the counter's flags, and the scan never wraps.
 * A killer inside the internal jr's skippable region does not count for
 * an instruction ahead of that region: the taken route never runs it. */
static int dsp_idle_flags_dead(int j)
{
	int k, overRegion = (idleIntJr >= 0 && j < idleIntFrom);

	for (k = j + 1; k < idleBodyCount - 1; k++)
	{
		if (k == idleIntJr)
			return 0;
		switch (idleBodyIdx[k])
		{
		case  0: case  2: case  4: case  6: case  8:
		case 22: case 24: case 25: case 27:
		case 28: case 29: case 30: case 31:
			if (overRegion && k >= idleIntFrom && k < idleIntTo)
				break;
			return 1;
		case  3: case  7: case  9: case 10: case 11:
		case 12: case 13: case 14: case 15:
		case 34: case 35: case 36: case 37: case 38:
		case 39: case 40: case 41: case 43: case 44:
		case 57: case 58: case 59:
			break;
		default:
			return 0;
		}
	}
	return 0;
}

/* Register-dependent half of the admission rule, run at S2 where the
 * head state is provably steady.  Walks the body tracking each
 * register's known value so a load base written earlier in the same body
 * (Doom's `movei #addr,r2 ; load (r2),r1`) resolves to the address the
 * load will really use, not to whatever the head snapshot held. */
static int dsp_idle_check_body(const uint32_t *delta, int cur, int alt)
{
	uint32_t kval[64];
	uint8_t  kok[64];
	uint64_t skipped = 0;		/* registers written in the skippable region */
	int src[3];
	int nsrc, dst, s, j, i, counter;
	uint32_t idx, p1, p2, ea;

	for (i = 0; i < 32; i++)
	{
		kval[i]      = dsp_reg_bank_0[i];
		kval[32 + i] = dsp_reg_bank_1[i];
		kok[i]       = 1;
		kok[32 + i]  = 1;
	}

	for (j = 0; j < idleBodyCount; j++)
	{
		idx = idleBodyIdx[j];
		p1  = idleBodyP1[j];
		p2  = idleBodyP2[j];

		/* Join after the internal jr's skippable region: the taken route
		 * did not run it, so nothing it wrote is known any more.  Its own
		 * instructions are still checked below as if they ran -- the
		 * not-taken route does run them. */
		if (j == idleIntTo && idleIntJr >= 0)
			for (i = 0; i < 64; i++)
				if (skipped & ((uint64_t)1 << i))
					kok[i] = 0;

		if (!dsp_idle_operands(idx, p1, p2, cur, alt, src, &nsrc, &dst))
			return 0;
		if (dst >= 0 && idleIntJr >= 0 && j >= idleIntFrom && j < idleIntTo)
			skipped |= (uint64_t)1 << dst;

		/* A register whose per-iteration delta is nonzero is a pure
		 * counter: it may only be read, and only be written, by an
		 * addqt/subqt targeting itself.  Those two are the only
		 * admitted opcodes that touch no flag, so this forbids a
		 * growing value from reaching a compare, a load address, a
		 * shift count or anything else.  addq/subq onto itself also
		 * qualify when the flags they write are dead
		 * (dsp_idle_flags_dead, #952). */
		counter = (idx == 3 || idx == 7)
		       || ((idx == 2 || idx == 6) && dsp_idle_flags_dead(j));
		for (s = 0; s < nsrc; s++)
			if (delta[src[s]] != 0 && !(counter && src[s] == dst))
				return 0;
		if (dst >= 0 && delta[dst] != 0 && !counter)
			return 0;

		/* Loads: the effective address must be provably plain RAM. */
		switch (idx)
		{
		case 39:							/* loadb */
		case 40:							/* loadw */
			/* Outside local RAM these divert to JaguarReadByte /
			 * JaguarReadWord, whose full TOM/JERRY decode is not
			 * audited here; inside it they degenerate to a pure
			 * DSPReadLong of the containing long. */
			if (!kok[cur + (int)p1])
				return 0;
			ea = kval[cur + (int)p1];
			if (!(ea >= DSP_WORK_RAM_BASE && ea <= DSP_WORK_RAM_BASE + 0x1FFF))
				return 0;
			break;
		case 41:							/* load */
			if (!kok[cur + (int)p1])
				return 0;
			ea = kval[cur + (int)p1] & 0xFFFFFFFC;
			if (!DSP_IDLE_EA_OK(ea))
				return 0;
			break;
		case 43:							/* load_r14_indexed */
			if (!kok[cur + 14])
				return 0;
			ea = (kval[cur + 14] & 0xFFFFFFFC)
			   + (dsp_convert_zero[p1] << 2);
			if (!DSP_IDLE_EA_OK(ea))
				return 0;
			break;
		case 44:							/* load_r15_indexed */
			if (!kok[cur + 15])
				return 0;
			ea = (kval[cur + 15] & 0xFFFFFFFC)
			   + (dsp_convert_zero[p1] << 2);
			if (!DSP_IDLE_EA_OK(ea))
				return 0;
			break;
		case 58:							/* load_r14_ri */
			if (!kok[cur + 14] || !kok[cur + (int)p1])
				return 0;
			ea = (kval[cur + 14] + kval[cur + (int)p1]) & 0xFFFFFFFC;
			if (!DSP_IDLE_EA_OK(ea))
				return 0;
			break;
		case 59:							/* load_r15_ri */
			if (!kok[cur + 15] || !kok[cur + (int)p1])
				return 0;
			ea = (kval[cur + 15] + kval[cur + (int)p1]) & 0xFFFFFFFC;
			if (!DSP_IDLE_EA_OK(ea))
				return 0;
			break;
		default:
			break;
		}

		/* Propagate what we can still prove about the destination. */
		if (dst >= 0)
		{
			switch (idx)
			{
			case 38:						/* movei -- 32-bit immediate */
				kval[dst] = idleBodyImm[j];
				kok[dst]  = 1;
				break;
			case 35:						/* moveq -- RN = IMM_1 */
				kval[dst] = p1;
				kok[dst]  = 1;
				break;
			case 34: case 36: case 37:		/* move / moveta / movefa */
				kval[dst] = kval[src[0]];
				kok[dst]  = kok[src[0]];
				break;
			default:
				kok[dst] = 0;
				break;
			}
		}
	}

	return 1;
}

static void dsp_idle_snapshot(uint32_t *s)
{
	memcpy(s,      dsp_reg_bank_0, 32 * sizeof(uint32_t));
	memcpy(s + 32, dsp_reg_bank_1, 32 * sizeof(uint32_t));
}

/* Give up on an in-flight probe.  When the loop that displaced it is a
 * different one, memo the abandoned loop: otherwise two interleaved
 * loops could restart each other forever without either reaching S2. */
static void dsp_idle_probe_abandon(uint32_t head, uint32_t jr)
{
	if (idleProbeStage != 0
	    && (idleProbeHead != head || idleProbeJr != jr))
		dsp_idle_memo_reject(idleProbeHead, idleProbeJr);
	idleProbeStage = 0;
}

/* Called from DSPExec immediately after a taken backward/self `jr`, with
 * dsp_pc already at the loop head and the delay slot already executed.
 * Returns the (possibly advanced) cycle budget. */
static int32_t DSPIdleLoopProbe(int32_t cycles, uint32_t head, uint32_t jrAddr)
{
	uint32_t delta[64];
	int32_t  cost, n;
	uint32_t opcost, jrt;
	int      cur, alt, i;

	/* The same rejected loop again, with no probe in flight: exactly what
	 * the memo check below would conclude, minus the scan. */
	if (idleProbeStage == 0 && idleMemoCount != 0
	    && head == idleMemoLastHead && jrAddr == idleMemoLastJr)
		return cycles;

	/* Whole body -- including the delay slot and its trailing byte --
	 * must sit in DSP local SRAM, so every fetch is a pure dsp_ram_8
	 * read and the PC-escape check in DSPExec is a no-op for it. */
	if (head < DSP_WORK_RAM_BASE
	    || jrAddr + 3 > DSP_WORK_RAM_BASE + 0x1FFF)
	{
		dsp_idle_probe_abandon(head, jrAddr);
		return cycles;
	}

	/* Theorem (2): a pending IMASK clear or an un-retired D_FLAGS store
	 * means interrupt state is in flight; do not extrapolate over it.
	 * Both are transient (DSPExec dispatches the pending IRQ on its very
	 * next iteration), so this is a reset, not a permanent reject. */
	if (IMASKCleared || dspFlagsRetireDelay)
	{
		dsp_idle_probe_abandon(head, jrAddr);
		return cycles;
	}

	/* A different loop showed up mid-probe.  Only then -- calling this
	 * unconditionally would reset the probe of the loop we are actually
	 * in the middle of measuring, and nothing would ever reach S2. */
	if (idleProbeStage != 0
	    && (idleProbeHead != head || idleProbeJr != jrAddr))
		dsp_idle_probe_abandon(head, jrAddr);

	if (dsp_idle_memo_hit(head, jrAddr))
		return cycles;

	if (idleProbeStage == 0)
	{
		if (!dsp_idle_decode(head, jrAddr))
		{
			dsp_idle_memo_reject(head, jrAddr);
			return cycles;
		}
		dsp_idle_snapshot(idleProbeS0);
		idleProbeFz0   = dsp_flag_z;
		idleProbeFn0   = dsp_flag_n;
		idleProbeFc0   = dsp_flag_c;
		idleProbeCyc0  = cycles;
		idleProbeOpc0  = dsp_exec_opcode_count;
		idleProbeJrt0  = dsp_jr_taken;
		idleProbeHead  = head;
		idleProbeJr    = jrAddr;
		idleProbeBank  = dsp_reg;
		idleProbeLdxFix = dsp_load_wb_fixups;
		idleProbeDivFix = dsp_div_store_fixups;
		idleProbeStage = 1;
		return cycles;
	}

	if (idleProbeStage == 1)
	{
		dsp_idle_snapshot(idleProbeS1);
		idleProbeFz1   = dsp_flag_z;
		idleProbeFn1   = dsp_flag_n;
		idleProbeFc1   = dsp_flag_c;
		idleProbeCyc1  = cycles;
		idleProbeOpc1  = dsp_exec_opcode_count;
		idleProbeJrt1  = dsp_jr_taken;
		idleProbeStage = 2;
		return cycles;
	}

	/* Stage 2: the live machine state is S2. */
	idleProbeStage = 0;

	/* Flags must have been identical at all THREE loop heads.  Comparing
	 * only S0 against S2 would admit a two-iteration oscillation whose
	 * third iteration behaves like neither probe. */
	if (idleProbeFz1 != idleProbeFz0 || idleProbeFn1 != idleProbeFn0
	    || idleProbeFc1 != idleProbeFc0
	    || dsp_flag_z != idleProbeFz0 || dsp_flag_n != idleProbeFn0
	    || dsp_flag_c != idleProbeFc0)
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}

	/* Issue #811: dsp_idle_check_body models a load followed by an
	 * overwrite of its target in program order (the overwrite wins), but
	 * the interpreter now lets the external load data land last.  A loop
	 * in which that fired is not the loop the dataflow proof describes.
	 * Same for a divide whose indexed store wrote the pre-divide value. */
	if (dsp_load_wb_fixups != idleProbeLdxFix
	      || dsp_div_store_fixups != idleProbeDivFix)
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}

	/* Theorem (3): the bank pointers must not have moved. */
	if (dsp_reg != idleProbeBank)
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}

	/* Cost and opcode count measured, never recomputed: the inlined
	 * delay slot is not charged by DSPExec's own `cycles -=`. */
	cost = idleProbeCyc0 - idleProbeCyc1;
	if (cost <= 0 || (idleProbeCyc1 - cycles) != cost)
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}
	opcost = idleProbeOpc1 - idleProbeOpc0;
	if (opcost == 0 || (dsp_exec_opcode_count - idleProbeOpc1) != opcost)
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}

	/* EXECUTED-PATH CHECK.  Everything above pins what the *decoded* body
	 * would do; this is what pins that the machine actually walked it.
	 *
	 * The probe only fires on a TAKEN backward jr, so an arrival at the
	 * loop head says nothing about how the previous arrival got here: a
	 * NOT-taken jr, a `jump`, or fall-through all reach `head` without
	 * ever entering this function.  A compound period that happens to
	 * have the same net register/flag effect -- e.g. a counter that
	 * cycles 2 -> 1 (taken) -> 0 (not taken) -> a fall-through path that
	 * resets it, containing an undecoded `store` -- would otherwise pass
	 * every check above, because the decoded portion really is pure and
	 * the deltas really are constant.  Eliding `n` copies of that store
	 * (I2S LTXD/RTXD, a blitter command, a latch clear) is exactly the
	 * silent divergence this whole design exists to prevent.
	 *
	 * dsp_exec_opcode_count is incremented in three reachable places --
	 * DSPExec's main loop, and the inlined delay slots in
	 * dsp_opcode_jump and dsp_opcode_jr (a fourth site exists in the
	 * pipelined DSP_jr, but that executor is dead code -- DSPExecP/
	 * DSPExecP2 are declared and never defined) -- so one traversal of
	 * a branch-free admitted body charges, deterministically:
	 *
	 *     (idleBodyCount - 1)   body instructions before the jr
	 *   + 1                     the loop-closing jr itself
	 *   + 1                     its inlined delay slot
	 *   = idleBodyCount + 1
	 *
	 * (idleBodyCount counts the decoded [head, jr) instructions -- movei
	 * once, not three times -- plus the delay slot; the jr is not in the
	 * array.)  Any other route from one arrival to the next must execute
	 * the whole body AND at least one further instruction to get back,
	 * so it costs strictly more.  Requiring exact equality therefore
	 * admits the straight-line traversal and nothing else.
	 *
	 * EXIT-BRANCH CHECK (#952).  That argument needs a branch-free body.
	 * With an exit jr in it, a taken exit can leave, run undecoded code
	 * (a store) and come back through a `jump` to the closing jr with
	 * exactly the straight-line opcode count -- dsp_idle_probe_falsify
	 * program D is such a route.  So also require that each probe
	 * iteration took exactly ONE jr, the closing one: a taken exit is a
	 * taken jr and would make it two.  With every exit untaken, the body
	 * is straight-line again and the count argument above applies.
	 *
	 * INTERNAL-BRANCH CHECK (#952).  With the body's one internal jr
	 * (exits then excluded by the decoder) there are exactly two routes,
	 * F = idleBodyCount + 1:
	 *     internal not taken:  1 taken jr,  F opcodes
	 *     internal taken:      2 taken jrs, F - K opcodes
	 * (K = idleIntTo - idleIntFrom; the delay slot is charged once either
	 * way, by DSPExec's loop or inline by dsp_opcode_jr).  Both iterations
	 * must show the same pair, and it must be one of these two.  Any
	 * other route has to fall through the closing jr (the only way out
	 * without a taken jr), so it runs one full pass (at least F - K, or F
	 * with the internal untaken), a transfer back plus its delay slot
	 * (+2), and the closing jr plus its slot again (+2) -- and leaving can
	 * only ADD taken jrs.  So a detour showing 1 taken jr took no internal
	 * branch and costs >= F + 4, and one showing 2 costs >= F - K + 4:
	 * never equal to the legal pair with the same count. */
	jrt = idleProbeJrt1 - idleProbeJrt0;
	if (dsp_jr_taken - idleProbeJrt1 != jrt
	    || !((jrt == 1 && opcost == (uint32_t)idleBodyCount + 1)
	         || (jrt == 2 && idleIntJr >= 0
	             && opcost == (uint32_t)(idleBodyCount + 1
	                                     - (idleIntTo - idleIntFrom)))))
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}

	/* Per-iteration register delta must be constant across both probes. */
	for (i = 0; i < 32; i++)
	{
		delta[i]      = idleProbeS1[i] - idleProbeS0[i];
		delta[32 + i] = idleProbeS1[32 + i] - idleProbeS0[32 + i];
		if (dsp_reg_bank_0[i] - idleProbeS1[i] != delta[i])
		{
			dsp_idle_memo_reject(head, jrAddr);
			return cycles;
		}
		if (dsp_reg_bank_1[i] - idleProbeS1[32 + i] != delta[32 + i])
		{
			dsp_idle_memo_reject(head, jrAddr);
			return cycles;
		}
	}

	cur = (dsp_reg == dsp_reg_bank_0) ? 0 : 32;
	alt = 32 - cur;

	if (!dsp_idle_check_body(delta, cur, alt))
	{
		dsp_idle_memo_reject(head, jrAddr);
		return cycles;
	}

	/* Always leave one full iteration to execute normally. */
	n = (cycles / cost) - 1;
	if (n <= 0)
		return cycles;

	for (i = 0; i < 32; i++)
	{
		if (delta[i])
			dsp_reg_bank_0[i] += (uint32_t)n * delta[i];
		if (delta[32 + i])
			dsp_reg_bank_1[i] += (uint32_t)n * delta[32 + i];
	}
	cycles -= n * cost;
	dsp_exec_opcode_count += (uint32_t)n * opcost;

	dsp_idle_skip_fires++;
	dsp_idle_skip_iters   += (uint32_t)n;
	dsp_idle_skip_opcodes += (uint32_t)n * opcost;

	return cycles;
}

/* DSP execution core */

static DSP_NOINLINE void DSPExecTimed(int32_t cycles);
static DSP_NOINLINE void DSPExecUntimed(int32_t cycles);
#if !defined(VJ_GDB_STUB_DISABLE_HOOKS) && !defined(VJ_GDB_STUB_DISABLE_DSP_HOOK)
static DSP_NOINLINE void DSPExecUntimedArmed(int32_t cycles);
#endif

/* Timing models (pipeline or dram_timing) run a separate loop, picked
 * once per call, so the untimed loop below and the opcode handlers it
 * dispatches are exactly develop's (issue #313 / #892).  The untimed loop
 * is itself built twice, with and without the GDB breakpoint test (issue
 * #1054, see dsp_exec_untimed.h), so the default path carries no debugger
 * code.  All loops are out of line so none can merge into, or
 * re-allocate, another. */
void DSPExec(int32_t cycles)
{
	if (vjs.gpuPipelineTiming || busArbiter.enabled)
		DSPExecTimed(cycles);
#if !defined(VJ_GDB_STUB_DISABLE_HOOKS) && !defined(VJ_GDB_STUB_DISABLE_DSP_HOOK)
	else if (gdbArmedDSP)
		DSPExecUntimedArmed(cycles);
#endif
	else
		DSPExecUntimed(cycles);
}

#define DSP_UNTIMED_NAME DSPExecUntimed
#define DSP_UNTIMED_GDB  0
#include "dsp_exec_untimed.h"

#if !defined(VJ_GDB_STUB_DISABLE_HOOKS) && !defined(VJ_GDB_STUB_DISABLE_DSP_HOOK)
#define DSP_UNTIMED_NAME DSPExecUntimedArmed
#define DSP_UNTIMED_GDB  1
#include "dsp_exec_untimed.h"
#endif

INLINE static void dsp_executeOpcode(uint32_t index)
{
#ifdef __GNUC__
	/* Computed-goto dispatch table -- one label per RISC opcode.
	 * GCC/Clang extension: &&label yields the address of a label;
	 * goto *ptr jumps through an arbitrary code address.  This
	 * eliminates the single indirect-branch bottleneck of switch
	 * dispatch and lets the branch predictor track each opcode
	 * independently. */
	static const void *dsp_dispatch[64] = {
		&&dsp_op_add,             &&dsp_op_addc,
		&&dsp_op_addq,            &&dsp_op_addqt,
		&&dsp_op_sub,             &&dsp_op_subc,
		&&dsp_op_subq,            &&dsp_op_subqt,
		&&dsp_op_neg,             &&dsp_op_and,
		&&dsp_op_or,              &&dsp_op_xor,
		&&dsp_op_not,             &&dsp_op_btst,
		&&dsp_op_bset,            &&dsp_op_bclr,
		&&dsp_op_mult,            &&dsp_op_imult,
		&&dsp_op_imultn,          &&dsp_op_resmac,
		&&dsp_op_imacn,           &&dsp_op_div,
		&&dsp_op_abs,             &&dsp_op_sh,
		&&dsp_op_shlq,            &&dsp_op_shrq,
		&&dsp_op_sha,             &&dsp_op_sharq,
		&&dsp_op_ror,             &&dsp_op_rorq,
		&&dsp_op_cmp,             &&dsp_op_cmpq,
		&&dsp_op_subqmod,         &&dsp_op_sat16s,
		&&dsp_op_move,            &&dsp_op_moveq,
		&&dsp_op_moveta,          &&dsp_op_movefa,
		&&dsp_op_movei,           &&dsp_op_loadb,
		&&dsp_op_loadw,           &&dsp_op_load,
		&&dsp_op_sat32s,          &&dsp_op_load_r14_indexed,
		&&dsp_op_load_r15_indexed,&&dsp_op_storeb,
		&&dsp_op_storew,          &&dsp_op_store,
		&&dsp_op_mirror,          &&dsp_op_store_r14_indexed,
		&&dsp_op_store_r15_indexed,&&dsp_op_move_pc,
		&&dsp_op_jump,            &&dsp_op_jr,
		&&dsp_op_mmult,           &&dsp_op_mtoi,
		&&dsp_op_normi,           &&dsp_op_nop,
		&&dsp_op_load_r14_ri,     &&dsp_op_load_r15_ri,
		&&dsp_op_store_r14_ri,    &&dsp_op_store_r15_ri,
		&&dsp_op_illegal,         &&dsp_op_addqmod
	};

	goto *dsp_dispatch[index];

	dsp_op_add:             dsp_opcode_add();             return;
	dsp_op_addc:            dsp_opcode_addc();            return;
	dsp_op_addq:            dsp_opcode_addq();            return;
	dsp_op_addqt:           dsp_opcode_addqt();           return;
	dsp_op_sub:             dsp_opcode_sub();             return;
	dsp_op_subc:            dsp_opcode_subc();            return;
	dsp_op_subq:            dsp_opcode_subq();            return;
	dsp_op_subqt:           dsp_opcode_subqt();           return;
	dsp_op_neg:             dsp_opcode_neg();             return;
	dsp_op_and:             dsp_opcode_and();             return;
	dsp_op_or:              dsp_opcode_or();              return;
	dsp_op_xor:             dsp_opcode_xor();             return;
	dsp_op_not:             dsp_opcode_not();             return;
	dsp_op_btst:            dsp_opcode_btst();            return;
	dsp_op_bset:            dsp_opcode_bset();            return;
	dsp_op_bclr:            dsp_opcode_bclr();            return;
	dsp_op_mult:            dsp_opcode_mult();            return;
	dsp_op_imult:           dsp_opcode_imult();           return;
	dsp_op_imultn:          dsp_opcode_imultn();          return;
	dsp_op_resmac:          dsp_opcode_resmac();          return;
	dsp_op_imacn:           dsp_opcode_imacn();           return;
	dsp_op_div:             dsp_opcode_div();             return;
	dsp_op_abs:             dsp_opcode_abs();             return;
	dsp_op_sh:              dsp_opcode_sh();              return;
	dsp_op_shlq:            dsp_opcode_shlq();            return;
	dsp_op_shrq:            dsp_opcode_shrq();            return;
	dsp_op_sha:             dsp_opcode_sha();             return;
	dsp_op_sharq:           dsp_opcode_sharq();           return;
	dsp_op_ror:             dsp_opcode_ror();             return;
	dsp_op_rorq:            dsp_opcode_rorq();            return;
	dsp_op_cmp:             dsp_opcode_cmp();             return;
	dsp_op_cmpq:            dsp_opcode_cmpq();            return;
	dsp_op_subqmod:         dsp_opcode_subqmod();         return;
	dsp_op_sat16s:          dsp_opcode_sat16s();          return;
	dsp_op_move:            dsp_opcode_move();            return;
	dsp_op_moveq:           dsp_opcode_moveq();           return;
	dsp_op_moveta:          dsp_opcode_moveta();          return;
	dsp_op_movefa:          dsp_opcode_movefa();          return;
	dsp_op_movei:           dsp_opcode_movei();           return;
	dsp_op_loadb:           dsp_opcode_loadb();           return;
	dsp_op_loadw:           dsp_opcode_loadw();           return;
	dsp_op_load:            dsp_opcode_load();            return;
	dsp_op_sat32s:          dsp_opcode_sat32s();          return;
	dsp_op_load_r14_indexed:dsp_opcode_load_r14_indexed();return;
	dsp_op_load_r15_indexed:dsp_opcode_load_r15_indexed();return;
	dsp_op_storeb:          dsp_opcode_storeb();          return;
	dsp_op_storew:          dsp_opcode_storew();          return;
	dsp_op_store:           dsp_opcode_store();           return;
	dsp_op_mirror:          dsp_opcode_mirror();          return;
	dsp_op_store_r14_indexed:dsp_opcode_store_r14_indexed();return;
	dsp_op_store_r15_indexed:dsp_opcode_store_r15_indexed();return;
	dsp_op_move_pc:         dsp_opcode_move_pc();         return;
	dsp_op_jump:            dsp_opcode_jump();            return;
	dsp_op_jr:              dsp_opcode_jr();              return;
	dsp_op_mmult:           dsp_opcode_mmult();           return;
	dsp_op_mtoi:            dsp_opcode_mtoi();            return;
	dsp_op_normi:           dsp_opcode_normi();           return;
	dsp_op_nop:             dsp_opcode_nop();             return;
	dsp_op_load_r14_ri:     dsp_opcode_load_r14_ri();     return;
	dsp_op_load_r15_ri:     dsp_opcode_load_r15_ri();     return;
	dsp_op_store_r14_ri:    dsp_opcode_store_r14_ri();    return;
	dsp_op_store_r15_ri:    dsp_opcode_store_r15_ri();    return;
	dsp_op_illegal:         dsp_opcode_illegal();         return;
	dsp_op_addqmod:         dsp_opcode_addqmod();         return; /* NOLINT(readability-redundant-control-flow) -- goto target */
#else
	/* Switch fallback for MSVC and other non-GNU compilers */
	switch (index)
	{
	case 0:  dsp_opcode_add(); break;
	case 1:  dsp_opcode_addc(); break;
	case 2:  dsp_opcode_addq(); break;
	case 3:  dsp_opcode_addqt(); break;
	case 4:  dsp_opcode_sub(); break;
	case 5:  dsp_opcode_subc(); break;
	case 6:  dsp_opcode_subq(); break;
	case 7:  dsp_opcode_subqt(); break;
	case 8:  dsp_opcode_neg(); break;
	case 9:  dsp_opcode_and(); break;
	case 10: dsp_opcode_or(); break;
	case 11: dsp_opcode_xor(); break;
	case 12: dsp_opcode_not(); break;
	case 13: dsp_opcode_btst(); break;
	case 14: dsp_opcode_bset(); break;
	case 15: dsp_opcode_bclr(); break;
	case 16: dsp_opcode_mult(); break;
	case 17: dsp_opcode_imult(); break;
	case 18: dsp_opcode_imultn(); break;
	case 19: dsp_opcode_resmac(); break;
	case 20: dsp_opcode_imacn(); break;
	case 21: dsp_opcode_div(); break;
	case 22: dsp_opcode_abs(); break;
	case 23: dsp_opcode_sh(); break;
	case 24: dsp_opcode_shlq(); break;
	case 25: dsp_opcode_shrq(); break;
	case 26: dsp_opcode_sha(); break;
	case 27: dsp_opcode_sharq(); break;
	case 28: dsp_opcode_ror(); break;
	case 29: dsp_opcode_rorq(); break;
	case 30: dsp_opcode_cmp(); break;
	case 31: dsp_opcode_cmpq(); break;
	case 32: dsp_opcode_subqmod(); break;
	case 33: dsp_opcode_sat16s(); break;
	case 34: dsp_opcode_move(); break;
	case 35: dsp_opcode_moveq(); break;
	case 36: dsp_opcode_moveta(); break;
	case 37: dsp_opcode_movefa(); break;
	case 38: dsp_opcode_movei(); break;
	case 39: dsp_opcode_loadb(); break;
	case 40: dsp_opcode_loadw(); break;
	case 41: dsp_opcode_load(); break;
	case 42: dsp_opcode_sat32s(); break;
	case 43: dsp_opcode_load_r14_indexed(); break;
	case 44: dsp_opcode_load_r15_indexed(); break;
	case 45: dsp_opcode_storeb(); break;
	case 46: dsp_opcode_storew(); break;
	case 47: dsp_opcode_store(); break;
	case 48: dsp_opcode_mirror(); break;
	case 49: dsp_opcode_store_r14_indexed(); break;
	case 50: dsp_opcode_store_r15_indexed(); break;
	case 51: dsp_opcode_move_pc(); break;
	case 52: dsp_opcode_jump(); break;
	case 53: dsp_opcode_jr(); break;
	case 54: dsp_opcode_mmult(); break;
	case 55: dsp_opcode_mtoi(); break;
	case 56: dsp_opcode_normi(); break;
	case 57: dsp_opcode_nop(); break;
	case 58: dsp_opcode_load_r14_ri(); break;
	case 59: dsp_opcode_load_r15_ri(); break;
	case 60: dsp_opcode_store_r14_ri(); break;
	case 61: dsp_opcode_store_r15_ri(); break;
	case 62: dsp_opcode_illegal(); break;
	case 63: dsp_opcode_addqmod(); break;
	default: break;
	}
#endif
}

// DSP opcode handlers

/* There is a problem here with interrupt handlers the JUMP and JR instructions that
 * can cause trouble because an interrupt can occur *before* the instruction following the
 * jump can execute... !!! FIX !!! */
INLINE static void dsp_opcode_jump(void)
{
	/* KLUDGE: Used by BRANCH_CONDITION */
	uint32_t jaguar_flags = (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;

	if (BRANCH_CONDITION(IMM_2))
	{
		/* The target register is latched a pipeline stage before a
		 * D_FLAGS store in the slot ahead of us can retire, so RM still
		 * reads the bank that was live when that store issued -- the
		 * switch is deferred until it retires.  See the D_FLAGS case in
		 * DSPWriteLong. */
		uint32_t delayed_pc = RM;
		uint16_t ds_opcode;
		uint32_t ds_index;
		/* The delay slot is the second instruction behind such a store,
		 * past the retire window: commit the switch before it runs. */
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
		/* Inline delay-slot: fetch-decode-execute one instruction at current
		 * PC before applying the branch target.  This replaces the old
		 * recursive DSPExec(1) call, avoiding full function-call overhead,
		 * redundant IRQ checks, and pipeline-state save/restore. */
		if (dsp_pc >= DSP_WORK_RAM_BASE && dsp_pc < DSP_WORK_RAM_BASE + 0x2000 - 1)
		{
			uint32_t off = dsp_pc - DSP_WORK_RAM_BASE;
			ds_opcode = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
		}
		else
			ds_opcode = DSPReadWord(dsp_pc, DSP);
		ds_index = ds_opcode >> 10;
		dsp_opcode_first_parameter  = (ds_opcode >> 5) & 0x1F;
		dsp_opcode_second_parameter = ds_opcode & 0x1F;
		dsp_pc += 2;
		dsp_exec_opcode_count++;
		dsp_executeOpcode(ds_index);
		dsp_pc = delayed_pc;
		/* Refilling the pipeline from the branch target costs enough
		 * cycles that a D_FLAGS store the delay slot just issued reaches
		 * Write-back first, so the target instruction sees the new bank.
		 * See DSPWriteLong. */
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
	}
}


INLINE static void dsp_opcode_jr(void)
{
	/* KLUDGE: Used by BRANCH_CONDITION */
	uint32_t jaguar_flags = (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;

	if (BRANCH_CONDITION(IMM_2))
	{
		int32_t offset = ((IMM_1 & 0x10) ? 0xFFFFFFF0 | IMM_1 : IMM_1);		/* Sign extend IMM_1 */
		int32_t delayed_pc = dsp_pc + (offset * 2);
		uint16_t ds_opcode;
		uint32_t ds_index;
		dsp_jr_taken++;			/* idle-skip exit-branch check (#952) */
		/* Same retire-window commits as dsp_opcode_jump. */
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
		/* Inline delay-slot: fetch-decode-execute one instruction at current
		 * PC before applying the branch target.  Same rationale as in
		 * dsp_opcode_jump above. */
		if (dsp_pc >= DSP_WORK_RAM_BASE && dsp_pc < DSP_WORK_RAM_BASE + 0x2000 - 1)
		{
			uint32_t off = dsp_pc - DSP_WORK_RAM_BASE;
			ds_opcode = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
		}
		else
			ds_opcode = DSPReadWord(dsp_pc, DSP);
		ds_index = ds_opcode >> 10;
		dsp_opcode_first_parameter  = (ds_opcode >> 5) & 0x1F;
		dsp_opcode_second_parameter = ds_opcode & 0x1F;
		dsp_pc += 2;
		dsp_exec_opcode_count++;
		dsp_executeOpcode(ds_index);
		dsp_pc = delayed_pc;
		/* Same branch-target pipeline refill as dsp_opcode_jump. */
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
	}
}


INLINE static void dsp_opcode_add(void)
{
	uint32_t res = RN + RM;
	SET_ZNC_ADD(RN, RM, res);
	RN = res;
}


INLINE static void dsp_opcode_addc(void)
{
	uint64_t res = (uint64_t)RN + (uint64_t)RM + (uint64_t)dsp_flag_c;
	dsp_flag_c = (uint8_t)((res >> 32) & 0x01);
	RN = (uint32_t)(res & 0xFFFFFFFF);
	SET_ZN(RN);
}


INLINE static void dsp_opcode_addq(void)
{
	uint32_t r1 = dsp_convert_zero[IMM_1];
	uint32_t res = RN + r1;
	CLR_ZNC; SET_ZNC_ADD(RN, r1, res);
	RN = res;
}


INLINE static void dsp_opcode_sub(void)
{
	uint32_t res = RN - RM;
	SET_ZNC_SUB(RN, RM, res);
	RN = res;
}


INLINE static void dsp_opcode_subc(void)
{
	// This is how the DSP ALU does it--Two's complement with inverted carry
	uint64_t res = (uint64_t)RN + (uint64_t)(RM ^ 0xFFFFFFFF) + (dsp_flag_c ^ 1);
	// Carry out of the result is inverted too
	dsp_flag_c = ((res >> 32) & 0x01) ^ 1;
	RN = (res & 0xFFFFFFFF);
	SET_ZN(RN);
}


INLINE static void dsp_opcode_subq(void)
{
	uint32_t r1 = dsp_convert_zero[IMM_1];
	uint32_t res = RN - r1;
	SET_ZNC_SUB(RN, r1, res);
	RN = res;
}


INLINE static void dsp_opcode_cmp(void)
{
	uint32_t res = RN - RM;
	SET_ZNC_SUB(RN, RM, res);
}


INLINE static void dsp_opcode_cmpq(void)
{
	static int32_t sqtable[32] =
		{ 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1 };
	uint32_t r1 = sqtable[IMM_1 & 0x1F]; // I like this better -> (INT8)(jaguar.op >> 2) >> 3;
	uint32_t res = RN - r1;
	SET_ZNC_SUB(RN, r1, res);
}


INLINE static void dsp_opcode_and(void)
{
	RN = RN & RM;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_or(void)
{
	RN = RN | RM;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_xor(void)
{
	RN = RN ^ RM;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_not(void)
{
	RN = ~RN;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_move_pc(void)
{
	RN = dsp_pc - 2;
}


INLINE static void dsp_opcode_store_r14_indexed(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	DSPWriteLong((dsp_reg[14] & 0xFFFFFFFC) + (dsp_convert_zero[IMM_1] << 2), RN, DSP);
#else
	DSPWriteLong(dsp_reg[14] + (dsp_convert_zero[IMM_1] << 2), RN, DSP);
#endif
}


INLINE static void dsp_opcode_store_r15_indexed(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	DSPWriteLong((dsp_reg[15] & 0xFFFFFFFC) + (dsp_convert_zero[IMM_1] << 2), RN, DSP);
#else
	DSPWriteLong(dsp_reg[15] + (dsp_convert_zero[IMM_1] << 2), RN, DSP);
#endif
}


INLINE static void dsp_opcode_load_r14_ri(void)
{
	DSPLoadNoteExternal(dsp_reg[14] + RM);
#ifdef DSP_CORRECT_ALIGNMENT
	RN = DSPReadLong((dsp_reg[14] + RM) & 0xFFFFFFFC, DSP);
#else
	RN = DSPReadLong(dsp_reg[14] + RM, DSP);
#endif
}


INLINE static void dsp_opcode_load_r15_ri(void)
{
	DSPLoadNoteExternal(dsp_reg[15] + RM);
#ifdef DSP_CORRECT_ALIGNMENT
	RN = DSPReadLong((dsp_reg[15] + RM) & 0xFFFFFFFC, DSP);
#else
	RN = DSPReadLong(dsp_reg[15] + RM, DSP);
#endif
}


INLINE static void dsp_opcode_store_r14_ri(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	DSPWriteLong((dsp_reg[14] + RM) & 0xFFFFFFFC, RN, DSP);
#else
	DSPWriteLong(dsp_reg[14] + RM, RN, DSP);
#endif
}


INLINE static void dsp_opcode_store_r15_ri(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	DSPWriteLong((dsp_reg[15] + RM) & 0xFFFFFFFC, RN, DSP);
#else
	DSPWriteLong(dsp_reg[15] + RM, RN, DSP);
#endif
}


INLINE static void dsp_opcode_nop(void)
{
}


INLINE static void dsp_opcode_storeb(void)
{
	if (RM >= DSP_WORK_RAM_BASE && RM <= (DSP_WORK_RAM_BASE + 0x1FFF))
		DSPWriteLong(RM, RN & 0xFF, DSP);
	else
		JaguarWriteByte(RM, RN, DSP);
}


INLINE static void dsp_opcode_storew(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	if (RM >= DSP_WORK_RAM_BASE && RM <= (DSP_WORK_RAM_BASE + 0x1FFF))
		DSPWriteLong(RM & 0xFFFFFFFE, RN & 0xFFFF, DSP);
	else
		JaguarWriteWord(RM & 0xFFFFFFFE, RN, DSP);
#else
	if (RM >= DSP_WORK_RAM_BASE && RM <= (DSP_WORK_RAM_BASE + 0x1FFF))
		DSPWriteLong(RM, RN & 0xFFFF, DSP);
	else
		JaguarWriteWord(RM, RN, DSP);
#endif
}


INLINE static void dsp_opcode_store(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	DSPWriteLong(RM & 0xFFFFFFFC, RN, DSP);
#else
	DSPWriteLong(RM, RN, DSP);
#endif
}


INLINE static void dsp_opcode_loadb(void)
{
	if (RM >= DSP_WORK_RAM_BASE && RM <= (DSP_WORK_RAM_BASE + 0x1FFF))
	{
		/* JTRM (Technical Reference v8, "Load Byte"): byte extraction
		 * "applies to external memory only, internal memory will perform
		 * a 32-bit read."  A byte load from DSP local RAM returns the
		 * ENTIRE long containing the address -- same rule as the GPU
		 * (see gpu_opcode_loadb). */
		RN = DSPReadLong(RM & 0xFFFFFFFC, DSP);
	}
	else
	{
		DSPLoadNoteExternal(RM);
		RN = JaguarReadByte(RM, DSP);
	}
}


INLINE static void dsp_opcode_loadw(void)
{
	if (RM >= DSP_WORK_RAM_BASE && RM <= (DSP_WORK_RAM_BASE + 0x1FFF))
	{
		/* Same JTRM rule as LOADB: word loads from internal RAM perform
		 * a full 32-bit read of the long containing the address. */
		RN = DSPReadLong(RM & 0xFFFFFFFC, DSP);
	}
#ifdef DSP_CORRECT_ALIGNMENT
	else
	{
		DSPLoadNoteExternal(RM);
		RN = JaguarReadWord(RM & 0xFFFFFFFE, DSP);
	}
#else
	else
	{
		DSPLoadNoteExternal(RM);
		RN = JaguarReadWord(RM, DSP);
	}
#endif
}


INLINE static void dsp_opcode_load(void)
{
	DSPLoadNoteExternal(RM);
#ifdef DSP_CORRECT_ALIGNMENT
	RN = DSPReadLong(RM & 0xFFFFFFFC, DSP);
#else
	RN = DSPReadLong(RM, DSP);
#endif
}


INLINE static void dsp_opcode_load_r14_indexed(void)
{
	DSPLoadNoteExternal(dsp_reg[14] + (dsp_convert_zero[IMM_1] << 2));
#ifdef DSP_CORRECT_ALIGNMENT
	RN = DSPReadLong((dsp_reg[14] & 0xFFFFFFFC) + (dsp_convert_zero[IMM_1] << 2), DSP);
#else
	RN = DSPReadLong(dsp_reg[14] + (dsp_convert_zero[IMM_1] << 2), DSP);
#endif
}


INLINE static void dsp_opcode_load_r15_indexed(void)
{
	DSPLoadNoteExternal(dsp_reg[15] + (dsp_convert_zero[IMM_1] << 2));
#ifdef DSP_CORRECT_ALIGNMENT
	RN = DSPReadLong((dsp_reg[15] & 0xFFFFFFFC) + (dsp_convert_zero[IMM_1] << 2), DSP);
#else
	RN = DSPReadLong(dsp_reg[15] + (dsp_convert_zero[IMM_1] << 2), DSP);
#endif
}


INLINE static void dsp_opcode_movei(void)
{
	// This instruction is followed by 32-bit value in LSW / MSW format...
	RN = (uint32_t)DSPReadWord(dsp_pc, DSP) | ((uint32_t)DSPReadWord(dsp_pc + 2, DSP) << 16);
	dsp_pc += 4;
}


INLINE static void dsp_opcode_moveta(void)
{
	ALTERNATE_RN = RM;
}


INLINE static void dsp_opcode_movefa(void)
{
	RN = ALTERNATE_RM;
}


INLINE static void dsp_opcode_move(void)
{
	RN = RM;
}


INLINE static void dsp_opcode_moveq(void)
{
	RN = IMM_1;
}


INLINE static void dsp_opcode_resmac(void)
{
	RN = (uint32_t)dsp_acc;
}


INLINE static void dsp_opcode_imult(void)
{
	RN = (int16_t)RN * (int16_t)RM;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_mult(void)
{
	RN = (uint16_t)RM * (uint16_t)RN;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_bclr(void)
{
	uint32_t res = RN & ~(1 << IMM_1);
	RN = res;
	SET_ZN(res);
}


INLINE static void dsp_opcode_btst(void)
{
	dsp_flag_z = (~RN >> IMM_1) & 1;
}


INLINE static void dsp_opcode_bset(void)
{
	uint32_t res = RN | (1 << IMM_1);
	RN = res;
	SET_ZN(res);
}


INLINE static void dsp_opcode_subqt(void)
{
	RN -= dsp_convert_zero[IMM_1];
}


INLINE static void dsp_opcode_addqt(void)
{
	RN += dsp_convert_zero[IMM_1];
}


INLINE static void dsp_opcode_imacn(void)
{
	int32_t res = (int16_t)RM * (int16_t)RN;

	dsp_acc_mac_apply(&dsp_acc, res);
}


INLINE static void dsp_opcode_mtoi(void)
{
	RN = (((int32_t)RM >> 8) & 0xFF800000) | (RM & 0x007FFFFF);
	SET_ZN(RN);
}


/* NORMI: the right shift that normalises an unsigned integer "as an IEEE
 * 32-bit floating point value" (JTRM v8 p.52, DSP p.108), i.e. that puts the
 * top set bit at bit 23, the hidden-bit position: (index of the top set
 * bit) - 23.  NORMI 1 = -23, NORMI $800000 = 0, NORMI $80000000 = 8, and a
 * zero source gives -32.  JERRY's netlist (DSP_A-5Q.NET, "normalisation
 * integer generator") is line-for-line the same logic as TOM's ARITH.NET.
 *
 * The old code normalised to bit 22 and returned one too many everywhere
 * (0 for a zero source) -- the same off-by-one fixed in the GPU for #611. */
INLINE static void dsp_opcode_normi(void)
{
	uint32_t _Rm = RM;
	uint32_t res = (uint32_t)-32;

	if (_Rm)
	{
		res = (uint32_t)-23;
		while ((_Rm >>= 1) != 0)
			res++;
	}
	RN = res;
	SET_ZN(RN);
}


INLINE static void dsp_opcode_mmult(void)
{
   uint32_t res;
   unsigned i;
   int count	= dsp_matrix_control&0x0f;
   uint32_t addr = 0xF1B000 | (dsp_pointer_to_matrix & 0xFFC); // in the dsp ram
   int64_t accum = 0;

   /* Per JTRM ("Systolic Matrix Multiplies"), the packed vector operand
    * lives in the SECONDARY register bank (bank 1) — an absolute bank
    * reference, not "the bank not currently selected".  With IMASK set
    * (interrupt service) the current bank is forced to 0, so the old
    * dsp_alternate_reg happened to be bank 1 and looked correct; but a
    * mixer running mainline with REGPAGE=1 (e.g. Baldies) loads its
    * sample vector into bank 1 as its CURRENT bank, and reading the
    * "alternate" bank 0 multiplies the matrix by the interrupt
    * handler's pointers instead — rail-to-rail clipped audio. */
   if (!(dsp_matrix_control & 0x10))
   {
      for (i = 0; i < count; i++)
      {
         int16_t a;
         int16_t b;

         if (i&0x01)
            a=(int16_t)((dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]>>16)&0xffff);
         else
            a=(int16_t)(dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]&0xffff);
         b=((int16_t)DSPReadWord(addr + 2, DSP));
         accum += a*b;
         addr = 0xF1B000 | ((addr + 4) & 0xFFC);
      }
   }
   else
   {
      for (i = 0; i < count; i++)
      {
         int16_t a;
         int16_t b;

         if (i&0x01)
            a=(int16_t)((dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]>>16)&0xffff);
         else
            a=(int16_t)(dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]&0xffff);
         b=((int16_t)DSPReadWord(addr + 2, DSP));
         accum += a*b;
         addr = 0xF1B000 | ((addr + 4 * count) & 0xFFC);
      }
   }
   /* SYSTOLIC.NET MACOUNT is the live ten-bit address counter,
    * not a temporary copy: later MMULTs continue where it stopped. */
   dsp_pointer_to_matrix = addr;
   RN = res = (int32_t)accum;
   // carry flag to do
   //NOTE: The flags are set based upon the last add/multiply done...
   SET_ZN(RN);
}


INLINE static void dsp_opcode_abs(void)
{
	uint32_t _Rn = RN;
	uint32_t res;

	if (_Rn == 0x80000000)
	{
		/* ABS(0x80000000) overflows back to 0x80000000; set flags accordingly:
		 * C=1 (input was negative), N=1 (result is negative), Z=0. */
		dsp_flag_n = 1;
		dsp_flag_c = 1;
		dsp_flag_z = 0;
	}
	else
	{
		dsp_flag_c = ((_Rn & 0x80000000) >> 31);
		res = RN   = ((_Rn & 0x80000000) ? -_Rn : _Rn);
		CLR_ZN;
		SET_Z(res);
	}
}


INLINE static void dsp_opcode_div(void)
{
	/* 33-bit non-restoring divide, netlist-exact (risc_div.h): correct
	 * for divisors above $80000000; a zero divisor gives $FFFFFFFF with
	 * the dividend in D_REMAIN, as the hardware does. */
	RN = risc_divide(RN, RM, dsp_div_control & 0x01, &dsp_remain);
}


INLINE static void dsp_opcode_imultn(void)
{
	// This is OK, since this multiply won't overflow 32 bits...
	int32_t res = (int32_t)((int16_t)RN * (int16_t)RM);

	dsp_acc_set_from_i32(&dsp_acc, res);
	SET_ZN(res);
}


INLINE static void dsp_opcode_neg(void)
{
	uint32_t res = -RN;
	SET_ZNC_SUB(0, RN, res);
	RN = res;
}


INLINE static void dsp_opcode_shlq(void)
{
	// NB: This instruction is the *only* one that does (32 - immediate data).
	int32_t r1 = 32 - IMM_1;
	uint32_t res = RN << r1;
	SET_ZN(res); dsp_flag_c = (RN >> 31) & 1;
	RN = res;
}


INLINE static void dsp_opcode_shrq(void)
{
	int32_t r1 = dsp_convert_zero[IMM_1];
	uint32_t res = RN >> r1;
	SET_ZN(res); dsp_flag_c = RN & 1;
	RN = res;
}


INLINE static void dsp_opcode_ror(void)
{
	uint32_t r1 = RM & 0x1F;
	uint32_t res = (RN >> r1) | (RN << ((-r1) & 31));
	SET_ZN(res); dsp_flag_c = (RN >> 31) & 1;
	RN = res;
}


INLINE static void dsp_opcode_rorq(void)
{
	/* dsp_convert_zero[0] returns 32 (rotate-by-0 means rotate-by-full-word,
	 * a no-op).  Masking to 0x1F maps 32 -> 0, preserving that semantic and
	 * avoiding `RN >> 32` UB in the rotate idiom below. */
	uint32_t r1 = dsp_convert_zero[IMM_1 & 0x1F] & 0x1F;
	uint32_t r2 = RN;
	uint32_t res = (r2 >> r1) | (r2 << ((-r1) & 31));
	RN = res;
	SET_ZN(res); dsp_flag_c = (r2 >> 31) & 0x01;
}


INLINE static void dsp_opcode_sha(void)
{
	uint32_t res;

	if ((int32_t)RM < 0)
	{
		res = ((int32_t)RM <= -32) ? 0 : (RN << -(int32_t)RM);
		dsp_flag_c = RN >> 31;
	}
	else
	{
		res = ((int32_t)RM >= 32) ? ((int32_t)RN >> 31) : ((int32_t)RN >> (int32_t)RM);
		dsp_flag_c = RN & 0x01;
	}
	RN = res;
	SET_ZN(res);
}


INLINE static void dsp_opcode_sharq(void)
{
	uint32_t res = (int32_t)RN >> dsp_convert_zero[IMM_1];
	SET_ZN(res); dsp_flag_c = RN & 0x01;
	RN = res;
}


INLINE static void dsp_opcode_sh(void)
{
	if (RM & 0x80000000)		/* Shift left */
	{
		dsp_flag_c = RN >> 31;
		RN = ((int32_t)RM <= -32 ? 0 : RN << -(int32_t)RM);
	}
	else						/* Shift right */
	{
		dsp_flag_c = RN & 0x01;
		RN = (RM >= 32 ? 0 : RN >> RM);
	}
	SET_ZN(RN);
}

void dsp_opcode_addqmod(void)
{
	uint32_t r1 = dsp_convert_zero[IMM_1];
	uint32_t r2 = RN;
	uint32_t res = r2 + r1;
	res = (res & (~dsp_modulo)) | (r2 & dsp_modulo);
	RN = res;
	SET_ZNC_ADD(r2, r1, res);
}

void dsp_opcode_subqmod(void)
{
	uint32_t r1 = dsp_convert_zero[IMM_1];
	uint32_t r2 = RN;
	uint32_t res = r2 - r1;
	res = (res & (~dsp_modulo)) | (r2 & dsp_modulo);
	RN = res;

	SET_ZNC_SUB(r2, r1, res);
}

void dsp_opcode_mirror(void)
{
	uint32_t r1 = RN;
	RN = (mirror_table[r1 & 0xFFFF] << 16) | mirror_table[r1 >> 16];
	SET_ZN(RN);
}

void dsp_opcode_sat32s(void)
{
	int32_t r2 = (uint32_t)RN;
	int32_t temp = (int32_t)(dsp_acc_i40_signed(dsp_acc) >> 32);
	uint32_t res = (temp < -1) ? (int32_t)0x80000000 : (temp > 0) ? (int32_t)0x7FFFFFFF : r2;
	RN = res;
	SET_ZN(res);
}

void dsp_opcode_sat16s(void)
{
	int32_t r2 = RN;
	uint32_t res = (r2 < -32768) ? -32768 : (r2 > 32767) ? 32767 : r2;
	RN = res;
	SET_ZN(res);
}

void dsp_opcode_illegal(void)
{
}

/* New pipelined DSP core */

INLINE static void DSP_abs(void);
INLINE static void DSP_add(void);
INLINE static void DSP_addc(void);
INLINE static void DSP_addq(void);
INLINE static void DSP_addqmod(void);
INLINE static void DSP_addqt(void);
INLINE static void DSP_and(void);
INLINE static void DSP_bclr(void);
INLINE static void DSP_bset(void);
INLINE static void DSP_btst(void);
INLINE static void DSP_cmp(void);
INLINE static void DSP_cmpq(void);
INLINE static void DSP_div(void);
INLINE static void DSP_imacn(void);
INLINE static void DSP_imult(void);
INLINE static void DSP_imultn(void);
INLINE static void DSP_illegal(void);
INLINE static void DSP_jr(void);
INLINE static void DSP_jump(void);
INLINE static void DSP_load(void);
INLINE static void DSP_loadb(void);
INLINE static void DSP_loadw(void);
INLINE static void DSP_load_r14_i(void);
INLINE static void DSP_load_r14_r(void);
INLINE static void DSP_load_r15_i(void);
INLINE static void DSP_load_r15_r(void);
INLINE static void DSP_mirror(void);
INLINE static void DSP_mmult(void);
INLINE static void DSP_move(void);
INLINE static void DSP_movefa(void);
INLINE static void DSP_movei(void);
INLINE static void DSP_movepc(void);
INLINE static void DSP_moveq(void);
INLINE static void DSP_moveta(void);
INLINE static void DSP_mtoi(void);
INLINE static void DSP_mult(void);
INLINE static void DSP_neg(void);
INLINE static void DSP_nop(void);
INLINE static void DSP_normi(void);
INLINE static void DSP_not(void);
INLINE static void DSP_or(void);
INLINE static void DSP_resmac(void);
INLINE static void DSP_ror(void);
INLINE static void DSP_rorq(void);
INLINE static void DSP_sat16s(void);
INLINE static void DSP_sat32s(void);
INLINE static void DSP_sh(void);
INLINE static void DSP_sha(void);
INLINE static void DSP_sharq(void);
INLINE static void DSP_shlq(void);
INLINE static void DSP_shrq(void);
INLINE static void DSP_store(void);
INLINE static void DSP_storeb(void);
INLINE static void DSP_storew(void);
INLINE static void DSP_store_r14_i(void);
INLINE static void DSP_store_r14_r(void);
INLINE static void DSP_store_r15_i(void);
INLINE static void DSP_store_r15_r(void);
INLINE static void DSP_sub(void);
INLINE static void DSP_subc(void);
INLINE static void DSP_subq(void);
INLINE static void DSP_subqmod(void);
INLINE static void DSP_subqt(void);
INLINE static void DSP_xor(void);

void (* DSPOpcode[64])() =
{
	DSP_add,			DSP_addc,			DSP_addq,			DSP_addqt,
	DSP_sub,			DSP_subc,			DSP_subq,			DSP_subqt,
	DSP_neg,			DSP_and,			DSP_or,				DSP_xor,
	DSP_not,			DSP_btst,			DSP_bset,			DSP_bclr,

	DSP_mult,			DSP_imult,			DSP_imultn,			DSP_resmac,
	DSP_imacn,			DSP_div,			DSP_abs,			DSP_sh,
	DSP_shlq,			DSP_shrq,			DSP_sha,			DSP_sharq,
	DSP_ror,			DSP_rorq,			DSP_cmp,			DSP_cmpq,

	DSP_subqmod,		DSP_sat16s,			DSP_move,			DSP_moveq,
	DSP_moveta,			DSP_movefa,			DSP_movei,			DSP_loadb,
	DSP_loadw,			DSP_load,			DSP_sat32s,			DSP_load_r14_i,
	DSP_load_r15_i,		DSP_storeb,			DSP_storew,			DSP_store,

	DSP_mirror,			DSP_store_r14_i,	DSP_store_r15_i,	DSP_movepc,
	DSP_jump,			DSP_jr,				DSP_mmult,			DSP_mtoi,
	DSP_normi,			DSP_nop,			DSP_load_r14_r,		DSP_load_r15_r,
	DSP_store_r14_r,	DSP_store_r15_r,	DSP_illegal,		DSP_addqmod
};

bool readAffected[64][2] =
{
	{ true,  true}, { true,  true}, {false,  true}, {false,  true},
	{ true,  true}, { true,  true}, {false,  true}, {false,  true},
	{false,  true}, { true,  true}, { true,  true}, { true,  true},
	{false,  true}, {false,  true}, {false,  true}, {false,  true},

	{ true,  true}, { true,  true}, { true,  true}, {false,  true},
	{ true,  true}, { true,  true}, {false,  true}, { true,  true},
	{false,  true}, {false,  true}, { true,  true}, {false,  true},
	{ true,  true}, {false,  true}, { true,  true}, {false,  true},

	{false,  true}, {false,  true}, { true, false}, {false, false},
	{ true, false}, {false, false}, {false, false}, { true, false},
	{ true, false}, { true, false}, {false,  true}, { true, false},
	{ true, false}, { true,  true}, { true,  true}, { true,  true},

	{false,  true}, { true,  true}, { true,  true}, {false,  true},
	{ true, false}, { true, false}, { true,  true}, { true, false},
	{ true, false}, {false, false}, { true, false}, { true, false},
	{ true,  true}, { true,  true}, {false, false}, {false,  true}
};

bool isLoadStore[65] =
{
	false, false, false, false, false, false, false, false,
	false, false, false, false, false, false, false, false,

	false, false, false, false, false, false, false, false,
	false, false, false, false, false, false, false, false,

	false, false, false, false, false, false, false,  true,
	 true,  true, false,  true,  true,  true,  true,  true,

	false,  true,  true, false, false, false, false, false,
	false, false,  true,  true,  true,  true, false, false, false
};

void FlushDSPPipeline(void)
{
   unsigned i;

	plPtrFetch = 3, plPtrRead = 2, plPtrExec = 1, plPtrWrite = 0;

	for(i=0; i<4; i++)
		pipeline[i].opcode = PIPELINE_STALL;

	for(i=0; i<32; i++)
		scoreboard[i] = 0;
}

uint32_t pcQueue1[0x400];
uint32_t pcQPtr1 = 0;
static uint32_t prevR1;

/* DSP pipelined opcode handlers */

#define PRM				pipeline[plPtrExec].reg1
#define PRN				pipeline[plPtrExec].reg2
#define PIMM1			pipeline[plPtrExec].operand1
#define PIMM2			pipeline[plPtrExec].operand2
#define PRES			pipeline[plPtrExec].result
#define PWBR			pipeline[plPtrExec].writebackRegister
#define NO_WRITEBACK	pipeline[plPtrExec].writebackRegister = 0xFF
#define DSP_PPC			dsp_pc - (pipeline[plPtrRead].opcode == 38 ? 6 : (pipeline[plPtrRead].opcode == PIPELINE_STALL ? 0 : 2)) - (pipeline[plPtrExec].opcode == 38 ? 6 : (pipeline[plPtrExec].opcode == PIPELINE_STALL ? 0 : 2))
#define WRITEBACK_ADDR	pipeline[plPtrExec].writebackRegister = 0xFE

INLINE static void DSP_abs(void)
{
	uint32_t _Rn = PRN;

	if (_Rn == 0x80000000)
	{
		/* ABS(0x80000000) overflows back to 0x80000000; set flags accordingly:
		 * C=1 (input was negative), N=1 (result is negative), Z=0.
		 * Must set PRES so the writeback stage stores the correct value. */
		PRES = 0x80000000;
		dsp_flag_n = 1;
		dsp_flag_c = 1;
		dsp_flag_z = 0;
	}
	else
	{
		dsp_flag_c = ((_Rn & 0x80000000) >> 31);
		PRES = ((_Rn & 0x80000000) ? -_Rn : _Rn);
		CLR_ZN; SET_Z(PRES);
	}
}

INLINE static void DSP_add(void)
{
	uint32_t res = PRN + PRM;
	SET_ZNC_ADD(PRN, PRM, res);
	PRES = res;
}

INLINE static void DSP_addc(void)
{
	uint32_t res = PRN + PRM + dsp_flag_c;
	uint32_t carry = dsp_flag_c;
	SET_ZNC_ADD(PRN + carry, PRM, res);
	PRES = res;
}

INLINE static void DSP_addq(void)
{
	uint32_t r1 = dsp_convert_zero[PIMM1];
	uint32_t res = PRN + r1;
	CLR_ZNC; SET_ZNC_ADD(PRN, r1, res);
	PRES = res;
}

INLINE static void DSP_addqmod(void)
{
	uint32_t r1 = dsp_convert_zero[PIMM1];
	uint32_t r2 = PRN;
	uint32_t res = r2 + r1;
	res = (res & (~dsp_modulo)) | (r2 & dsp_modulo);
	PRES = res;
	SET_ZNC_ADD(r2, r1, res);
}

INLINE static void DSP_addqt(void)
{
	PRES = PRN + dsp_convert_zero[PIMM1];
}

INLINE static void DSP_and(void)
{
	PRES = PRN & PRM;
	SET_ZN(PRES);
}

INLINE static void DSP_bclr(void)
{
	PRES = PRN & ~(1 << PIMM1);
	SET_ZN(PRES);
}

INLINE static void DSP_bset(void)
{
	PRES = PRN | (1 << PIMM1);
	SET_ZN(PRES);
}

INLINE static void DSP_btst(void)
{
	dsp_flag_z = (~PRN >> PIMM1) & 1;
	NO_WRITEBACK;
}

INLINE static void DSP_cmp(void)
{
	uint32_t res = PRN - PRM;
	SET_ZNC_SUB(PRN, PRM, res);
	NO_WRITEBACK;
}

INLINE static void DSP_cmpq(void)
{
	static int32_t sqtable[32] =
		{ 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1 };
	uint32_t r1 = sqtable[PIMM1 & 0x1F]; // I like this better -> (INT8)(jaguar.op >> 2) >> 3;
	uint32_t res = PRN - r1;
	SET_ZNC_SUB(PRN, r1, res);
	NO_WRITEBACK;
}

INLINE static void DSP_div(void)
{
	PRES = risc_divide(PRN, PRM, dsp_div_control & 0x01, &dsp_remain);
}

INLINE static void DSP_imacn(void)
{
	int32_t res = (int16_t)PRM * (int16_t)PRN;

	dsp_acc_mac_apply(&dsp_acc, res);
	NO_WRITEBACK;
}

INLINE static void DSP_imult(void)
{
	PRES = (int16_t)PRN * (int16_t)PRM;
	SET_ZN(PRES);
}

INLINE static void DSP_imultn(void)
{
	// This is OK, since this multiply won't overflow 32 bits...
	int32_t res = (int32_t)((int16_t)PRN * (int16_t)PRM);

	dsp_acc_set_from_i32(&dsp_acc, res);
	SET_ZN(res);
	NO_WRITEBACK;
}

INLINE static void DSP_illegal(void)
{
	NO_WRITEBACK;
}

// There is a problem here with interrupt handlers the JUMP and JR instructions that
// can cause trouble because an interrupt can occur *before* the instruction following the
// jump can execute... !!! FIX !!!
// This can probably be solved by judicious coding in the pipeline execution core...
// And should be fixed now...
INLINE static void DSP_jr(void)
{
   // KLUDGE: Used by BRANCH_CONDITION macro
   uint32_t jaguar_flags = (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;

   if (BRANCH_CONDITION(PIMM2))
   {
      int32_t offset = ((PIMM1 & 0x10) ? 0xFFFFFFF0 | PIMM1 : PIMM1);		// Sign extend PIMM1
      //Account for pipeline effects...
      uint32_t newPC = dsp_pc + (offset * 2) - (pipeline[plPtrRead].opcode == 38 ? 6 : (pipeline[plPtrRead].opcode == PIPELINE_STALL ? 0 : 2));

      // Now that we've branched, we have to make sure that the following instruction
      // is executed atomically with this one and then flush the pipeline before setting
      // the new PC.

      // Step 1: Handle writebacks at stage 3 of pipeline
      if (pipeline[plPtrWrite].opcode != PIPELINE_STALL)
      {
         if (pipeline[plPtrWrite].writebackRegister != 0xFF)
         {
            if (pipeline[plPtrWrite].writebackRegister != 0xFE)
               dsp_reg[pipeline[plPtrWrite].writebackRegister] = pipeline[plPtrWrite].result;
            else
            {
               if (pipeline[plPtrWrite].type == TYPE_BYTE)
                  JaguarWriteByte(pipeline[plPtrWrite].address, pipeline[plPtrWrite].value, UNKNOWN);
               else if (pipeline[plPtrWrite].type == TYPE_WORD)
                  JaguarWriteWord(pipeline[plPtrWrite].address, pipeline[plPtrWrite].value, UNKNOWN);
               else
                  JaguarWriteLong(pipeline[plPtrWrite].address, pipeline[plPtrWrite].value, UNKNOWN);
            }
         }

#ifndef NEW_SCOREBOARD
         if (affectsScoreboard[pipeline[plPtrWrite].opcode])
            scoreboard[pipeline[plPtrWrite].operand2] = false;
#else
         //Yup, sequential MOVEQ # problem fixing (I hope!)...
         if (affectsScoreboard[pipeline[plPtrWrite].opcode])
            if (scoreboard[pipeline[plPtrWrite].operand2])
               scoreboard[pipeline[plPtrWrite].operand2]--;
#endif
      }

      // Step 2: Push instruction through pipeline & execute following instruction
      // NOTE: By putting our following instruction at stage 3 of the pipeline,
      //       we effectively handle the final push of the instruction through the
      //       pipeline when the new PC takes effect (since when we return, the
      //       pipeline code will be executing the writeback stage. If we reverse
      //       the execution order of the pipeline stages, this will no longer be
      //       the case!)...
      pipeline[plPtrExec] = pipeline[plPtrRead];
      //This is BAD. We need to get that next opcode and execute it!
      //NOTE: The problem is here because of a bad stall. Once those are fixed, we can probably
      //      remove this crap.
      if (pipeline[plPtrExec].opcode == PIPELINE_STALL)
      {
         uint16_t instruction = DSPReadWord(dsp_pc, DSP);
         pipeline[plPtrExec].opcode = instruction >> 10;
         pipeline[plPtrExec].operand1 = (instruction >> 5) & 0x1F;
         pipeline[plPtrExec].operand2 = instruction & 0x1F;
         pipeline[plPtrExec].reg1 = dsp_reg[pipeline[plPtrExec].operand1];
         pipeline[plPtrExec].reg2 = dsp_reg[pipeline[plPtrExec].operand2];
         pipeline[plPtrExec].writebackRegister = pipeline[plPtrExec].operand2;	// Set it to RN
      }//*/
      dsp_pc += 2;	// For DSP_DIS_* accuracy
      dsp_exec_opcode_count++;
      DSPOpcode[pipeline[plPtrExec].opcode]();
      pipeline[plPtrWrite] = pipeline[plPtrExec];

      // Step 3: Flush pipeline & set new PC
      pipeline[plPtrRead].opcode = pipeline[plPtrExec].opcode = PIPELINE_STALL;
      dsp_pc = newPC;
   }
   else
      NO_WRITEBACK;
}

INLINE static void DSP_jump(void)
{
	// KLUDGE: Used by BRANCH_CONDITION macro
	uint32_t jaguar_flags = (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;

	if (BRANCH_CONDITION(PIMM2))
	{
		uint32_t PCSave = PRM;
		// Now that we've branched, we have to make sure that the following instruction
		// is executed atomically with this one and then flush the pipeline before setting
		// the new PC.

		// Step 1: Handle writebacks at stage 3 of pipeline
		if (pipeline[plPtrWrite].opcode != PIPELINE_STALL)
		{
			if (pipeline[plPtrWrite].writebackRegister != 0xFF)
			{
				if (pipeline[plPtrWrite].writebackRegister != 0xFE)
					dsp_reg[pipeline[plPtrWrite].writebackRegister] = pipeline[plPtrWrite].result;
				else
				{
					if (pipeline[plPtrWrite].type == TYPE_BYTE)
						JaguarWriteByte(pipeline[plPtrWrite].address, pipeline[plPtrWrite].value, UNKNOWN);
					else if (pipeline[plPtrWrite].type == TYPE_WORD)
						JaguarWriteWord(pipeline[plPtrWrite].address, pipeline[plPtrWrite].value, UNKNOWN);
					else
						JaguarWriteLong(pipeline[plPtrWrite].address, pipeline[plPtrWrite].value, UNKNOWN);
				}
			}

#ifndef NEW_SCOREBOARD
			if (affectsScoreboard[pipeline[plPtrWrite].opcode])
				scoreboard[pipeline[plPtrWrite].operand2] = false;
#else
//Yup, sequential MOVEQ # problem fixing (I hope!)...
			if (affectsScoreboard[pipeline[plPtrWrite].opcode])
				if (scoreboard[pipeline[plPtrWrite].operand2])
					scoreboard[pipeline[plPtrWrite].operand2]--;
#endif
		}

		// Step 2: Push instruction through pipeline & execute following instruction
		// NOTE: By putting our following instruction at stage 3 of the pipeline,
		//       we effectively handle the final push of the instruction through the
		//       pipeline when the new PC takes effect (since when we return, the
		//       pipeline code will be executing the writeback stage. If we reverse
		//       the execution order of the pipeline stages, this will no longer be
		//       the case!)...
		pipeline[plPtrExec] = pipeline[plPtrRead];
//This is BAD. We need to get that next opcode and execute it!
//Also, same problem in JR!
//NOTE: The problem is here because of a bad stall. Once those are fixed, we can probably
//      remove this crap.
		if (pipeline[plPtrExec].opcode == PIPELINE_STALL)
		{
		uint16_t instruction = DSPReadWord(dsp_pc, DSP);
		pipeline[plPtrExec].opcode = instruction >> 10;
		pipeline[plPtrExec].operand1 = (instruction >> 5) & 0x1F;
		pipeline[plPtrExec].operand2 = instruction & 0x1F;
			pipeline[plPtrExec].reg1 = dsp_reg[pipeline[plPtrExec].operand1];
			pipeline[plPtrExec].reg2 = dsp_reg[pipeline[plPtrExec].operand2];
			pipeline[plPtrExec].writebackRegister = pipeline[plPtrExec].operand2;	// Set it to RN
		}
	dsp_pc += 2;	// For DSP_DIS_* accuracy
		DSPOpcode[pipeline[plPtrExec].opcode]();
		pipeline[plPtrWrite] = pipeline[plPtrExec];

		// Step 3: Flush pipeline & set new PC
		pipeline[plPtrRead].opcode = pipeline[plPtrExec].opcode = PIPELINE_STALL;
		dsp_pc = PCSave;
	}
	else
		NO_WRITEBACK;
}

INLINE static void DSP_load(void)
{
#ifdef DSP_CORRECT_ALIGNMENT
	PRES = DSPReadLong(PRM & 0xFFFFFFFC, DSP);
#else
	PRES = DSPReadLong(PRM, DSP);
#endif
}

INLINE static void DSP_loadb(void)
{
	if (PRM >= DSP_WORK_RAM_BASE && PRM <= (DSP_WORK_RAM_BASE + 0x1FFF))
	{
		/* JTRM: internal-RAM byte loads perform a full 32-bit read
		 * (see dsp_opcode_loadb). */
		PRES = DSPReadLong(PRM & 0xFFFFFFFC, DSP);
	}
	else
		PRES = JaguarReadByte(PRM, DSP);
}

INLINE static void DSP_loadw(void)
{
	if (PRM >= DSP_WORK_RAM_BASE && PRM <= (DSP_WORK_RAM_BASE + 0x1FFF))
	{
		/* JTRM: internal-RAM word loads perform a full 32-bit read
		 * (see dsp_opcode_loadw). */
		PRES = DSPReadLong(PRM & 0xFFFFFFFC, DSP);
	}
#ifdef DSP_CORRECT_ALIGNMENT
	else
		PRES = JaguarReadWord(PRM & 0xFFFFFFFE, DSP);
#else
	else
		PRES = JaguarReadWord(PRM, DSP);
#endif
}

INLINE static void DSP_load_r14_i(void)
{
#ifdef DSP_CORRECT_ALIGNMENT
	PRES = DSPReadLong((dsp_reg[14] & 0xFFFFFFFC) + (dsp_convert_zero[PIMM1] << 2), DSP);
#else
	PRES = DSPReadLong(dsp_reg[14] + (dsp_convert_zero[PIMM1] << 2), DSP);
#endif
}

INLINE static void DSP_load_r14_r(void)
{
#ifdef DSP_CORRECT_ALIGNMENT
	PRES = DSPReadLong((dsp_reg[14] + PRM) & 0xFFFFFFFC, DSP);
#else
	PRES = DSPReadLong(dsp_reg[14] + PRM, DSP);
#endif
}

INLINE static void DSP_load_r15_i(void)
{
#ifdef DSP_CORRECT_ALIGNMENT
	PRES = DSPReadLong((dsp_reg[15] &0xFFFFFFFC) + (dsp_convert_zero[PIMM1] << 2), DSP);
#else
	PRES = DSPReadLong(dsp_reg[15] + (dsp_convert_zero[PIMM1] << 2), DSP);
#endif
}

INLINE static void DSP_load_r15_r(void)
{
#ifdef DSP_CORRECT_ALIGNMENT
	PRES = DSPReadLong((dsp_reg[15] + PRM) & 0xFFFFFFFC, DSP);
#else
	PRES = DSPReadLong(dsp_reg[15] + PRM, DSP);
#endif
}

INLINE static void DSP_mirror(void)
{
	uint32_t r1 = PRN;
	PRES = (mirror_table[r1 & 0xFFFF] << 16) | mirror_table[r1 >> 16];
	SET_ZN(PRES);
}

INLINE static void DSP_mmult(void)
{
	uint32_t res;
   unsigned i;
	int count	= dsp_matrix_control&0x0f;
	uint32_t addr = 0xF1B000 | (dsp_pointer_to_matrix & 0xFFC); // in the dsp ram
	int64_t accum = 0;

	/* Vector operand comes from the SECONDARY bank (bank 1) per JTRM —
	 * see dsp_opcode_mmult above. */
	if (!(dsp_matrix_control & 0x10))
	{
		for (i = 0; i < count; i++)
		{
			int16_t a;
         int16_t b;

			if (i&0x01)
				a=(int16_t)((dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]>>16)&0xffff);
			else
				a=(int16_t)(dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]&0xffff);
			b=((int16_t)DSPReadWord(addr + 2, DSP));
			accum += a*b;
			addr = 0xF1B000 | ((addr + 4) & 0xFFC);
		}
	}
	else
	{
		for (i = 0; i < count; i++)
		{
			int16_t a;
         int16_t b;

			if (i&0x01)
				a=(int16_t)((dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]>>16)&0xffff);
			else
				a=(int16_t)(dsp_reg_bank_1[dsp_opcode_first_parameter + (i>>1)]&0xffff);
			b=((int16_t)DSPReadWord(addr + 2, DSP));
			accum += a*b;
			addr = 0xF1B000 | ((addr + 4 * count) & 0xFFC);
		}
	}

   /* SYSTOLIC.NET MACOUNT is the live ten-bit address counter,
    * not a temporary copy: later MMULTs continue where it stopped. */
   dsp_pointer_to_matrix = addr;
	PRES = res = (int32_t)accum;
	// carry flag to do
//NOTE: The flags are set based upon the last add/multiply done...
	SET_ZN(PRES);
}

INLINE static void DSP_move(void)
{
	PRES = PRM;
}

INLINE static void DSP_movefa(void)
{
	PRES = dsp_alternate_reg[PIMM1];
}

INLINE static void DSP_movei(void)
{
//	// This instruction is followed by 32-bit value in LSW / MSW format...
}

INLINE static void DSP_movepc(void)
{
//Account for pipeline effects...
	PRES = dsp_pc - 2 - (pipeline[plPtrRead].opcode == 38 ? 6 : (pipeline[plPtrRead].opcode == PIPELINE_STALL ? 0 : 2));
}

INLINE static void DSP_moveq(void)
{
	PRES = PIMM1;
}

INLINE static void DSP_moveta(void)
{
	dsp_alternate_reg[PIMM2] = PRM;
	NO_WRITEBACK;
}

INLINE static void DSP_mtoi(void)
{
	PRES = (((int32_t)PRM >> 8) & 0xFF800000) | (PRM & 0x007FFFFF);
	SET_ZN(PRES);
}

INLINE static void DSP_mult(void)
{
	PRES = (uint16_t)PRM * (uint16_t)PRN;
	SET_ZN(PRES);
}

INLINE static void DSP_neg(void)
{
	uint32_t res = -PRN;
	SET_ZNC_SUB(0, PRN, res);
	PRES = res;
}

INLINE static void DSP_nop(void)
{
	NO_WRITEBACK;
}

INLINE static void DSP_normi(void)
{
	uint32_t _Rm = PRM;
	uint32_t res = 0;

	if (_Rm)
	{
		while ((_Rm & 0xffc00000) == 0)
		{
			_Rm <<= 1;
			res--;
		}
		while ((_Rm & 0xff800000) != 0)
		{
			_Rm >>= 1;
			res++;
		}
	}
	PRES = res;
	SET_ZN(PRES);
}

INLINE static void DSP_not(void)
{
	PRES = ~PRN;
	SET_ZN(PRES);
}

INLINE static void DSP_or(void)
{
	PRES = PRN | PRM;
	SET_ZN(PRES);
}

INLINE static void DSP_resmac(void)
{
	PRES = (uint32_t)dsp_acc;
}

INLINE static void DSP_ror(void)
{
	uint32_t r1 = PRM & 0x1F;
	uint32_t res = (PRN >> r1) | (PRN << ((-r1) & 31));
	SET_ZN(res); dsp_flag_c = (PRN >> 31) & 1;
	PRES = res;
}

INLINE static void DSP_rorq(void)
{
	/* See dsp_opcode_rorq above for why we mask to 0x1F. */
	uint32_t r1 = dsp_convert_zero[PIMM1 & 0x1F] & 0x1F;
	uint32_t r2 = PRN;
	uint32_t res = (r2 >> r1) | (r2 << ((-r1) & 31));
	PRES = res;
	SET_ZN(res); dsp_flag_c = (r2 >> 31) & 0x01;
}

INLINE static void DSP_sat16s(void)
{
	int32_t r2 = PRN;
	uint32_t res = (r2 < -32768) ? -32768 : (r2 > 32767) ? 32767 : r2;
	PRES = res;
	SET_ZN(res);
}

INLINE static void DSP_sat32s(void)
{
	int32_t r2 = (uint32_t)PRN;
	int32_t temp = (int32_t)(dsp_acc_i40_signed(dsp_acc) >> 32);
	uint32_t res = (temp < -1) ? (int32_t)0x80000000 : (temp > 0) ? (int32_t)0x7FFFFFFF : r2;
	PRES = res;
	SET_ZN(res);
}

INLINE static void DSP_sh(void)
{
	int32_t sRm = (int32_t)PRM;
	uint32_t _Rn = PRN;

	if (sRm < 0)
	{
		uint32_t shift = -sRm;

		if (shift >= 32)
			shift = 32;

		dsp_flag_c = (_Rn & 0x80000000) >> 31;

		while (shift)
		{
			_Rn <<= 1;
			shift--;
		}
	}
	else
	{
		uint32_t shift = sRm;

		if (shift >= 32)
			shift = 32;

		dsp_flag_c = _Rn & 0x1;

		while (shift)
		{
			_Rn >>= 1;
			shift--;
		}
	}

	PRES = _Rn;
	SET_ZN(PRES);
}

INLINE static void DSP_sha(void)
{
	int32_t sRm = (int32_t)PRM;
	uint32_t _Rn = PRN;

	if (sRm < 0)
	{
		uint32_t shift = -sRm;

		if (shift >= 32)
			shift = 32;

		dsp_flag_c = (_Rn & 0x80000000) >> 31;

		while (shift)
		{
			_Rn <<= 1;
			shift--;
		}
	}
	else
	{
		uint32_t shift = sRm;

		if (shift >= 32)
			shift = 32;

		dsp_flag_c = _Rn & 0x1;

		while (shift)
		{
			_Rn = ((int32_t)_Rn) >> 1;
			shift--;
		}
	}

	PRES = _Rn;
	SET_ZN(PRES);
}

INLINE static void DSP_sharq(void)
{
	uint32_t res = (int32_t)PRN >> dsp_convert_zero[PIMM1];
	SET_ZN(res); dsp_flag_c = PRN & 0x01;
	PRES = res;
}

INLINE static void DSP_shlq(void)
{
	int32_t r1 = 32 - PIMM1;
	uint32_t res = PRN << r1;
	SET_ZN(res); dsp_flag_c = (PRN >> 31) & 1;
	PRES = res;
}

INLINE static void DSP_shrq(void)
{
	int32_t r1 = dsp_convert_zero[PIMM1];
	uint32_t res = PRN >> r1;
	SET_ZN(res); dsp_flag_c = PRN & 1;
	PRES = res;
}

INLINE static void DSP_store(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	pipeline[plPtrExec].address = PRM & 0xFFFFFFFC;
#else
	pipeline[plPtrExec].address = PRM;
#endif
	pipeline[plPtrExec].value = PRN;
	pipeline[plPtrExec].type = TYPE_DWORD;
	WRITEBACK_ADDR;
}

INLINE static void DSP_storeb(void)
{
	pipeline[plPtrExec].address = PRM;

	if (PRM >= DSP_WORK_RAM_BASE && PRM <= (DSP_WORK_RAM_BASE + 0x1FFF))
	{
		pipeline[plPtrExec].value = PRN & 0xFF;
		pipeline[plPtrExec].type = TYPE_DWORD;
	}
	else
	{
		pipeline[plPtrExec].value = PRN;
		pipeline[plPtrExec].type = TYPE_BYTE;
	}

	WRITEBACK_ADDR;
}

INLINE static void DSP_storew(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	pipeline[plPtrExec].address = PRM & 0xFFFFFFFE;
#else
	pipeline[plPtrExec].address = PRM;
#endif

	if (PRM >= DSP_WORK_RAM_BASE && PRM <= (DSP_WORK_RAM_BASE + 0x1FFF))
	{
		pipeline[plPtrExec].value = PRN & 0xFFFF;
		pipeline[plPtrExec].type = TYPE_DWORD;
	}
	else
	{
		pipeline[plPtrExec].value = PRN;
		pipeline[plPtrExec].type = TYPE_WORD;
	}
	WRITEBACK_ADDR;
}

INLINE static void DSP_store_r14_i(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	pipeline[plPtrExec].address = (dsp_reg[14] & 0xFFFFFFFC) + (dsp_convert_zero[PIMM1] << 2);
#else
	pipeline[plPtrExec].address = dsp_reg[14] + (dsp_convert_zero[PIMM1] << 2);
#endif
	pipeline[plPtrExec].value = PRN;
	pipeline[plPtrExec].type = TYPE_DWORD;
	WRITEBACK_ADDR;
}

INLINE static void DSP_store_r14_r(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	pipeline[plPtrExec].address = (dsp_reg[14] + PRM) & 0xFFFFFFFC;
#else
	pipeline[plPtrExec].address = dsp_reg[14] + PRM;
#endif
	pipeline[plPtrExec].value = PRN;
	pipeline[plPtrExec].type = TYPE_DWORD;
	WRITEBACK_ADDR;
}

INLINE static void DSP_store_r15_i(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	pipeline[plPtrExec].address = (dsp_reg[15] & 0xFFFFFFFC) + (dsp_convert_zero[PIMM1] << 2);
#else
	pipeline[plPtrExec].address = dsp_reg[15] + (dsp_convert_zero[PIMM1] << 2);
#endif
	pipeline[plPtrExec].value = PRN;
	pipeline[plPtrExec].type = TYPE_DWORD;
	WRITEBACK_ADDR;
}

INLINE static void DSP_store_r15_r(void)
{
#ifdef DSP_CORRECT_ALIGNMENT_STORE
	pipeline[plPtrExec].address = (dsp_reg[15] + PRM) & 0xFFFFFFFC;
#else
	pipeline[plPtrExec].address = dsp_reg[15] + PRM;
#endif
	pipeline[plPtrExec].value = PRN;
	pipeline[plPtrExec].type = TYPE_DWORD;
	WRITEBACK_ADDR;
}

INLINE static void DSP_sub(void)
{
	uint32_t res = PRN - PRM;
	SET_ZNC_SUB(PRN, PRM, res);
	PRES = res;
}

INLINE static void DSP_subc(void)
{
	uint32_t res = PRN - PRM - dsp_flag_c;
	uint32_t borrow = dsp_flag_c;
	SET_ZNC_SUB(PRN - borrow, PRM, res);
	PRES = res;
}

INLINE static void DSP_subq(void)
{
	uint32_t r1 = dsp_convert_zero[PIMM1];
	uint32_t res = PRN - r1;
	SET_ZNC_SUB(PRN, r1, res);
	PRES = res;
}

INLINE static void DSP_subqmod(void)
{
	uint32_t r1 = dsp_convert_zero[PIMM1];
	uint32_t r2 = PRN;
	uint32_t res = r2 - r1;
	res = (res & (~dsp_modulo)) | (r2 & dsp_modulo);
	PRES = res;
	SET_ZNC_SUB(r2, r1, res);
}

INLINE static void DSP_subqt(void)
{
	PRES = PRN - dsp_convert_zero[PIMM1];
}

INLINE static void DSP_xor(void)
{
	PRES = PRN ^ PRM;
	SET_ZN(PRES);
}


/* Save state serialization for DSP */

#include "state.h"

size_t DSPStateSave(uint8_t *buf)
{
   uint8_t *start = buf;
   uint8_t active_bank;

   STATE_SAVE_BUF(buf, dsp_ram_8, sizeof(dsp_ram_8));
   STATE_SAVE_VAR(buf, dsp_pc);
   STATE_SAVE_VAR(buf, dsp_acc);
   STATE_SAVE_VAR(buf, dsp_remain);
   STATE_SAVE_VAR(buf, dsp_modulo);
   STATE_SAVE_VAR(buf, dsp_flags);
   STATE_SAVE_VAR(buf, dsp_matrix_control);
   STATE_SAVE_VAR(buf, dsp_pointer_to_matrix);
   STATE_SAVE_VAR(buf, dsp_data_organization);
   STATE_SAVE_VAR(buf, dsp_control);
   STATE_SAVE_VAR(buf, dsp_div_control);
   STATE_SAVE_VAR(buf, dsp_flag_z);
   STATE_SAVE_VAR(buf, dsp_flag_n);
   STATE_SAVE_VAR(buf, dsp_flag_c);
   STATE_SAVE_BUF(buf, dsp_reg_bank_0, sizeof(dsp_reg_bank_0));
   STATE_SAVE_BUF(buf, dsp_reg_bank_1, sizeof(dsp_reg_bank_1));

   /* Bit 0: the live bank.  Bits 1-2: an un-retired D_FLAGS store's
    * remaining delay (DSP_FLAGS_RETIRE_DELAY).  While one is outstanding
    * the live bank is the PRE-store bank and the switch is still owed, so
    * a state captured between the store and the instruction behind it
    * must carry both or that instruction runs in the wrong bank after a
    * load (run-ahead / netplay, #400 class).  States written before #853
    * hold 0 or 1 here, i.e. no window -- no layout change. */
   active_bank = (uint8_t)(((dsp_reg == dsp_reg_bank_0) ? 0 : 1)
                           | ((dspFlagsRetireDelay & 3) << 1));
   STATE_SAVE_VAR(buf, active_bank);

   STATE_SAVE_VAR(buf, dsp_opcode_first_parameter);
   STATE_SAVE_VAR(buf, dsp_opcode_second_parameter);
   STATE_SAVE_VAR(buf, dsp_in_exec);
   STATE_SAVE_VAR(buf, dsp_releaseTimeSlice_flag);

   /* Pipeline state */
   STATE_SAVE_BUF(buf, pipeline, sizeof(pipeline));
   STATE_SAVE_VAR(buf, plPtrFetch);
   STATE_SAVE_VAR(buf, plPtrRead);
   STATE_SAVE_VAR(buf, plPtrExec);
   STATE_SAVE_VAR(buf, plPtrWrite);
   STATE_SAVE_BUF(buf, scoreboard, sizeof(scoreboard));
   STATE_SAVE_VAR(buf, IMASKCleared);

   STATE_SAVE_VAR(buf, prevR1);

   return (size_t)(buf - start);
}


size_t DSPStateLoad(const uint8_t *buf)
{
   const uint8_t *start = buf;
   uint8_t active_bank;

   STATE_LOAD_BUF(buf, dsp_ram_8, sizeof(dsp_ram_8));
   STATE_LOAD_VAR(buf, dsp_pc);
   STATE_LOAD_VAR(buf, dsp_acc);
   STATE_LOAD_VAR(buf, dsp_remain);
   STATE_LOAD_VAR(buf, dsp_modulo);
   STATE_LOAD_VAR(buf, dsp_flags);
   STATE_LOAD_VAR(buf, dsp_matrix_control);
   STATE_LOAD_VAR(buf, dsp_pointer_to_matrix);
   STATE_LOAD_VAR(buf, dsp_data_organization);
   STATE_LOAD_VAR(buf, dsp_control);
   STATE_LOAD_VAR(buf, dsp_div_control);
   STATE_LOAD_VAR(buf, dsp_flag_z);
   STATE_LOAD_VAR(buf, dsp_flag_n);
   STATE_LOAD_VAR(buf, dsp_flag_c);
   STATE_LOAD_BUF(buf, dsp_reg_bank_0, sizeof(dsp_reg_bank_0));
   STATE_LOAD_BUF(buf, dsp_reg_bank_1, sizeof(dsp_reg_bank_1));

   STATE_LOAD_VAR(buf, active_bank);
   if ((active_bank & 1) == 0)
   {
      dsp_reg = dsp_reg_bank_0;
      dsp_alternate_reg = dsp_reg_bank_1;
   }
   else
   {
      dsp_reg = dsp_reg_bank_1;
      dsp_alternate_reg = dsp_reg_bank_0;
   }
   /* An un-retired D_FLAGS store rides in bits 1-2 (see DSPStateSave). */
   dspFlagsRetireDelay = (active_bank >> 1) & 3;
   if (dspFlagsRetireDelay > DSP_FLAGS_RETIRE_DELAY)
      dspFlagsRetireDelay = DSP_FLAGS_RETIRE_DELAY;

   STATE_LOAD_VAR(buf, dsp_opcode_first_parameter);
   STATE_LOAD_VAR(buf, dsp_opcode_second_parameter);
   STATE_LOAD_VAR(buf, dsp_in_exec);
   STATE_LOAD_VAR(buf, dsp_releaseTimeSlice_flag);

   STATE_LOAD_BUF(buf, pipeline, sizeof(pipeline));
   STATE_LOAD_VAR(buf, plPtrFetch);
   STATE_LOAD_VAR(buf, plPtrRead);
   STATE_LOAD_VAR(buf, plPtrExec);
   STATE_LOAD_VAR(buf, plPtrWrite);
   STATE_LOAD_BUF(buf, scoreboard, sizeof(scoreboard));
   STATE_LOAD_VAR(buf, IMASKCleared);

   STATE_LOAD_VAR(buf, prevR1);

   return (size_t)(buf - start);
}


/* ==================================================================
 * Timed DSP execution (issue #313 / #892)
 * ==================================================================
 *
 * Everything the DSP timing models need per instruction lives below,
 * in a loop of its own.  DSPExec() picks this path ONCE per call when
 * virtualjaguar_gpu_pipeline_timing or virtualjaguar_dram_timing is on;
 * with both off it runs its own loop and the opcode handlers exactly
 * as on develop -- no per-instruction or per-load/store test of either
 * option is left on that path (the "model off unchanged" gate).
 *
 * DSPExecTimed() is DSPExec()'s loop minus the #569 idle-loop probe
 * (which both options already disable) plus the model hooks:
 *   - DSPPipeCheckUse() before dispatch (pipeline model only);
 *   - dsp_executeOpcodeT(): the memory hook for load/store opcodes
 *     (DSPMemPre) and the timed jump/jr variants, which charge their
 *     inlined delay slot and refill;
 *   - DSPTimedCharge() for the slice deduction.
 * Results are identical to the untimed path; only time is charged. */

/* Load/store memory hook, evaluated BEFORE the opcode runs so the
 * address registers still hold their pre-instruction values.  Address
 * expressions mirror the opcode bodies (alignment masking does not
 * matter for the local/external decision or the bus cost). */
static void DSPMemPre(uint32_t index)
{
	switch (index)
	{
	case 39: DSPMemTimed(RM, 1, 0); break;                                         /* loadb */
	case 40: DSPMemTimed(RM, 1, 0); break;                                         /* loadw */
	case 41: DSPMemTimed(RM, 1, 1); break;                                         /* load */
	case 43: DSPMemTimed(dsp_reg[14] + (dsp_convert_zero[IMM_1] << 2), 1, 1); break; /* load (r14+n) */
	case 44: DSPMemTimed(dsp_reg[15] + (dsp_convert_zero[IMM_1] << 2), 1, 1); break; /* load (r15+n) */
	case 45: DSPMemTimed(RM, 0, 0); break;                                         /* storeb */
	case 46: DSPMemTimed(RM, 0, 0); break;                                         /* storew */
	case 47: DSPMemTimed(RM, 0, 1); break;                                         /* store */
	case 49: DSPMemTimed(dsp_reg[14] + (dsp_convert_zero[IMM_1] << 2), 0, 1); break; /* store (r14+n) */
	case 50: DSPMemTimed(dsp_reg[15] + (dsp_convert_zero[IMM_1] << 2), 0, 1); break; /* store (r15+n) */
	case 58: DSPMemTimed(dsp_reg[14] + RM, 1, 1); break;                           /* load (r14+Rn) */
	case 59: DSPMemTimed(dsp_reg[15] + RM, 1, 1); break;                           /* load (r15+Rn) */
	case 60: DSPMemTimed(dsp_reg[14] + RM, 0, 1); break;                           /* store (r14+Rn) */
	case 61: DSPMemTimed(dsp_reg[15] + RM, 0, 1); break;                           /* store (r15+Rn) */
	default: break;
	}
}

static void dsp_opcode_jump_t(void);
static void dsp_opcode_jr_t(void);

/* Timed-path dispatch: the untimed handlers, plus the memory hook and
 * the timed jump variants. */
static void dsp_executeOpcodeT(uint32_t index)
{
	if (index == 52)
	{
		dsp_opcode_jump_t();
		return;
	}
	if (index == 53)
	{
		dsp_opcode_jr_t();
		return;
	}
	DSPMemPre(index);
	dsp_executeOpcode(index);
}

/* dsp_opcode_jump() plus the model's delay-slot accounting: the inlined
 * delay slot is never charged by the exec loop, and a taken JUMP adds
 * ~2 dead refill ticks (R12).  Pipeline model only, as before. */
static void dsp_opcode_jump_t(void)
{
	/* KLUDGE: Used by BRANCH_CONDITION */
	uint32_t jaguar_flags = (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;

	if (BRANCH_CONDITION(IMM_2))
	{
		uint32_t delayed_pc = RM;
		uint16_t ds_opcode;
		uint32_t ds_index;
		int dsTimed = (dsp_mem_timed == 2);

		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
		if (dsp_pc >= DSP_WORK_RAM_BASE && dsp_pc < DSP_WORK_RAM_BASE + 0x2000 - 1)
		{
			uint32_t off = dsp_pc - DSP_WORK_RAM_BASE;
			ds_opcode = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
		}
		else
			ds_opcode = DSPReadWord(dsp_pc, DSP);
		ds_index = ds_opcode >> 10;
		dsp_opcode_first_parameter  = (ds_opcode >> 5) & 0x1F;
		dsp_opcode_second_parameter = ds_opcode & 0x1F;
		dsp_pc += 2;
		dsp_exec_opcode_count++;
		if (dsTimed)
			DSPPipeCheckUse(ds_index);
		dsp_executeOpcodeT(ds_index);
		if (dsTimed)
		{
			dsp_pipe_core_stall += 1u + 2u;
			dsp_pipe_stall_total += 1u + 2u;
		}
		dsp_pc = delayed_pc;
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
	}
}

/* dsp_opcode_jr() plus the delay-slot charge and the taken-JR refill
 * (~3 dead ticks, R13). */
static void dsp_opcode_jr_t(void)
{
	/* KLUDGE: Used by BRANCH_CONDITION */
	uint32_t jaguar_flags = (dsp_flag_n << 2) | (dsp_flag_c << 1) | dsp_flag_z;

	if (BRANCH_CONDITION(IMM_2))
	{
		int32_t offset = ((IMM_1 & 0x10) ? 0xFFFFFFF0 | IMM_1 : IMM_1);		/* Sign extend IMM_1 */
		int32_t delayed_pc = dsp_pc + (offset * 2);
		uint16_t ds_opcode;
		uint32_t ds_index;
		int dsTimed = (dsp_mem_timed == 2);

		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
		if (dsp_pc >= DSP_WORK_RAM_BASE && dsp_pc < DSP_WORK_RAM_BASE + 0x2000 - 1)
		{
			uint32_t off = dsp_pc - DSP_WORK_RAM_BASE;
			ds_opcode = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
		}
		else
			ds_opcode = DSPReadWord(dsp_pc, DSP);
		ds_index = ds_opcode >> 10;
		dsp_opcode_first_parameter  = (ds_opcode >> 5) & 0x1F;
		dsp_opcode_second_parameter = ds_opcode & 0x1F;
		dsp_pc += 2;
		dsp_exec_opcode_count++;
		if (dsTimed)
			DSPPipeCheckUse(ds_index);
		dsp_executeOpcodeT(ds_index);
		if (dsTimed)
		{
			dsp_pipe_core_stall += 1u + 3u;
			dsp_pipe_stall_total += 1u + 3u;
		}
		dsp_pc = delayed_pc;
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay = 0;
			DSPUpdateRegisterBanks();
		}
	}
}

/* DSPExec()'s loop for timed slices -- see the block comment above.
 * Kept statement-for-statement in step with DSPExec() apart from the
 * marked model hooks and the absent idle-loop probe. */
/* Out of line on purpose: inlined, it would merge both loops into
 * DSPExec() and change the untimed path's code. */
static DSP_NOINLINE void DSPExecTimed(int32_t cycles)
{
	int gdbArmedSlice;
	int pipeTiming;
	uint32_t riscScale;
	uint32_t *ldxArmed = NULL;
	uint32_t ldxVal = 0, ldxPc = 0;
	uint32_t *divArmed = NULL;
	uint32_t divOld = 0, divPc = 0;

#ifdef DSP_SINGLE_STEPPING
	if (dsp_control & 0x18)
	{
		cycles = 1;
		dsp_control &= ~0x10;
	}
#endif
	/* No return between here and VJP_LEAVE (perf_iface.h). */
	VJP_ENTER(VJP_DSP);

	dsp_releaseTimeSlice_flag = 0;
	gdbArmedSlice = gdbArmedDSP;
	dsp_in_exec++;
	/* Model hook: latch the timing mode for this slice. */
	dsp_mem_timed = vjs.gpuPipelineTiming ? 2 : 1;
	pipeTiming = (dsp_mem_timed == 2);
	riscScale  = riscClockScalePct;

	/* The #569 idle-loop probe is never active here: its gate already
	 * excludes both timing options.  Its per-call statics are reset as
	 * DSPExec does, so nothing stale survives into a later untimed
	 * slice. */
	idleProbeStage = 0;
	idleMemoCount  = 0;
	idleMemoNext   = 0;
	dsp_ldx_slot   = NULL;

	while ((cycles > 0 || ldxArmed || divArmed) && DSP_RUNNING)
	{
		uint16_t opcode;
		uint32_t index;
		uint32_t pcThis;
#ifdef VJ_TRACE
		VJT_PCHIST_DSP(dsp_pc);
#endif

		if (IMASKCleared && dspFlagsRetireDelay == 0)
		{
			DSPHandleIRQsNP();
			IMASKCleared = false;
		}

		/* PC escape bail-out -- see DSPExec. */
		if (!((dsp_pc <= 0x00E3FFFF) ||
		      (dsp_pc >= DSP_WORK_RAM_BASE && dsp_pc < DSP_WORK_RAM_BASE + 0x2000)))
		{
			cycles = 0;
			break;
		}

		pcThis = dsp_pc;

#if !defined(VJ_GDB_STUB_DISABLE_HOOKS) && !defined(VJ_GDB_STUB_DISABLE_DSP_HOOK)
		if (gdbArmedSlice && GDBCheckPC(GDB_TGT_DSP, pcThis))
		{
			GDBHalt(GDB_TGT_DSP, GDB_STOP_BREAKPOINT, pcThis);
			gdbArmedSlice = gdbArmedDSP;
		}
#endif

		if (dsp_pc >= DSP_WORK_RAM_BASE && dsp_pc < DSP_WORK_RAM_BASE + 0x2000 - 1)
		{
			uint32_t off = dsp_pc - DSP_WORK_RAM_BASE;
			opcode = ((uint16_t)dsp_ram_8[off] << 8) | (uint16_t)dsp_ram_8[off + 1];
		}
		else
			opcode = DSPReadWord(dsp_pc, DSP);
		index = opcode >> 10;
		dsp_opcode_first_parameter = (opcode >> 5) & 0x1F;
		dsp_opcode_second_parameter = opcode & 0x1F;
		dsp_pc += 2;
		dsp_exec_opcode_count++;
		/* Model hook: score-board / interlock waits BEFORE the opcode
		 * runs (only time is charged, results are unchanged). */
		if (pipeTiming)
		{
			dsp_bus_stall = 0;
			dsp_pipe_core_stall = 0;
			DSPPipeCheckUse(index);
		}
		if (divArmed && pcThis == divPc
		      && &dsp_reg[dsp_opcode_second_parameter] == divArmed)
		{
			/* Issue #811 -- see DSPExec. */
			uint32_t quot = *divArmed;

			*divArmed = divOld;
			dsp_executeOpcodeT(index);
			*divArmed = quot;
			dsp_div_store_fixups++;
			divArmed = NULL;
		}
		else if (index == 21)
		{
			uint32_t *dst = &dsp_reg[dsp_opcode_second_parameter];
			uint32_t old = *dst;

			dsp_executeOpcodeT(index);
			divArmed = DSPDivStorePeek(dst, &divPc);
			divOld = old;
		}
		else
		{
			dsp_executeOpcodeT(index);
			divArmed = NULL;
		}
		/* Model hook: timed slice deduction. */
		cycles -= DSPTimedCharge(index, riscScale);

		/* Issue #811 late load write-back -- see DSPExec. */
		if (ldxArmed)
		{
			if (pcThis == ldxPc
			      && &dsp_reg[dsp_opcode_second_parameter] == ldxArmed)
			{
				*ldxArmed = ldxVal;
				dsp_load_wb_fixups++;
			}
			ldxArmed = NULL;
		}
		if (dsp_ldx_slot)
		{
			ldxArmed = DSPLoadOverwritePeek(&ldxVal, &ldxPc);
			dsp_ldx_slot = NULL;
		}

		/* D_FLAGS retire -- see DSPExec. */
		if (dspFlagsRetireDelay)
		{
			dspFlagsRetireDelay--;
			if (dspFlagsRetireDelay == 0)
				DSPUpdateRegisterBanks();
		}
	}

	dsp_in_exec--;

	VJP_LEAVE(VJP_DSP);
}
