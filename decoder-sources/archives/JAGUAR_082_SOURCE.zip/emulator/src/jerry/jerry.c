//
// JERRY Core
//
// Originally by David Raingeard
// GCC/SDL port by Niels Wagenaar (Linux/WIN32) and Carwin Jones (BeOS)
// Cleanups/rewrites/fixes by James Hammons
//
// JLH = James Hammons <jlhamm@acm.org>
//
// WHO  WHEN        WHAT
// ---  ----------  -----------------------------------------------------------
// JLH  11/25/2009  Major rewrite of memory subsystem and handlers
//

// ------------------------------------------------------------
// JERRY REGISTERS (Mapped by Aaron Giles)
// ------------------------------------------------------------
// F10000-F13FFF   R/W   xxxxxxxx xxxxxxxx   Jerry
// F10000            W   xxxxxxxx xxxxxxxx   JPIT1 - timer 1 pre-scaler
// F10002            W   xxxxxxxx xxxxxxxx   JPIT2 - timer 1 divider
// F10004            W   xxxxxxxx xxxxxxxx   JPIT3 - timer 2 pre-scaler
// F10008            W   xxxxxxxx xxxxxxxx   JPIT4 - timer 2 divider
// F10010            W   ------xx xxxxxxxx   CLK1 - processor clock divider
// F10012            W   ------xx xxxxxxxx   CLK2 - video clock divider
// F10014            W   -------- --xxxxxx   CLK3 - chroma clock divider
// F10020          R/W   ---xxxxx ---xxxxx   JINTCTRL - interrupt control register
//                   W   ---x---- --------      (J_SYNCLR - clear synchronous serial intf ints)
//                   W   ----x--- --------      (J_ASYNCLR - clear asynchronous serial intf ints)
//                   W   -----x-- --------      (J_TIM2CLR - clear timer 2 [tempo] interrupts)
//                   W   ------x- --------      (J_TIM1CLR - clear timer 1 [sample] interrupts)
//                   W   -------x --------      (J_EXTCLR - clear external interrupts)
//                 R/W   -------- ---x----      (J_SYNENA - enable synchronous serial intf ints)
//                 R/W   -------- ----x---      (J_ASYNENA - enable asynchronous serial intf ints)
//                 R/W   -------- -----x--      (J_TIM2ENA - enable timer 2 [tempo] interrupts)
//                 R/W   -------- ------x-      (J_TIM1ENA - enable timer 1 [sample] interrupts)
//                 R/W   -------- -------x      (J_EXTENA - enable external interrupts)
// F10030          R/W   -------- xxxxxxxx   ASIDATA - asynchronous serial data
// F10032            W   -x------ -xxxxxxx   ASICTRL - asynchronous serial control
//                   W   -x------ --------      (TXBRK - transmit break)
//                   W   -------- -x------      (CLRERR - clear error)
//                   W   -------- --x-----      (RINTEN - enable receiver interrupts)
//                   W   -------- ---x----      (TINTEN - enable transmitter interrupts)
//                   W   -------- ----x---      (RXIPOL - receiver input polarity)
//                   W   -------- -----x--      (TXOPOL - transmitter output polarity)
//                   W   -------- ------x-      (PAREN - parity enable)
//                   W   -------- -------x      (ODD - odd parity select)
// F10032          R     xxx-xxxx x-xxxxxx   ASISTAT - asynchronous serial status
//                 R     x------- --------      (ERROR - OR of PE,FE,OE)
//                 R     -x------ --------      (TXBRK - transmit break)
//                 R     --x----- --------      (SERIN - serial input)
//                 R     ----x--- --------      (OE - overrun error)
//                 R     -----x-- --------      (FE - framing error)
//                 R     ------x- --------      (PE - parity error)
//                 R     -------x --------      (TBE - transmit buffer empty)
//                 R     -------- x-------      (RBF - receive buffer full)
//                 R     -------- ---x----      (TINTEN - enable transmitter interrupts)
//                 R     -------- ----x---      (RXIPOL - receiver input polarity)
//                 R     -------- -----x--      (TXOPOL - transmitter output polarity)
//                 R     -------- ------x-      (PAREN - parity enable)
//                 R     -------- -------x      (ODD - odd parity)
// F10034          R/W   xxxxxxxx xxxxxxxx   ASICLK - asynchronous serial interface clock
// F10036          R     xxxxxxxx xxxxxxxx   JPIT1 - timer 1 pre-scaler
// F10038          R     xxxxxxxx xxxxxxxx   JPIT2 - timer 1 divider
// F1003A          R     xxxxxxxx xxxxxxxx   JPIT3 - timer 2 pre-scaler
// F1003C          R     xxxxxxxx xxxxxxxx   JPIT4 - timer 2 divider
// ------------------------------------------------------------
// F14000-F17FFF   R/W   xxxxxxxx xxxxxxxx   Joysticks and GPIO0-5
// F14000          R     xxxxxxxx xxxxxxxx   JOYSTICK - read joystick state
// F14000            W   x------- xxxxxxxx   JOYSTICK - latch joystick output
//                   W   x------- --------      (enable joystick outputs)
//                   W   -------- xxxxxxxx      (joystick output data)
// F14002          R     xxxxxxxx xxxxxxxx   JOYBUTS - button register
// F14800-F14FFF   R/W   xxxxxxxx xxxxxxxx   GPI00 - reserved (CD-ROM? no.)
// F15000-F15FFF   R/W   xxxxxxxx xxxxxxxx   GPI01 - reserved
// F16000-F16FFF   R/W   xxxxxxxx xxxxxxxx   GPI02 - reserved
// F17000-F177FF   R/W   xxxxxxxx xxxxxxxx   GPI03 - reserved
// F17800-F17BFF   R/W   xxxxxxxx xxxxxxxx   GPI04 - reserved
// F17C00-F17FFF   R/W   xxxxxxxx xxxxxxxx   GPI05 - "Paddle Interface":
//                                           the early-board 8-bit ADC
//                                           (ADC0844 at U16).  See
//                                           src/jerry/paddle.h (#505).
//                 R     -------- xxxxxxxx      (completed conversion)
//                   W   -------- ----xxxx      (MUX address: channel | 4)
// ------------------------------------------------------------
// F18000-F1FFFF   R/W   xxxxxxxx xxxxxxxx   Jerry DSP
// F1A100          R/W   xxxxxxxx xxxxxxxx   D_FLAGS - DSP flags register
//                 R/W   x------- --------      (DMAEN - DMA enable)
//                 R/W   -x------ --------      (REGPAGE - register page)
//                   W   --x----- --------      (D_EXT0CLR - clear external interrupt 0)
//                   W   ---x---- --------      (D_TIM2CLR - clear timer 2 interrupt)
//                   W   ----x--- --------      (D_TIM1CLR - clear timer 1 interrupt)
//                   W   -----x-- --------      (D_I2SCLR - clear I2S interrupt)
//                   W   ------x- --------      (D_CPUCLR - clear CPU interrupt)
//                 R/W   -------x --------      (D_EXT0ENA - enable external interrupt 0)
//                 R/W   -------- x-------      (D_TIM2ENA - enable timer 2 interrupt)
//                 R/W   -------- -x------      (D_TIM1ENA - enable timer 1 interrupt)
//                 R/W   -------- --x-----      (D_I2SENA - enable I2S interrupt)
//                 R/W   -------- ---x----      (D_CPUENA - enable CPU interrupt)
//                 R/W   -------- ----x---      (IMASK - interrupt mask)
//                 R/W   -------- -----x--      (NEGA_FLAG - ALU negative)
//                 R/W   -------- ------x-      (CARRY_FLAG - ALU carry)
//                 R/W   -------- -------x      (ZERO_FLAG - ALU zero)
// F1A102          R/W   -------- ------xx   D_FLAGS - upper DSP flags
//                 R/W   -------- ------x-      (D_EXT1ENA - enable external interrupt 1)
//                 R/W   -------- -------x      (D_EXT1CLR - clear external interrupt 1)
// F1A104            W   -------- ----xxxx   D_MTXC - matrix control register
//                   W   -------- ----x---      (MATCOL - column/row major)
//                   W   -------- -----xxx      (MATRIX3-15 - matrix width)
// F1A108            W   ----xxxx xxxxxx--   D_MTXA - matrix address register
// F1A10C            W   -------- -----x-x   D_END - data organization register
//                   W   -------- -----x--      (BIG_INST - big endian instruction fetch)
//                   W   -------- -------x      (BIG_IO - big endian I/O)
// F1A110          R/W   xxxxxxxx xxxxxxxx   D_PC - DSP program counter
// F1A114          R/W   xxxxxxxx xx-xxxxx   D_CTRL - DSP control/status register
//                 R     xxxx---- --------      (VERSION - DSP version code)
//                 R/W   ----x--- --------      (BUS_HOG - hog the bus!)
//                 R/W   -----x-- --------      (D_EXT0LAT - external interrupt 0 latch)
//                 R/W   ------x- --------      (D_TIM2LAT - timer 2 interrupt latch)
//                 R/W   -------x --------      (D_TIM1LAT - timer 1 interrupt latch)
//                 R/W   -------- x-------      (D_I2SLAT - I2S interrupt latch)
//                 R/W   -------- -x------      (D_CPULAT - CPU interrupt latch)
//                 R/W   -------- ---x----      (SINGLE_GO - single step one instruction)
//                 R/W   -------- ----x---      (SINGLE_STEP - single step mode)
//                 R/W   -------- -----x--      (FORCEINT0 - cause interrupt 0 on GPU)
//                 R/W   -------- ------x-      (CPUINT - send GPU interrupt to CPU)
//                 R/W   -------- -------x      (DSPGO - enable DSP execution)
// F1A116          R/W   -------- -------x   D_CTRL - upper DSP control/status register
//                 R/W   -------- -------x      (D_EXT1LAT - external interrupt 1 latch)
// F1A118-F1A11B     W   xxxxxxxx xxxxxxxx   D_MOD - modulo instruction mask
// F1A11C-F1A11F   R     xxxxxxxx xxxxxxxx   D_REMAIN - divide unit remainder
// F1A11C            W   -------- -------x   D_DIVCTRL - divide unit control
//                   W   -------- -------x      (DIV_OFFSET - 1=16.16 divide, 0=32-bit divide)
// F1A120-F1A123   R     xxxxxxxx xxxxxxxx   D_MACHI - multiply & accumulate high bits
// F1A148            W   xxxxxxxx xxxxxxxx   R_DAC - right transmit data
// F1A14C            W   xxxxxxxx xxxxxxxx   L_DAC - left transmit data
// F1A150            W   -------- xxxxxxxx   SCLK - serial clock frequency
// F1A150          R     -------- ------xx   SSTAT
//                 R     -------- ------x-      (left - no description)
//                 R     -------- -------x      (WS - word strobe status)
// F1A154            W   -------- --xxxx-x   SMODE - serial mode
//                   W   -------- --x-----      (EVERYWORD - interrupt on MSB of every word)
//                   W   -------- ---x----      (FALLING - interrupt on falling edge)
//                   W   -------- ----x---      (RISING - interrupt of rising edge)
//                   W   -------- -----x--      (WSEN - enable word strobes)
//                   W   -------- -------x      (INTERNAL - enables serial clock)
// ------------------------------------------------------------
// F1B000-F1CFFF   R/W   xxxxxxxx xxxxxxxx   Local DSP RAM
// ------------------------------------------------------------
// F1D000          R     xxxxxxxx xxxxxxxx   ROM_TRI - triangle wave
// F1D200          R     xxxxxxxx xxxxxxxx   ROM_SINE - full sine wave
// F1D400          R     xxxxxxxx xxxxxxxx   ROM_AMSINE - amplitude modulated sine wave
// F1D600          R     xxxxxxxx xxxxxxxx   ROM_12W - sine wave and second order harmonic
// F1D800          R     xxxxxxxx xxxxxxxx   ROM_CHIRP16 - chirp
// F1DA00          R     xxxxxxxx xxxxxxxx   ROM_NTRI - traingle wave with noise
// F1DC00          R     xxxxxxxx xxxxxxxx   ROM_DELTA - spike
// F1DE00          R     xxxxxxxx xxxxxxxx   ROM_NOISE - white noise
// ------------------------------------------------------------

#include "jerry.h"

#include <stdio.h>
#include <string.h>								// For memcpy
#include "cdrom.h"
#include "log.h"
#include "dac.h"
#include "dsp.h"
#include "eeprom.h"
#include "event.h"
#include "jaggd.h"
#include "jaguar.h"
#include "perf_counters.h"

PERF_COUNTER(timing_jerry_irqs);
#include "inputdev.h"
#include "joystick.h"
#include "jlink.h"
#include "paddle.h"
#include "uart.h"
#include "m68000/m68kinterface.h"
#include "memtrack.h"
#include "settings.h"
#include "tom.h"
#include "wavetable.h"

//Note that 44100 Hz requires samples every 22.675737 usec.

#define JERRY_TRACE_DEBUG 0
#if JERRY_TRACE_DEBUG
#define JERRY_TRACE(...) LOG_DBG("[JERRY-TRACE] " __VA_ARGS__)
#else
#define JERRY_TRACE(...) ((void)0)
#endif

uint8_t jerry_ram_8[0x10000];

uint8_t analog_x, analog_y;

static uint32_t JERRYPIT1Prescaler;
static uint32_t JERRYPIT1Divider;
static uint32_t JERRYPIT2Prescaler;
static uint32_t JERRYPIT2Divider;
static int32_t jerry_timer_1_counter;
static int32_t jerry_timer_2_counter;

int32_t JERRYI2SInterruptTimer = -1;
uint32_t jerryI2SCycles;
uint32_t jerryIntPending;

static uint16_t jerryInterruptMask = 0;
static uint16_t jerryPendingInterrupt = 0;

// Private function prototypes

void JERRYResetPIT1(void);
void JERRYResetPIT2(void);
void JERRYResetI2S(void);

void JERRYPIT1Callback(void);
void JERRYPIT2Callback(void);
void JERRYI2SCallback(void);


void JERRYResetI2S(void)
{
   *sclk = 8;
   JERRYI2SInterruptTimer = -1;
}


/*
 * PIT clock rate: both PITs divide the full processor clock (26.59 MHz
 * NTSC), per JTRM Rev 8 p.16 ("The system clock is divided by (one plus the
 * value in the first register)") and Software Reference v2.4 pp.14, 69-71.
 * JERRY PIT uses the RISC rate (full system clock); so does the TOM PIT
 * (see TOMResetPIT in src/tom/tom.c).  A half-rate (M68K) TOM PIT was tried
 * for Battle Sphere in PRs #134/#141/#154 and reverted (4e51603) -- it broke
 * Doom and Rayman music timing.  Source: JTRM Rev 8 p.16.
 */

void JERRYResetPIT1(void)
{
   RemoveCallback(JERRYPIT1Callback);

   if (JERRYPIT1Prescaler | JERRYPIT1Divider)
   {
      double usecs = (double)(JERRYPIT1Prescaler + 1) * (double)(JERRYPIT1Divider + 1)
         * (vjs.hardwareTypeNTSC ? RISC_CYCLE_IN_USEC : RISC_CYCLE_PAL_IN_USEC);
      SetCallbackTime(JERRYPIT1Callback, usecs, EVENT_JERRY);
   }
}


void JERRYResetPIT2(void)
{
   RemoveCallback(JERRYPIT2Callback);

   if (JERRYPIT2Prescaler | JERRYPIT2Divider)
   {
      double usecs = (double)(JERRYPIT2Prescaler + 1) * (double)(JERRYPIT2Divider + 1)
         * (vjs.hardwareTypeNTSC ? RISC_CYCLE_IN_USEC : RISC_CYCLE_PAL_IN_USEC);
      SetCallbackTime(JERRYPIT2Callback, usecs, EVENT_JERRY);
   }
}


// This is the cause of the regressions in Cybermorph and Missile Command 3D...
// Solution: Probably have to check the DSP enable bit before sending these thru.

void JERRYPIT1Callback(void)
{
   if (TOMIRQEnabled(IRQ_DSP))
   {
      if (jerryInterruptMask & IRQ2_TIMER1)		// CPU Timer 1 IRQ
      {
         // Not sure, but I think we don't generate another IRQ if one's already going...
         // But this seems to work... :-/
         jerryPendingInterrupt |= IRQ2_TIMER1;
         PERF_INC(timing_jerry_irqs);
         m68k_set_irq(2);						// Generate 68K IPL 2
      }
   }

   DSPSetIRQLine(DSPIRQ_TIMER0, ASSERT_LINE);	// This does the 'IRQ enabled' checking...
   JERRYResetPIT1();
}


void JERRYPIT2Callback(void)
{
   if (TOMIRQEnabled(IRQ_DSP))
   {
      if (jerryInterruptMask & IRQ2_TIMER2)		// CPU Timer 2 IRQ
      {
         jerryPendingInterrupt |= IRQ2_TIMER2;
         PERF_INC(timing_jerry_irqs);
         m68k_set_irq(2);						// Generate 68K IPL 2
      }
   }

   DSPSetIRQLine(DSPIRQ_TIMER1, ASSERT_LINE);	// This does the 'IRQ enabled' checking...
   JERRYResetPIT2();
}


/* Restart the I2S interrupt timer chain WITHOUT asserting an interrupt
 * now.  Called on SCLK writes (src/jerry/dac.c).  On real hardware the
 * SSI raises its first word-strobe interrupt only after a complete I2S
 * word has been shifted -- 32 bits x 2 clock phases x (SCLK+1) system
 * clocks -- never in the same instruction that programmed the clock.
 * Invoking JERRYI2SCallback() synchronously here vectored the DSP into
 * its I2S handler in the middle of the store that wrote SCLK, before
 * the DSP module's init code had set up the handler's pointer
 * registers; the handler then wrote CD samples through stale pointers
 * over its own code (Highlander / Dragon's Lair CD crash: dsp_pc
 * escape to $FFFFCE03 after a module re-upload). */
void JERRYRescheduleI2S(void)
{
   double usecs;

   jerryI2SCycles = 32 * (2 * (*sclk + 1));

   if (*smode & SMODE_INTERNAL)
      usecs = (double)jerryI2SCycles
         * (vjs.hardwareTypeNTSC ? RISC_CYCLE_IN_USEC : RISC_CYCLE_PAL_IN_USEC);
   else
      usecs = 22.675737;

   SetCallbackTime(JERRYI2SCallback, usecs, EVENT_JERRY);
}


void JERRYI2SCallback(void)
{
   // We don't have to divide the RISC clock rate by this--the reason is a bit
   // convoluted. Will put explanation here later...
   // What's needed here is to find the ratio of the frequency to the number of clock cycles
   // in one second. For example, if the sample rate is 44100, we divide the clock rate by
   // this: 26590906 / 44100 = 602 cycles.
   // Which means, every 602 cycles that go by we have to generate an interrupt.
   jerryI2SCycles = 32 * (2 * (*sclk + 1));

   // If INTERNAL flag is set, then JERRY's SCLK is master
   if (*smode & SMODE_INTERNAL)
   {
      double usecs;

      /* Latch the pair the DSP left from the previous strobe before
       * asking it for the next one -- one sample per word clock. */
      DACWordStrobe();

      // This does the 'IRQ enabled' checking...
      DSPSetIRQLine(DSPIRQ_SSI, ASSERT_LINE);
      //		double usecs = (float)jerryI2SCycles * RISC_CYCLE_IN_USEC;
      //this fix is almost enough to fix timings in tripper, but not quite enough...
      usecs = (float)jerryI2SCycles * (vjs.hardwareTypeNTSC ? RISC_CYCLE_IN_USEC : RISC_CYCLE_PAL_IN_USEC);
      SetCallbackTime(JERRYI2SCallback, usecs, EVENT_JERRY);
   }
   else
   {
      // JERRY is slave to external word clock

      //Note that 44100 Hz requires samples every 22.675737 usec.
      //When JERRY is slave to the word clock, we need to do interrupts either at 44.1K
      //sample rate or at a 88.2K sample rate (11.332... usec).

      /* The external word clock runs whether or not BUTCH has data, and
       * the DAC re-transmits the holding register when the DSP does not
       * refresh it.  Latch unconditionally so the ring fills at the same
       * 44.1 kHz DACUpdateSCLKRate() resamples from. */
      DACWordStrobe();

      if (ButchIsReadyToSend())//Not sure this is right spot to check...
      {
         /* CDDA-DIAG: samples/s delivered from BUTCH to LRXD/RRXD in
          * slave mode; ~44100/s expected while CD audio should play. */
         static uint32_t ssiDeliveries = 0;
         ssiDeliveries++;
         if (ssiDeliveries <= 3 || (ssiDeliveries % 220500) == 0)
            LOG_DBG("[CDDA] BUTCH->SSI delivery #%u (%us of samples)\n",
                    ssiDeliveries, ssiDeliveries / 44100);
         //	return GetWordFromButchSSI(offset, who);
         SetSSIWordsXmittedFromButch();
         DSPSetIRQLine(DSPIRQ_SSI, ASSERT_LINE);
      }

      SetCallbackTime(JERRYI2SCallback, 22.675737, EVENT_JERRY);
   }
}


void JERRYInit(void)
{
   JoystickInit();
   InputDevInit();
   PaddleInit();
   MTInit();
   memcpy(&jerry_ram_8[0xD000], waveTableROM, 0x1000);

   JERRYPIT1Prescaler = 0xFFFF;
   JERRYPIT2Prescaler = 0xFFFF;
   JERRYPIT1Divider = 0xFFFF;
   JERRYPIT2Divider = 0xFFFF;
   jerryInterruptMask = 0x0000;
   jerryPendingInterrupt = 0x0000;

   DACInit();
   UARTInit();
}


void JERRYReset(void)
{
   JoystickReset();
   InputDevReset();
   PaddleReset();
   EepromReset();
   MTReset();
   JERRYResetI2S();

   memset(jerry_ram_8, 0x00, 0xD000);		// Don't clear out the Wavetable ROM...!
   JERRYPIT1Prescaler = 0xFFFF;
   JERRYPIT2Prescaler = 0xFFFF;
   JERRYPIT1Divider = 0xFFFF;
   JERRYPIT2Divider = 0xFFFF;
   jerry_timer_1_counter = 0;
   jerry_timer_2_counter = 0;
   jerryInterruptMask = 0x0000;
   jerryPendingInterrupt = 0x0000;

   DACReset();
   UARTReset();
}


void JERRYDone(void)
{
   JoystickDone();
   DACDone();
   EepromDone();
   MTDone();
   UARTDone();
}


bool JERRYIRQEnabled(int irq)
{
   // Read the word @ $F10020
   return jerryInterruptMask & irq;
}


/* True while JERRY is driving its interrupt output (DINT) at the TOM
 * input, i.e. an enabled JERRY source has an uncleared pending latch.
 * TOM gates this with INT1 bit 4 before it reaches the 68K -- see
 * TOMIRQRequestActive(). */
bool JERRYIRQRequestActive(void)
{
   return (jerryPendingInterrupt & jerryInterruptMask) ? true : false;
}


void JERRYSetPendingIRQ(int irq)
{
   // This is the shadow of INT (it's a split RO/WO register)
   uint16_t oldPending = jerryPendingInterrupt;
   jerryPendingInterrupt |= irq;
   if (irq == IRQ2_EXTERNAL && !(oldPending & IRQ2_EXTERNAL))
      JERRY_TRACE("External IRQ pending set (mask=$%02X pending=$%02X)\n",
                  jerryInterruptMask & 0xFF, jerryPendingInterrupt & 0xFF);
}


//
// JERRY byte access (read)
//
uint8_t JERRYReadByte(uint32_t offset, uint32_t who/*=UNKNOWN*/)
{
   if ((offset >= DSP_CONTROL_RAM_BASE) && (offset < DSP_CONTROL_RAM_BASE+0x20))
      return DSPReadByte(offset, who);
   else if ((offset >= DSP_WORK_RAM_BASE) && (offset < DSP_WORK_RAM_BASE+0x2000))
      return DSPReadByte(offset, who);
   // LRXD/RRXD/SSTAT $F1A148/4C/50 (really 16-bit registers...)
   else if (offset >= 0xF1A148 && offset <= 0xF1A153)
      return DACReadByte(offset, who);
   // ASIDATA/ASISTAT/ASICLK $F10030-35 (16-bit UART registers)
   else if ((offset >= 0xF10030) && (offset <= 0xF10035))
   {
      uint16_t value = UARTReadWord(offset & 0xFFFFFFFE);
      return (offset & 0x01) ? (uint8_t)(value & 0xFF)
                             : (uint8_t)(value >> 8);
   }
   //	F10036          R     xxxxxxxx xxxxxxxx   JPIT1 - timer 1 pre-scaler
   //	F10038          R     xxxxxxxx xxxxxxxx   JPIT2 - timer 1 divider
   //	F1003A          R     xxxxxxxx xxxxxxxx   JPIT3 - timer 2 pre-scaler
   //	F1003C          R     xxxxxxxx xxxxxxxx   JPIT4 - timer 2 divider
   else if ((offset >= 0xF10036) && (offset <= 0xF1003D))
   {
      uint16_t value;

      switch (offset & 0xFFFFFFFE)
      {
         case 0xF10036: value = JERRYPIT1Prescaler; break;
         case 0xF10038: value = JERRYPIT1Divider;   break;
         case 0xF1003A: value = JERRYPIT2Prescaler; break;
         case 0xF1003C: value = JERRYPIT2Divider;   break;
         default:       value = 0;                  break;
      }

      return (offset & 0x01) ? (value & 0xFF) : (value >> 8);
   }
   else if (offset >= 0xF14000 && offset <= 0xF14003)
   {
      uint16_t value = JoystickReadWord(offset & 0xFE);

      if (offset & 0x01)
         value &= 0xFF;
      else
         value >>= 8;

      // This is wrong, should only have the lowest bit from $F14001
      return value | EepromReadByte(offset);
   }
   /* JagGD SPI mailbox (GPIO2).  Must sit above the EEPROM catch-all,
    * which otherwise swallows these addresses and returns $0000.  When
    * the GameDrive is not active we deliberately fall through: a $0000
    * status read reproduces the stock-console "GD absent" hang. */
   else if (jgdActive && offset >= JGD_REG_FIRST && offset <= JGD_REG_LAST)
      return JGDControlReadByte(offset);
   /* GPIO5 paddle ADC (#505).  The word path has diverted this range away
      from the EEPROM catch-all since v3.4.0; the byte path had been left
      behind, so a byte read still returned the EEPROM handler's $00
      instead of the not-fitted $FF.  No known software byte-accesses the
      range -- the three ROMs that touch it all use move.w. */
   else if (offset >= 0xF17C00 && offset <= 0xF17FFF)
      return PaddleReadByte(offset);
   else if (offset >= 0xF14000 && offset <= 0xF1A0FF)
      return EepromReadByte(offset);

   return jerry_ram_8[offset & 0xFFFF];
}


//
// JERRY word access (read)
//
uint16_t JERRYReadWord(uint32_t offset, uint32_t who/*=UNKNOWN*/)
{

   if ((offset >= DSP_CONTROL_RAM_BASE) && (offset < DSP_CONTROL_RAM_BASE+0x20))
      return DSPReadWord(offset, who);
   else if (offset >= DSP_WORK_RAM_BASE && offset <= DSP_WORK_RAM_BASE + 0x1FFF)
      return DSPReadWord(offset, who);
   // LRXD/RRXD/SSTAT $F1A148/4C/50 (really 16-bit registers...)
   else if (offset >= 0xF1A148 && offset <= 0xF1A153)
      return DACReadWord(offset, who);
   // ASIDATA/ASISTAT/ASICLK $F10030-35 (16-bit UART registers)
   else if ((offset >= 0xF10030) && (offset <= 0xF10035))
      return UARTReadWord(offset & 0xFFFFFFFE);
   //	F10036          R     xxxxxxxx xxxxxxxx   JPIT1 - timer 1 pre-scaler
   //	F10038          R     xxxxxxxx xxxxxxxx   JPIT2 - timer 1 divider
   //	F1003A          R     xxxxxxxx xxxxxxxx   JPIT3 - timer 2 pre-scaler
   //	F1003C          R     xxxxxxxx xxxxxxxx   JPIT4 - timer 2 divider
   else if ((offset >= 0xF10036) && (offset <= 0xF1003D))
   {
      switch (offset & 0xFFFFFFFE)
      {
         case 0xF10036: return JERRYPIT1Prescaler;
         case 0xF10038: return JERRYPIT1Divider;
         case 0xF1003A: return JERRYPIT2Prescaler;
         case 0xF1003C: return JERRYPIT2Divider;
         default:       return 0;
      }
   }
   else if (offset == 0xF10020)
   {
      if (jerryPendingInterrupt & IRQ2_EXTERNAL)
      {
         static uint32_t extReadCount = 0;
         extReadCount++;
         if (extReadCount <= 10 || (extReadCount % 10000) == 0)
            JERRY_TRACE("J_INT read=$%04X (ext pending) mask=$%04X [68K_PC=$%06X] #%u\n",
                        jerryPendingInterrupt, jerryInterruptMask,
                        m68k_get_reg(NULL, M68K_REG_PC), extReadCount);
      }
      return jerryPendingInterrupt;
   }
   else if (offset == 0xF14000)
      return (JoystickReadWord(offset) & 0xFFFE) | EepromReadWord(offset);
   else if ((offset >= 0xF14002) && (offset < 0xF14003))
      return JoystickReadWord(offset);
   /* JagGD SPI mailbox (GPIO2) -- see JERRYReadByte. */
   else if (jgdActive && offset >= JGD_REG_FIRST && offset <= JGD_REG_LAST)
      return JGDControlReadWord(offset);
   /* GPIO5, the "Paddle Interface": the 8-bit ADC (ADC0844 at U16) fitted
      only to early Jaguar boards, emulated in src/jerry/paddle.c (#505).
      Reads $00FF -- a retail console with no converter on the board --
      unless the user has explicitly selected a paddle device on a port. */
   else if ((offset >= 0xF17C00) && (offset <= 0xF17FFF))
      return PaddleReadWord(offset);
   else if ((offset >= 0xF14000) && (offset <= 0xF1A0FF))
      return EepromReadWord(offset);

   offset &= 0xFFFF;				// Prevent crashing...!
   return ((uint16_t)jerry_ram_8[offset+0] << 8) | jerry_ram_8[offset+1];
}


//
// JERRY byte access (write)
//
void JERRYWriteByte(uint32_t offset, uint8_t data, uint32_t who/*=UNKNOWN*/)
{
   if ((offset >= DSP_CONTROL_RAM_BASE) && (offset < DSP_CONTROL_RAM_BASE+0x20))
   {
      DSPWriteByte(offset, data, who);
      return;
   }
   else if ((offset >= DSP_WORK_RAM_BASE) && (offset < DSP_WORK_RAM_BASE+0x2000))
   {
      DSPWriteByte(offset, data, who);
      return;
   }
   // SCLK ($F1A150--8 bits wide)
   //NOTE: This should be taken care of in DAC...
   // LTXD/RTXD/SCLK/SMODE $F1A148/4C/50/54 (really 16-bit registers...)
   else if (offset >= 0xF1A148 && offset <= 0xF1A157)
   {
      DACWriteByte(offset, data, who);
      return;
   }
   else if (offset >= 0xF10000 && offset <= 0xF10007)
   {
      /* Unhandled timer write (BYTE) */
      return;
   }
   // ASIDATA/ASICTRL/ASICLK $F10030-35 (16-bit UART registers).  Byte
   // writes carry the payload in the low byte for ASIDATA/ASICTRL;
   // ASICLK merges the touched half into the existing divider.
   else if (offset >= 0xF10030 && offset <= 0xF10035)
   {
      uint32_t base = offset & 0xFFFFFFFE;

      /* ASIDATA/ASICTRL: byte writes are meaningful only to the low byte. */
      if ((base == 0xF10030 || base == 0xF10032) && !(offset & 0x01))
         return;

      if (base == 0xF10034)
      {
         uint16_t cur = UARTReadWord(base);
         uint16_t v;
         if (offset & 0x01)
            v = (uint16_t)((cur & 0xFF00) | data);
         else
            v = (uint16_t)((cur & 0x00FF) | ((uint16_t)data << 8));
         UARTWriteWord(base, v);
      }
      else
      {
         UARTWriteWord(base, (uint16_t)data);
      }
      return;
   }
   // JERRY -> 68K interrupt enables/latches (need to be handled!)
   else if (offset >= 0xF10020 && offset <= 0xF10021)//WAS:23)
   {
      if (offset == 0xF10020)
      {
         // Clear pending interrupts...
         jerryPendingInterrupt &= ~data;
      }
      else if (offset == 0xF10021)
         jerryInterruptMask = data;
   }
   else if ((offset >= 0xF14000) && (offset <= 0xF14003))
   {
      JoystickWriteWord(offset & 0xFE, (uint16_t)data);
      EepromWriteByte(offset, data);
      return;
   }
   /* JagGD SPI mailbox (GPIO2) -- see JERRYReadByte. */
   else if (jgdActive && offset >= JGD_REG_FIRST && offset <= JGD_REG_LAST)
   {
      JGDControlWriteByte(offset, data, who);
      return;
   }
   /* GPIO5 paddle ADC (#505) -- see JERRYReadByte. */
   else if (offset >= 0xF17C00 && offset <= 0xF17FFF)
   {
      PaddleWriteByte(offset, data);
      return;
   }
   else if ((offset >= 0xF14000) && (offset <= 0xF1A0FF))
   {
      EepromWriteByte(offset, data);
      return;
   }

   //Need to protect write attempts to Wavetable ROM (F1D000-FFF)
   if (offset >= 0xF1D000 && offset <= 0xF1DFFF)
      return;

   jerry_ram_8[offset & 0xFFFF] = data;
}


//
// JERRY word access (write)
//
void JERRYWriteWord(uint32_t offset, uint16_t data, uint32_t who/*=UNKNOWN*/)
{
   if ((offset >= DSP_CONTROL_RAM_BASE) && (offset < DSP_CONTROL_RAM_BASE+0x20))
   {
      DSPWriteWord(offset, data, who);
      return;
   }
   else if ((offset >= DSP_WORK_RAM_BASE) && (offset < DSP_WORK_RAM_BASE+0x2000))
   {
      DSPWriteWord(offset, data, who);
      return;
   }
   //NOTE: This should be taken care of in DAC...
   // LTXD/RTXD/SCLK/SMODE $F1A148/4C/50/54 (really 16-bit registers...)
   else if (offset >= 0xF1A148 && offset <= 0xF1A156)
   {
      DACWriteWord(offset, data, who);
      return;
   }
   // ASIDATA/ASICTRL/ASICLK $F10030-35 (16-bit UART registers)
   else if (offset >= 0xF10030 && offset <= 0xF10035)
   {
      UARTWriteWord(offset & 0xFFFFFFFE, data);
      return;
   }
   else if (offset >= 0xF10000 && offset <= 0xF10007)
   {
      switch(offset & 0x07)
      {
         case 0:
            JERRYPIT1Prescaler = data;
            JERRYResetPIT1();
            break;
         case 2:
            JERRYPIT1Divider = data;
            JERRYResetPIT1();
            break;
         case 4:
            JERRYPIT2Prescaler = data;
            JERRYResetPIT2();
            break;
         case 6:
            JERRYPIT2Divider = data;
            JERRYResetPIT2();
      }
      // Need to handle (unaligned) cases???

      return;
   }
   // JERRY -> 68K interrupt enables/latches
   else if (offset == 0xF10020)
   {
      uint16_t oldMask = jerryInterruptMask;
      uint16_t oldPending = jerryPendingInterrupt;
      jerryInterruptMask = data & 0xFF;
      jerryPendingInterrupt &= ~(data >> 8);
      /* CDDA-DIAG: JINTCTRL external-int enable edges gate the BUTCH ->
       * 68K IPL2 delivery (cdrom.c BUTCHExec); rare, log unconditionally. */
      if ((oldMask ^ jerryInterruptMask) & IRQ2_EXTERNAL)
         LOG_DBG("[CDDA] JINTCTRL ext-int enable %s (J_INT=$%04X who=%u 68kpc=$%06X)\n",
                 (jerryInterruptMask & IRQ2_EXTERNAL) ? "ON" : "OFF",
                 data, who, m68k_get_reg(NULL, M68K_REG_PC));
      if (oldMask != jerryInterruptMask || oldPending != jerryPendingInterrupt)
      {
         JERRY_TRACE("J_INT write word data=$%04X who=%u mask $%02X->$%02X pending $%02X->$%02X%s%s\n",
                     data, who, oldMask & 0xFF, jerryInterruptMask & 0xFF,
                     oldPending & 0xFF, jerryPendingInterrupt & 0xFF,
                     (!(oldMask & IRQ2_EXTERNAL) && (jerryInterruptMask & IRQ2_EXTERNAL)) ? " extena-on" : "",
                     ((oldPending & IRQ2_EXTERNAL) && !(jerryPendingInterrupt & IRQ2_EXTERNAL)) ? " extclr" : "");
      }
      return;
   }
   else if (offset >= 0xF14000 && offset < 0xF14003)
   {
      JoystickWriteWord(offset, data);
      EepromWriteWord(offset, data);
      return;
   }
   /* JagGD SPI mailbox (GPIO2) -- see JERRYReadByte. */
   else if (jgdActive && offset >= JGD_REG_FIRST && offset <= JGD_REG_LAST)
   {
      JGDControlWriteWord(offset, data, who);
      return;
   }
   /* Paddle-interface channel select (see JERRYReadWord and paddle.h).
      With no converter fitted the write has nowhere to go; swallowed
      rather than let through to the EEPROM handler. */
   else if (offset >= 0xF17C00 && offset <= 0xF17FFF)
   {
      PaddleWriteWord(offset, data);
      return;
   }
   else if (offset >= 0xF14000 && offset <= 0xF1A0FF)
   {
      EepromWriteWord(offset, data);
      return;
   }

   //Need to protect write attempts to Wavetable ROM (F1D000-FFF)
   if (offset >= 0xF1D000 && offset <= 0xF1DFFF)
      return;

   jerry_ram_8[(offset+0) & 0xFFFF] = (data >> 8) & 0xFF;
   jerry_ram_8[(offset+1) & 0xFFFF] = data & 0xFF;
}


int JERRYGetPIT1Frequency(void)
{
   /* JERRY PIT uses RISC (full system) clock; see PIT clock rate note. */
   int systemClockFrequency = SYSTEM_CLOCK_RATE;
   int64_t divisor = (int64_t)(JERRYPIT1Prescaler + 1) * (int64_t)(JERRYPIT1Divider + 1);
   if (divisor == 0)
      return 0;
   return (int)(systemClockFrequency / divisor);
}


int JERRYGetPIT2Frequency(void)
{
   /* JERRY PIT uses RISC (full system) clock; see PIT clock rate note. */
   int systemClockFrequency = SYSTEM_CLOCK_RATE;
   int64_t divisor = (int64_t)(JERRYPIT2Prescaler + 1) * (int64_t)(JERRYPIT2Divider + 1);
   if (divisor == 0)
      return 0;
   return (int)(systemClockFrequency / divisor);
}

#include "state.h"

size_t JERRYStateSave(uint8_t *buf)
{
	uint8_t *start = buf;

	STATE_SAVE_VAR(buf, JERRYPIT1Prescaler);
	STATE_SAVE_VAR(buf, JERRYPIT1Divider);
	STATE_SAVE_VAR(buf, JERRYPIT2Prescaler);
	STATE_SAVE_VAR(buf, JERRYPIT2Divider);
	STATE_SAVE_VAR(buf, jerry_timer_1_counter);
	STATE_SAVE_VAR(buf, jerry_timer_2_counter);
	STATE_SAVE_VAR(buf, jerryInterruptMask);
	STATE_SAVE_VAR(buf, jerryPendingInterrupt);
	STATE_SAVE_VAR(buf, JERRYI2SInterruptTimer);
	STATE_SAVE_VAR(buf, jerryI2SCycles);
	STATE_SAVE_VAR(buf, jerryIntPending);

	return (size_t)(buf - start);
}

size_t JERRYStateLoad(const uint8_t *buf)
{
	const uint8_t *start = buf;

	STATE_LOAD_VAR(buf, JERRYPIT1Prescaler);
	STATE_LOAD_VAR(buf, JERRYPIT1Divider);
	STATE_LOAD_VAR(buf, JERRYPIT2Prescaler);
	STATE_LOAD_VAR(buf, JERRYPIT2Divider);
	STATE_LOAD_VAR(buf, jerry_timer_1_counter);
	STATE_LOAD_VAR(buf, jerry_timer_2_counter);
	STATE_LOAD_VAR(buf, jerryInterruptMask);
	STATE_LOAD_VAR(buf, jerryPendingInterrupt);
	STATE_LOAD_VAR(buf, JERRYI2SInterruptTimer);
	STATE_LOAD_VAR(buf, jerryI2SCycles);
	STATE_LOAD_VAR(buf, jerryIntPending);

	return (size_t)(buf - start);
}

