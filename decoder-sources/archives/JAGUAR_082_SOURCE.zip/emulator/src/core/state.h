/*
 * Save state serialization support for Virtual Jaguar
 *
 * Each hardware module provides StateSave/StateLoad functions that
 * serialize their internal (static) state into a flat byte buffer.
 * libretro.c orchestrates the overall save/load sequence.
 */

#ifndef STATE_H
#define STATE_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Save state format identifier and version.
 * v1: original layout, written only by release v2.2.0 (savestate support
 *     first shipped there; the bump to v2 shipped in v2.3.0).
 * v2: DAC chunk gained the I2S resampler fields (i2sWritePos,
 *     i2sWriteCount, i2sPhase, i2sRateRatio).
 * v3: DAC chunk gained i2sNonZeroCount.
 * v4: CDROM chunk restructured — the two 2628-byte staging buffers
 *     (cdBuf2/cdBuf3) the pre-CD-support layout carried were dropped and
 *     replaced by the BUTCH/FIFO/DSA/SSI working set, and the chunk gained
 *     the DSA response queue + serial-delay counter.
 * v5: CDROM chunk gained the latched drive speed (DSA Set Mode $15nn).
 * v6: new UART chunk (JERRY async serial + jlink RX ring).
 * v7: Memory Track chunk gained the latched $80AAA8 override flag and
 *     the NVM BIOS dispatcher state (nvmbios.c); trailing bus-arbiter
 *     68K self-cost carry (symmetric DRAM timing).  One shared bump —
 *     all in-flight changes since the last release use v7.
 * v8: trailing Jaguar GameDrive chunk (bank pages + SPI mailbox engine,
 *     jaggd.c).  One shared bump — all in-flight changes since the
 *     v3.1.0 release use v8.  Released in v3.2.0.
 * v9: DAC block gained the I2S ring (dac.c).
 * v10: trailing blitter busy-window counter (blitter timing model).
 * v11: trailing hi-res shadow-surface epoch (shadowfb.c).  The epoch is a
 *     modulo-256 age stamp that gates which supersampled blocks resolve,
 *     and ShadowHiresFrameTick() drops every cached block when it wraps.
 *     That clear is visible in the presented frame, so a state restored
 *     without it replays the wrap at a different frame and diverges —
 *     which is exactly the determinism we advertise as
 *     savestate_features = 3.  See issue #400.
 *     v9-v11 all shipped together: this is the newest RELEASED layout
 *     (v3.3.0).  (The note that used to sit on v8 calling it the newest
 *     released layout, and the "develop only" tags on v9-v11, were stale
 *     from before the v3.3.0 cut.)
 * v12: trailing input-device chunk (src/jerry/inputdev.c).  The
 *     quadrature accumulator and phase are machine-visible — the phase IS
 *     what the game reads at $F14000 — so a state restored without them
 *     replays different motion.  Older states load with the encoders
 *     reset, which is what a pre-v12 core was.
 *     EXTENDED IN PLACE (still v12, one bump per release): the analog /
 *     driving controller (#437) appended 5 bytes per port — bank, last
 *     row, latched ADC X/Y, switch mask — to the chunk; a pre-extension
 *     v12 state reads them from the zero-fill tail, which is inert (see
 *     inputdev.h).  v12 SHIPPED in v3.4.0 — this is the newest RELEASED
 *     layout.  (The "develop only" tags that sat here were stale from
 *     before that cut, the same way v8's and v9-v11's were before theirs.)
 * v13: trailing Team Tap chunk (#513) — the pads in sockets 1-3 of each
 *     port, 63 bytes per port.  What a pad behind the adapter holds is
 *     machine-visible the instant a title selects that socket's row code,
 *     so it has to be in the blob or run-ahead and netplay diverge.  The
 *     adapter's own presence is NOT serialized: user configuration, like
 *     the input-device type (joystick.h).  develop only — first bump of
 *     the post-v3.4.0 cycle, so any other in-flight state change this
 *     cycle extends v13 in place rather than bumping again.
 *     EXTENDED IN PLACE (still v13): #552 replaced the netlink speed
 *     option's 2x/4x values with a negotiated "auto" and appended one
 *     trailing uint32 — the negotiated wire-speedup Effective divisor —
 *     strictly after the Team Tap chunk.  Unlike Team Tap's config-only
 *     "auto" INTENT (never serialized, same as NTSC/PAL), the negotiated
 *     value is machine-affecting the moment a peer confirms it: it
 *     changes UARTFrameUsec(), which schedules the UART TX/RX
 *     event-queue deadlines.  A pre-#552 v13 state (Team Tap only) reads
 *     nothing here and the loader falls back to stock (1), which is
 *     exactly what a pre-#552 core was — see UARTWireSpeedupStateLoad().
 * v14: mounted-disc identity + image index (#651).  Shipped in v3.6.0.
 * v15: CDROM chunk gained the last $03nn/$14nn TOC word handed out
 *     (dsaLastMultiWord).  Shipped in v3.7.0.
 *     EXTENDED IN PLACE (still v15): #787 appended the HLE CD streaming
 *     chunk strictly last, behind a magic word, so a v15 blob written
 *     before it (zero-filled tail) loads with the transfer dropped.
 * v16: two real-BIOS CD chunks (#804), appended strictly last, each behind
 *     a magic word: "CDB1" (boot stub injected yet) and "CDX1" (FIFO
 *     refill accumulator + CD IRQ edge detector).  First bump of
 *     the v3.7.1 cycle, so any other in-flight state change this cycle
 *     extends v16 in place rather than bumping again.
 *     EXTENDED IN PLACE (still v16): #800 appended "BLH1" strictly after
 *     CDX1: the sticky "blitter hung" flag + the stuck inner count (a
 *     blit hardware never finishes leaves the blitter busy until reset).
 *     A v16 blob written before it ends in the zero-filled tail there, so
 *     the magic misses and it loads as not hung; v15 and older too.
 * v17: GameDrive SD-card handles (#783), appended strictly after BLH1
 *     behind "JGF1": per open file its card-relative path, access and
 *     position, per open directory its path and entry index.  Restore
 *     reopens with the original access only (never a create/truncate/
 *     append), so loading a state cannot clobber a file.  First bump of
 *     the v3.8.0 cycle: any other in-flight state change this cycle
 *     extends v17 in place rather than bumping again.
 *     EXTENDED IN PLACE (still v17, no layout change): #853 packs an
 *     un-retired D_FLAGS store's remaining delay into bits 1-2 of the DSP
 *     chunk's existing active_bank byte (bit 0 stays the live bank).
 *     Older states hold 0/1 there and load as "no window".
 *     EXTENDED IN PLACE again (still v17, no layout change): #865 does the
 *     same for an un-retired G_FLAGS store in the GPU chunk's active_bank
 *     byte -- bits 1-2 the remaining delay, bit 3 the interrupt re-check
 *     it owes.  Older states hold 0/1 there and load as "no window". */
#define STATE_MAGIC     0x564A5353  /* "VJSS" */
#define STATE_VERSION   17
/* Oldest layout retro_unserialize still accepts.  States between
 * STATE_MIN_VERSION and STATE_VERSION load by reading each chunk in the
 * layout the header version names (see DACStateLoad, CDROMStateLoad);
 * STATE_VERSION is always what we write.
 *
 * Released cores wrote exactly four versions: 1 (v2.2.0), 2 (v2.3.0 and
 * v2.3.1), 3 (v2.3.2) and 7 (v3.0.0, v3.1.0).  Versions 4-6 existed only
 * on develop/nightlies.  All four released layouts load (issue #268). */
#define STATE_MIN_VERSION 1

/* Per-field version gates.  A module loader that has to skip a field an
 * older layout did not carry compares the header version against the
 * constant naming that field, never a bare literal. */
/* First version whose DAC block carries the I2S resampler fields
 * (i2sWritePos, i2sWriteCount, i2sPhase, i2sRateRatio). */
#define STATE_VERSION_DAC_I2S_RESAMPLER 2
/* First version whose DAC block carries i2sNonZeroCount. */
#define STATE_VERSION_DAC_I2S_NONZEROCOUNT 3
/* First version whose CDROM block carries the post-CD-support working set
 * (cdrom_eeprom_ram, the BUTCH/FIFO/DSA flags and the SSI head) in place
 * of the two cdBuf2/cdBuf3 staging buffers the original layout carried.
 * Every released core below this wrote the old shape; see
 * CDROMStateLoad. */
#define STATE_VERSION_CDROM_RESTRUCTURE 4
/* First version whose CDROM block carries the DSA response queue and
 * serial-delay counter. */
#define STATE_VERSION_CDROM_DSA_QUEUE 4
/* First version whose CDROM block carries the latched drive speed. */
#define STATE_VERSION_CDROM_DRIVE_SPEED 5
/* First version carrying the JERRY UART + jlink chunk. */
#define STATE_VERSION_JERRY_UART 6
/* First version whose Memory Track block carries the $80AAA8 override flag. */
#define STATE_VERSION_MEMTRACK_OVERRIDE 7
/* First version carrying the trailing bus-arbiter 68K carry (symmetric
 * DRAM self-cost). */
#define STATE_VERSION_BUS_ARBITER 7
/* First version whose DAC block carries the I2S hardware registers
 * themselves (LTXD/RTXD/SCLK/SMODE at $F1A148-$F1A157, plus the dual
 * read-side registers LRXD/RRXD/SSTAT).
 *
 * These sit in jagMemSpace, which no STATE_SAVE_BUF covers: the state
 * saves jaguarMainRAM (the low 2 MB of jagMemSpace), tomRam8, and
 * jerry_ram_8 — and jerry_ram_8 is a separate array in jerry.c, not the
 * $F10000 window of jagMemSpace.  So every DAC register was restored as
 * whatever the previous run happened to leave behind.  DACPrepareFrame
 * seeds the resampler's interpolation endpoints from LTXD/RTXD, which
 * made the first frame after a rollback differ (see
 * test/tools/test_runahead_determinism.c). */
#define STATE_VERSION_DAC_REGISTERS 8
/* First version carrying the trailing Jaguar GameDrive chunk.  Older
 * states load with the GD at its reset state (identity pages, write
 * protect, idle SPI) — see JGDStateLoad / the caller's else branch. */
#define STATE_VERSION_JAGGD 8

/* v9: the I2S resample ring contents.  The ring and its cursors now
 * persist across frames (the per-frame reset was half of the 60 Hz
 * audio step), so replay determinism requires the ring data itself in
 * the state -- the cursors alone reference content the load cannot
 * reconstruct. */
#define STATE_VERSION_DAC_I2S_RING 9

/* v10: blitter bus-time busy window (virtualjaguar_blitter_timing).
 * One uint32 appended after the bus-arbiter fields.  Older states load
 * with the window closed -- at most one pending blit's stall is lost,
 * self-corrects within a field. */
#define STATE_VERSION_BLITTER_TIMING 10
/* First version whose trailer carries the hi-res shadow-surface epoch
 * (shadowfb.c).  Issue #400: without it, the epoch wrap's cache clear
 * replays at a different frame after a rollback and the picture diverges. */
#define STATE_VERSION_HIRES_EPOCH 11
/* First version carrying the trailing input-device chunk (inputdev.c):
 * per-port quadrature backlog / Q8 carry / Gray phase, the mouse button
 * latches, and the emission-clock armed flag.  Older states load with
 * InputDevReset() -- encoders at phase 0, no button held. */
#define STATE_VERSION_INPUT_DEVICES 12
/* First version carrying the trailing Team Tap chunk (#513): the pads in
 * sockets 1-3 of each port, 63 bytes per port.  What those pads hold is
 * machine-visible at $F14000/$F14002 the instant a title selects one of
 * their row codes, so it belongs in the blob for the same reason the
 * hi-res epoch (#400) and the input-device encoders (#479) do -- run-ahead
 * and netplay are what notice otherwise.
 *
 * APPENDED rather than folded into the joystick chunk, which sits in the
 * middle of the blob: test/test_state_compat.c builds its legacy fixtures
 * by locating module blocks in a live state and splicing, so a mid-blob
 * size change invalidates every one of them.  Older states load with
 * JoystickTeamTapStateReset() -- sockets 1-3 released, which is exactly
 * what a pre-v13 core was.  The adapter's own presence is NOT serialized
 * (it is user configuration; see joystick.h). */
#define STATE_VERSION_TEAMTAP 13

/* v14: disk control (#651).  The mounted disc's identity -- session count,
 * track count, total sectors, all three already exported by cdintf.h --
 * plus the current image index.  Loading a state taken on disc A while
 * disc B is mounted would resume a machine whose CD state points at
 * content that is not there; refusing it loudly beats the silent
 * wrong-disc class.  Hashing the image is not an option: a Jaguar CD disc
 * runs to hundreds of megabytes and states are written constantly.
 *
 * 13 shipped in v3.5.1, so this needs its own bump; 14 is now the single
 * shared bump for this release, per the one-bump-per-release policy. */
#define STATE_VERSION_DISK_CONTROL 14

/* v15: the CDROM chunk carries dsaLastMultiWord, the word an early DS_DATA
 * read returns between two $03nn/$14nn TOC words.  A state taken there and
 * loaded into a fresh core would otherwise read 0, and run-ahead/netplay
 * would diverge (the #400 class).  Older states load it as 0. */
#define STATE_VERSION_CDROM_DSA_LASTWORD 15
/* First version that may carry the trailing HLE CD streaming chunk
 * (#787).  "May": the chunk is tagged, see JaguarCDHLEStateLoad. */
#define STATE_VERSION_HLE_CD_STREAM 15
/* v16: trailing real-BIOS CD boot chunk (#804): jagcd_bios.c's
 * cdBootStubInjected flag, which gates the 68K boot-stub injection hook.
 * Outside the blob, a rollback to a pre-injection state kept the flag set
 * by the replay that had already injected, so the replay never injected
 * the stub and the game never started (run-ahead diverged mid-load); and
 * a post-injection state loaded into a fresh core re-armed the $005E40
 * GPU-magic stomp over the game's own RAM.  Older states do not carry it:
 * the live session's value is left alone (v3.7.0 behaviour). */
#define STATE_VERSION_BIOS_CD_BOOT 16
/* v17: trailing "JGF1" GameDrive SD-handle chunk (#783, JGDFSStateSave in
 * src/core/jaggd_fs.c).  Older states: every handle closes. */
#define STATE_VERSION_JGD_SD 17
/* v16, extended in place (#800): trailing "BLH1" hung-blitter chunk
 * (BlitterHungStateSave, src/tom/blitter_mmio.c), read only for
 * version >= STATE_VERSION_BIOS_CD_BOOT, strictly after CDX1.  Missing or
 * wrong magic, or an older version: not hung. */

/* Header flags */
#define STATE_FLAG_MEMTRACK  0x01
#define STATE_FLAG_CDROM     0x02

/* Fixed save state size (~2.4 MB).
 * Must never increase between retro_load_game() and retro_unload_game(). */
/* v9 grew the payload by the 64 KB I2S resample ring
 * (STATE_VERSION_DAC_I2S_RING).  States written by v8-and-older cores
 * are STATE_SIZE_V8 bytes; retro_unserialize sizes its floor check by
 * the version the state itself declares, so those still load. */
#define STATE_SIZE     0x280000  /* 2,621,440 bytes */
#define STATE_SIZE_V8  0x260000  /* 2,490,368 bytes -- all pre-v9 layouts */

/* Helper macros for sequential buffer writes/reads.
 * These advance the buffer pointer automatically. */
#define STATE_SAVE_VAR(buf, var) \
   do { memcpy((buf), &(var), sizeof(var)); (buf) += sizeof(var); } while (0)
#define STATE_LOAD_VAR(buf, var) \
   do { memcpy(&(var), (buf), sizeof(var)); (buf) += sizeof(var); } while (0)

#define STATE_SAVE_BUF(buf, src, len) \
   do { memcpy((buf), (src), (len)); (buf) += (len); } while (0)
#define STATE_LOAD_BUF(buf, dst, len) \
   do { memcpy((dst), (buf), (len)); (buf) += (len); } while (0)

/* Module save/load functions — each returns bytes written/read */
size_t GPUStateSave(uint8_t *buf);
size_t GPUStateLoad(const uint8_t *buf);

size_t DSPStateSave(uint8_t *buf);
size_t DSPStateLoad(const uint8_t *buf);

size_t BlitterStateSave(uint8_t *buf);
size_t BlitterStateLoad(const uint8_t *buf);

size_t EventStateSave(uint8_t *buf);
size_t EventStateLoad(const uint8_t *buf);

size_t EepromStateSave(uint8_t *buf);
size_t EepromStateLoad(const uint8_t *buf);

size_t JERRYStateSave(uint8_t *buf);
size_t JERRYStateLoad(const uint8_t *buf);

/* UART chunk is wholly new in v6; the caller gates on
 * STATE_VERSION_JERRY_UART before invoking the loader. */
size_t UARTStateSave(uint8_t *buf);
size_t UARTStateLoad(const uint8_t *buf, uint32_t stateVersion);

size_t TOMStateSave(uint8_t *buf);
size_t TOMStateLoad(const uint8_t *buf);

size_t CDROMStateSave(uint8_t *buf);
size_t CDROMStateLoad(const uint8_t *buf, uint32_t stateVersion);
/* Trailing drive-timing chunk (#804, STATE_VERSION_BIOS_CD_BOOT): the FIFO
 * refill error-diffusion accumulator and the CD IRQ edge detector.  Tagged
 * with a magic word; Reset is what a state without the chunk gets. */
size_t CDROMStateExtSize(void);
size_t CDROMStateExtSave(uint8_t *buf);
size_t CDROMStateExtLoad(const uint8_t *buf);
void   CDROMStateExtReset(void);


size_t JoystickStateSave(uint8_t *buf);
size_t JoystickStateLoad(const uint8_t *buf);

/* Team Tap sockets 1-3 (v13 trailing chunk); the caller gates the load on
 * STATE_VERSION_TEAMTAP and calls JoystickTeamTapStateReset() below it. */
size_t JoystickTeamTapStateSave(uint8_t *buf);
size_t JoystickTeamTapStateLoad(const uint8_t *buf);
void   JoystickTeamTapStateReset(void);

size_t MTStateSave(uint8_t *buf);
size_t MTStateLoad(const uint8_t *buf, uint32_t version);
size_t NVMBiosStateSave(uint8_t *buf);
size_t NVMBiosStateLoad(const uint8_t *buf);

size_t DACStateSave(uint8_t *buf);
/* stateVersion is the version read from the state header: fields added in
 * later versions are skipped for older states (see STATE_MIN_VERSION). */
size_t DACStateLoad(const uint8_t *buf, uint32_t stateVersion);

size_t M68KStateSave(uint8_t *buf);
size_t M68KStateLoad(const uint8_t *buf);

#ifdef __cplusplus
}
#endif

#endif /* STATE_H */
