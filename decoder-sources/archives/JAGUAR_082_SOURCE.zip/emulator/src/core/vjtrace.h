/* vjtrace.h -- core-side flight-recorder trace facility.
 *
 * Dev-build only (compiled when VJ_TRACE is defined, which the Makefile
 * sets automatically inside the TEST_EXPORTS=1 branch).  In shipped
 * builds every VJT_* macro below compiles to nothing and vjtrace.c's
 * body is entirely #ifdef'd out, so there is zero cost and zero
 * exported symbols (see docs/vjtrace-design.md).
 *
 * The event enum, vjtrace_ev, and vjtrace_counters_t are declared
 * OUTSIDE the VJ_TRACE guard so that offline analyzer tools (which are
 * never built with VJ_TRACE) can still include this header for the
 * types used by the binary dump format.
 *
 * PERFORMANCE NOTE (VJ_TRACE is coupled 1:1 to TEST_EXPORTS=1, so any
 * always-on cost here taxes every test-mode build, not just callers
 * that use vjtrace directly -- roughly 40 harnesses link a VJ_TRACE
 * core and never trace at all): the GPU/DSP per-instruction PC-history
 * hooks in GPUExec()/DSPExec() (see vjtrace_pchist_gpu()/
 * vjtrace_pchist_dsp() below), unconditionally writing every recorded
 * event through vjtrace_emit() (tom.c/op.c/blitter.c/gpu.c/
 * m68kinterface.c fire ~15 VJT_EMIT sites, some -- OP_OBJECT/
 * OP_LIST_START -- multiple thousand times a frame), originally
 * measured a ~6-8% wall-clock throughput regression on `make
 * BENCH_PROFILE=1 benchmark` versus a build with no vjtrace hooks at
 * all (task-3-report.md has the full before/after numbers). A plain
 * function call and an inlined macro that writes the ring arrays
 * directly were both measured -- 11 paired, interleaved samples put
 * them within 0.02% of each other, i.e. statistically indistinguishable
 * on this hardware -- so the cost was the per-instruction ring write
 * itself, not call overhead.
 *
 * That regression was real and visible outside synthetic benchmarks:
 * `test/test_frontend_pacing.c`'s strict 1x row (no
 * `--max-fastest-frame-fraction` override, Makefile:1163) asserts the
 * fastest observed frame beats 0.5x the frame period (8.333 ms at
 * 60 fps) -- already load-sensitive on its own (the Makefile's own
 * comment near line 1173 notes it "would flake on loaded CI runners:
 * observed locally 11.3 ms vs the 8.3 ms limit under parallel builds",
 * which is why the *other* two invocations defuse it with
 * `--max-fastest-frame-fraction 100`) -- and flaked for real on a
 * loaded 32-bit CI runner once the vjtrace hot-path hooks were always
 * compiled in (9.4-14.0 ms observed, vs 4.3 ms on the same job before
 * vjtrace existed).
 *
 * FIX: every hot-path recording site now checks a module-private
 * "armed" flag (vjtrace_armed, default OFF) FIRST and returns
 * immediately when clear -- vjtrace_emit() centrally (covering all
 * ~15 VJT_EMIT call sites in one place) and vjtrace_pchist_gpu()/
 * vjtrace_pchist_dsp() individually (they're called directly from
 * GPUExec()/DSPExec(), not through vjtrace_emit()). A disarmed VJ_TRACE
 * build now pays one predictable, well-branch-predicted comparison per
 * site instead of doing real ring/history work, which should put its
 * throughput within noise of a plain (non-VJ_TRACE) build -- see the
 * paired-sampling numbers in the commit that introduced vjtrace_arm()/
 * vjtrace_disarm() for the actual before/after measurement.
 *
 * vjtrace_arm() is called from trace_probe_attach()
 * (test/harness/trace_probe.c) the moment a tool actually requests
 * tracing (--watch/--trace-out/--field-csv/--snap/--mark), so every
 * existing tracing consumer is unaffected -- backtraces and the ring
 * are complete from the attach point forward, same as before. Callers
 * that want tracing without going through trace_probe's CLI can call
 * vjtrace_arm()/vjtrace_disarm() directly. If a tool asks trace_probe
 * for tracing but the resolved core doesn't export vjtrace_arm (an
 * older core, built before this fix), that is a hard, loud failure
 * (exit 2) via the same missing-symbol check every other required
 * vjtrace export already goes through -- never a silently-empty ring.
 *
 * Any wall-clock-derived assertion in a DISARMED VJ_TRACE build should
 * now behave the same as a plain build; re-verify that specifically
 * (not just `make test`'s overall exit code) if a new always-on
 * (unarmed-reachable) vjtrace hook is ever added. */
#ifndef __VJTRACE_H__
#define __VJTRACE_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Event types.  addr/value meaning is documented per-type. */
enum
{
   VJT_EV_NONE = 0,
   VJT_EV_IRQ_ASSERT,     /* addr = src: 0 video,1 gpu,2 obj,3 timer,4 jerry */
   VJT_EV_IRQ_DISPATCH,   /* 68K autovector entry */
   VJT_EV_GPU_GO,         /* value = G_PC at start */
   VJT_EV_GPU_STOP,       /* value = PC at stop */
   VJT_EV_OP_LIST_START,  /* addr = OLP, value = halfline */
   VJT_EV_OP_OBJECT,      /* addr = object phrase addr, value = type 0-7 */
   VJT_EV_OP_GPU_OBJ,
   VJT_EV_OP_BRANCH,      /* value = branch target */
   VJT_EV_BLIT_CMD,       /* addr = B_CMD value, value = A1_BASE */
   VJT_EV_INPUT_EDGE,     /* host-injected: addr = pad, value = bits */
   VJT_EV_WATCH_RD,
   VJT_EV_WATCH_WR,
   VJT_EV_SNAPSHOT,
   VJT_EV_MARK,
   VJT_EV__COUNT
};

/* 32 bytes with alignment. */
typedef struct
{
   uint64_t seq;
   uint32_t frame;
   uint16_t halfline;
   uint8_t type;
   uint8_t who;
   uint32_t pc;
   uint32_t addr;
   uint32_t value;
} vjtrace_ev;

typedef struct
{
   uint64_t ev[VJT_EV__COUNT];   /* one cumulative counter per event type */
} vjtrace_counters_t;

#ifdef VJ_TRACE

/* alloc ring; cap from env VJ_TRACE_RING (parsed strictly -- non-numeric,
 * zero, negative, or overflowing values fall back to the default),
 * default 1<<20, hard ceiling 1<<25 */
void vjtrace_init(void);
/* Counterpart to vjtrace_init(): frees the ring and resets every module
 * static (ring/cap/head/seq/frame, watches, counters, GPU/DSP PC
 * history) so a subsequent vjtrace_init() call re-allocates cleanly.
 * Call from the core's shutdown path (retro_deinit(), libretro.c) --
 * iOS cannot dlclose cores, so that is the paired call to retro_init()'s
 * vjtrace_init(), same lifecycle symmetry every other per-session vjtrace
 * static already has via retro_unload_game()/retro_deinit().  Idempotent:
 * safe to call when the ring was never allocated or already freed. */
void vjtrace_shutdown(void);
/* Arms/disarms recording. Default OFF (see the PERFORMANCE NOTE above):
 * every hot-path recording site (vjtrace_emit(), vjtrace_pchist_gpu(),
 * vjtrace_pchist_dsp()) checks this first and is a cheap no-op while
 * disarmed. trace_probe_attach() (test/harness/trace_probe.c) calls
 * vjtrace_arm() the moment a tool actually requests tracing, so this
 * is transparent to every existing tracing consumer; call directly for
 * programmatic control without the CLI flags. vjtrace_shutdown() resets
 * back to disarmed. Backtraces/ring contents are only guaranteed
 * complete from the moment vjtrace_arm() was called, not from core
 * boot -- matches the existing "events before the first retro_run carry
 * frame 0" caveat below: nothing is recorded before someone asks for
 * it. */
void vjtrace_arm(void);
void vjtrace_disarm(void);
/* Sets the frame number stamped onto every subsequently emitted event.
 * Called from the TOP of retro_run (libretro.c) with a 1-based counter,
 * so events emitted while frame N is being run -- by the machine and by
 * a harness's post-run frame hook alike -- all carry N, and no consumer
 * needs a per-event-source correction.  Events emitted before the first
 * retro_run (retro_init / retro_load_game) carry 0. */
void vjtrace_frame_tick(uint32_t frame);
void vjtrace_emit(uint8_t type, uint8_t who, uint32_t addr, uint32_t value);
/* rw: 1=r 2=w 3=rw; ret idx or -1.  Sanitizes its inputs: an inverted
 * range (hi < lo) is swapped, and rw is masked to its low 2 bits and
 * defaulted to 2 (writes) if that leaves 0 -- so a bad range or mode
 * from any caller installs a working watch instead of one that can
 * never fire. */
int vjtrace_watch_add(uint32_t lo, uint32_t hi, unsigned rw);
void vjtrace_watch_clear(void);
void vjtrace_watch_check(uint32_t addr, uint32_t value, uint32_t who, int is_write);
/* WATCH COVERAGE (updated by Task 7.5 -- see docs/vjtrace-design.md
 * section 2 for the original design): VJT_WATCH_RD/WR sites live in
 * JaguarReadByte, JaguarReadWord, JaguarReadLong, JaguarWriteByte,
 * JaguarWriteWord and JaguarWriteLong (src/core/jaguar.c), which every
 * GPU/DSP/OP/blitter/CDROM access to the shared memory map routes
 * through, AND directly in the 68K's own bus-access fast path --
 * m68k_read_memory_8/16/32 and m68k_write_memory_8/16/32 (also
 * jaguar.c) -- which UAE calls for every 68K instruction fetch and
 * data access and which never routes through the Jaguar dispatch above
 * (it writes/reads jaguarMainRAM[] directly and dispatches TOM/JERRY/
 * CDROM itself). Only the non-decomposing entry points of that fast
 * path are hooked (e.g. m68k_write_memory_32's direct-RAM branch, not
 * its two-half TOM/JERRY/CDROM fallback, which already gets two
 * records from the two m68k_write_memory_16 calls it makes) so a
 * single 68K bus access yields the natural record(s), never a
 * double-count. who=M68K therefore now appears in WATCH_RD/WATCH_WR
 * records with a real originating PC (who=OP and who=BLITTER do NOT --
 * vjt_pc_of() only resolves a PC for M68K/JAGUAR/GPU/DSP; OP and
 * BLITTER records always carry pc=0, same as before this task).
 *
 * PC ATTRIBUTION is the instruction-START PC, not whatever regs.pc
 * happens to hold at the moment of the access: m68k_incpc() (or a
 * handler's own equivalent) advances regs.pc at or near the top of
 * nearly every opcode handler, before that handler's memory access
 * runs, so reading M68K_REG_PC at access time names the NEXT
 * instruction's fetch in the overwhelming majority of cases (859 of
 * 861 opcode handlers, measured). vjt_pc_of() (src/core/vjtrace.c)
 * instead reads the most recent entry of pcQueue/pcQPtr
 * (src/core/jaguar.c), which M68KInstructionHook() latches BEFORE each
 * instruction's opcode handler runs -- see the comment on vjt_pc_of()
 * for the full argument.
 *
 * RECORD VALUE for a 68K write is masked to the access width (8/16/32
 * bits) at each m68k_write_memory_* hook site, matching what
 * JaguarWriteByte/Word/Long already carry -- UAE's `value` argument to
 * the byte/word bus functions is not itself masked (e.g. a byte store
 * of $AA can arrive as $FFFFFFAA), so the hook masks explicitly rather
 * than forwarding the raw argument. A 68K read's `value` field is
 * always 0 (the read hasn't happened yet at hook time), same as
 * JaguarReadByte/Word/Long.
 *
 * RECORD SHAPE IS REGION-DEPENDENT for 32-bit 68K accesses, both
 * m68k_read_memory_32 and m68k_write_memory_32: a 32-bit access to main
 * RAM or cart ROM is terminal and produces ONE record covering the
 * whole 4-byte span at its base address; a 32-bit access to anything
 * else (TOM/JERRY/CDROM/unknown) decomposes into two 16-bit accesses
 * and so produces TWO 2-byte records, at addr and addr+2. vjtrace_ev
 * has no width/size field, so a consumer cannot tell which shape a
 * given record came from except by knowing the target region. See the
 * WATCH RECORD SHAPE note in test/harness/trace_probe.h (where
 * `--watch` is documented) for the concrete failure mode this causes
 * for a watch window that starts mid-longword.
 *
 * STILL OUT OF SCOPE: GPU/DSP local-store writes -- a GPU/DSP
 * instruction writing its own local RAM ($F03000-$F03FFF /
 * $F1B000-$F1CFFF) does not go through the Jaguar dispatch either, so
 * those writes are not watch-visible. (GPU/DSP writes reaching main RAM
 * or the other processor's local RAM DO route through it and are
 * covered.) */
/* binary ring dump; see docs/vjtrace-design.md for the format */
int vjtrace_dump(const char *path);

/* Live ring readback, for a consumer that wants to drain events as they
 * are produced instead of waiting for vjtrace_dump() at exit (the
 * harness-side trace_probe tallies VJT_EV_IRQ_ASSERT per source this
 * way -- vjtrace_counters carries one counter per event *type*, so the
 * per-source split in the event's addr field is only available from the
 * events themselves).
 *
 * vjtrace_ring_head() returns the total number of events ever emitted,
 * i.e. one past the index of the newest event; it is NOT reduced by
 * eviction, so it is a stable monotonic cursor.  A caller drains
 * [last_head, vjtrace_ring_head()) and remembers the new head.
 *
 * vjtrace_ring_read() copies event `idx` into *out and returns 1, or
 * returns 0 without touching *out when the index is unreadable: ring
 * not initialized, out NULL, idx not yet written (idx >= head), or idx
 * already overwritten by wraparound (head - idx > capacity).  A caller
 * that drains less often than the ring fills therefore sees 0 for the
 * evicted prefix of its window and can report the undercount rather
 * than silently mis-tallying. */
uint64_t vjtrace_ring_head(void);
int vjtrace_ring_read(uint64_t idx, vjtrace_ev *out);

/* Multi-section emulator state dump ("VJSN" v1 format; see
 * docs/vjtrace-design.md). Writes host-endian, native-struct-layout
 * data (the reader runs on the same host as the writer -- no byte-swap
 * or wire-format packing is done). Header: { char magic[4]="VJSN";
 * uint32_t version=1; uint32_t nsections=8; } followed by nsections of
 * { char name[8] (NUL-padded, NOT required to be NUL-terminated --
 * "JERRYREG" fills all 8 bytes with no terminator); uint32_t base;
 * uint32_t len; } + len raw bytes, in this fixed order: MAINRAM (base
 * 0, 2 MB), GPURAM (base $F03000, 4 KB), DSPRAM (base $F1B000, 8 KB),
 * TOMREG (base $F00000, 16 KB), JERRYREG (base $F10000, 64 KB),
 * REGS68K (base 0, 18 uint32: D0-D7,A0-A7,PC,SR), REGSGPU (base 0, 34
 * uint32: 32 regs of the CURRENT bank + PC + GPU_FLAGS), REGSDSP (base
 * 0, 34 uint32: 32 regs of the CURRENT bank + PC + DSP_FLAGS). Slot 33
 * of REGSGPU/REGSDSP is the flags register (GPUGetFlags()/
 * DSPGetFlags()), NOT the control register -- G_CTRL/D_CTRL are a
 * different register at a different address and are not captured by
 * this format.
 * Only the currently-selected GPU/DSP register bank is captured -- the
 * alternate bank is not dumped.
 *
 * Emits a VJT_EV_SNAPSHOT event on success (who=JAGUAR, addr=0,
 * value=ordinal), ordinal counting from 0 for the first snapshot
 * written by this process, so ring events can be correlated back to a
 * specific snapshot file by index.
 *
 * Returns -1 (no event emitted, no partial file left open) if the
 * vjtrace ring is not initialized (vjtrace_init() not yet called) or
 * if the output file can't be opened; never crashes. */
int vjtrace_snapshot(const char *path);

/* GPU/DSP PC history rings (0x400 entries each), fed from the per-
 * instruction top of GPUExec()/DSPExec() via a plain function call.
 * Read back via vjtrace_backtrace(). An inlined-macro form that writes
 * the ring arrays directly (no call) was measured against this and
 * found statistically indistinguishable -- see the PERFORMANCE NOTE
 * above -- so this is the simpler of the two working designs, kept per
 * that measurement rather than assumed. */
#define VJT_PCHIST_CAP 0x400

void vjtrace_pchist_gpu(uint32_t pc);
void vjtrace_pchist_dsp(uint32_t pc);

/* Fills out[] with up to maxn PCs from the requested processor's PC
 * history ring, oldest first / newest last, and sets *count to the
 * number of entries actually written.  who is one of the vjag_memory.h
 * enum values (M68K, GPU, DSP); any other value yields *count = 0.
 *
 * GPU/DSP are fill-tracked: *count is min(maxn, VJT_PCHIST_CAP, entries
 * actually pushed since the ring was last cleared/emulation start), so
 * a backtrace requested before either processor has executed
 * VJT_PCHIST_CAP instructions returns only real entries -- never
 * zero-filled or stale fabricated history.
 *
 * M68K reads the existing pcQueue/pcQPtr ring in src/core/jaguar.c
 * rather than a duplicate (see M68KInstructionHook(), jaguar.c:332).
 * KNOWN LIMITATION: that ring has no fill counter of its own, and
 * adding one means touching jaguar.c's per-instruction hot path, which
 * is out of scope for this module. vjtrace_backtrace() therefore
 * assumes it is full and can return zero/stale-placeholder entries for
 * the first VJT_PCHIST_CAP 68K instructions of emulation (pcQueue is a
 * plain BSS array, so unwritten slots read as PC=0). In practice
 * M68KInstructionHook() runs unconditionally every 68K instruction from
 * the very first one executed (it is not gated by VJ_TRACE), so this
 * window closes within roughly VJT_PCHIST_CAP instructions of core
 * boot -- a few dozen microseconds -- and does not recur afterward. */
void vjtrace_backtrace(int who, uint32_t *out, int maxn, int *count);

extern vjtrace_counters_t vjtrace_counters;
extern uint32_t vjtrace_nwatch;
extern int vjtrace_armed;

#define VJT_EMIT(t, w, a, v)   vjtrace_emit((uint8_t)(t), (uint8_t)(w), (a), (v))
#define VJT_WATCH_WR(a, v, w)  do { if (vjtrace_nwatch) vjtrace_watch_check((a), (v), (w), 1); } while (0)
#define VJT_WATCH_RD(a, v, w)  do { if (vjtrace_nwatch) vjtrace_watch_check((a), (v), (w), 0); } while (0)

/* Per-instruction PC-history hooks.  These sit in GPUExec()/DSPExec(),
 * the two hottest loops in the emulator (a busy title runs ~450k GPU
 * instructions per frame), so the armed test happens HERE at the call
 * site -- same shape as VJT_WATCH_* above -- and not only inside the
 * callee.  Gating in the callee alone still costs a cross-TU call per
 * instruction in a disarmed build, which is exactly the wall-clock tax
 * the armed gate exists to remove (it pushed the 32-bit CI runner's
 * test_frontend_pacing over its 8.333 ms fastest-frame limit).  The
 * callee keeps its own check as well, so a direct caller cannot bypass
 * the gate. */
#define VJT_PCHIST_GPU(pc)     do { if (vjtrace_armed) vjtrace_pchist_gpu(pc); } while (0)
#define VJT_PCHIST_DSP(pc)     do { if (vjtrace_armed) vjtrace_pchist_dsp(pc); } while (0)

/* ---- Bus-traffic census (timing campaign S2, docs/timing-campaign-plan.md).
 *
 * Counts every bus master's external traffic per HALFLINE, independent
 * of busArbiter.enabled (the dram_timing option): the existing charge
 * sites only run with that option on, which is how an earlier census read
 * "0 GPU external accesses" with timing off.  Nothing here charges or
 * changes emulated time; it only counts.  Test ABI only (VJ_TRACE ==
 * TEST_EXPORTS=1), disarmed by default, one never-taken branch per hook
 * while disarmed.
 *
 * Masters and units:
 *   68K   16-bit bus cycles (a longword = 2), split work/spin by the
 *         instruction-start PC against caller windows; 68K clocks per
 *         instruction (deltas of regs.remainingCycles between
 *         M68KInstructionHook calls, closed at slice end) split the same
 *         way; pending-stall clocks drained by M68KExecuteWithStalls.
 *   GPU   external transactions from the load/store hook (a phrase LOADP
 *         = 1), split by GPU PC against the gpu_busy_* windows; GPU
 *         work/total cycles are sampled from the gpu_busy census.
 *   DSP   16-bit transactions (JTRM v8 p.99: 16-bit external interface)
 *         seen at the Jaguar dispatch with who == DSP.
 *   OP    the model's own OP-occupancy rule (bus_arbiter_op_charge
 *         sites: 1 sysclk per 32-bit fetch/write-back + a row change per
 *         rendered object), but UNGATED.
 *   Blitter  B_CMD count and BUSHI (bit 29) count per halfline; phrase
 *         traffic comes from the BENCH_PROFILE perf counters, sampled.
 * Idle-bus memory-cycle price per access (sysclks) uses a per-master
 * open-DRAM-row tracker (4 KB rows) and busArbiter's MEMCON-derived
 * costs: page hit 2, miss 2 + row change, ROM rom_clocks, I/O 2. */
#define VJT_BUS_MAX_WIN 8
typedef struct
{
   uint32_t m68k_bus_work, m68k_bus_spin;   /* 16-bit bus cycles */
   uint32_t m68k_clk_work, m68k_clk_spin;   /* sysclks (= 2 x 68K clocks) */
   uint32_t m68k_rom_bus;                   /* of which cart/boot ROM */
   uint32_t m68k_stall_clk;                 /* pending-stall sysclks drained */
   uint32_t gpu_ext_work, gpu_ext_spin;     /* GPU external transactions */
   uint32_t gpu_mem_work, gpu_mem_spin;     /* their idle-bus memory sysclks */
   uint32_t gpu_dmaen;                      /* transactions with FLAGS.DMAEN */
   uint32_t gpu_cyc_work, gpu_cyc_total;    /* gpu_busy deltas (GPU cycles) */
   uint32_t dsp_ext, dsp_mem;               /* DSP 16-bit transactions, sysclks */
   uint32_t op_clk;                         /* OP occupancy, model rule, ungated */
   uint32_t op_objs;                        /* rendered bitmap/scaled objects */
   uint32_t op_release;                     /* ... of which RELEASE (bit 48) set */
   uint32_t blit_cmds, blit_bushi;          /* B_CMD writes, of which BUSHI */
   uint32_t blit_prd, blit_pwr;             /* phrase reads/writes (BENCH_PROFILE) */
   uint32_t vc;                             /* VC at the halfline callback */
   uint32_t dsp_ext_spin;                   /* of dsp_ext, issued from a DSP window */
   uint32_t dsp_ins_work, dsp_ins_spin;     /* DSP instructions (needs vjtrace_arm) */
} vjtrace_bus_hl;

extern int vjtrace_bus_armed;
void vjtrace_bus_arm(int on);
void vjtrace_bus_set_m68k_window(uint32_t i, uint32_t lo, uint32_t hi);
void vjtrace_bus_set_dsp_window(uint32_t i, uint32_t lo, uint32_t hi);
uint32_t vjtrace_bus_ring_head(void);
int vjtrace_bus_ring_read(uint32_t idx, vjtrace_bus_hl *out);
void vjtrace_bus_m68k(uint32_t addr, uint32_t naccesses);
void vjtrace_bus_m68k_insn(uint32_t pc, int32_t remaining);
void vjtrace_bus_m68k_slice_end(int32_t remaining);
void vjtrace_bus_m68k_stall(uint32_t cycles68k);
void vjtrace_bus_gpu(uint32_t addr);
void vjtrace_bus_dsp(uint32_t addr, uint32_t n16);
void vjtrace_bus_op(uint32_t sysclks);
void vjtrace_bus_op_object(int release);
void vjtrace_bus_halfline(uint32_t vc);

#define VJT_BUS_M68K(a, n, nc)    do { if (vjtrace_bus_armed && !(nc)) vjtrace_bus_m68k((a), (n)); } while (0)
#define VJT_BUS_M68K_INSN(pc, r)  do { if (vjtrace_bus_armed) vjtrace_bus_m68k_insn((pc), (r)); } while (0)
#define VJT_BUS_M68K_END(r)       do { if (vjtrace_bus_armed) vjtrace_bus_m68k_slice_end(r); } while (0)
#define VJT_BUS_M68K_STALL(c)     do { if (vjtrace_bus_armed) vjtrace_bus_m68k_stall(c); } while (0)
#define VJT_BUS_GPU(a)            do { if (vjtrace_bus_armed) vjtrace_bus_gpu(a); } while (0)
#define VJT_BUS_DSP(w, a, n)      do { if (vjtrace_bus_armed && (w) == DSP) vjtrace_bus_dsp((a), (n)); } while (0)
#define VJT_BUS_OP(w, c)          do { if (vjtrace_bus_armed && (w) == OP) vjtrace_bus_op(c); } while (0)
#define VJT_BUS_OP_OBJ(rel)       do { if (vjtrace_bus_armed) vjtrace_bus_op_object(rel); } while (0)
#define VJT_BUS_HALFLINE(vc)      do { if (vjtrace_bus_armed) vjtrace_bus_halfline(vc); } while (0)

#else /* !VJ_TRACE */

#define VJT_EMIT(t, w, a, v)   do { } while (0)
#define VJT_WATCH_WR(a, v, w)  do { } while (0)
#define VJT_WATCH_RD(a, v, w)  do { } while (0)
#define VJT_PCHIST_GPU(pc)     do { } while (0)
#define VJT_PCHIST_DSP(pc)     do { } while (0)
#define VJT_BUS_M68K(a, n, nc)    do { } while (0)
#define VJT_BUS_M68K_INSN(pc, r)  do { } while (0)
#define VJT_BUS_M68K_END(r)       do { } while (0)
#define VJT_BUS_M68K_STALL(c)     do { } while (0)
#define VJT_BUS_GPU(a)            do { } while (0)
#define VJT_BUS_DSP(w, a, n)      do { } while (0)
#define VJT_BUS_OP(w, c)          do { } while (0)
#define VJT_BUS_OP_OBJ(rel)       do { } while (0)
#define VJT_BUS_HALFLINE(vc)      do { } while (0)

#endif /* VJ_TRACE */

#ifdef __cplusplus
}
#endif

#endif /* __VJTRACE_H__ */
