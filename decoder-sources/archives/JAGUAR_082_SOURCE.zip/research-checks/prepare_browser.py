from pathlib import Path
import numpy as np,json,hashlib
R=Path(__file__).resolve().parent;rows=[]
for bank in json.loads((R/'banks.json').read_text()):
 for t in bank['tracks']:
  source=np.fromfile(t['source_window'],dtype='<i2').reshape(-1,2).astype(np.float64)/32768;source=np.concatenate([source,np.zeros((1,2))]);n=t['source_audio_frames']
  for rate in [44100,48000]:
   total=int(np.ceil(n*rate/48000))+128;index=np.arange(total,dtype=np.int64);numerator=index*48000;at=numerator//rate;rem=numerator%rate;valid=at<n;out=np.zeros((total,2),dtype='<f4');a=source[at[valid]];b=source[at[valid]+1];out[valid]=(a+(b-a)*rem[valid,None]/rate).astype(np.float32);dest=R/'probes'/f"missil3d-{t['subsong']:02d}-{rate}-expected.f32";out.tofile(dest)
   rows.append({'key':f"missil3d-{t['subsong']:02d}",'format':'jgz','subsong':t['subsong'],'file':bank['file'],'sha256':bank['sha256'],'rate':rate,'frames':total,'expected':str(dest),'reference_source_s16_sha256':t['source_s16_sha256']})
(R/'browser-plan.json').write_text(json.dumps(rows,indent=2)+'\n');print('Prepared',len(rows),'complete source reference comparisons')
