from pathlib import Path
import ctypes as C,json,hashlib,time,os
R=Path(__file__).resolve().parent
class Host:
 def __init__(self,game,name):
  self.game=game;self.out=R/'probes'/name;self.out.mkdir(parents=True,exist_ok=True);self.frame=0;self.actions=[];os.chdir(self.out)
  self.lib=C.CDLL(str(R/'build/libgremlin-jaguar.dylib'));l=self.lib
  l.gremlin_jag_load.argtypes=[C.c_void_p,C.c_uint32];l.gremlin_jag_step.argtypes=[C.c_uint32];l.gremlin_jag_audio.restype=C.POINTER(C.c_int16);l.gremlin_jag_video.restype=C.POINTER(C.c_uint32);l.gremlin_jag_error.restype=C.c_char_p;l.m68k_get_reg.argtypes=[C.c_void_p,C.c_int];l.m68k_get_reg.restype=C.c_uint32
  b=(R.parent/'work-081/original'/f'{game}.j64').read_bytes();p=C.create_string_buffer(b);assert l.gremlin_jag_load(p,len(b))==0,l.gremlin_jag_error();self.audiohash=hashlib.sha256();self.videohash=hashlib.sha256();self.audioframes=0;self.started=time.monotonic();self.pcm=(self.out/'reference.s16').open('wb');self.frame_rows=[]
 def run(self,frames,mask=0,label=None):
  l=self.lib;start=self.frame
  for _ in range(frames):
   assert l.gremlin_jag_step(mask)==0;self.frame+=1;n=l.gremlin_jag_audio_frames();b=C.string_at(l.gremlin_jag_audio(),n*4);self.audiohash.update(b);self.audioframes+=n;self.pcm.write(b);values=memoryview(b).cast('h');self.frame_rows.append({'frame':self.frame,'samples':n,'rms':(sum(x*x for x in values)/max(1,len(values)))**.5,'peak':max((abs(x)for x in values),default=0)})
  self.actions.append({'from':start,'frames':frames,'mask':mask,'label':label});print(json.dumps({'game':self.game,'frame':self.frame,'label':label,'seconds_host':time.monotonic()-self.started}),flush=True)
 def stats(self):
  return {'frame':self.frame,'cpu_pc':hex(self.lib.m68k_get_reg(None,16)),'dsp_pc':hex(self.lib.DSPGetPC()),'dsp_control':hex(self.lib.DSPGetControl()),'gpu_pc':hex(self.lib.GPUGetPC())}
 def screen(self,name):
  l=self.lib;w=l.gremlin_jag_video_width();h=l.gremlin_jag_video_height();b=C.string_at(l.gremlin_jag_video(),w*h*4);rgb=bytes(v for i in range(0,len(b),4)for v in (b[i+2],b[i+1],b[i]));(self.out/(name+'.ppm')).write_bytes(f'P6\n{w} {h}\n255\n'.encode()+rgb);return w,h
 def state(self,name):
  n=self.lib.gremlin_jag_state_size();b=C.create_string_buffer(n);assert self.lib.gremlin_jag_save_state(b,n)==0;(self.out/(name+'.state')).write_bytes(b.raw)
 def close(self):
  self.pcm.close();(self.out/'audio-timeline.json').write_text(json.dumps(self.frame_rows)+'\n');s={'game':self.game,'frames':self.frame,'audio_frames':self.audioframes,'audio_s16_sha256':self.audiohash.hexdigest(),'actions':self.actions,'seconds_host':time.monotonic()-self.started,'profile':'Unchanged pinnedVirtualJaguar3.11.0, defaultoptions exceptnoenhancementpresets/hooks; ordinaryinputsonly','boot_mode':'real BIOS'if self.game=='rayman'else'HLE'};(self.out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');self.lib.gremlin_jag_close()
if __name__=='__main__':
 import sys
 game=sys.argv[1];h=Host(game,game+'-boot-1');h.run(900,label='boot');h.screen('boot');h.state('boot');h.close()
