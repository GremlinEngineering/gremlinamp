from host import Host,R
import sys,json,ctypes as C
h=Host(sys.argv[1],sys.argv[2]);print('READY',flush=True)
try:
 for line in sys.stdin:
  x=json.loads(line)
  if x['cmd']=='run':h.run(x['frames'],x.get('mask',0),x.get('label'));h.screen(x.get('label','frame-'+str(h.frame)))
  elif x['cmd']=='stats':print(json.dumps(h.stats()),flush=True)
  elif x['cmd']=='state':h.state(x.get('name','frame-'+str(h.frame)));print('SAVED',flush=True)
  elif x['cmd']=='close':break
finally:h.close()
