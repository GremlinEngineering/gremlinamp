from host import Host,R
from pathlib import Path
import json,sys,time,hashlib
old=json.loads((R/'probes/missile-context-1/summary.json').read_text());base=[]
for a in old['actions']:
 base.append(a)
 if a['label']=='music-test-menu':break
assert sum(x['frames']for x in base)==3184
names=['Main Title','Undersea','Seaboss','Cloudy View','Cloud Boss','Weird Space','Space Boss'];plan=[]
selected=list(map(int,sys.argv[1:]))if len(sys.argv)>1 else list(range(7))
for index in selected:
 h=Host('missil3d',f'missil3d-music-{index:02d}-1');prefix=[]
 for a in base:h.run(a['frames'],a['mask'],a['label']);prefix.append({'frames':a['frames'],'mask':a['mask']})
 for i in range(7-index):
  for n,mask in [(3,16),(20,0)]:h.run(n,mask,'select-'+str(i));prefix.append({'frames':n,'mask':mask})
 h.screen('selected-before-trigger');start_byte=h.audioframes*4;start_frame=h.frame
 h.run(3,256,'original-music-test-trigger');h.screen('original-music-test-playing')
 h.run(10977,0,'original-music-test-window');h.screen('original-music-test-end');h.close()
 full=(h.out/'reference.s16').read_bytes();window=full[start_byte:];assert len(window)==10980*800*4
 (h.out/'selected.s16').write_bytes(window)
 entry={'game':'missil3d','game_id':'game-ra-6765','subsong':index,'title':names[index],'prefix':prefix,'prefix_frames':start_frame,'play_inputs':[{'frames':3,'mask':256},{'frames':10977,'mask':0}],'selected_game_frames':10980,'source_audio_rate':48000,'source_audio_frames':len(window)//4,'seconds':len(window)/4/48000,'source_window':str(h.out/'selected.s16'),'source_s16_sha256':hashlib.sha256(window).hexdigest(),'original_music_test_screenshot':str(h.out/'original-music-test-playing.ppm'),'no_gameplay_memory_writes':True,'music_source_program_unchanged':True,'status':'research_only_until_native_browser_full_window_comparison'}
 plan.append(entry);(R/f'missile-plan-{index:02d}.json').write_text(json.dumps(entry,indent=2)+'\n');print('SELECTED',json.dumps(entry),flush=True)
