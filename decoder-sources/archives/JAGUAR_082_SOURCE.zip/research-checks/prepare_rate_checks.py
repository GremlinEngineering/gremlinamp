from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent;b=json.loads((R/'banks.json').read_text())[0];t=b['tracks'][0];source=np.fromfile(t['source_window'],dtype='<i2').reshape(-1,2).astype(np.float64)/32768;rows=[]
for rate in [8000,192000]:
 frames=rate;v=np.arange(frames,dtype=np.int64)*48000;at=v//rate;rem=v%rate;out=(source[at]+(source[at+1]-source[at])*rem[:,None]/rate).astype('<f4');p=R/'probes'/f'missil3d-boundary-{rate}.f32';out.tofile(p);rows.append({'key':'missil3d-00','format':'jgz','subsong':0,'file':b['file'],'sha256':b['sha256'],'rate':rate,'frames':frames,'expected':str(p),'chunkSizes':[1,3,17,511,16384]})
(R/'rate-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
s=(R/'check_browser.cjs').read_text().replace('browser-plan.json','rate-plan.json').replace('check-browser.html','check-rates.html').replace('browser-results','rate-results').replace('8983','8986');(R/'check_rates.cjs').write_text(s)
s=(R/'check-browser.html').read_text().replace('function next(){worker.postMessage', 'let renderIndex=0;function next(){worker.postMessage').replace('Math.min(4096,(total-count)/2)','Math.min(t.chunkSizes?.[renderIndex++%t.chunkSizes.length]??4096,(total-count)/2)');(R/'check-rates.html').write_text(s)
