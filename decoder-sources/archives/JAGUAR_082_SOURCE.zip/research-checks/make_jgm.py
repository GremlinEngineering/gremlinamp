from pathlib import Path
import json,struct,zlib,gzip,hashlib
R=Path(__file__).resolve().parent;G=R.parent;O=R/'native';O.mkdir(exist_ok=True)
rows=[json.loads(p.read_text())for p in sorted(R.glob('missile-plan-*.json'))]
assert rows and [x['subsong']for x in rows]==list(range(len(rows)))
rom=(G/'work-081/original/missil3d.j64').read_bytes();scripts=bytearray();table=bytearray()
for x in rows:
 prefix_offset=len(scripts)
 for a in x['prefix']:scripts+=struct.pack('<II',a['frames'],a['mask'])
 play_offset=len(scripts)
 for a in x['play_inputs']:scripts+=struct.pack('<II',a['frames'],a['mask'])
 table+=struct.pack('<16I',x['subsong'],prefix_offset,len(x['prefix']),x['prefix_frames'],play_offset,len(x['play_inputs']),x['selected_game_frames'],x['source_audio_frames'],*([0]*8))
header=bytearray(128);table_offset=128;scripts_offset=128+len(table);rom_offset=scripts_offset+len(scripts);total=rom_offset+len(rom)
struct.pack_into('<4s15I',header,0,b'JGM\x1a',1,1,48000,800,len(rom),len(rows),128,64,scripts_offset,len(scripts),rom_offset,total,zlib.crc32(table),zlib.crc32(scripts),zlib.crc32(rom));header[64:96]=hashlib.sha256(rom).digest();header[96:116]=bytes.fromhex('34696082dbc0448caf23aa4ecb5ed40817cb8da0')
data=header+table+scripts+rom;p=O/'missil3d-music-test.jgm';p.write_bytes(data);q=p.with_suffix('.jgz');q.write_bytes(gzip.compress(data,compresslevel=9,mtime=0));result={'game':'missil3d','native_format':'jgz','file':str(q),'bytes':len(q.read_bytes()),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'uncompressed_bytes':total,'original_rom_bytes_unchanged':True,'original_rom_sha256':hashlib.sha256(rom).hexdigest(),'tracks':rows,'research_only':True};(R/'banks.json').write_text(json.dumps([result],indent=2)+'\n');print('Created',len(rows),'original music-test selections',len(data),'raw',q.stat().st_size,'gzip')
