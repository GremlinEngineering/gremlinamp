"""Rebuild the supplied unchanged original Jaguar core and frontend adapter."""
from pathlib import Path
import argparse,os,subprocess,shlex,json,re,hashlib,shutil
R=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--emsdk',type=Path,required=True);parser.add_argument('--em-config',type=Path);args=parser.parse_args();sdk=args.emsdk.resolve();ccdir=next((p for p in [sdk/'install/emscripten',sdk/'upstream/emscripten']if(p/'emcc.py').exists()),None);assert ccdir,'Emscripten not found'
env={**os.environ,'GIT_CEILING_DIRECTORIES':str(R)}
if os.uname().sysname=='Darwin':env['DEVELOPER_DIR']='/Library/Developer/CommandLineTools'
if args.em_config:env['EM_CONFIG']=str(args.em_config.resolve())
elif(sdk/'.emscripten').exists():env['EM_CONFIG']=str(sdk/'.emscripten')
E=R/'emulator';O=R/'built';O.mkdir(exist_ok=True)
subprocess.run(['make','-j4','platform=emscripten','TEST_EXPORTS=0','CC=python3 '+shlex.quote(str(ccdir/'emcc.py')),'CXX=python3 '+shlex.quote(str(ccdir/'em++.py')),'AR=python3 '+shlex.quote(str(ccdir/'emar.py'))],cwd=E,env=env,check=True)
archive=O/'libvirtualjaguar.a';shutil.copy2(E/'virtualjaguar_libretro_emscripten.bc',archive)
common=[str(E/'libretro-common'/x)for x in re.findall(r'\$\(LIBRETRO_COMM_DIR\)/([^\\\s]+\.c)',(E/'Makefile.common').read_text())];assert len(common)==13
exports=['load','close','step','audio','audio_frames','video','video_width','video_height','capture_video','error','state_size','save_state','load_state'];exports=['_gremlin_jag_'+x for x in exports]+['_malloc','_free']
cmd=['python3',str(ccdir/'emcc.py'),'-std=gnu89','-O2','-fwrapv','-ffp-contract=off',str(R/'source/jaguar_host.c'),str(archive),*common,'-D__LIBRETRO__','-DHAVE_EMSCRIPTEN','-I'+str(E/'libretro-common/include'),'--no-entry','-sMODULARIZE=1','-sEXPORT_NAME=GremlinJaguarMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=134217728','-sMAXIMUM_MEMORY=268435456','-sFORCE_FILESYSTEM=1','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAPU32","FS"]','-o',str(O/'gremlin-jaguar.js')];subprocess.run(cmd,env=env,check=True)
for p in O.glob('gremlin-jaguar.*'):print(p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
