Corresponding core and frontend source. Emscripten6.0.13 used for delivered build.
Runrebuild.py with yourSDK path. No game ROM is required to rebuild the decoder.
Original full-repository archive SHA25638e9558cc46d702e01a392d2f674c84d4e32a8dcde9a16a5879c3103227e0b1b.
Original core inputs are unchanged; non-build site/app/test media omitted.
Format and musical selection provenance are in FORMAT.txt/SOURCE_PROOF.json.
