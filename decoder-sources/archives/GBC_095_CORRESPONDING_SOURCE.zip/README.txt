Original Gambatte77f2567d718b8973d02caa2daa8dce4953faf811, GPL2. Original source ZIP SHA25609896e086b546b1c8f284bc6767039d362eaff8bad267796fdf10137f4a0173f.
No original core source changed. gb_host.c is a separate minimal libretro frontend. Default core options and32768Hz blipper output, standard post-BIOS original core initial state, no external BIOS.
Build: python3 build_wasm.py --emsdk /absolute/emsdk --output /absolute/build
Verified with Emscripten6.0.13-git: independent clean build matches delivered JS/Wasm bit-for-bit.
Source: https://github.com/libretro/gambatte-libretro/tree/77f2567d718b8973d02caa2daa8dce4953faf811
