from pathlib import Path
import argparse,zipfile,hashlib,subprocess,os,shlex,re,json,shutil
p=argparse.ArgumentParser();p.add_argument('--emsdk',required=True);p.add_argument('--output',required=True);a=p.parse_args()
R=Path(__file__).resolve().parent;SDK=Path(a.emsdk).resolve();S=SDK/'install/emscripten';B=Path(a.output).resolve();E=B/'core';O=B/'common';O.mkdir(parents=True,exist_ok=True)
archive=R/'original-sources.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='09896e086b546b1c8f284bc6767039d362eaff8bad267796fdf10137f4a0173f'
with zipfile.ZipFile(archive)as z:
 for x in z.infolist():
  if x.is_dir():continue
  rel=Path(*Path(x.filename).parts[1:]);assert not rel.is_absolute()and'..'not in rel.parts;dest=E/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(x))
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'GIT_CEILING_DIRECTORIES':str(B),'DEVELOPER_DIR':'/Library/Developer/CommandLineTools'}
cmd=['make','-f','Makefile.libretro','-j4','platform=emscripten','HAVE_NETWORK=0','CC=python3 '+shlex.quote(str(S/'emcc.py')),'CXX=python3 '+shlex.quote(str(S/'em++.py')),'AR=python3 '+shlex.quote(str(S/'emar.py'))]
with(B/'make.log').open('w')as f:subprocess.run(cmd,cwd=E,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
incs=[E/'libgambatte/src',E/'libgambatte/include',E/'common',E/'common/resample',E/'libgambatte/libretro',E/'libgambatte/libretro-common/include'];flags=['-O2','-DNDEBUG','-DHAVE_STDINT_H','-DHAVE_INTTYPES_H','-D__LIBRETRO__','-DCC_RESAMPLER_NO_HIGHPASS','-DVIDEO_RGB565']+['-I'+str(x)for x in incs]
common=re.findall(r'\$\(LIBRETRO_COMM_DIR\)/([^\\\s]+\.c)',(E/'Makefile.common').read_text());assert len(common)==13
for name in common:
 src=E/'libgambatte/libretro-common'/name;out=O/('-'.join(src.relative_to(E).parts)+'.o');subprocess.run(['python3',str(S/'emcc.py'),*flags,'-c',str(src),'-o',str(out)],env=env,check=True)
subprocess.run(['python3',str(S/'emcc.py'),*flags,'-c',str(R/'gb_host.c'),'-o',str(O/'gb_host.o')],env=env,check=True)
shutil.copy2(E/'gambatte_libretro_emscripten.bc',O/'libgambatte.a')
exports=['_gremlin_gb_'+s for s in ['load','close','step','audio','audio_frames','video','video_width','video_height','capture_video','error','source_rate','source_fps']]+['_malloc','_free']
cmd=['python3',str(S/'em++.py'),'-O2','--no-entry',str(O/'gb_host.o'),str(O/'libgambatte.a')]+[str(x)for x in sorted(O.glob('*.o'))if x.name!='gb_host.o']+['-sMODULARIZE=1','-sEXPORT_NAME=GremlinGBCMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sSTACK_SIZE=1048576','-sFILESYSTEM=1','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAPU32"]','-o',str(B/'gremlin-gbc.js')]
with(B/'link.log').open('w')as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
print('Built original pinned Gambatte plus frontend; no core or musical data changes')
