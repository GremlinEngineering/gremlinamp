const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {chromium}=require('playwright');
(async()=>{
 const root=path.join(__dirname,'test-site');
 const server=http.createServer((req,res)=>{
  const file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/\/$/,'/index.html'));
  if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}
  res.setHeader('Content-Type',({'.js':'application/javascript','.wasm':'application/wasm','.html':'text/html'})[path.extname(file)]||'application/octet-stream');
  fs.readFile(file,(e,b)=>{res.writeHead(e?404:200);res.end(e?'not found':b);});
 });
 await new Promise(r=>server.listen(8807,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:path.resolve(__dirname,'../music_player_codecs_0_1/.tools/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,args:['--no-sandbox','--autoplay-policy=no-user-gesture-required']});
 const page=await browser.newPage();await page.goto('http://127.0.0.1:8807/');await page.waitForFunction(()=>window.engine);
 const result=await page.evaluate(async()=>{
  const wait=ms=>new Promise(r=>setTimeout(r,ms));const gains=[];
  async function audible(){for(let i=0;i<60;i++){const s=engine.snapshot();if(s.state==='error'||s.state==='playing'&&s.diagnostics.rms>0)return s;await wait(100);}return engine.snapshot();}
  const create=AudioContext.prototype.createGain;AudioContext.prototype.createGain=function(...args){const node=create.apply(this,args);gains.push(node);return node;};
  const manifest={id:'new-wsr-controls',manifestURL:location.href,delivery:{preload_budget_bytes:65536},tracks:[
   {backend:'gme',gain_db:-6,subsong:0,play_ms:30000,fade_ms:0,asset:{url:'/wsr-originals/rockman.wsr',format:'wsr',path:'original.wsr',bytes:0}},
   {backend:'gme',subsong:0,play_ms:30000,fade_ms:0,asset:{url:'/originals/zelda2.nsf',format:'nsf',path:'original.nsf',bytes:0}}
   ,{backend:'gme',subsong:0,play_ms:30000,fade_ms:0,asset:{url:'/fixtures/01 Main Theme.spc',format:'spc',path:'original.spc',bytes:0}}
  ]};
  engine.setVolume(1);await engine.play(manifest,0);await wait(500);const playing=engine.snapshot();const fullGain=gains[0].gain.value;
  engine.setVolume(.4);const lowerGain=gains[0].gain.value;
  engine.pause();await wait(250);const a=engine.snapshot();await wait(300);const b=engine.snapshot();
  await engine.play(manifest,0);await wait(400);const resumed=engine.snapshot();
  await engine.play(manifest,1);const other=await audible();
  await engine.play(manifest,0);await wait(450);const back=engine.snapshot();
  await engine.play(manifest,2);const legacy=await audible();await engine.play(manifest,0);const final=await audible();
  engine.stop();const stopped=engine.snapshot();const pending=engine.play({...manifest,id:'cancel-wsr-load'},0);engine.stop();await pending;await wait(200);const cancelled=engine.snapshot();
  const checks={wsr_playing:playing.state==='playing'&&playing.diagnostics.rms>0,pause:a.state==='paused'&&b.state==='paused'&&a.seconds===b.seconds,resume:resumed.state==='playing'&&resumed.seconds>=b.seconds,switch_to_fds_nsf:other.state==='playing'&&other.diagnostics.rms>0,switch_back_to_wsr:back.state==='playing'&&back.diagnostics.rms>0,stop:stopped.state==='idle',cancel_load:cancelled.state==='idle',switch_to_legacy_spc:legacy.state==='playing'&&legacy.diagnostics.rms>0,switch_back_from_legacy:final.state==='playing'&&final.diagnostics.rms>0,gain_at_full_volume:Math.abs(fullGain-10**(-6/20))<1e-6,gain_after_volume_change:Math.abs(lowerGain-.4*10**(-6/20))<1e-6};
  return {checks,pass:Object.values(checks).every(Boolean),fullGain,lowerGain,wsr_rms:playing.diagnostics.rms,gme_rms:other.diagnostics.rms,wsr_after_switch_rms:back.diagnostics.rms,transport:playing.diagnostics.transport};
 });
 await browser.close();await new Promise(r=>server.close(r));
 fs.writeFileSync(__dirname+'/wsr-controls-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));if(!result.pass)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
