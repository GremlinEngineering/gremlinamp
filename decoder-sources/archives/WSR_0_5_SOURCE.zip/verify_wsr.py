"""Fresh native in_wsr instances, exact previously validated640-frame cadence."""
from pathlib import Path
import ctypes,json,hashlib,math,multiprocessing
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
R=Path(__file__).resolve().parent;COL=R.parent/'music_collection_full_0_2';V=R/'verification';PCM=V/'pcm';PCM.mkdir(parents=True,exist_ok=True)
IDS=['game-ra-614','game-ra-14593','game-ra-17250','game-ra-17754','game-ra-14873','game-ra-2533']
def sha(b):return hashlib.sha256(b).hexdigest()
def render(t):
 raw=Path(t['file']).read_bytes();buf=ctypes.create_string_buffer(raw);g=ctypes.CDLL(str((COL/'runtime/wsr/libin_wsr.so').resolve()))
 g.Load_WSR.argtypes=[ctypes.c_void_p,ctypes.c_uint];g.Load_WSR.restype=ctypes.c_int;g.Reset_WSR.argtypes=[ctypes.c_uint];g.Set_Frequency.argtypes=[ctypes.c_uint];g.Set_Frequency.restype=ctypes.c_uint;g.Set_ChannelMuting.argtypes=[ctypes.c_uint];g.Update_WSR.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_uint];g.Update_WSR.restype=ctypes.c_int
 rate=t.get('sample_rate',48000);g.Set_Frequency(rate);assert g.Load_WSR(buf,len(raw));g.Reset_WSR(t['subsong']);assert g.Set_Frequency(rate)==rate;g.Set_ChannelMuting(0)
 frames=math.ceil(sum(t['timing'].get(k,0)for k in ['play_ms','fade_ms'])*rate/1000/4096)*4096;output=np.zeros(1280,np.int16);samples=0;peak=0;power=0;nonzero=0;saturated=0;digest=hashlib.sha256();p=PCM/(t['game_id']+'-'+t['track_id']+'-'+str(rate)+'.s16le')
 with p.open('wb')as file:
  for start in range(0,frames,640):
   assert g.Update_WSR(output.ctypes.data,output.nbytes,640);count=min(640,frames-start)*2;a=output[:count];b=a.tobytes();file.write(b);digest.update(b);x=a.astype(np.int64);peak=max(peak,int(np.max(abs(x))));power+=int(np.sum(x*x));nonzero+=int(np.count_nonzero(x));saturated+=int(np.count_nonzero(abs(x)>=32767));samples+=count
 g.Close_WSR();assert nonzero and saturated==0,(t['game_id'],t['track_id'],nonzero,saturated)
 probe={**t,'sample_rate':rate,'decoder':'wsr','reference_pcm':str(p.resolve()),'reference_pcm_format':'s16le','reference_frames':frames,'source_sha256':sha(raw)}
 row={'game_id':t['game_id'],'track_id':t['track_id'],'title':t['title'],'subsong':t['subsong'],'sample_rate':rate,'source_sha256':sha(raw),'decoded_frames':frames,'peak':peak/32768,'rms':math.sqrt(power/samples)/32768,'nonzero_samples':nonzero,'int16_saturated_samples':saturated,'pcm_sha256':digest.hexdigest(),'pass':True}
 return probe,row
if __name__=='__main__':
 jobs=[]
 for gid in IDS:jobs+=json.loads((COL/'albums'/gid/'probes.json').read_text())
 assert len(jobs)==83
 # Representative44100Hz outputs add a real check for each of the six source files.
 extra=[]
 for gid in IDS:
  t=next(t for t in jobs if t['game_id']==gid);extra.append({**t,'track_id':t['track_id']+'-44100','timing':{'play_ms':30000},'sample_rate':44100})
 jobs+=extra;results=[];probes=[]
 with ProcessPoolExecutor(max_workers=2,max_tasks_per_child=1,mp_context=multiprocessing.get_context('spawn'))as pool:
  futures={pool.submit(render,t):t for t in jobs}
  for f in as_completed(futures):
   probe,result=f.result();probes.append(probe);results.append(result)
   (R/'native-wsr-results.partial.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
   print(json.dumps({'complete':len(results),'total':len(jobs),'game_id':result['game_id'],'track_id':result['track_id'],'pass':True}),flush=True)
 probes.sort(key=lambda p:next(i for i,t in enumerate(jobs)if t['game_id']==p['game_id']and t['track_id']==p['track_id']));results.sort(key=lambda p:next(i for i,t in enumerate(jobs)if t['game_id']==p['game_id']and t['track_id']==p['track_id']))
 (R/'original-wsr-probes.json').write_text(json.dumps(probes,ensure_ascii=False,indent=2)+'\n');(R/'native-wsr-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
