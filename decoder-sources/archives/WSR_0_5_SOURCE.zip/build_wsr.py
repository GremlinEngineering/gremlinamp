"""Pinned unmodified Kodi in_wsr NEC/WonderSwan decoder, native and isolated WASM builds."""
from pathlib import Path
import argparse,subprocess,os,json,hashlib
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--sdk',required=True,type=Path);args=p.parse_args();sdk=args.sdk.resolve();out=R/'built';out.mkdir(exist_ok=True);build=R/'build';build.mkdir(exist_ok=True)
source=R/'third_party/in_wsr';files=[source/'nec/nec.c']+[source/n for n in ['ws_audio.c','ws_io.c','ws_memory.c','wsr_player.c']]
flags=['-O3','-DNDEBUG','-fwrapv','-fno-strict-aliasing','-I'+str(source)]
def run(cmd,label,env=None):
 with(build/(label+'.log')).open('w')as f:r=subprocess.run([str(x)for x in cmd],stdout=f,stderr=subprocess.STDOUT,env=env)
 if r.returncode:print((build/(label+'.log')).read_text()[-6000:]);raise SystemExit(r.returncode)
run(['gcc','-shared','-fPIC']+flags+files+['-lm','-o',out/'libgremlin-wsr.so'],'native')
env={**os.environ,'EMSDK':str(sdk),'EM_CONFIG':str(sdk/'.emscripten'),'PATH':str(sdk/'upstream/emscripten')+os.pathsep+os.environ.get('PATH','')}
exports=['_Load_WSR','_Reset_WSR','_Set_Frequency','_Set_ChannelMuting','_Get_FirstSong','_Update_WSR','_Close_WSR','_malloc','_free']
run(['python3',sdk/'upstream/emscripten/emcc.py']+flags+files+['--no-entry','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sMAXIMUM_MEMORY=134217728','-sENVIRONMENT=worker,node','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16"]','-o',out/'gremlin-wsr.js'],'wasm',env)
rows=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in [out/'gremlin-wsr.js',out/'gremlin-wsr.wasm']]
(out/'BUILD.json').write_text(json.dumps({'version':'0.5','component':'wsr','source':json.loads((R/'source-provenance.json').read_text()),'upstream_core_modified':False,'compiler':'Emscripten6.0.13','flags':flags[:4],'output':'Signed16 stereo PCM;640-frame internal cadence matches the previously validated desktop renderer.','files':rows,'production_deployed':False},indent=2)+'\n');print(json.dumps(rows))
