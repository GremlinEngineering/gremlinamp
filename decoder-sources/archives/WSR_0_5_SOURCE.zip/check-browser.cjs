// Actual worker decoding, automatic routing and full PCM comparison with native build.
const fs=require('node:fs'),http=require('node:http'),path=require('node:path');
const {chromium}=require('playwright');
const root=__dirname,player=root+'/test-site/music',port=8805;
const smoke=process.argv.includes('--smoke'),stem=smoke?'browser-wsr-smoke':'browser-wsr-results';
const probes=JSON.parse(fs.readFileSync(root+(smoke?'/smoke-probes.json':'/original-wsr-probes.json')));
for(let i=0;i<probes.length;i++){const t=probes[i];t.index=i;t.check_ms=(t.timing.play_ms||0)+(t.timing.fade_ms||0);t.source_sha256=require('node:crypto').createHash('sha256').update(fs.readFileSync(t.file)).digest('hex');}
const html=`<!doctype html><script type="module">
import {decoderFor} from '/music/decoders.js';
const sha=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b))).map(n=>n.toString(16).padStart(2,'0')).join('');
window.check=async t=>{
 const rate=t.sample_rate||48000;
 const bytes=await(await fetch('/input/'+t.index)).arrayBuffer();if(await sha(bytes)!==t.source_sha256)throw Error('Different source bytes');
 const route=decoderFor({format:t.format},bytes);if(route.id!=='wsr')throw Error('Wrong automatic decoder route: '+route.id);
 const reference=new Int16Array(await(await fetch('/reference/'+t.index)).arrayBuffer());
 return new Promise(resolve=>{
  const w=new Worker('/music/'+route.worker),start=performance.now();let count=0,peak=0,sum=0,nonzero=0,maxError=0,clipped=0,firstNonzero=null,lastNonzero=null;
  const timer=setTimeout(()=>done({error:'timeout'}),180000);
  function done(r){clearTimeout(timer);w.terminate();resolve({...r,decoder:route.id,count,reference_count:reference.length,max_absolute_error:maxError,peak,rms:count?Math.sqrt(sum/count):0,nonzero,int16_saturated_samples:clipped,firstNonzero,lastNonzero,elapsed_ms:Math.round(performance.now()-start)});}
  w.onerror=e=>done({error:e.message});
  w.onmessage=({data:m})=>{
   if(m.type==='error')return done({error:m.message});
   if(m.type==='ready')return w.postMessage({type:'render',frames:4096});
   if(m.type==='pcm'){
    for(const x of new Float32Array(m.pcm)){
     if(!Number.isFinite(x))return done({error:'Non-finite PCM'});
     if(count>=reference.length)return done({error:'More PCM than reference'});
     maxError=Math.max(maxError,Math.abs(x-reference[count]/32768));peak=Math.max(peak,Math.abs(x));sum+=x*x;
     if(Math.abs(x)>=32767/32768)clipped++;
     if(Math.abs(x)>.00001){nonzero++;if(firstNonzero===null)firstNonzero=count/2/rate;lastNonzero=count/2/rate;}
     count++;
    }
    if(count>=reference.length)return done({});
    w.postMessage({type:'render',frames:4096});
   }
  };
  w.postMessage({type:'load',bytes,format:t.format,subsong:t.subsong,sampleRate:rate},[bytes]);
 });
};
</script>`;
(async()=>{
 const server=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://localhost').pathname;
  if(url==='/'){res.setHeader('Content-Type','text/html');return res.end(html);}
  let file;
  if(url.startsWith('/music/'))file=path.resolve(player,decodeURIComponent(url.slice(7)));
  else if(url.startsWith('/input/'))file=probes[Number(url.slice(7))]?.file;
  else if(url.startsWith('/reference/'))file=probes[Number(url.slice(11))]?.reference_pcm;
  if(!file){res.writeHead(404).end();return;}
  if(url.startsWith('/music/')&&!file.startsWith(player+'/')){res.writeHead(403).end();return;}
  res.setHeader('Content-Type',({'.js':'application/javascript','.wasm':'application/wasm'})[path.extname(file)]||'application/octet-stream');fs.readFile(file,(e,b)=>{res.writeHead(e?404:200);res.end(e?'not found':b);});
 });
 await new Promise(r=>server.listen(port,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:path.resolve(root,'../music_player_codecs_0_1/.tools/chrome-headless-shell-linux64/chrome-headless-shell'),headless:true,args:['--no-sandbox']});
 const results=[],errors=[];let next=0;
 await Promise.all(Array.from({length:4},async()=>{
  const page=await browser.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+port);await page.waitForFunction(()=>window.check);
  while(next<probes.length){const t=probes[next++],r=await page.evaluate(t=>check(t),t);const row={game_id:t.game_id,track_id:t.track_id,title:t.title,format:t.format,subsong:t.subsong,source_sha256:t.source_sha256,...r,pass:!r.error&&r.count===r.reference_count&&r.max_absolute_error===0&&r.nonzero>0&&r.int16_saturated_samples===0};results.push(row);fs.writeFileSync(root+'/'+stem+'.partial.json',JSON.stringify(results,null,2));if(!row.pass||results.length%10===0)console.log(JSON.stringify({complete:results.length,total:probes.length,...row}));}
  await page.close();
 }));
 results.sort((a,b)=>probes.findIndex(t=>t.game_id===a.game_id&&t.track_id===a.track_id)-probes.findIndex(t=>t.game_id===b.game_id&&t.track_id===b.track_id));
 fs.writeFileSync(root+'/'+stem+'.json',JSON.stringify({method:'Actual browser worker, automatic format/header routing, complete configured duration,48000Hz plus six44100Hz representatives; every output sample compared with fresh instances of the previously validated native core,640-frame internal cadence. Original file SHA256 checked in browser. No notes or source WSR bytes changed.',results,pageErrors:errors},null,2));
 console.log(JSON.stringify({done:results.length,failed:results.filter(r=>!r.pass).map(r=>({game_id:r.game_id,subsong:r.subsong,error:r.error,max_error:r.max_absolute_error})),pageErrors:errors}));
 await browser.close();await new Promise(r=>server.close(r));if(results.some(r=>!r.pass)||errors.length)process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
