from pathlib import Path
import argparse,zipfile,hashlib,subprocess,os,shlex,json,shutil,sys
p=argparse.ArgumentParser();p.add_argument('--emsdk',required=True);p.add_argument('--output',required=True);a=p.parse_args();R=Path(__file__).resolve().parent;SDK=Path(a.emsdk).resolve();S=SDK/'install/emscripten';B=Path(a.output).resolve();E=B/'core';B.mkdir(parents=True,exist_ok=True)
archive=R/'original-sources.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='f06933f4bd2aed57ccd40f64f346d1c387f83c162afa352b23e335ae39f71596'
with zipfile.ZipFile(archive)as z:
 for x in z.infolist():
  if x.is_dir():continue
  rel=Path(*Path(x.filename).parts[1:]);assert not rel.is_absolute()and'..'not in rel.parts;dest=E/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(x))
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'SOURCE_DATE_EPOCH':'0','GIT_CEILING_DIRECTORIES':str(B),'DEVELOPER_DIR':'/Library/Developer/CommandLineTools'}
cmd=['make','-j4','platform=emscripten','GIT_VERSION=ef3e0fe','CC=python3 '+shlex.quote(str(S/'emcc.py')),'CXX=python3 '+shlex.quote(str(S/'em++.py')),'AR=python3 '+shlex.quote(str(S/'emar.py'))]
with(B/'make.log').open('w')as f:subprocess.run(cmd,cwd=E,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
cc=[sys.executable,str(S/'emcc.py')];host=B/'iv_host.o';subprocess.run([*cc,'-O2','-DNDEBUG','-I'+str(E/'src/deps/libretro-common/include'),'-c',str(R/'iv_host.c'),'-o',str(host)],env=env,check=True);shutil.copyfile(E/'freeintv_libretro_emscripten.bc',B/'libfreeintv.a')
import re
common=re.findall(r'\$\(LIBRETRO_COMM_DIR\)/([^\\\s]+\.c)',(E/'Makefile.common').read_text());assert len(common)==12
compat=[]
for name in common:
 src=E/'src/deps/libretro-common'/name;obj=B/('compat-'+name.replace('/','-')+'.o');subprocess.run([*cc,'-O2','-DNDEBUG','-D__LIBRETRO__','-I'+str(E/'src'),'-I'+str(E/'src/deps/libretro-common/include'),'-c',str(src),'-o',str(obj)],env=env,check=True);compat.append(str(obj))
exports=['_malloc','_free']+['_gremlin_iv_'+x for x in ['load','close','step','audio','audio_frames','video','video_width','video_height','capture_video','error','source_rate','source_fps']]
cmd=[*cc,'-O2','--no-entry',str(host),str(B/'libfreeintv.a'),*compat,'-sMODULARIZE=1','-sEXPORT_NAME=GremlinIVMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sSTACK_SIZE=1048576','-sFILESYSTEM=1','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAPU32"]','-o',str(B/'gremlin-iv.js')]
with(B/'link.log').open('w')as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
meta={'core':'Original FreeIntv Intellivision CP1610/PSG','commit':'ef3e0fe322bec62a7f916c0bb0834c08c348d0b4','core_changes':False,'default_options':True,'outputs':{n:{'bytes':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()}for n in ['gremlin-iv.js','gremlin-iv.wasm']}};(B/'BUILD.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
