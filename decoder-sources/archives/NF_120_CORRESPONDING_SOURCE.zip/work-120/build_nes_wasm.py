from pathlib import Path
import zipfile,subprocess,os,json,sys,shlex,hashlib,shutil,argparse
W=Path(__file__).resolve().parent;G=W.parent
p=argparse.ArgumentParser();p.add_argument('--emsdk',default=str(G/'work-040/references/emsdk'));p.add_argument('--output',default=str(W/'nes-wasm'));a=p.parse_args();SDK=Path(a.emsdk).resolve();S=SDK/'install/emscripten';B=Path(a.output).resolve();E=B/'core';E.mkdir(parents=True,exist_ok=True);B.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(W/'sources/fceumm-source.zip')as z:
 for i in z.infolist():
  rel=Path(*Path(i.filename).parts[1:])
  if not rel.parts or i.is_dir():continue
  dest=E/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(i))
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'SOURCE_DATE_EPOCH':'0','GIT_CEILING_DIRECTORIES':str(W),'DEVELOPER_DIR':'/Library/Developer/CommandLineTools'}
cmd=['make','-j4','platform=emscripten','GIT_VERSION=e0f3086a','CC=python3 '+shlex.quote(str(S/'emcc.py')),'CXX=python3 '+shlex.quote(str(S/'em++.py')),'AR=python3 '+shlex.quote(str(S/'emar.py'))]
with(B/'make.log').open('w')as f:subprocess.run(cmd,cwd=E,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
cc=[sys.executable,str(S/'emcc.py')]
# The standalone libretro build must include upstream's filesystem fallback helpers.
common=['compat/compat_posix_string.c','compat/compat_snprintf.c','compat/compat_strcasestr.c','compat/compat_strl.c','compat/fopen_utf8.c','encodings/encoding_utf.c','file/file_path.c','file/file_path_io.c','streams/file_stream.c','streams/file_stream_transforms.c','string/stdstring.c','time/rtime.c','vfs/vfs_implementation.c']
extra=[]
for name in common:
 source=E/'src/drivers/libretro/libretro-common'/name;obj=B/(source.stem+'.o');subprocess.run([*cc,'-O2','-DNDEBUG','-D__LIBRETRO__','-I'+str(E/'src/drivers/libretro/libretro-common/include'),'-c',str(source),'-o',str(obj)],env=env,check=True);extra.append(str(obj))
host=B/'nes_host.o';subprocess.run([*cc,'-O2','-DNDEBUG','-I'+str(E/'src/drivers/libretro/libretro-common/include'),'-c',str(W/'nes_host.c'),'-o',str(host)],env=env,check=True);lib=E/'fceumm_libretro_emscripten.bc';assert lib.exists();shutil.copy2(lib,B/'libfceumm.a');lib=B/'libfceumm.a'
exports=['_malloc','_free']+['_gremlin_nes_'+x for x in ['load','close','step','audio','audio_frames','video','video_width','video_height','capture_video','error','source_rate','source_fps']]
cmd=[*cc,'-O2','--no-entry',str(host),str(lib),*extra,'-sMODULARIZE=1','-sEXPORT_NAME=GremlinNESMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sSTACK_SIZE=1048576','-sFILESYSTEM=1','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAPU32","FS"]','-o',str(B/'gremlin-nf.js')]
with(B/'link.log').open('w')as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
proof={'core':'Original full FCEUmm NES/FDS/Vs. System','commit':json.loads((W/'fceumm-source-proof.json').read_text())['commit'],'core_source_changes':False,'original_ROM_BIOS_and_sound_programs':True,'outputs':{n:{'bytes':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()}for n in['gremlin-nf.js','gremlin-nf.wasm']}}
(B/'BUILD.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof,flush=True)
