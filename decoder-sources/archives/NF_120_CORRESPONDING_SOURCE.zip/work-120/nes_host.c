/* GPL-2.0-or-later. Frontend adapter for the pinned unchanged FCEUmm core.
   Original ROM/BIOS execution and ordinary controller inputs only. */
#include "libretro.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define API __attribute__((visibility("default")))
static const struct retro_core_options_v2 *options;
static const struct retro_core_option_definition *options1;
static uint32_t mask;static int loaded,initialized,failed,capture=1,pixel_format;
static uint8_t *original;static struct retro_game_info_ext ext;
static int16_t audio[32768];static unsigned audio_count,width,height;static uint32_t pixels[1024*1024];
static double source_rate,source_fps;static char error_text[256];
static bool environment(unsigned cmd,void *data){
 struct retro_variable *v;
 switch(cmd){
 case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:*(unsigned*)data=2;return true;
 case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2:options=data;return true;
 case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL:options=((const struct retro_core_options_v2_intl*)data)->us;return true;
 case RETRO_ENVIRONMENT_SET_CORE_OPTIONS:options1=data;return true;
 case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL:options1=((const struct retro_core_options_intl*)data)->us;return true;
 case RETRO_ENVIRONMENT_GET_VARIABLE:
  v=data;if(options)for(const struct retro_core_option_v2_definition *d=options->definitions;d->key;d++)if(!strcmp(d->key,v->key)){v->value=d->default_value;return true;}
  if(options1)for(const struct retro_core_option_definition *d=options1;d->key;d++)if(!strcmp(d->key,v->key)){v->value=d->default_value;return true;}
  v->value=NULL;return false;
 case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:*(bool*)data=false;return true;
 case RETRO_ENVIRONMENT_GET_GAME_INFO_EXT:*(const struct retro_game_info_ext**)data=&ext;return original!=NULL;
 case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
 case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:*(const char**)data=".";return true;
 case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:pixel_format=*(enum retro_pixel_format*)data;return pixel_format==RETRO_PIXEL_FORMAT_RGB565||pixel_format==RETRO_PIXEL_FORMAT_XRGB8888;
 case RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE:
 case RETRO_ENVIRONMENT_SET_DISK_CONTROL_EXT_INTERFACE:
 case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
 case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
 case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_UPDATE_DISPLAY_CALLBACK:
 case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
 case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
 case RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE:
 case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS:
 case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
 case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO:
 case RETRO_ENVIRONMENT_SET_GEOMETRY:return true;
 case RETRO_ENVIRONMENT_GET_LANGUAGE:*(unsigned*)data=RETRO_LANGUAGE_ENGLISH;return true;
 case RETRO_ENVIRONMENT_GET_CAN_DUPE:*(bool*)data=true;return true;
 default:return false;
 }
}
static void video(const void *data,unsigned w,unsigned h,size_t pitch){
 if(!data||!capture)return;if(!w||!h||w>1024||h>1024){failed=1;return;}width=w;height=h;
 for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){
  if(pixel_format==RETRO_PIXEL_FORMAT_XRGB8888)pixels[y*w+x]=0xff000000|((const uint32_t*)((const uint8_t*)data+y*pitch))[x];
  else{uint16_t c=((const uint16_t*)((const uint8_t*)data+y*pitch))[x];pixels[y*w+x]=0xff000000|(((c>>11)&31)*255/31<<16)|(((c>>5)&63)*255/63<<8)|((c&31)*255/31);}
 }
}
static size_t audio_batch(const int16_t *data,size_t n){if(n>16384-audio_count){failed=1;return n;}memcpy(audio+audio_count*2,data,n*4);audio_count+=n;return n;}
static void audio_one(int16_t l,int16_t r){int16_t p[2]={l,r};audio_batch(p,1);}static void poll(void){}
static int16_t input(unsigned port,unsigned device,unsigned index,unsigned id){(void)index;return port==0&&device==RETRO_DEVICE_JOYPAD&&id<16?((mask>>id)&1):0;}
API void gremlin_nes_close(void){if(loaded)retro_unload_game();loaded=0;if(initialized)retro_deinit();initialized=0;free(original);original=NULL;options=NULL;options1=NULL;audio_count=0;}
API int gremlin_nes_load(const uint8_t *rom,uint32_t bytes,int fds){
 gremlin_nes_close();error_text[0]=0;failed=0;mask=0;width=height=0;pixel_format=RETRO_PIXEL_FORMAT_0RGB1555;
 if(!rom||bytes<8192||bytes>16777216){strcpy(error_text,"Original NES ROM bounds");return 1;}
 original=malloc(bytes);if(!original){strcpy(error_text,"Original NES allocation failed");return 1;}memcpy(original,rom,bytes);
 const char *name=fds?"original.fds":"original.nes";memset(&ext,0,sizeof(ext));ext.full_path=name;ext.dir=".";ext.name="original";ext.ext=fds?"fds":"nes";ext.data=original;ext.size=bytes;ext.persistent_data=true;
 retro_set_environment(environment);retro_set_video_refresh(video);retro_set_audio_sample(audio_one);retro_set_audio_sample_batch(audio_batch);retro_set_input_poll(poll);retro_set_input_state(input);retro_init();initialized=1;
 struct retro_game_info info={name,original,bytes,NULL};if(!retro_load_game(&info)){strcpy(error_text,"Original NES/FDS cartridge load failed");gremlin_nes_close();return 1;}
 struct retro_system_av_info av;retro_get_system_av_info(&av);source_rate=av.timing.sample_rate;source_fps=av.timing.fps;loaded=1;return 0;
}
API int gremlin_nes_step(uint32_t value){if(!loaded)return 1;mask=value;audio_count=0;failed=0;retro_run();return failed;}
API const int16_t *gremlin_nes_audio(void){return audio;}API uint32_t gremlin_nes_audio_frames(void){return audio_count;}
API const uint32_t *gremlin_nes_video(void){return pixels;}API uint32_t gremlin_nes_video_width(void){return width;}API uint32_t gremlin_nes_video_height(void){return height;}
API void gremlin_nes_capture_video(int value){capture=value;}API const char *gremlin_nes_error(void){return error_text;}
API double gremlin_nes_source_rate(void){return source_rate;}API double gremlin_nes_source_fps(void){return source_fps;}
