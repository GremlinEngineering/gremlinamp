#include "original_sftm.h"
#include "hash/mednafen/mednafen.h"
#include "hash/sha256.h"
#include <deque>
#include <string>
#include <cstring>
static OriginalSftm original;
static bool loaded=false;
static uint32_t output_rate,skip_frames;
static uint64_t output_position,sample_counter,queue_base;
static std::deque<std::array<float,2>>pcm;
static std::string error_text,device_text,stats_text;
static uint32_t r32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static void receive_sample(float l,float r){if(sample_counter>=skip_frames)pcm.push_back({l,r});sample_counter++;}
static void ensure_sample(uint64_t index){while(queue_base+pcm.size()<=index){uint64_t absolute=uint64_t(skip_frames)+queue_base+pcm.size();original.advance((absolute+1)*64);}}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_e6m_close(){loaded=false;pcm.clear();output_position=sample_counter=queue_base=0;original.output=[](float,float){};original.cpu.reset();original.program.clear();original.rom0.clear();original.rom3.clear();}
API const char*gremlin_e6m_error(){return error_text.c_str();}
API const char*gremlin_e6m_devices(){return device_text.c_str();}
API const char*gremlin_e6m_stats(){char b[600];snprintf(b,sizeof(b),"{\"cpu_cycles\":%llu,\"cpu_pc\":%u,\"reads\":%llu,\"writes\":%llu,\"rate_changes\":%llu,\"unknown_reads\":%llu,\"unknown_writes\":%llu}",original.elapsed,original.cpu?original.cpu->m_pc.w:0,original.reads,original.writes,original.rate_changes,original.unmapped_reads,original.unmapped_writes);stats_text=b;return stats_text.c_str();}
API int gremlin_e6m_load(const uint8_t*b,uint32_t length,uint32_t rate,uint32_t command){
 gremlin_e6m_close();error_text.clear();device_text.clear();
 try{
  if(!b||length<160||memcmp(b,"E6M\x1a",4)||r32(b+4)!=1)throw std::runtime_error("Invalid E6M1 header");
  if(r32(b+8)!=2||r32(b+12)!=2000000||r32(b+16)!=16000000||r32(b+20)!=31250||r32(b+24)!=262144||r32(b+28)!=2097152||r32(b+32)!=524288||r32(b+40)!=160||r32(b+44)!=4000000||rate<8000||rate>192000)throw std::runtime_error("Unsupported original ITech32 rev2 profile");
  uint32_t count=r32(b+36),po=r32(b+48),ao=r32(b+52),bo=r32(b+56),tail=r32(b+60);uint64_t expected=160+uint64_t(count)*16;
  if(!count||count>256||po!=expected||ao!=uint64_t(po)+262144||bo!=uint64_t(ao)+2097152||tail!=uint64_t(bo)+524288||tail!=length)throw std::runtime_error("Invalid E6M original region bounds");
  auto ph=Mednafen::sha256(b+po,262144),ah=Mednafen::sha256(b+ao,2097152),bh=Mednafen::sha256(b+bo,524288);if(memcmp(ph.data(),b+64,32)||memcmp(ah.data(),b+96,32)||memcmp(bh.data(),b+128,32))throw std::runtime_error("Original audio-region SHA256 differs");
  uint32_t extra_frames=0;bool seen[256]={},selected=false;for(unsigned i=0;i<count;i++){const auto*p=b+160+i*16;unsigned id=r32(p);if(id>255||seen[id])throw std::runtime_error("Duplicate or invalid E6M command");seen[id]=true;if(r32(p+4)>3750000)throw std::runtime_error("E6M silent pre-roll exceeds profile limit");for(unsigned j=8;j<16;j++)if(p[j])throw std::runtime_error("Unsupported E6M command flags");if(id==command){selected=true;extra_frames=r32(p+4);}}
  if(!selected)throw std::runtime_error("Original E6M music command absent");
  skip_frames=62500+extra_frames;output_rate=rate;original.open(std::vector<u8>(b+po,b+ao),std::vector<u8>(b+ao,b+bo),std::vector<u8>(b+bo,b+tail),command);original.output=receive_sample;original.advance(uint64_t(skip_frames)*64);loaded=true;
  device_text="[{\"type\":\"es5506\",\"clock_hz\":16000000,\"internal_sample_rate\":31250,\"original_sound_cpu\":\"MC6809E@2000000\",\"core\":\"pinned MAME methods\",\"stereo\":\"original ITech32 swapped L/R x1.6\",\"game_rom_or_bios_dependency\":false}]";return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_e6m_close();return 1;}
}
API uint32_t gremlin_e6m_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;
 try{
  for(unsigned i=0;i<frames;i++,output_position++){
   uint64_t numerator=output_position*31250,at=numerator/output_rate;uint32_t remainder=numerator%output_rate;ensure_sample(at+1);size_t q=size_t(at-queue_base);
   for(unsigned c=0;c<2;c++){double a=pcm[q][c],b=pcm[q+1][c];out[i*2+c]=float((a+(b-a)*double(remainder)/output_rate));}
   while(queue_base<at){pcm.pop_front();queue_base++;}
  }
  return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_e6m_close();return 0;}
}
}
