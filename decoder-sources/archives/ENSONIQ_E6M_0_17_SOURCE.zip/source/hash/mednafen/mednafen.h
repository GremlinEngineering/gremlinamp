#pragma once
#include <cstdint>
#include <cstring>
#include <array>
#include <algorithm>
#include <type_traits>
#include <cassert>
using uint8=uint8_t;using uint32=uint32_t;using uint64=uint64_t;
#define INLINE inline
inline uint32 MDFN_de32msb(const void*p){const auto*b=(const uint8*)p;return uint32(b[0])<<24|uint32(b[1])<<16|uint32(b[2])<<8|b[3];}
inline void MDFN_en32msb(void*p,uint32 v){auto*b=(uint8*)p;for(int i=3;i>=0;i--){b[i]=v;v>>=8;}}
inline void MDFN_en64msb(void*p,uint64 v){auto*b=(uint8*)p;for(int i=7;i>=0;i--){b[i]=v;v>>=8;}}
template<class T,bool aligned=false>inline void MDFN_enlsb(void*p,T v){auto*b=(uint8*)p;for(unsigned i=0;i<sizeof(T);i++){b[i]=v;v>>=8;}}
