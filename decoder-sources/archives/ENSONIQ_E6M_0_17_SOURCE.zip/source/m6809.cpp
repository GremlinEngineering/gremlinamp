#include "es5506.h"
#include "m6809.h"
#include "m6809inl.h"
m6809_base_device::m6809_base_device(Bus*bus):m_mintf(bus),m_pc{},m_ppc{},m_q{},m_x{},m_y{},m_u{},m_s{},m_dp(0),m_cc(0),m_temp{},m_opcode(0),m_reg8(nullptr),m_reg16(nullptr),m_reg(0),m_nmi_line(false),m_nmi_asserted(false),m_firq_line(false),m_irq_line(false),m_lds_encountered(false),m_icount(0),m_addressing_mode(0),m_ea{},m_state(0),m_cond(false),m_free_run(false),m_clock_divider(1){device_reset();}
void m6809_base_device::device_reset()
{
	m_nmi_asserted = false;
	m_lds_encountered = false;
	m_free_run = false;

	m_dp = 0x00;        // reset direct page register

	m_cc |= CC_I;       // IRQ disabled
	m_cc |= CC_F;       // FIRQ disabled

	set_ea(VECTOR_RESET_FFFE);

	// reset sub-instruction state
	reset_state();
}

void m6809_base_device::execute_set_input(int inputnum, int state)
{
	LOGMASKED(LOG_INTERRUPTS, "%s: inputnum=%s state=%d totalcycles=%d\n", machine().describe_context(), inputnum_string(inputnum), state, attotime_to_clocks(machine().time()));

	switch(inputnum)
	{
		case INPUT_LINE_NMI:
			// NMI is edge triggered
			m_nmi_asserted = m_nmi_asserted || ((state != CLEAR_LINE) && !m_nmi_line && m_lds_encountered);
			m_nmi_line = (state != CLEAR_LINE);
			break;

		case M6809_FIRQ_LINE:
			// FIRQ is line triggered
			m_firq_line = (state != CLEAR_LINE);
			break;

		case M6809_IRQ_LINE:
			// IRQ is line triggered
			m_irq_line = (state != CLEAR_LINE);
			break;
	}
}

const char *m6809_base_device::inputnum_string(int inputnum)
{
	switch(inputnum)
	{
		case INPUT_LINE_NMI:    return "NMI";
		case M6809_FIRQ_LINE:   return "FIRQ";
		case M6809_IRQ_LINE:    return "IRQ";
		default:                return "???";
	}
}

uint16_t m6809_base_device::read_tfr_exg_816_register(uint8_t reg)
{
	uint16_t result;

	switch(reg & 0x0F)
	{
		case  0: result = m_q.r.d;   break;  // D
		case  1: result = m_x.w;     break;  // X
		case  2: result = m_y.w;     break;  // Y
		case  3: result = m_u.w;     break;  // U
		case  4: result = m_s.w;     break;  // S
		case  5: result = m_pc.w;    break;  // PC
		case  8: result = ((uint16_t)0xff00) | m_q.r.a;   break;  // A
		case  9: result = ((uint16_t)0xff00) | m_q.r.b;   break;  // B
		case 10: result = ((uint16_t)m_cc) << 8 | m_cc;   break;  // CC
		case 11: result = ((uint16_t)m_dp) << 8 | m_dp;   break;  // DP
		default: result = 0xffff; break;
	}

	return result;
}

uint16_t m6809_base_device::read_exg_168_register(uint8_t reg)
{
	uint16_t result;

	switch(reg & 0x0F)
	{
		case  0: result = m_q.r.d;   break;  // D
		case  1: result = m_x.w;     break;  // X
		case  2: result = m_y.w;     break;  // Y
		case  3: result = m_u.w;     break;  // U
		case  4: result = m_s.w;     break;  // S
		case  5: result = m_pc.w;    break;  // PC
		case  8: result = ((uint16_t)0xff00) | m_q.r.a;   break;  // A
		case  9: result = ((uint16_t)0xff00) | m_q.r.b;   break;  // B
		case 10: result = ((uint16_t)0xff00) | m_cc;   break;  // CC
		case 11: result = ((uint16_t)0xff00) | m_dp;   break;  // DP
		default: result = 0xffff; break;
	}

	return result;
}

void m6809_base_device::write_exgtfr_register(uint8_t reg, uint16_t value)
{
	switch(reg & 0x0F)
	{
		case  0: m_q.r.d = value;    break;  // D
		case  1: m_x.w   = value;    break;  // X
		case  2: m_y.w   = value;    break;  // Y
		case  3: m_u.w   = value;    break;  // U
		case  4: m_s.w   = value;    break;  // S
		case  5: m_pc.w  = value;    break;  // PC
		case  8: m_q.r.a = (uint8_t)value; break;  // A
		case  9: m_q.r.b = (uint8_t)value; break;  // B
		case 10: m_cc    = (uint8_t)value; break;  // CC
		case 11: m_dp    = (uint8_t)value; break;  // DP
	}
}

void m6809_base_device::log_illegal()
{
	logerror("%s: illegal opcode at %04x\n", machine().describe_context(), (unsigned) m_pc.w);
}

void m6809_base_device::execute_one()
{
	switch(pop_state())
	{
#include "m6809.hxx"
	}
}

void m6809_base_device::execute_run()
{
	do
	{
		execute_one();
	} while(m_icount > 0);
}
