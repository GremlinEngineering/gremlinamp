// license:BSD-3-Clause; copyright-holders:Nathan Woods
// Framework shim; pinned MAME instruction/microstate methods remain unchanged.
#pragma once
#include <cstdint>
#include <functional>
#include <cassert>
#include <stdexcept>
#include <limits>
#include <type_traits>
#define LSB_FIRST 1
#define BIT(x,n) (((x)>>(n))&1)
#define UNEXPECTED(x) (x)
#define ATTR_FORCE_INLINE
#define ASSERT_LINE 1
#define CLEAR_LINE 0
#define INPUT_LINE_NMI 2
#define M6809_IRQ_LINE 0
#define M6809_FIRQ_LINE 1
#define LOGMASKED(...) ((void)0)
#define logerror(...) ((void)0)
#define fatalerror(...) throw std::runtime_error("6809 invalid internal state")
union PAIR16 { uint16_t w;struct { uint8_t l,h; }b; };
class m6809_base_device
{
public:
 struct Bus { std::function<uint8_t(uint16_t)> read;std::function<void(uint16_t,uint8_t)> write;uint8_t read_opcode(uint16_t a){return read(a);}uint8_t read_opcode_arg(uint16_t a){return read(a);} };
 explicit m6809_base_device(Bus* bus);
 void device_reset();void execute_set_input(int inputnum,int state);void execute_run();
 int run(int n){m_icount=n;execute_run();return n-m_icount;}int remaining()const{return m_icount;}
 bool is_6809(){return true;}
 void debugger_instruction_hook(unsigned){}void debugger_wait_hook(){}void debugger_exception_hook(int){}void standard_irq_callback(int,unsigned){}
	// addressing modes
	enum
	{
		ADDRESSING_MODE_IMMEDIATE   = 0,
		ADDRESSING_MODE_EA          = 1,
		ADDRESSING_MODE_REGISTER_A  = 2,
		ADDRESSING_MODE_REGISTER_B  = 3,
		ADDRESSING_MODE_REGISTER_D  = 4
	};

	// flag bits in the cc register
	enum
	{
		CC_C        = 0x01,         // Carry
		CC_V        = 0x02,         // Overflow
		CC_Z        = 0x04,         // Zero
		CC_N        = 0x08,         // Negative
		CC_I        = 0x10,         // Inhibit IRQ
		CC_H        = 0x20,         // Half (auxiliary) carry
		CC_F        = 0x40,         // Inhibit FIRQ
		CC_E        = 0x80          // Entire state pushed
	};

	// flag combinations
	enum
	{
		CC_VC   = CC_V | CC_C,
		CC_ZC   = CC_Z | CC_C,
		CC_NZ   = CC_N | CC_Z,
		CC_NZC  = CC_N | CC_Z | CC_C,
		CC_NZV  = CC_N | CC_Z | CC_V,
		CC_NZVC = CC_N | CC_Z | CC_V | CC_C,
		CC_HNZVC = CC_H | CC_N | CC_Z | CC_V | CC_C
	};

	// interrupt vectors
	enum
	{
		VECTOR_SWI3         = 0xFFF2,
		VECTOR_SWI2         = 0xFFF4,
		VECTOR_FIRQ         = 0xFFF6,
		VECTOR_IRQ          = 0xFFF8,
		VECTOR_SWI          = 0xFFFA,
		VECTOR_NMI          = 0xFFFC,
		VECTOR_RESET_FFFE   = 0xFFFE
	};

	// exception numbers for debugger
	enum
	{
		EXCEPTION_SWI   = 1,
		EXCEPTION_SWI2  = 2,
		EXCEPTION_SWI3  = 3,
		EXCEPTION_XFIRQ = 4,
		EXCEPTION_XRES  = 5
	};

	union M6809Q
	{
		#ifdef LSB_FIRST
			union
			{
				struct { uint8_t f, e, b, a; };
				struct { uint16_t w, d; };
			} r;
			struct { PAIR16 w, d; } p;
		#else
			union
			{
				struct { uint8_t a, b, e, f; };
				struct { uint16_t d, w; };
			} r;
			struct { PAIR16 d, w; } p;
		#endif
		uint32_t q;
	};

	// Memory interface
	Bus* m_mintf;

	// CPU registers
	PAIR16                      m_pc;               // program counter
	PAIR16                      m_ppc;              // previous program counter
	M6809Q                      m_q;                // accumulator a and b (plus e and f on 6309)
	PAIR16                      m_x, m_y;           // index registers
	PAIR16                      m_u, m_s;           // stack pointers
	uint8_t                     m_dp;               // direct page register
	uint8_t                     m_cc;
	PAIR16                      m_temp;
	uint8_t                     m_opcode;

	// other internal state
	uint8_t *                   m_reg8;
	PAIR16 *                    m_reg16;
	int                         m_reg;
	bool                        m_nmi_line;
	bool                        m_nmi_asserted;
	bool                        m_firq_line;
	bool                        m_irq_line;
	bool                        m_lds_encountered;
	int                         m_icount;
	int                         m_addressing_mode;
	PAIR16                      m_ea;                 // effective address

	// Callbacks
	Callback            m_lic_func;           // LIC pin on the 6809E
	Callback                 m_vector_read_func;   // Indicates interrupt/reset acknowledge cycle (BA=0, BS=1)
	Callback            m_syncack_write_func; // Indicates sync acknowledge buscycle

	// eat cycles
	inline void eat(int cycles)                              { m_icount -= cycles; }
	void eat_remaining();

	// read a byte from given memory location
	inline uint8_t read_memory(uint16_t address)             { eat(1); return m_mintf->read(address); }

	// write a byte to given memory location
	inline void write_memory(uint16_t address, uint8_t data) { eat(1); m_mintf->write(address, data); }

	// read_opcode() is like read_memory() except it is used for reading opcodes. In  the case of a system
	// with memory mapped I/O, this function can be used  to greatly speed up emulation.
	inline uint8_t read_opcode(uint16_t address)             { eat(1); return m_mintf->read_opcode(address); }

	// read_opcode_arg() is identical to read_opcode() except it is used for reading opcode  arguments. This
	// difference can be used to support systems that use different encoding mechanisms for opcodes
	// and opcode arguments.
	inline uint8_t read_opcode_arg(uint16_t address)         { eat(1); return m_mintf->read_opcode_arg(address); }

	// read_opcode() and bump the program counter
	inline uint8_t read_opcode()                             { return read_opcode(m_pc.w++); }
	inline uint8_t read_opcode_arg()                         { return read_opcode_arg(m_pc.w++); }
	inline void dummy_read_opcode_arg(uint16_t delta)        { read_opcode_arg(m_pc.w + delta); }
	inline void dummy_vma(int count)                         { for(int i=0; i != count; i++) { read_opcode_arg(0xffff); } }

	// state stack - implemented as a uint32_t
	void push_state(uint16_t state)                 { m_state = (m_state << 9) | state; }
	uint16_t pop_state()                            { uint16_t result = m_state & 0x1ff; m_state >>= 9; return result; }
	void reset_state()                              { m_state = 1; }

	// effective address reading/writing
	uint8_t read_ea()                               { return read_memory(m_ea.w); }
	void write_ea(uint8_t data)                     { write_memory(m_ea.w, data); }
	void set_ea(uint16_t ea)                        { m_ea.w = ea; m_addressing_mode = ADDRESSING_MODE_EA; }
	void set_ea_h(uint8_t ea_h)                     { m_ea.b.h = ea_h; }
	void set_ea_l(uint8_t ea_l)                     { m_ea.b.l = ea_l; m_addressing_mode = ADDRESSING_MODE_EA; }

	// operand reading/writing
	uint8_t read_operand();
	uint8_t read_operand(int ordinal);
	uint8_t read_vector(int ordinal);
	void write_operand(uint8_t data);
	void write_operand(int ordinal, uint8_t data);

	// instructions
	void daa();
	void mul();

	// miscellaneous
	void nop()                                      { }
	template<class T> T rotate_right(T value);
	template<class T> uint32_t rotate_left(T value);
	void set_a()                                    { m_addressing_mode = ADDRESSING_MODE_REGISTER_A; }
	void set_b()                                    { m_addressing_mode = ADDRESSING_MODE_REGISTER_B; }
	void set_d()                                    { m_addressing_mode = ADDRESSING_MODE_REGISTER_D; }
	void set_imm()                                  { m_addressing_mode = ADDRESSING_MODE_IMMEDIATE; }
	void set_regop8(uint8_t &reg)                   { m_reg8 = &reg; m_reg16 = nullptr; }
	void set_regop16(PAIR16 &reg)                   { m_reg16 = &reg; m_reg8 = nullptr; }
	uint8_t &regop8()                               { assert(m_reg8 != nullptr); return *m_reg8; }
	PAIR16 &regop16()                               { assert(m_reg16 != nullptr); return *m_reg16; }
	bool is_register_register_op_16_bit()           { return m_reg16 != nullptr; }
	bool add8_sets_h()                              { return true; }
	virtual bool hd6309_native_mode()               { return false; }

	// index reg
	uint16_t &ireg();

	// flags
	template<class T> T set_flags(uint8_t mask, T a, T b, uint32_t r);
	template<class T> T set_flags(uint8_t mask, T r);

	// branch conditions
	inline bool cond_hi() { return !(m_cc & CC_ZC); }                                                // BHI/BLS
	inline bool cond_cc() { return !(m_cc & CC_C); }                                                 // BCC/BCS
	inline bool cond_ne() { return !(m_cc & CC_Z); }                                                 // BNE/BEQ
	inline bool cond_vc() { return !(m_cc & CC_V); }                                                 // BVC/BVS
	inline bool cond_pl() { return !(m_cc & CC_N); }                                                 // BPL/BMI
	inline bool cond_ge() { return (m_cc & CC_N ? true : false) == (m_cc & CC_V ? true : false); }   // BGE/BLT
	inline bool cond_gt() { return cond_ge() && !(m_cc & CC_Z); }                                    // BGT/BLE
	inline void set_cond(bool cond)  { m_cond = cond; }
	inline bool branch_taken()       { return m_cond; }

	// interrupt registers
	bool firq_saves_entire_state()      { return false; }
	uint16_t partial_state_registers()  { return 0x81; }
	uint16_t entire_state_registers()   { return 0xFF; }

	// miscellaneous
	inline uint16_t read_tfr_exg_816_register(uint8_t reg);
	inline uint16_t read_exg_168_register(uint8_t reg);
	inline void write_exgtfr_register(uint8_t reg, uint16_t value);
	bool is_register_addressing_mode();
	bool is_ea_addressing_mode() { return m_addressing_mode == ADDRESSING_MODE_EA; }
	uint16_t get_pending_interrupt();
	void log_illegal();

public:
	// other state
	uint32_t                    m_state;
	bool                        m_cond;
	bool                        m_free_run;

	// incidentals
	int                         m_clock_divider;

	// functions
	inline void execute_one();
	const char *inputnum_string(int inputnum);
};

