#include "es5506.h"
static constexpr u32 FINE_FILTER_BIT = 16;
static constexpr u32 FILTER_BIT      = 12;
static constexpr u32 FILTER_SHIFT    = FINE_FILTER_BIT - FILTER_BIT;

static constexpr u32 ULAW_MAXBITS        = 8;

namespace {

enum : u16 {
	CONTROL_BS1         = 0x8000,
	CONTROL_BS0         = 0x4000,
	CONTROL_CMPD        = 0x2000,
	CONTROL_CA2         = 0x1000,
	CONTROL_CA1         = 0x0800,
	CONTROL_CA0         = 0x0400,
	CONTROL_LP4         = 0x0200,
	CONTROL_LP3         = 0x0100,
	CONTROL_IRQ         = 0x0080,
	CONTROL_DIR         = 0x0040,
	CONTROL_IRQE        = 0x0020,
	CONTROL_BLE         = 0x0010,
	CONTROL_LPE         = 0x0008,
	CONTROL_LEI         = 0x0004,
	CONTROL_STOP1       = 0x0002,
	CONTROL_STOP0       = 0x0001,

	CONTROL_BSMASK      = (CONTROL_BS1 | CONTROL_BS0),
	CONTROL_CAMASK      = (CONTROL_CA2 | CONTROL_CA1 | CONTROL_CA0),
	CONTROL_LPMASK      = (CONTROL_LP4 | CONTROL_LP3),
	CONTROL_LOOPMASK    = (CONTROL_BLE | CONTROL_LPE),
	CONTROL_STOPMASK    = (CONTROL_STOP1 | CONTROL_STOP0),

	// ES5505 has sightly different control bit
	CONTROL_5505_LP4    = 0x0800,
	CONTROL_5505_LP3    = 0x0400,
	CONTROL_5505_CA1    = 0x0200,
	CONTROL_5505_CA0    = 0x0100,

	CONTROL_5505_LPMASK = (CONTROL_5505_LP4 | CONTROL_5505_LP3),
	CONTROL_5505_CAMASK = (CONTROL_5505_CA1 | CONTROL_5505_CA0)
};

}


es550x_device::es550x_device():m_stream(nullptr),m_sample_rate(0),m_master_clock(16000000),m_address_acc_shift(0),m_address_acc_mask(0),m_volume_shift(0),m_volume_acc_shift(0),m_current_page(0),m_active_voices(31),m_mode(0x17),m_irqv(0x80),m_voice_index(0),m_channels(1){}
es5506_device::es5506_device():m_write_latch(0),m_read_latch(0),m_wst(0),m_wend(0),m_lrend(0){m_stream=&stream;compute_tables(16,4,8);get_accum_mask(21,11);m_sample_rate=31250;}
static inline s32 apply_lowpass(s32 out, s32 cutoff, s32 in)
{
	return ((s32)(cutoff >> FILTER_SHIFT) * (out - in) / (1 << FILTER_BIT)) + in;
}

static inline s32 apply_highpass(s32 out, s32 cutoff, s32 in, s32 prev)
{
	return out - prev + ((s32)(cutoff >> FILTER_SHIFT) * in) / (1 << (FILTER_BIT + 1)) + in / 2;
}

// update poles from outputs
static inline void update_pole(s32 &pole, s32 sample)
{
	pole = sample;
}

static inline void update_2_pole(s32 &prev, s32 &pole, s32 sample)
{
	prev = pole;
	pole = sample;
}

void es550x_device::update_irq_state()
{
	// ES5505/6 irq line has been set high - inform the host
	m_irq_cb(1); // IRQB set high
}

void es550x_device::update_internal_irq_state()
{
	/*  Host (cpu) has just read the voice interrupt vector (voice IRQ ack).

	    Reset the voice vector to show the IRQB line is low (top bit set).
	    If we have any stacked interrupts (other voices waiting to be
	    processed - with their IRQ bit set) then they will be moved into
	    the vector next time the voice is processed.  In emulation
	    terms they get updated next time generate_samples() is called.
	*/

	m_irqv = 0x80;

	m_irq_cb(0); // IRQB set low
}

void es550x_device::compute_tables(u32 total_volume_bit, u32 exponent_bit, u32 mantissa_bit)
{
	// allocate ulaw lookup table
	m_ulaw_lookup.resize(1 << ULAW_MAXBITS);

	// generate ulaw lookup table
	for (int i = 0; i < (1 << ULAW_MAXBITS); i++)
	{
		const u16 rawval = (i << (16 - ULAW_MAXBITS)) | (1 << (15 - ULAW_MAXBITS));
		const u8 exponent = rawval >> 13;
		u32 mantissa = (rawval << 3) & 0xffff;

		if (exponent == 0)
			m_ulaw_lookup[i] = s16(mantissa) >> 7;
		else
		{
			mantissa = (mantissa >> 1) | (~mantissa & 0x8000);
			m_ulaw_lookup[i] = s16(mantissa) >> (7 - exponent);
		}
	}

	const u32 volume_bit = (exponent_bit + mantissa_bit);
	m_volume_shift = total_volume_bit - volume_bit;
	const u32 volume_len = 1 << volume_bit;
	// allocate volume lookup table
	m_volume_lookup.resize(volume_len);

	// generate volume lookup table
	const u32 exponent_shift = 1 << exponent_bit;
	const u32 exponent_mask = exponent_shift - 1;

	const u32 mantissa_len = (1 << mantissa_bit);
	const u32 mantissa_mask = (mantissa_len - 1);
	const u32 mantissa_shift = exponent_shift - mantissa_bit - 1;

	for (int i = 0; i < volume_len; i++)
	{
		const u32 exponent = (i >> mantissa_bit) & exponent_mask;
		const u32 mantissa = (i & mantissa_mask) | mantissa_len;

		m_volume_lookup[i] = (mantissa << mantissa_shift) >> (exponent_shift - exponent);
	}
	m_volume_acc_shift = (16 + exponent_mask) - VOLUME_ACC_BIT;

	// init the voices
	for (int j = 0; j < 32; j++)
	{
		m_voice[j].index = j;
		m_voice[j].control = CONTROL_STOPMASK;
		m_voice[j].lvol = (1 << (total_volume_bit - 1));
		m_voice[j].rvol = (1 << (total_volume_bit - 1));
	}
}

void es550x_device::get_accum_mask(u32 address_integer, u32 address_frac)
{
	m_address_acc_shift = ADDRESS_FRAC_BIT - address_frac;
	m_address_acc_mask = lshift_signed<u64, s8>(((((1 << address_integer) - 1) << address_frac) | ((1 << address_frac) - 1)), m_address_acc_shift);
	if (m_address_acc_shift > 0)
		m_address_acc_mask |= ((1 << m_address_acc_shift) - 1);
}

inline s32 es550x_device::interpolate(s32 sample1, s32 sample2, u64 accum)
{
	const u32 shifted = 1 << ADDRESS_FRAC_BIT;
	const u32 mask = shifted - 1;
	accum &= mask & m_address_acc_mask;
	return (sample1 * (s32)(shifted - accum) +
			sample2 * (s32)(accum)) >> ADDRESS_FRAC_BIT;
}

inline void es550x_device::apply_filters(es550x_voice *voice, s32 &sample)
{
	// pole 1 is always low-pass using K1
	sample = apply_lowpass(sample, voice->k1, voice->o1n1);
	update_pole(voice->o1n1, sample);

	// pole 2 is always low-pass using K1
	sample = apply_lowpass(sample, voice->k1, voice->o2n1);
	update_2_pole(voice->o2n2, voice->o2n1, sample);

	// remaining poles depend on the current filter setting
	switch (get_lp(voice->control))
	{
		case 0:
			// pole 3 is high-pass using K2
			sample = apply_highpass(sample, voice->k2, voice->o3n1, voice->o2n2);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is high-pass using K2
			sample = apply_highpass(sample, voice->k2, voice->o4n1, voice->o3n2);
			update_pole(voice->o4n1, sample);
			break;

		case LP3:
			// pole 3 is low-pass using K1
			sample = apply_lowpass(sample, voice->k1, voice->o3n1);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is high-pass using K2
			sample = apply_highpass(sample, voice->k2, voice->o4n1, voice->o3n2);
			update_pole(voice->o4n1, sample);
			break;

		case LP4:
			// pole 3 is low-pass using K2
			sample = apply_lowpass(sample, voice->k2, voice->o3n1);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is low-pass using K2
			sample = apply_lowpass(sample, voice->k2, voice->o4n1);
			update_pole(voice->o4n1, sample);
			break;

		case LP3 | LP4:
			// pole 3 is low-pass using K1
			sample = apply_lowpass(sample, voice->k1, voice->o3n1);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is low-pass using K2
			sample = apply_lowpass(sample, voice->k2, voice->o4n1);
			update_pole(voice->o4n1, sample);
			break;
	}
}

void es550x_device::generate_ulaw(es550x_voice *voice, s32 *dest)
{
	const u32 freqcount = voice->freqcount;
	u64 accum = voice->accum & m_address_acc_mask;

	// outer loop, in case we switch directions
	if (!(voice->control & CONTROL_STOPMASK))
	{
		// two cases: first case is forward direction
		if (!(voice->control & CONTROL_DIR))
		{
			// fetch two samples
			s32 val1 = read_sample(voice, get_integer_addr(accum));
			s32 val2 = read_sample(voice, get_integer_addr(accum, 1));

			// decompress u-law
			val1 = m_ulaw_lookup[val1 >> (16 - ULAW_MAXBITS)];
			val2 = m_ulaw_lookup[val2 >> (16 - ULAW_MAXBITS)];

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum + freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_forward(voice, accum);
		}

		// two cases: second case is backward direction
		else
		{
			// fetch two samples
			s32 val1 = read_sample(voice, get_integer_addr(accum));
			s32 val2 = read_sample(voice, get_integer_addr(accum, 1));

			// decompress u-law
			val1 = m_ulaw_lookup[val1 >> (16 - ULAW_MAXBITS)];
			val2 = m_ulaw_lookup[val2 >> (16 - ULAW_MAXBITS)];

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum - freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_reverse(voice, accum);
		}
	}
	else
	{
		// if we stopped, process any additional envelope
		if (voice->ecount != 0)
			update_envelopes(voice);
	}

	voice->accum = accum;
}

void es550x_device::generate_pcm(es550x_voice *voice, s32 *dest)
{
	const u32 freqcount = voice->freqcount;
	u64 accum = voice->accum & m_address_acc_mask;

	// outer loop, in case we switch directions
	if (!(voice->control & CONTROL_STOPMASK))
	{
		// two cases: first case is forward direction
		if (!(voice->control & CONTROL_DIR))
		{
			// fetch two samples
			s32 val1 = (s16)read_sample(voice, get_integer_addr(accum));
			s32 val2 = (s16)read_sample(voice, get_integer_addr(accum, 1));

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum + freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_forward(voice, accum);
		}

		// two cases: second case is backward direction
		else
		{
			// fetch two samples
			s32 val1 = (s16)read_sample(voice, get_integer_addr(accum));
			s32 val2 = (s16)read_sample(voice, get_integer_addr(accum, 1));

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum - freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_reverse(voice, accum);
		}
	}
	else
	{
		// if we stopped, process any additional envelope
		if (voice->ecount != 0)
			update_envelopes(voice);
	}

	voice->accum = accum;
}

inline void es550x_device::generate_irq(es550x_voice *voice, int v)
{
	// does this voice have it's IRQ bit raised?
	if (voice->control & CONTROL_IRQ)
	{
		LOG("es5506: IRQ raised on voice %d!!\n",v);

		// only update voice vector if existing IRQ is acked by host
		if (m_irqv & 0x80)
		{
			// latch voice number into vector, and set high bit low
			m_irqv = v & 0x1f;

			// take down IRQ bit on voice
			voice->control &= ~CONTROL_IRQ;

			// inform host of irq
			update_irq_state();
		}
	}
}

inline void es5506_device::update_envelopes(es550x_voice *voice)
{
	const u32 volume_max = (1 << VOLUME_BIT_ES5506) - 1;
	// decrement the envelope counter
	voice->ecount--;

	// ramp left volume
	if (voice->lvramp)
	{
		voice->lvol += (int8_t)voice->lvramp;
		if ((s32)voice->lvol < 0) voice->lvol = 0;
		else if (voice->lvol > volume_max) voice->lvol = volume_max;
	}

	// ramp right volume
	if (voice->rvramp)
	{
		voice->rvol += (int8_t)voice->rvramp;
		if ((s32)voice->rvol < 0) voice->rvol = 0;
		else if (voice->rvol > volume_max) voice->rvol = volume_max;
	}

	// ramp k1 filter constant
	if (voice->k1ramp && ((s32)voice->k1ramp >= 0 || !(voice->filtcount & 7)))
	{
		voice->k1 += (int8_t)voice->k1ramp;
		if ((s32)voice->k1 < 0) voice->k1 = 0;
		else if (voice->k1 > 0xffff) voice->k1 = 0xffff;
	}

	// ramp k2 filter constant
	if (voice->k2ramp && ((s32)voice->k2ramp >= 0 || !(voice->filtcount & 7)))
	{
		voice->k2 += (int8_t)voice->k2ramp;
		if ((s32)voice->k2 < 0) voice->k2 = 0;
		else if (voice->k2 > 0xffff) voice->k2 = 0xffff;
	}

	// update the filter constant counter
	voice->filtcount++;

}

inline void es5506_device::check_for_end_forward(es550x_voice *voice, u64 &accum)
{
	// are we past the end?
	if (accum > voice->end && !(voice->control & CONTROL_LEI))
	{
		// generate interrupt if required
		if (voice->control & CONTROL_IRQE)
			voice->control |= CONTROL_IRQ;

		// handle the different types of looping
		switch (voice->control & CONTROL_LOOPMASK)
		{
			// non-looping
			case 0:
				voice->control |= CONTROL_STOP0;
				break;

			// uni-directional looping
			case CONTROL_LPE:
				accum = (voice->start + (accum - voice->end)) & m_address_acc_mask;
				break;

			// trans-wave looping
			case CONTROL_BLE:
				accum = (voice->start + (accum - voice->end)) & m_address_acc_mask;
				voice->control = (voice->control & ~CONTROL_LOOPMASK) | CONTROL_LEI;
				break;

			// bi-directional looping
			case CONTROL_LPE | CONTROL_BLE:
				accum = (voice->end - (accum - voice->end)) & m_address_acc_mask;
				voice->control ^= CONTROL_DIR;
				break;
		}
	}
}

inline void es5506_device::check_for_end_reverse(es550x_voice *voice, u64 &accum)
{
	// are we past the end?
	if (accum < voice->start && !(voice->control & CONTROL_LEI))
	{
		// generate interrupt if required
		if (voice->control & CONTROL_IRQE)
			voice->control |= CONTROL_IRQ;

		// handle the different types of looping
		switch (voice->control & CONTROL_LOOPMASK)
		{
			// non-looping
			case 0:
				voice->control |= CONTROL_STOP0;
				break;

			// uni-directional looping
			case CONTROL_LPE:
				accum = (voice->end - (voice->start - accum)) & m_address_acc_mask;
				break;

			// trans-wave looping
			case CONTROL_BLE:
				accum = (voice->end - (voice->start - accum)) & m_address_acc_mask;
				voice->control = (voice->control & ~CONTROL_LOOPMASK) | CONTROL_LEI;
				break;

			// bi-directional looping
			case CONTROL_LPE | CONTROL_BLE:
				accum = (voice->start + (voice->start - accum)) & m_address_acc_mask;
				voice->control ^= CONTROL_DIR;
				break;
		}
	}
}

void es5506_device::generate_samples(sound_stream &stream)
{
	// loop while we still have samples to generate
	for (int sampindex = 0; sampindex < stream.samples(); sampindex++)
	{
		// loop over voices
		s32 cursample[12] = { 0 };
		for (int v = 0; v <= m_active_voices; v++)
		{
			es550x_voice *voice = &m_voice[v];

			// special case: if end == start, stop the voice
			if (voice->start == voice->end)
				voice->control |= CONTROL_STOP0;

			const int voice_channel = get_ca(voice->control);
			const int channel = voice_channel % m_channels;
			const int l = channel << 1;

			// generate from the appropriate source
			if (voice->control & CONTROL_CMPD)
				generate_ulaw(voice, &cursample[l]);
			else
				generate_pcm(voice, &cursample[l]);

			// does this voice have it's IRQ bit raised?
			generate_irq(voice, v);
		}

		for (int c = 0; c < stream.output_count(); c++)
			// generated samples are 20-bit signed, range is [-2^19 .. 2^19-1]
			stream.put_int_clamp(c, sampindex, cursample[c], (1 << 19));
	}
}

inline void es5506_device::reg_write_low(es550x_voice *voice, offs_t offset, u32 data)
{
	switch (offset)
	{
		case 0x00/8:    // CR
			voice->control = data & 0xffff;
			LOG("voice %d, control=%04x\n", m_current_page & 0x1f, voice->control);
			break;

		case 0x08/8:    // FC
			voice->freqcount = get_address_acc_shifted_val(data & 0x1ffff);
			LOG("voice %d, freq count=%08x\n", m_current_page & 0x1f, get_address_acc_res(voice->freqcount));
			break;

		case 0x10/8:    // LVOL
			voice->lvol = data & 0xffff; // low 4 bit is used for finer envelope control
			LOG("voice %d, left vol=%04x\n", m_current_page & 0x1f, voice->lvol);
			break;

		case 0x18/8:    // LVRAMP
			voice->lvramp = (data & 0xff00) >> 8;
			LOG("voice %d, left vol ramp=%04x\n", m_current_page & 0x1f, voice->lvramp);
			break;

		case 0x20/8:    // RVOL
			voice->rvol = data & 0xffff; // low 4 bit is used for finer envelope control
			LOG("voice %d, right vol=%04x\n", m_current_page & 0x1f, voice->rvol);
			break;

		case 0x28/8:    // RVRAMP
			voice->rvramp = (data & 0xff00) >> 8;
			LOG("voice %d, right vol ramp=%04x\n", m_current_page & 0x1f, voice->rvramp);
			break;

		case 0x30/8:    // ECOUNT
			voice->ecount = data & 0x1ff;
			voice->filtcount = 0;
			LOG("voice %d, envelope count=%04x\n", m_current_page & 0x1f, voice->ecount);
			break;

		case 0x38/8:    // K2
			voice->k2 = data & 0xffff; // low 4 bit is used for finer envelope control
			LOG("voice %d, K2=%04x\n", m_current_page & 0x1f, voice->k2);
			break;

		case 0x40/8:    // K2RAMP
			voice->k2ramp = ((data & 0xff00) >> 8) | ((data & 0x0001) << 31);
			LOG("voice %d, K2 ramp=%04x\n", m_current_page & 0x1f, voice->k2ramp);
			break;

		case 0x48/8:    // K1
			voice->k1 = data & 0xffff; // low 4 bit is used for finer envelope control
			LOG("voice %d, K1=%04x\n", m_current_page & 0x1f, voice->k1);
			break;

		case 0x50/8:    // K1RAMP
			voice->k1ramp = ((data & 0xff00) >> 8) | ((data & 0x0001) << 31);
			LOG("voice %d, K1 ramp=%04x\n", m_current_page & 0x1f, voice->k1ramp);
			break;

		case 0x58/8:    // ACTV
		{
			m_active_voices = data & 0x1f;
			m_sample_rate = m_master_clock / (16 * (m_active_voices + 1));
			m_stream->set_sample_rate(m_sample_rate);
			m_sample_rate_changed_cb(m_sample_rate);

			LOG("active voices=%d, sample_rate=%d\n", m_active_voices, m_sample_rate);
			break;
		}

		case 0x60/8:    // MODE
			// [4:3] = 00 : Single, Master, Early address mode
			// [4:3] = 01 : Single, Master, Normal address mode
			// [4:3] = 10 : Dual, Slave, Normal address mode
			// [4:3] = 11 : Dual, Master, Normal address mode
			m_mode = data & 0x1f; // MODE1[4], MODE0[3], BCLK_EN[2], WCLK_EN[1], LRCLK_EN[0]
			break;

		case 0x68/8:    // PAR - read only
		case 0x70/8:    // IRQV - read only
			break;

		case 0x78/8:    // PAGE
			m_current_page = data & 0x7f;
			break;
	}
}

inline void es5506_device::reg_write_high(es550x_voice *voice, offs_t offset, u32 data)
{
	switch (offset)
	{
		case 0x00/8:    // CR
			voice->control = data & 0xffff;
			LOG("voice %d, control=%04x\n", m_current_page & 0x1f, voice->control);
			break;

		case 0x08/8:    // START
			voice->start = get_address_acc_shifted_val(data & 0xfffff800);
			LOG("voice %d, loop start=%08x\n", m_current_page & 0x1f, get_address_acc_res(voice->start));
			break;

		case 0x10/8:    // END
			voice->end = get_address_acc_shifted_val(data & 0xffffff80);
			LOG("voice %d, loop end=%08x\n", m_current_page & 0x1f, get_address_acc_res(voice->end));
			break;

		case 0x18/8:    // ACCUM
			voice->accum = get_address_acc_shifted_val(data);
			LOG("voice %d, accum=%08x\n", m_current_page & 0x1f, get_address_acc_res(voice->accum));
			break;

		case 0x20/8:    // O4(n-1); TODO: 16.1 signed fixed point according to datasheet
			voice->o4n1 = util::sext(data, 18);
			LOG("voice %d, O4(n-1)=%05x\n", m_current_page & 0x1f, voice->o4n1 & 0x3ffff);
			break;

		case 0x28/8:    // O3(n-1)
			voice->o3n1 = util::sext(data, 18);
			LOG("voice %d, O3(n-1)=%05x\n", m_current_page & 0x1f, voice->o3n1 & 0x3ffff);
			break;

		case 0x30/8:    // O3(n-2)
			voice->o3n2 = util::sext(data, 18);
			LOG("voice %d, O3(n-2)=%05x\n", m_current_page & 0x1f, voice->o3n2 & 0x3ffff);
			break;

		case 0x38/8:    // O2(n-1)
			voice->o2n1 = util::sext(data, 18);
			LOG("voice %d, O2(n-1)=%05x\n", m_current_page & 0x1f, voice->o2n1 & 0x3ffff);
			break;

		case 0x40/8:    // O2(n-2)
			voice->o2n2 = util::sext(data, 18);
			LOG("voice %d, O2(n-2)=%05x\n", m_current_page & 0x1f, voice->o2n2 & 0x3ffff);
			break;

		case 0x48/8:    // O1(n-1)
			voice->o1n1 = util::sext(data, 18);
			LOG("voice %d, O1(n-1)=%05x\n", m_current_page & 0x1f, voice->o1n1 & 0x3ffff);
			break;

		case 0x50/8:    // W_ST
			m_wst = data & 0x7f;
			LOGMASKED(LOG_SERIAL, "%s: word clock start = %02x\n", machine().describe_context(), m_wst);
			break;

		case 0x58/8:    // W_END
			m_wend = data & 0x7f;
			LOGMASKED(LOG_SERIAL, "%s: word clock end = %02x\n", machine().describe_context(), m_wend);
			break;

		case 0x60/8:    // LR_END
			m_lrend = data & 0x7f;
			LOGMASKED(LOG_SERIAL, "%s: left/right clock end = %02x\n", machine().describe_context(), m_lrend);
			break;

		case 0x68/8:    // PAR - read only
		case 0x70/8:    // IRQV - read only
			break;

		case 0x78/8:    // PAGE
			m_current_page = data & 0x7f;
			break;
	}
}

inline void es5506_device::reg_write_test(es550x_voice *voice, offs_t offset, u32 data)
{
	switch (offset)
	{
		case 0x00/8:    // CHANNEL 0 LEFT
			LOG("Channel 0 left test write %08x\n", data);
			break;

		case 0x08/8:    // CHANNEL 0 RIGHT
			LOG("Channel 0 right test write %08x\n", data);
			break;

		case 0x10/8:    // CHANNEL 1 LEFT
			LOG("Channel 1 left test write %08x\n", data);
			break;

		case 0x18/8:    // CHANNEL 1 RIGHT
			LOG("Channel 1 right test write %08x\n", data);
			break;

		case 0x20/8:    // CHANNEL 2 LEFT
			LOG("Channel 2 left test write %08x\n", data);
			break;

		case 0x28/8:    // CHANNEL 2 RIGHT
			LOG("Channel 2 right test write %08x\n", data);
			break;

		case 0x30/8:    // CHANNEL 3 LEFT
			LOG("Channel 3 left test write %08x\n", data);
			break;

		case 0x38/8:    // CHANNEL 3 RIGHT
			LOG("Channel 3 right test write %08x\n", data);
			break;

		case 0x40/8:    // CHANNEL 4 LEFT
			LOG("Channel 4 left test write %08x\n", data);
			break;

		case 0x48/8:    // CHANNEL 4 RIGHT
			LOG("Channel 4 right test write %08x\n", data);
			break;

		case 0x50/8:    // CHANNEL 5 LEFT
			LOG("Channel 5 left test write %08x\n", data);
			break;

		case 0x58/8:    // CHANNEL 6 RIGHT
			LOG("Channel 5 right test write %08x\n", data);
			break;

		case 0x60/8:    // EMPTY
			LOG("Test write EMPTY %08x\n", data);
			break;

		case 0x68/8:    // PAR - read only
		case 0x70/8:    // IRQV - read only
			break;

		case 0x78/8:    // PAGE
			m_current_page = data & 0x7f;
			break;
	}
}

void es5506_device::write(offs_t offset, u8 data)
{
	es550x_voice *voice = &m_voice[m_current_page & 0x1f];
	int shift = 8 * (offset & 3);

	// accumulate the data
	m_write_latch = (m_write_latch & ~(0xff000000 >> shift)) | (data << (24 - shift));

	// wait for a write to complete
	if (shift != 24)
		return;

	// force an update
	m_stream->update();

	// switch off the page and register
	if (m_current_page < 0x20)
		reg_write_low(voice, offset / 4, m_write_latch);
	else if (m_current_page < 0x40)
		reg_write_high(voice, offset / 4, m_write_latch);
	else
		reg_write_test(voice, offset / 4, m_write_latch);

	// clear the write latch when done
	m_write_latch = 0;
}

inline u32 es5506_device::reg_read_low(es550x_voice *voice, offs_t offset)
{
	u32 result = 0;

	switch (offset)
	{
		case 0x00/8:    // CR
			result = voice->control;
			break;

		case 0x08/8:    // FC
			result = get_address_acc_res(voice->freqcount);
			break;

		case 0x10/8:    // LVOL
			result = voice->lvol;
			break;

		case 0x18/8:    // LVRAMP
			result = voice->lvramp << 8;
			break;

		case 0x20/8:    // RVOL
			result = voice->rvol;
			break;

		case 0x28/8:    // RVRAMP
			result = voice->rvramp << 8;
			break;

		case 0x30/8:    // ECOUNT
			result = voice->ecount;
			break;

		case 0x38/8:    // K2
			result = voice->k2;
			break;

		case 0x40/8:    // K2RAMP
			result = (voice->k2ramp << 8) | (voice->k2ramp >> 31);
			break;

		case 0x48/8:    // K1
			result = voice->k1;
			break;

		case 0x50/8:    // K1RAMP
			result = (voice->k1ramp << 8) | (voice->k1ramp >> 31);
			break;

		case 0x58/8:    // ACTV
			result = m_active_voices;
			break;

		case 0x60/8:    // MODE
			result = m_mode;
			break;

		case 0x68/8:    // PAR
			if (!m_read_port_cb.isunset())
				result = m_read_port_cb(0) & 0x3ff; // 10 bit, 9:0
			break;

		case 0x70/8:    // IRQV
			result = m_irqv;
			if (!machine().side_effects_disabled())
				update_internal_irq_state();
			break;

		case 0x78/8:    // PAGE
			result = m_current_page;
			break;
	}
	return result;
}

inline u32 es5506_device::reg_read_high(es550x_voice *voice, offs_t offset)
{
	u32 result = 0;

	switch (offset)
	{
		case 0x00/8:    // CR
			result = voice->control;
			break;

		case 0x08/8:    // START
			result = get_address_acc_res(voice->start);
			break;

		case 0x10/8:    // END
			result = get_address_acc_res(voice->end);
			break;

		case 0x18/8:    // ACCUM
			result = get_address_acc_res(voice->accum);
			break;

		case 0x20/8:    // O4(n-1); TODO: 16.1 signed fixed point according to datasheet
			result = voice->o4n1 & 0x3ffff;
			break;

		case 0x28/8:    // O3(n-1)
			result = voice->o3n1 & 0x3ffff;
			break;

		case 0x30/8:    // O3(n-2)
			result = voice->o3n2 & 0x3ffff;
			break;

		case 0x38/8:    // O2(n-1)
			result = voice->o2n1 & 0x3ffff;
			break;

		case 0x40/8:    // O2(n-2)
			result = voice->o2n2 & 0x3ffff;
			break;

		case 0x48/8:    // O1(n-1)
			result = voice->o1n1 & 0x3ffff;
			break;

		case 0x50/8:    // W_ST
			result = m_wst;
			break;

		case 0x58/8:    // W_END
			result = m_wend;
			break;

		case 0x60/8:    // LR_END
			result = m_lrend;
			break;

		case 0x68/8:    // PAR
			if (!m_read_port_cb.isunset())
				result = m_read_port_cb(0) & 0x3ff; // 10 bit, 9:0
			break;

		case 0x70/8:    // IRQV
			result = m_irqv;
			if (!machine().side_effects_disabled())
				update_internal_irq_state();
			break;

		case 0x78/8:    // PAGE
			result = m_current_page;
			break;
	}
	return result;
}

inline u32 es5506_device::reg_read_test(es550x_voice *voice, offs_t offset)
{
	u32 result = 0;

	switch (offset)
	{
		case 0x68/8:    // PAR
			if (!m_read_port_cb.isunset())
				result = m_read_port_cb(0) & 0x3ff; // 10 bit, 9:0
			break;

		case 0x70/8:    // IRQV
			result = m_irqv;
			break;

		case 0x78/8:    // PAGE
			result = m_current_page;
			break;
	}
	return result;
}

u8 es5506_device::read(offs_t offset)
{
	es550x_voice *voice = &m_voice[m_current_page & 0x1f];
	int shift = 8 * (offset & 3);

	// only read on offset 0
	if (shift != 0)
		return m_read_latch >> (24 - shift);

	LOG("read from %02x/%02x -> ", m_current_page, offset / 4 * 8);

	// force an update
	m_stream->update();

	// switch off the page and register
	if (m_current_page < 0x20)
		m_read_latch = reg_read_low(voice, offset / 4);
	else if (m_current_page < 0x40)
		m_read_latch = reg_read_high(voice, offset / 4);
	else
		m_read_latch = reg_read_test(voice, offset / 4);

	LOG("%08x\n", m_read_latch);

	// return the high byte
	return m_read_latch >> 24;
}
