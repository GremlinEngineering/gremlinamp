#pragma once
#include "es5506.h"
#include "m6809.h"
#include <memory>
#include <array>
#include <cstring>
class OriginalSftm {
public:
 es5506_device chip;
 m6809_base_device::Bus bus;
 std::unique_ptr<m6809_base_device> cpu;
 std::vector<u8> program,rom0,rom3;
 std::array<u8,8192>ram{};
 u64 elapsed=0,chip_time=0,next_sample=64,irq_index=1,next_boot=200000,next_cmd=4000000;
 unsigned bank=0,latch=0,boot_index=0,send_index=0,command=0,budget=0;
 u64 reads=0,writes=0,rate_changes=0,unmapped_reads=0,unmapped_writes=0;bool pending=false,executing=false;
 std::function<void(float,float)>output=[](float,float){};
 std::function<void(u64,unsigned,unsigned,unsigned)>trace=[](u64,unsigned,unsigned,unsigned){};
 u64 timestamp()const{return elapsed+(executing?budget-cpu->remaining():0);}
 void chip_advance(u64 target){while(next_sample<=target){float f[2];chip.sample(f);output(f[1]*1.6f,f[0]*1.6f);chip_time=next_sample;next_sample+=chip.period();}}
 u8 read(u16 a){
  if(a==0||a==0x400){pending=false;cpu->execute_set_input(M6809_IRQ_LINE,0);return latch;}
  if((a>=0x800&&a<=0x83f)||(a>=0x880&&a<=0x8bf)){chip_advance(timestamp());u8 v=chip.read(a&63);trace(timestamp(),1,a&63,v);reads++;return v;}
  if(a==0x1800)return pending?128:0;
  if(a>=0x2000&&a<0x4000)return ram[a-0x2000];
  if(a>=0x4000&&a<0x8000)return program[((bank&15)*0x4000+a-0x4000)&0x3ffff];
  if(a>=0x8000)return program[0x38000+a-0x8000];
  unmapped_reads++;return 0;
 }
 void write(u16 a,u8 v){
  if((a>=0x800&&a<=0x83f)||(a>=0x880&&a<=0x8bf)){chip_advance(timestamp());unsigned old=chip.period();trace(timestamp(),0,a&63,v);chip.write(a&63,v);writes++;if(old!=chip.period()){rate_changes++;next_sample=chip_time+chip.period();}return;}
  if(a==0xc00){bank=v;return;}if(a==0x1400){cpu->execute_set_input(M6809_FIRQ_LINE,0);return;}
  if(a>=0x2000&&a<0x4000){ram[a-0x2000]=v;return;}
  if(a!=0x1000&&a!=0x1800&&a!=0x1c00){unmapped_writes++;trace(timestamp(),2,a,v);}
 }
 void open(std::vector<u8>p,std::vector<u8>a,std::vector<u8>b,unsigned cmd){
  cpu.reset();chip.~es5506_device();new(&chip)es5506_device();program=std::move(p);rom0=std::move(a);rom3=std::move(b);chip.set_roms(rom0.data(),rom3.data());ram.fill(0);
  elapsed=chip_time=0;next_sample=64;irq_index=1;next_boot=200000;next_cmd=4000000;bank=latch=boot_index=send_index=budget=0;command=cmd;pending=executing=false;reads=writes=rate_changes=unmapped_reads=unmapped_writes=0;
  bus.read=[this](u16 a){return read(a);};bus.write=[this](u16 a,u8 v){write(a,v);};cpu=std::make_unique<m6809_base_device>(&bus);
 }
 void advance(u64 target){
  static constexpr unsigned boot[]={12,0,0,0,254,0,0,0,254,0,0,0,0,0,0,0,0,0,0,0,253,0,0,0};
  while(elapsed<target){
   if(boot_index<24&&elapsed>=next_boot){latch=boot[boot_index++];pending=true;cpu->execute_set_input(M6809_IRQ_LINE,1);next_boot+=100000;}
   if(send_index<2&&elapsed>=next_cmd){latch=send_index?0:command;send_index++;pending=true;cpu->execute_set_input(M6809_IRQ_LINE,1);next_cmd+=100000;}
   while(elapsed>=irq_index*2000000/240){cpu->execute_set_input(M6809_FIRQ_LINE,1);irq_index++;}
   u64 next=std::min(target,irq_index*2000000/240);if(boot_index<24)next=std::min(next,next_boot);if(send_index<2)next=std::min(next,next_cmd);if(next<=elapsed)continue;
   budget=unsigned(std::min<u64>(next-elapsed,64));executing=true;int used=cpu->run(budget);executing=false;elapsed+=used;chip_advance(elapsed);
  }
 }
};
