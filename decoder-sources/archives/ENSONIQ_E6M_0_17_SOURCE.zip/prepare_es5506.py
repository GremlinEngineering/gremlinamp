from pathlib import Path
import re,hashlib,json
R=Path(__file__).resolve().parent;Q=R.parent/'work-040/references';S=R/'source';S.mkdir(exist_ok=True)
h=(Q/'mame-es5506.h').read_text();c=(Q/'mame-es5506.cpp').read_text()
base=h[h.index('class es550x_device'):h.index('DECLARE_DEVICE_TYPE(ES5506')]
base=base.replace(' : public device_t, public device_sound_interface, public device_memory_interface','')
start=base.index('public:');end=base.index('protected:');base=base[:start]+'''public:
 es550x_device();
 virtual ~es550x_device() = default;
'''+base[end:]
base=re.sub(r'\tes550x_device\(const machine_config[^;]+;','',base)
base=re.sub(r'\t// device-level overrides.*?\tvoid update_irq_state\(\);','\tvoid update_irq_state();',base,flags=re.S)
base=re.sub(r'\toptional_memory_region m_region0;.*?\tint m_channels;', '\tint m_channels;',base,flags=re.S)
base=base.replace('devcb_write_line','Callback').replace('devcb_read16','Callback').replace('devcb_write32','Callback')
base=base.replace('es5506_device(const machine_config &mconfig, const char *tag, device_t *owner, u32 clock);','es5506_device();\n void sample(float* out) { stream.out=out; generate_samples(stream); }\n unsigned rate() const { return m_sample_rate; }\n unsigned period() const { return 2*(m_active_voices+1); }\n unsigned page() const { return m_current_page; }\n void set_roms(const u8* a,const u8* b) { m_cache[0].data=a;m_cache[0].length=2097152;m_cache[3].data=b;m_cache[3].length=524288; }\n sound_stream stream;')
base=re.sub(r'\t// device-level overrides.*?\tconst s8 VOLUME_BIT_ES5506', '\tconst s8 VOLUME_BIT_ES5506',base,flags=re.S)
base=base.replace('memory_access<21, 1, -1, ENDIANNESS_BIG>::cache','Cache')
shim='''// license:BSD-3-Clause; copyright-holders:Aaron Giles
// Framework shim for pinned MAME ES5506. Opcode/filter/envelope/register methods are extracted verbatim.
#pragma once
#include <cstdint>
#include <vector>
#include <algorithm>
using u8=uint8_t;using s8=int8_t;using u16=uint16_t;using s16=int16_t;using u32=uint32_t;using s32=int32_t;using u64=uint64_t;using s64=int64_t;using offs_t=u32;
#define ES5506_MAKE_WAVS 0
#define RAINE_CHECK 0
#define LOG(...) ((void)0)
#define LOGMASKED(...) ((void)0)
namespace util { inline s32 sext(u32 v,unsigned n){return s32(v<<(32-n))>>(32-n);} }
struct Callback { bool isunset()const{return true;} u32 operator()(u32=0)const{return 0;} };
struct MachineShim { bool side_effects_disabled()const{return false;} const char* describe_context()const{return "";} };inline MachineShim machine(){return {};}
struct sound_stream { float* out=nullptr;void update(){}void set_sample_rate(unsigned){}int samples()const{return 1;}int output_count()const{return 2;}void put_int_clamp(int c,int,s32 v,s32 scale){out[c]=std::clamp(float(v)/float(scale),-1.0f,1.0f);} };
struct Cache { const u8* data=nullptr;size_t length=0;u16 read_word(u32 a)const{a&=0x1fffff;return data?(a<length?u16(data[a])<<8:0):0;} };
'''
(S/'es5506.h').write_text(shim+base.replace('protected:','public:'))
def extract(name):
 m=re.search(r'^(?:inline )?(?:void|u8|u32|s32) '+re.escape(name)+r'\([^\n]*\)\n\{',c,re.M);assert m,name
 p=c.index('{',m.start());depth=1;i=p+1
 while depth:
  if c[i]=='{':depth+=1
  elif c[i]=='}':depth-=1
  i+=1
 return c[m.start():i]
names=['es550x_device::'+n for n in ['update_irq_state','update_internal_irq_state','compute_tables','get_accum_mask','interpolate','apply_filters','generate_ulaw','generate_pcm','generate_irq']]+['es5506_device::'+n for n in ['update_envelopes','check_for_end_forward','check_for_end_reverse','generate_samples','reg_write_low','reg_write_high','reg_write_test','write','reg_read_low','reg_read_high','reg_read_test','read']]
constants=c[c.index('static constexpr u32 FINE_FILTER_BIT'):c.index('es550x_device::es550x_device')]
helpers=c[c.index('static inline s32 apply_lowpass'):c.index('inline void es550x_device::apply_filters')]
constructors='''
es550x_device::es550x_device():m_stream(nullptr),m_sample_rate(0),m_master_clock(16000000),m_address_acc_shift(0),m_address_acc_mask(0),m_volume_shift(0),m_volume_acc_shift(0),m_current_page(0),m_active_voices(31),m_mode(0x17),m_irqv(0x80),m_voice_index(0),m_channels(1){}
es5506_device::es5506_device():m_write_latch(0),m_read_latch(0),m_wst(0),m_wend(0),m_lrend(0){m_stream=&stream;compute_tables(16,4,8);get_accum_mask(21,11);m_sample_rate=31250;}
'''
methods=[extract(n)for n in names]
(S/'es5506.cpp').write_text('#include "es5506.h"\n'+constants+constructors+helpers+'\n\n'.join(methods)+'\n')
(R/'es5506-method-extraction.json').write_text(json.dumps({'pin':'40d0f1125befade5edc08ec5699442ca3a229c01','methods':[{'name':n,'sha256':hashlib.sha256(b.encode()).hexdigest(),'verbatim':True}for n,b in zip(names,methods)]},indent=2)+'\n')
print(len(methods),'unaltered methods extracted')
