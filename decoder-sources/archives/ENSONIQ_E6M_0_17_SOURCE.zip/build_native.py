from pathlib import Path
import subprocess
R=Path(__file__).resolve().parent;S=R/'source';B=R/'build';B.mkdir(exist_ok=True)
subprocess.run(['clang++','-std=c++17','-O2','-fwrapv','-ffp-contract=off','-fvisibility=hidden','-dynamiclib','-I'+str(S/'hash'),*[str(S/n)for n in ['e6m_core.cpp','es5506.cpp','m6809.cpp','hash/sha256.cpp']],'-o',str(B/'libgremlin-e6m.dylib')],check=True)
