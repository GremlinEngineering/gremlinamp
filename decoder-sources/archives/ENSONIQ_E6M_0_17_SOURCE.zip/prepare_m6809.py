from pathlib import Path
import re,subprocess,shutil,sys
R=Path(__file__).resolve().parent;Q=R.parent/'work-040/references';S=R/'source';D=R/'generated';D.mkdir(exist_ok=True)
for n in ['m6809.lst','base6x09.lst','m6809make.py']:shutil.copyfile(Q/('mame-'+n),D/n)
with (S/'m6809.hxx').open('w')as f:subprocess.run([sys.executable,str(D/'m6809make.py'),str(D/'m6809.lst')],stdout=f,check=True)
h=(Q/'mame-m6809.h').read_text();h=h[h.index('class m6809_base_device'):h.index('// ======================> mc6809_device')];h=h.replace(' : public cpu_device','');h=h.replace('protected:','public:').replace('private:','public:');a=h.index('public:');b=h.index('\t// addressing modes');h=h[:a]+'''public:
 struct Bus { std::function<uint8_t(uint16_t)> read;std::function<void(uint16_t,uint8_t)> write;uint8_t read_opcode(uint16_t a){return read(a);}uint8_t read_opcode_arg(uint16_t a){return read(a);} };
 explicit m6809_base_device(Bus* bus);
 void device_reset();void execute_set_input(int inputnum,int state);void execute_run();
 int run(int n){m_icount=n;execute_run();return n-m_icount;}int remaining()const{return m_icount;}
 bool is_6809(){return true;}
 void debugger_instruction_hook(unsigned){}void debugger_wait_hook(){}void debugger_exception_hook(int){}void standard_irq_callback(int,unsigned){}
'''+h[b:]
h=h.replace('std::unique_ptr<memory_interface> m_mintf','Bus* m_mintf');h=h.replace('devcb_write_line','Callback').replace('devcb_read8','Callback');h=re.sub(r'\t// address spaces.*?\t// other state','\t// other state',h,flags=re.S)
shim='''// license:BSD-3-Clause; copyright-holders:Nathan Woods
// Framework shim; pinned MAME instruction/microstate methods remain unchanged.
#pragma once
#include <cstdint>
#include <functional>
#include <cassert>
#include <stdexcept>
#include <limits>
#include <type_traits>
#define LSB_FIRST 1
#define BIT(x,n) (((x)>>(n))&1)
#define UNEXPECTED(x) (x)
#define ATTR_FORCE_INLINE
#define ASSERT_LINE 1
#define CLEAR_LINE 0
#define INPUT_LINE_NMI 2
#define M6809_IRQ_LINE 0
#define M6809_FIRQ_LINE 1
#define LOGMASKED(...) ((void)0)
#define logerror(...) ((void)0)
#define fatalerror(...) throw std::runtime_error("6809 invalid internal state")
union PAIR16 { uint16_t w;struct { uint8_t l,h; }b; };
'''
(S/'m6809.h').write_text(shim+h)
inl=(Q/'mame-m6809inl.h').read_text();(S/'m6809inl.h').write_text(inl)
c=(Q/'mame-m6809.cpp').read_text()
def method(name):
 m=re.search(r'^[^\n;{}]*m6809_base_device::'+name+r'\([^\n]*\)[^\n]*\n\{',c,re.M);assert m,name
 p=c.index('{',m.start());i=p+1;depth=1
 while depth:
  if c[i]=='{':depth+=1
  if c[i]=='}':depth-=1
  i+=1
 return c[m.start():i]
names=['device_reset','execute_set_input','inputnum_string','read_tfr_exg_816_register','read_exg_168_register','write_exgtfr_register','log_illegal','execute_one','execute_run']
constructor='''m6809_base_device::m6809_base_device(Bus*bus):m_mintf(bus),m_pc{},m_ppc{},m_q{},m_x{},m_y{},m_u{},m_s{},m_dp(0),m_cc(0),m_temp{},m_opcode(0),m_reg8(nullptr),m_reg16(nullptr),m_reg(0),m_nmi_line(false),m_nmi_asserted(false),m_firq_line(false),m_irq_line(false),m_lds_encountered(false),m_icount(0),m_addressing_mode(0),m_ea{},m_state(0),m_cond(false),m_free_run(false),m_clock_divider(1){device_reset();}\n'''
parts=[method(n)for n in names];parts=[x.replace('"cpu/m6809/m6809.hxx"','"m6809.hxx"')for x in parts]
(S/'m6809.cpp').write_text('#include "es5506.h"\n#include "m6809.h"\n#include "m6809inl.h"\n'+constructor+'\n\n'.join(parts)+'\n')
