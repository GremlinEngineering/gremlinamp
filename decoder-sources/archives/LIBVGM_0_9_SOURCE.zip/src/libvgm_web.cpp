// Minimal browser ABI for the pinned upstream libvgm player and chip cores.
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <memory>
#include <string>
#include <vector>
#include "player/playera.hpp"
#include "player/vgmplayer.hpp"
#include "player/s98player.hpp"
#include "utils/MemoryLoader.h"
#include "emu/SoundDevs.h"


struct TMCEvent{uint32_t tick,action,channel;};
static std::vector<int16_t> titlePCM;
static std::vector<TMCEvent> titleEvents;
static uint64_t outputFrame=0,titleStartFrame=0;
static size_t titleEventIndex=0;
static uint32_t outputRate=48000;
static bool titlePlaying=false,tmcActive=false;
static uint32_t read32(const uint8_t*p){return p[0]|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
static std::unique_ptr<PlayerA> player;
static DATA_LOADER* loader = nullptr;
static std::vector<UINT8> source;
static std::vector<PLR_DEV_INFO> devices;
static std::string last_error;
static std::string device_json;

extern "C" {
void gremlin_vgm_close() {
    if (player) {
        player->Stop();
        player->UnloadFile();
        player.reset();
    }
    if (loader) { DataLoader_Deinit(loader); loader = nullptr; }
    source.clear(); devices.clear(); device_json.clear();titlePCM.clear();titleEvents.clear();outputFrame=0;titleEventIndex=0;titlePlaying=false;tmcActive=false;
}
const char* gremlin_vgm_error() { return last_error.c_str(); }
const char* gremlin_vgm_devices() { return device_json.c_str(); }

int gremlin_vgm_load(const UINT8* bytes, UINT32 length, UINT32 sample_rate) {
    gremlin_vgm_close(); last_error.clear();outputRate=sample_rate;
    if(bytes&&length>=32&&!memcmp(bytes,"TMC1",4)){
        const uint32_t ver=read32(bytes+4),ticks=read32(bytes+8),vlen=read32(bytes+12),rlen=read32(bytes+16),ec=read32(bytes+20),end=read32(bytes+24),pcmrate=read32(bytes+28);
        if(ver!=1||ticks!=44100||rlen!=524288||ec>100000||pcmrate!=20000||uint64_t(32)+vlen+rlen+uint64_t(ec)*12!=length||vlen<64){last_error="Invalid original TMNT title bundle";return 1;}
        const uint8_t*rom=bytes+32+vlen;titlePCM.reserve(rlen/2);
        for(uint32_t i=0;i<rlen;i+=2){uint16_t fp=(uint16_t(rom[i])|(uint16_t(rom[i+1])<<8))>>3;fp^=0x1e00;int16_t value=int16_t(uint16_t(fp<<6));titlePCM.push_back(int16_t(int32_t(value)>>((fp>>10)&7)));}
        const uint8_t*ev=rom+rlen;uint32_t last=0;
        for(uint32_t i=0;i<ec;i++){TMCEvent e={read32(ev+i*12),read32(ev+i*12+4),read32(ev+i*12+8)};if(e.tick<last||e.tick>end||e.action>1||e.channel){last_error="Invalid TMNT event";return 1;}last=e.tick;titleEvents.push_back(e);}
        bytes+=32;length=vlen;tmcActive=true;
    }
    if (!bytes || length < 0x40 || (memcmp(bytes, "Vgm ", 4) && memcmp(bytes,"S983",4)) || sample_rate < 8000 || sample_rate > 192000) {
        last_error = "Invalid VGM header or output sample rate"; return 1;
    }
    source.assign(bytes, bytes + length);
    loader = MemoryLoader_Init(source.data(), (UINT32)source.size());
    if (!loader || DataLoader_Load(loader)) { last_error = "Cannot load VGM memory buffer"; return 2; }
    player.reset(new PlayerA());
    player->RegisterPlayerEngine(new VGMPlayer());
    player->RegisterPlayerEngine(new S98Player());
    // The WASM build selects upstream's unclipped Float32 sample conversion.
    if (player->SetOutputSettings(sample_rate, 2, 32, 16384)) { last_error = "Cannot configure stereo Float32 output"; return 3; }
    PlayerA::Config options = player->GetConfiguration();
    options.masterVol = 0x10000;
    options.loopCount = 0; // Playback transport owns length and fade, not the core.
    options.fadeSmpls = 0;
    options.endSilenceSmpls = 0;
    options.pbSpeed = 1.0;
    player->SetConfiguration(options);
    if (player->LoadFile(loader) || player->Start()) { last_error = "libvgm rejected the song or its sound devices"; return 4; }
    // Upstream returns 1 for live device information, 0 for header-only data.
    if (player->GetPlayer()->GetSongDeviceInfo(devices) != 1 || devices.empty()) { last_error = "No running sound devices in VGM"; return 5; }
    device_json = "[";
    bool first = true;
    for (const auto& device : devices) {
        if (device.parentIdx != (UINT32)-1) continue;
        // A single built-in core may legitimately use coreID == 0 (WonderSwan).
        if (!device.devDecl || !device.smplRate) {
            last_error = "A sound chip declared by this VGM has no running emulation core"; return 6;
        }
        char line[192];
        snprintf(line, sizeof(line), "%s{\"type\":%u,\"instance\":%u,\"core\":%u,\"clock_hz\":%u,\"sample_rate\":%u}",
            first ? "" : ",", (unsigned)device.type, (unsigned)device.instance, (unsigned)device.core,
            device.devCfg ? (unsigned)device.devCfg->clock : 0, (unsigned)device.smplRate);
        device_json += line; first = false;
    }
    device_json += "]";
    return 0;
}

UINT32 gremlin_vgm_render(float* output, UINT32 frames) {
    if (!output || frames > 16384) return 0;
    memset(output, 0, (size_t)frames * 2 * sizeof(float));
    if (!player) return 0;
    uint32_t got=player->Render(frames * 2 * sizeof(float), output) / (2 * sizeof(float));
    if(tmcActive){for(uint32_t i=0;i<frames;i++,outputFrame++){
        while(titleEventIndex<titleEvents.size()&&uint64_t(titleEvents[titleEventIndex].tick)*outputRate<=outputFrame*44100){const TMCEvent&e=titleEvents[titleEventIndex++];if(e.action==0){if(!titlePlaying){titlePlaying=true;titleStartFrame=outputFrame;}}else titlePlaying=false;}
        if(titlePlaying){uint64_t pos=(outputFrame-titleStartFrame)*20000;size_t idx=size_t(pos/outputRate);if(idx>=titlePCM.size()){titlePlaying=false;continue;}uint32_t frac=uint32_t(pos%outputRate);int32_t a=titlePCM[idx],b=idx+1<titlePCM.size()?titlePCM[idx+1]:0;float value=float(int64_t(a)*(outputRate-frac)+int64_t(b)*frac)/float(uint64_t(outputRate)*32768)*0.25f;output[i*2]+=value;output[i*2+1]+=value;}
    }}return got;
}
}
