from pathlib import Path
import ctypes as C,json,sys,gzip,hashlib,math
import numpy as np
R=Path(__file__).resolve().parent
file=Path(sys.argv[1]);ms=int(sys.argv[2]);rate=int(sys.argv[3])if len(sys.argv)>3 else 48000
raw=file.read_bytes()
if raw[:2]==b'\x1f\x8b':raw=gzip.decompress(raw)
l=C.CDLL(str(R/'verification/libgremlin-vgm-native.so'));l.gremlin_vgm_load.argtypes=[C.c_void_p,C.c_uint,C.c_uint];l.gremlin_vgm_load.restype=C.c_int;l.gremlin_vgm_render.argtypes=[C.c_void_p,C.c_uint];l.gremlin_vgm_error.restype=C.c_char_p;l.gremlin_vgm_devices.restype=C.c_char_p
b=C.create_string_buffer(raw);r=l.gremlin_vgm_load(b,len(raw),rate)
assert r==0,l.gremlin_vgm_error().decode();a=np.zeros(8192,np.float32);digest=hashlib.sha256();frames=math.ceil(ms*rate/1000/4096)*4096;peak=0;energy=0;count=0;nonzero=0
binary='--binary'in sys.argv
for at in range(0,frames,4096):
 l.gremlin_vgm_render(a.ctypes.data,4096)
 if binary:sys.stdout.buffer.write(a.tobytes());continue
 digest.update(a.tobytes());peak=max(peak,float(np.max(np.abs(a))));energy+=float(np.sum(a.astype(float)**2));count+=len(a);nonzero+=int(np.count_nonzero(np.abs(a)>1e-5))
if not binary:print(json.dumps({'file':file.name,'sample_rate':rate,'frames':frames,'samples':count,'pcm_sha256':digest.hexdigest(),'peak':peak,'rms':math.sqrt(energy/count),'nonzero_samples':nonzero,'devices':json.loads(l.gremlin_vgm_devices())}))
