"""Reproducible local WebAssembly build; no site installation or publishing."""
from pathlib import Path
import argparse,json,os,subprocess,shutil,hashlib

ROOT=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser();p.add_argument('--sdk',required=True,type=Path);p.add_argument('--cmake',required=True,type=Path);p.add_argument('--source',required=True,type=Path);a=p.parse_args()
 sdk=a.sdk.resolve();cmake=a.cmake.resolve();source=a.source.resolve();build=ROOT/'build-wasm';build.mkdir(exist_ok=True)
 env={**os.environ,'EMSDK':str(sdk),'EM_CONFIG':str(sdk/'.emscripten'),'PATH':str(sdk/'upstream/emscripten')+os.pathsep+str(cmake.parent)+os.pathsep+os.environ.get('PATH','')}
 def run(args,label):
  log=build/(label+'.log')
  with log.open('w') as f:r=subprocess.run([str(x) for x in args],env=env,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:print(log.read_text()[-5000:],flush=True);raise SystemExit(r.returncode)
  print(label,'passed',flush=True)
 run(['python',sdk/'upstream/emscripten/embuilder.py','build','zlib'],'zlib')
 run(['python',sdk/'upstream/emscripten/emcmake.py',cmake,'-S',ROOT/'src','-B',build,'-DCMAKE_BUILD_TYPE=Release','-DLIBVGM_SOURCE_DIR='+str(source),'-DCMAKE_C_FLAGS=-O3 -sUSE_ZLIB=1','-DCMAKE_CXX_FLAGS=-O3 -sUSE_ZLIB=1','-DCMAKE_EXE_LINKER_FLAGS=-sUSE_ZLIB=1'],'configure')
 run([cmake,'--build',build,'--target','gremlin-libvgm','--parallel','3'],'compile')
 out=ROOT/'built';out.mkdir(exist_ok=True)
 files=[]
 for name in ['gremlin-libvgm.js','gremlin-libvgm.wasm']:
  matches=list(build.rglob(name));assert len(matches)==1,matches;target=out/name;shutil.copyfile(matches[0],target);files.append({'path':name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
 (out/'BUILD.json').write_text(json.dumps({'compiler':'Emscripten 4.0.10','libvgm_commit':'61b62d64455e039de2a1d01498afa9e9b5f1cb88','all_upstream_sound_devices':True,'pcm':'unclipped stereo Float32','files':files},indent=2)+'\n')
 print(json.dumps(files),flush=True)
if __name__=='__main__':main()
