# TMNT Original Capture, version1

TMC1 is a new transparent collection container, not an established VGM format. It preserves the original TMNT YM3014 title-ROM bytes, original start/stop event timing, and a complete VGM log for YM2151, K007232 and uPD7759. It contains no generated music, reconstructed notes, MP3, or rendered PCM.

All integers are unsigned little-endian32-bit. Header32bytes:magic TMC1;version1;event clock44100;VGM byte length;ROM byte length524288;event count;end tick;title sample rate20000. Then embedded VGM, unchanged YM3014 ROM, then12-byte events:tick,action(0=play,1=stop),channel0.

The original512KB ROM has262144 Yamaha floating-point samples. Every16-bit little-endian word is shifted right3 and decoded with ymfm::decode_fp, exactly as current MAME tmnt_decode_sample. At the output sample rate, phase is advanced at20000Hz and converted with deterministic linear interpolation. Sample start occurs at the first output frame whose timestamp reaches the event tick. Play only retriggers if not already playing, as in current MAME. Stop silences the original playback. Gain0.25 follows the MAME mixer route; original chip-register streams use the corresponding MAME routes encoded in VGM's volume header.

The music.md gain_db applies an additional whole-track reduction. No formal loop is invented. Underlying physical analog circuitry is not claimed to be reproduced exactly. Browser/native tests use the same libvgm build; independent integer conversion/resampling verification is also provided.
