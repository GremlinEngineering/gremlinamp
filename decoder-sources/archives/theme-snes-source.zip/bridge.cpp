// SPDX-License-Identifier: MIT
// Incremental version of Imperial School Views' offline S-DSP renderer.
#include "dsp_core/SPC_DSP.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <vector>

namespace {
constexpr uint32_t ram_size = 65536;
constexpr uint32_t header_size = 16;
constexpr uint32_t max_frames = 32000 * 3600;
struct Event { uint32_t sample; uint8_t address, value; };
std::vector<Event> events;
uint8_t ram[ram_size];
SPC_DSP dsp;
uint32_t position, duration;
size_t next_event;

uint32_t read_u32(const uint8_t* bytes) {
    return uint32_t(bytes[0]) | uint32_t(bytes[1]) << 8 |
           uint32_t(bytes[2]) << 16 | uint32_t(bytes[3]) << 24;
}
}

extern "C" {
int theme_snes_load(const uint8_t* bytes, uint32_t size) {
    if (size < header_size + ram_size || std::memcmp(bytes, "ISVSNES1", 8))
        return 1;
    const auto count = read_u32(bytes + 8);
    const auto total = read_u32(bytes + 12);
    if (total == 0 || total > max_frames || uint64_t(header_size) + ram_size + uint64_t(count) * 6 != size)
        return 2;
    events.clear();
    events.reserve(count);
    const auto* item = bytes + header_size + ram_size;
    uint32_t last = 0;
    for (uint32_t i = 0; i < count; ++i, item += 6) {
        const auto at = read_u32(item);
        if (at < last || at > total || item[4] >= 128)
            return 3;
        events.push_back({at, item[4], item[5]});
        last = at;
    }
    std::memcpy(ram, bytes + header_size, ram_size);
    dsp.init(ram);
    dsp.reset();
    position = 0;
    next_event = 0;
    duration = total;
    return 0;
}

int theme_snes_render(short* output, uint32_t frames) {
    frames = std::min(frames, duration - position);
    const auto end = position + frames;
    dsp.set_output(output, frames * 2 + SPC_DSP::extra_size);
    while (next_event < events.size() && events[next_event].sample < end) {
        const auto& event = events[next_event++];
        if (event.sample > position)
            dsp.run((event.sample - position) * 32);
        position = event.sample;
        dsp.write(event.address, event.value);
    }
    if (end > position)
        dsp.run((end - position) * 32);
    position = end;
    return dsp.sample_count() == int(frames * 2) ? int(frames) : -1;
}
}
