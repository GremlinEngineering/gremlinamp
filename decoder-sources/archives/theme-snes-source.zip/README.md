# Theme soundtrack SNES decoder

`bridge.cpp` streams the `ISVSNES1` format used by Imperial School Views. The format starts with the signature, event count and duration in stereo frames at 32 kHz. A 64 KiB RAM image follows, then events containing an absolute frame number, DSP register and byte value. All integers are little endian.

The decoder uses the same unmodified blargg S-DSP core and event timing as the [offline renderer](https://github.com/GremlinEngineering/imperial-school-views/blob/b77b493ce47d36df153b88308cc31620e06980e8/android-tv/music/teahouse/dsp_render.cpp). The bridge is MIT. The core license is in `dsp_core/LICENSE`.

Run `sh build.sh` with Emscripten on PATH. The resulting JavaScript and WebAssembly files belong in `music_player/vendor/theme-snes`.
