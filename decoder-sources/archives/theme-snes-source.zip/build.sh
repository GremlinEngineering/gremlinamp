#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p ../../music_player/vendor/theme-snes
em++ --no-entry -O3 -std=c++17 -DNDEBUG -sMODULARIZE=1 -sEXPORT_NAME=GremlinThemeSNES \
    -sENVIRONMENT=worker -sFILESYSTEM=0 -sALLOW_MEMORY_GROWTH=1 \
    -sEXPORTED_FUNCTIONS=_malloc,_free,_theme_snes_load,_theme_snes_render \
    -sEXPORTED_RUNTIME_METHODS=HEAPU8,HEAP16 \
    bridge.cpp dsp_core/SPC_DSP.cpp -o ../../music_player/vendor/theme-snes/theme-snes.js
