from pathlib import Path
import argparse,zipfile,hashlib,subprocess,os,shlex,json,shutil,sys
p=argparse.ArgumentParser();p.add_argument('--emsdk',required=True);p.add_argument('--output',required=True);a=p.parse_args();R=Path(__file__).resolve().parent;SDK=Path(a.emsdk).resolve();S=SDK/'install/emscripten';B=Path(a.output).resolve();E=B/'core';B.mkdir(parents=True,exist_ok=True)
archive=R/'original-sources.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='fae4c459afa399691cdb6a6f52d9bef483bf07113b7fb177d93a5f311b40dc00'
with zipfile.ZipFile(archive)as z:
 for x in z.infolist():
  if x.is_dir():continue
  rel=Path(*Path(x.filename).parts[1:]);assert not rel.is_absolute()and'..'not in rel.parts;dest=E/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(x))
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'SOURCE_DATE_EPOCH':'0','GIT_CEILING_DIRECTORIES':str(B),'DEVELOPER_DIR':'/Library/Developer/CommandLineTools'}
cmd=['make','-f','Makefile.libretro','-j4','platform=emscripten','GIT_VERSION=dccff54','CC=python3 '+shlex.quote(str(S/'emcc.py')),'CXX=python3 '+shlex.quote(str(S/'em++.py')),'AR=python3 '+shlex.quote(str(S/'emar.py'))]
with(B/'make.log').open('w')as f:subprocess.run(cmd,cwd=E,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
cc=[sys.executable,str(S/'emcc.py')];host=B/'vx_host.o';subprocess.run([*cc,'-O2','-DNDEBUG','-I'+str(E/'libretro-common/include'),'-c',str(R/'vx_host.c'),'-o',str(host)],env=env,check=True);shutil.copyfile(E/'vecx_libretro_emscripten.bc',B/'libvecx.a')
exports=['_malloc','_free']+['_gremlin_vx_'+x for x in ['load','close','step','audio','audio_frames','video','video_width','video_height','capture_video','error','source_rate','source_fps']]
cmd=[*cc,'-O2','--no-entry',str(host),str(B/'libvecx.a'),'-sMODULARIZE=1','-sEXPORT_NAME=GremlinVXMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sSTACK_SIZE=1048576','-sFILESYSTEM=1','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAPU32"]','-o',str(B/'gremlin-vx.js')]
with(B/'link.log').open('w')as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
meta={'core':'Original VecX full6809/PSG','commit':'dccff5402a16d1ea7c112095a8e42632bf149506','core_changes':False,'default_options':True,'outputs':{n:{'bytes':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()}for n in ['gremlin-vx.js','gremlin-vx.wasm']}};(B/'BUILD.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
