from pathlib import Path
import json,gzip,struct,hashlib
R=Path(__file__).resolve().parent;O=R/'native';O.mkdir(exist_ok=True)
for key in ['bubblem','bublbob2','elvactr','gunlock','spcinv95']:
 D=R.parent/'work-059/original'/key;proof=json.loads((D/'source-proof.json').read_text());ids={int(t['code'],0)for t in proof['hoot_titles']}
 if key=='elvactr':ids.add(44)
 selected=[x for x in proof['commands']if x['code']in ids];assert len(selected)==len(ids)
 p=(D/'program.bin').read_bytes();s=(D/'samples.bin').read_bytes();assert len(p)==524288 and len(s)==8388608
 po=160+16*len(ids);so=po+len(p);co=so+len(s);blob=bytearray();table=bytearray()
 for cmd in selected:
  b=bytes(cmd['bytes']);table+=struct.pack('<4I',cmd['code'],co+len(blob),len(b),0);blob+=b
 h=bytearray(b'F3M\x1a'+struct.pack('<15I',1,2,15238090,15238090,4000000,29761,len(p),len(s),len(ids),160,121904720,po,so,co,co+len(blob)))
 for b in [p,s,blob]:h+=hashlib.sha256(b).digest()
 assert len(h)==160
 bank=bytes(h+table)+p+s+blob;(O/(key+'-original.f3m')).write_bytes(bank);(O/(key+'-original.f3z')).write_bytes(gzip.compress(bank,compresslevel=9,mtime=0));print(key,len(selected),(O/(key+'-original.f3z')).stat().st_size)
