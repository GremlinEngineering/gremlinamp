from pathlib import Path
import ctypes as c,json,gzip,sys
import numpy as np
R=Path(__file__).resolve().parent
class Player:
 def __init__(self):
  self.l=c.CDLL(str(R/'build/libgremlin-f3.dylib'));l=self.l;l.gremlin_f3_load.argtypes=[c.c_void_p,c.c_uint32,c.c_uint32,c.c_uint32];l.gremlin_f3_load.restype=c.c_int;l.gremlin_f3_render.argtypes=[c.c_void_p,c.c_uint32];l.gremlin_f3_render.restype=c.c_uint32;l.gremlin_f3_error.restype=c.c_char_p;l.gremlin_f3_stats.restype=c.c_char_p;l.gremlin_f3_devices.restype=c.c_char_p
 def load(self,path,command,rate):
  b=Path(path).read_bytes()
  if b[:2]==b'\x1f\x8b':b=gzip.decompress(b)
  a=c.create_string_buffer(b);status=self.l.gremlin_f3_load(a,len(b),rate,command)
  if status:raise RuntimeError(self.l.gremlin_f3_error().decode())
 def render(self,n):
  a=np.zeros(n*2,dtype='<f4');assert self.l.gremlin_f3_render(a.ctypes.data,n)==n,self.l.gremlin_f3_error().decode();return a
 def close(self):self.l.gremlin_f3_close()
if __name__=='__main__':
 p=Player();path=sys.argv[1];seconds=float(sys.argv[2]);rate=int(sys.argv[3]);command=int(sys.argv[sys.argv.index('--command')+1]);p.load(path,command,rate);total=int(seconds*rate);frames=0;peak=0.;energy=0.;nonzero=0
 while frames<total:
  a=p.render(min(4096,total-frames));frames+=len(a)//2;peak=max(peak,float(np.max(np.abs(a))));energy+=float(np.sum(a.astype(np.float64)**2));nonzero+=int(np.count_nonzero(a))
  if '--binary'in sys.argv:sys.stdout.buffer.write(a.tobytes())
 stats={'frames':frames,'peak':peak,'rms':(energy/(frames*2))**.5,'nonzero':nonzero,'core':json.loads(p.l.gremlin_f3_stats())};p.close()
 if '--binary'not in sys.argv:print(json.dumps(stats))
