from pathlib import Path
import json,sys,subprocess,hashlib,time
import numpy as np
from render_f3 import Player
R=Path(__file__).resolve().parent;key=sys.argv[1];proof=json.loads((R.parent/'work-059/original'/key/'source-proof.json').read_text());bank=R/'native'/(key+'-original.f3z');ids=sorted({int(t['code'],0)for t in proof['hoot_titles']}|({44}if key=='elvactr'else set()));old=json.loads((R.parent/'work-055/baseline-metadata.json').read_text());gun=[92,93,94,95,102,96,97,98,99,104,101,100,105,106,109,108,107];durations={cue:max(30,int(np.ceil(old['game-ra-13588']['tracks'][i]['timing']['play_ms']/1000+3)))for i,cue in enumerate(gun)}if key=='gunlock'else{};out=R/'checks';out.mkdir(exist_ok=True);results=[];rate=29761
for number,cue in enumerate(ids):
 seconds=20;total=seconds*rate;p=Player();start=time.monotonic();p.load(bank,cue,rate);child=subprocess.Popen([str(R/'build/capture-original'),str(R.parent/'work-059/original'/key),str(cue),str(seconds),'-','none','8'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);h1=hashlib.sha256();h2=hashlib.sha256();offset=0;maximum=0.;peak=0.;energy=0.;nonzero=0;last_nonzero=-1
 try:
  while offset<total:
   frames=min(4096,total-offset);want=frames*8;chunks=[];n=0
   while n<want:
    b=child.stdout.read(want-n)
    if not b:raise RuntimeError('Original source ended early: '+child.stderr.read().decode())
    chunks.append(b);n+=len(b)
   raw=b''.join(chunks);a=np.frombuffer(raw,dtype='<f4');b=p.render(frames);assert np.all(np.isfinite(a))and np.all(np.isfinite(b));error=float(np.max(np.abs(a-b)));maximum=max(maximum,error)
   if error:raise AssertionError((key,cue,offset,error))
   h1.update(raw);h2.update(b.tobytes());peak=max(peak,float(np.max(np.abs(a))));energy+=float(np.sum(a.astype(np.float64)**2));nz=np.flatnonzero(np.max(np.abs(a.reshape(-1,2)),axis=1)>1e-5)
   if len(nz):last_nonzero=offset+int(nz[-1]);nonzero+=len(nz)
   offset+=frames
  trailing=child.stdout.read();stderr=child.stderr.read().decode();code=child.wait();assert code==0 and not trailing,(code,len(trailing),stderr)
  stats=json.loads(stderr.strip().splitlines()[-1]);assert stats['unmapped_reads']==0 and stats['unmapped_writes']==0 and stats['rate_changes']==0,stats
  row={'key':key,'cue':cue,'seconds':seconds,'sample_rate':rate,'frames':offset,'raw_original_sound_ROM_pcm_sha256':h1.hexdigest(),'native_bank_pcm_sha256':h2.hexdigest(),'source_native_exact':h1.hexdigest()==h2.hexdigest(),'max_error':maximum,'peak':peak,'rms':(energy/(2*offset))**.5,'nonzero_frames':nonzero,'last_nonsilent_seconds':(last_nonzero+1)/rate,'source_stats':stats,'native_stats':json.loads(p.l.gremlin_f3_stats()),'elapsed_seconds':time.monotonic()-start};results.append(row);(out/(key+'-source-results.partial.json')).write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'key':key,'complete':number+1,'total':len(ids),**{k:row[k]for k in ['cue','seconds','source_native_exact','peak','last_nonsilent_seconds','elapsed_seconds']}}),flush=True)
 finally:
  p.close()
  if child.poll()is None:child.terminate();child.wait()
(out/(key+'-source-results.json')).write_text(json.dumps({'scope':'Direct original sound ROM plus source-derived command bytes versus bounded F3 native-bank loader; same pinned ES5505/ES5510 methods and documented MC68681 adapter. Not physical hardware nor full MAME executable measurement.','all_exact':all(x['source_native_exact']for x in results),'results':results},indent=2)+'\n')
