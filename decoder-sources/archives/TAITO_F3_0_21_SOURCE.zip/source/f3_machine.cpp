#include "f3_machine.h"
static F3Machine* active=nullptr;
extern "C" unsigned m68k_read_memory_8(unsigned a){return active->read8(a);}
extern "C" unsigned m68k_read_memory_16(unsigned a){return active->read16(a);}
extern "C" unsigned m68k_read_memory_32(unsigned a){return unsigned(active->read16(a))<<16|active->read16(a+2);}
extern "C" void m68k_write_memory_8(unsigned a,unsigned v){active->write8(a,v);}
extern "C" void m68k_write_memory_16(unsigned a,unsigned v){active->write16(a,v);}
extern "C" void m68k_write_memory_32(unsigned a,unsigned v){active->write16(a,v>>16);active->write16(a+2,v);}
extern "C" void m68k_write_memory_32_pd(unsigned a,unsigned v){active->write16(a+2,v);active->write16(a,v>>16);}
static int ack(int){return active->ivr;}
void F3Machine::boot(){active=this;std::vector<u8> initial(m68k_context_size(),0);m68k_set_context(initial.data());m68k_init();m68k_set_cpu_type(M68K_CPU_TYPE_68000);m68k_set_int_ack_callback(ack);m68k_pulse_reset();}
void F3Machine::run_cycles(u64 end){active=this;while(cycles<end){advance(cycles);executing=true;int used=m68k_execute(1);executing=false;if(used<=0)throw std::runtime_error("68000 stopped time");cycles+=used;advance(cycles);}}

extern "C" unsigned m68k_read_disassembler_8(unsigned a){return m68k_read_memory_8(a);}
extern "C" unsigned m68k_read_disassembler_16(unsigned a){return m68k_read_memory_16(a);}
extern "C" unsigned m68k_read_disassembler_32(unsigned a){return m68k_read_memory_32(a);}
