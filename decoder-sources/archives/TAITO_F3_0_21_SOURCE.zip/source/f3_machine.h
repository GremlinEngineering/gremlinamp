// license:MIT; framework by Imperial Engineer Gremlin project.
// Original MC68000 instruction core: Musashi pinned313ebf1b, unchanged.
// Original ES5505/ES5510 runtime methods: MAME pinned40d0f112, unchanged.
#pragma once
#include "es5505.h"
#include "es5510.h"
#include <cmath>
#include <functional>
#include <array>
#include <stdexcept>
extern "C" {
#include "musashi/m68k.h"
}
struct F3Machine {
 static constexpr u32 CPU_CLOCK=15238090,UART_CLOCK=4000000,RATE=29761;
 es5505_device chip;es5510_device dsp;address_space dummy;
 std::vector<u8> program,samples;std::array<u8,65536>ram{};std::array<u8,2048>comm{};
 u64 cycles=0,next_sample=1,timer_due=0;bool executing=false,timer_on=false,pump_halted=true;u8 acr=0,imr=0,isr=0,ivr=15,opr=0,opcr=0,half_period=0;u16 ctr=0;
 struct Serial {u8 mr[2]={},ptr=0,csr=0,cr=0,sr=0;bool tx_enabled=false,rx_enabled=false;u64 due=0;unsigned bits=0,total=0,baud=0;};Serial serial[2];
 void serial_irq(unsigned c){unsigned bit=c?16:1;if(serial[c].sr&4)isr|=bit;else isr&=~bit;irq();}
 unsigned baud(unsigned c,u8 v){static const unsigned a[13]={50,110,134,200,300,600,1200,1050,2400,4800,7200,9600,38400};static const unsigned b[13]={75,110,134,150,300,600,1200,2000,2400,4800,1800,9600,19200};unsigned n=v&15;if(n<13)return(acr&128)?b[n]:a[n];if(n==14)return(c?1000000:500000)/16;if(n==15)return c?1000000:500000;throw std::runtime_error("Timer-driven serial channel not supported");}
 void serial_write(unsigned c,unsigned reg,u8 v){Serial&q=serial[c];switch(reg){case 0:q.mr[q.ptr]=v;q.ptr=1;break;case 1:q.csr=v;q.baud=baud(c,v);break;case 2:{unsigned cmd=(v>>4)&7;if(cmd==1)q.ptr=0;if(cmd==2){q.rx_enabled=false;q.sr&=~0xf3;}if(cmd==3){q.tx_enabled=false;q.sr&=~12;q.due=0;}if(cmd==4)q.sr&=~0xf0;if(v&1)q.rx_enabled=true;if(v&2){q.rx_enabled=false;q.sr&=~1;}if(!(q.cr&4)&&(v&4)){q.sr|=12;q.tx_enabled=true;}if(v&8){q.sr&=~12;q.tx_enabled=false;q.due=0;}q.cr=v;serial_irq(c);break;}case 3:if(q.sr&4){q.sr&=~12;q.bits=0;q.total=1+(q.mr[0]&3)+5+(((q.mr[0]>>3)&3)<2?1:0)+(((q.mr[1]>>2)&3)>=2?2:1);if(!q.baud)throw std::runtime_error("Serial TX has zero baud");q.due=now()*q.baud+CPU_CLOCK;serial_irq(c);}break;}}
 void serial_advance(u64 target){for(unsigned c=0;c<2;c++){Serial&q=serial[c];while(q.due&&q.due<=target*q.baud){q.bits++;if(q.bits>1&&q.tx_enabled)q.sr|=4;if(q.bits>=q.total){q.sr|=8;q.due=0;}else q.due+=CPU_CLOCK;serial_irq(c);}}}
 u8 serial_read(unsigned c,unsigned reg){Serial&q=serial[c];switch(reg){case 0:{u8 v=q.mr[q.ptr];q.ptr=1;return v;}case 1:return q.sr;case 3:return 0;default:return 0xff;}}
 u8 volume_control=0;std::array<u16,4>volume_latch{127,127,127,127};float gain[2]={3.125f,3.125f};
 u64 es_writes=0,dsp_writes=0,dsp_runs=0,irq_ticks=0,unmapped_reads=0,unmapped_writes=0,rate_changes=0;std::array<u32,16>uart_read_count{},uart_write_count{};std::array<u8,16>uart_last{};
 std::function<void(float,float)>sink;std::function<void(u64,u32,u32,u32)>event;
 F3Machine(std::vector<u8> p,std::vector<u8>s):program(std::move(p)),samples(std::move(s)){
  if(program.size()!=524288||samples.size()!=8388608)throw std::runtime_error("F3 region sizes");
  chip.set_rom(samples.data(),samples.size());std::copy(program.begin(),program.begin()+8,ram.begin());for(int i=0;i<4;i++)comm[0x7f8+i]=0x30;
 }
 u64 now()const{return cycles+(executing?m68k_cycles_run():0);}
 void record(u32 op,u32 a,u32 v){if(event)event(now(),op,a,v);}
 void irq(){m68k_set_irq((isr&imr)?6:0);}
 u32 timer_rate()const {unsigned mode=(acr>>4)&7;if(mode==3||mode==7)return UART_CLOCK/16;if(mode==1||mode==2)throw std::runtime_error("Unimplemented serial UART timer source");return UART_CLOCK;}
 void start_timer(u32 count){timer_on=true;timer_due=now()*UART_CLOCK+u64(count)*CPU_CLOCK*(UART_CLOCK/timer_rate());}
 void timer_advance(u64 target){
  while(timer_on&&timer_due<=target*UART_CLOCK){
   if(acr&64){half_period^=1;if((opcr&12)==4){opr^=8;pump_halted=(~opr&64)!=0;}if(!half_period){isr|=8;irq_ticks++;}timer_due+=u64(std::max(ctr,u16(1)))*CPU_CLOCK*(UART_CLOCK/timer_rate());}
   else{if((opcr&12)==4)opr|=8;isr|=8;irq_ticks++;timer_due+=u64(65535)*CPU_CLOCK*(UART_CLOCK/timer_rate());}irq();
  }
 }
 u8 uart_read(u32 o){o&=15;uart_read_count[o]++;record(5,o,0);switch(o){
  case 0:case 1:case 3:return serial_read(0,o);case 8:case 9:case 11:return serial_read(1,o&3);case 5:return isr;case 6:case 7:{u64 remain=timer_on&&timer_due>now()*UART_CLOCK?timer_due-now()*UART_CLOCK:0;u16 n=remain/(u64(CPU_CLOCK)*(UART_CLOCK/timer_rate()));return o==6?n>>8:n;}
  case 12:return ivr;case 13:return 0xff;case 14:if(acr&64)half_period=0;start_timer(std::max(ctr,u16(1)));return 0xff;
  case 15:if(!(acr&64)){timer_on=false;if((opcr&12)==4)opr&=~8;}isr&=~8;irq();return 0xff;case 4:return 0;case 10:return 0x61;default:return 0xff;}}
 void uart_write(u32 o,u8 v){o&=15;uart_write_count[o]++;uart_last[o]=v;record(4,o,v);switch(o){
  case 0:case 1:case 2:case 3:serial_write(0,o,v);break;case 8:case 9:case 10:case 11:serial_write(1,o&3,v);break;case 4:{u8 old=acr;acr=v;if((old^v)&64){if(v&64){half_period=0;start_timer(std::max(ctr,u16(1)));}else timer_on=false;}break;}
  case 5:imr=v;irq();break;
  case 6:ctr=(ctr&255)|(u16(v)<<8);break;case 7:ctr=(ctr&0xff00)|v;break;case 12:ivr=v;break;case 13:opcr=v;break;
  case 14:opr|=v;pump_halted=(~opr&64)!=0;break;case 15:opr&=~v;pump_halted=(~opr&64)!=0;break;
  default:break;}}
 void volume_write(u32 offset,u8 data){record(6,offset,data);if(offset&1)volume_control=data&31;else{
  unsigned ch=volume_control&3;u16 latch=volume_latch[ch]=((volume_control<<4)&0x1c0)|(data&63);unsigned index=!(latch&64)?65:(latch&256)?64:(latch&128)?0:(~latch&63);
  if(ch>=2){float factor=index==65?0:std::pow(10.0f,(-0.5f*index)/20.0f);unsigned percent=unsigned(factor*100.0+0.5f);gain[ch&1]=percent/32.0f;}
 }}
 void dsp_frame(){
  if(!pump_halted){
   // Equivalent to MAME run_once on valid programs, bounded to reject malformed banks.
   dsp.set_HALT(false);dsp.icount=1;dsp.execute_run();dsp.set_HALT(true);unsigned n=0;
   while(dsp.state!=es5510_device::STATE_HALTED){if(++n>256||dsp.pc>=160)throw std::runtime_error("Invalid or non-terminating ESP program");dsp.icount=1;dsp.execute_run();}dsp_runs++;
  }
 }
 void sample(){float f[8];chip.sample(f);for(unsigned c=0;c<8;c++)f[c]=(f[c]*gain[c&1])*0.18f;
  for(unsigned c=0;c<6;c++)dsp.ser_w(c,s32(f[c+2]*32768.0f));dsp_frame();float out[2];
  for(unsigned c=0;c<2;c++)out[c]=(float(dsp.ser_r(c+6))*(1.0f/32768.0f)*gain[c])*0.5f+(f[c]*gain[c])*0.5f;
  if(sink)sink(out[0],out[1]);}
 void advance(u64 target){timer_advance(target);serial_advance(target);while(next_sample*u64(CPU_CLOCK)<=target*RATE){sample();next_sample++;}}
 u8 read8(u32 a){a&=0xffffff;if(a<0x40000||a>=0xff0000)return ram[a&65535];if(a>=0xc00000&&a<=0xc7ffff)return program[a&0x7ffff];
  if(a>=0x140000&&a<=0x140fff)return(a&1)?0:comm[(a&4095)/2];
  if(a>=0x200000&&a<=0x20001f){advance(now());u16 v=chip.read((a&31)/2);return a&1?v:v>>8;}
  if(a>=0x260000&&a<=0x2601ff){advance(now());return(a&1)?dsp.host_r(dummy,(a&511)/2):0;}
  if(a>=0x280000&&a<=0x28001f){advance(now());return(a&1)?uart_read((a&31)/2):0;}
  unmapped_reads++;record(8,a,0);return 0;}
 u16 read16(u32 a){if(a>=0x200000&&a<=0x20001f){advance(now());return chip.read((a&31)/2);}return u16(read8(a))<<8|read8(a+1);}
 void write8(u32 a,u8 v){a&=0xffffff;if(a<0x40000||a>=0xff0000){ram[a&65535]=v;return;}if(a>=0x140000&&a<=0x140fff){if(!(a&1))comm[(a&4095)/2]=v;return;}
  if(a>=0x200000&&a<=0x20001f){advance(now());unsigned p=chip.period();record(0,(a&31)/2,(u32(a&1)<<16)|v);chip.write((a&31)/2,(a&1)?v:u16(v)<<8,(a&1)?0xff:0xff00);es_writes++;if(chip.period()!=p)rate_changes++;return;}
  if(a>=0x260000&&a<=0x2601ff){advance(now());if(a&1){record(2,(a&511)/2,v);dsp.host_w((a&511)/2,v);dsp_writes++;}return;}
  if(a>=0x280000&&a<=0x28001f){advance(now());if(a&1)uart_write((a&31)/2,v);return;}
  if(a>=0x300000&&a<=0x30003f){advance(now());u16 word=(a&1)?v:u16(v)<<8;record(3,(a&63)/2,word);chip.banks[(a&63)/2]=(word&7)<<20;return;}
  if(a>=0x340000&&a<=0x340003){advance(now());if(!(a&1))volume_write(((a&3)/2)^1,v);return;}
  unmapped_writes++;record(7,a,v);}
 void write16(u32 a,u16 v){if(a>=0x200000&&a<=0x20001f){advance(now());unsigned p=chip.period();record(1,(a&31)/2,v);chip.write((a&31)/2,v);es_writes++;if(chip.period()!=p)rate_changes++;return;}
  if(a>=0x300000&&a<=0x30003f){advance(now());record(3,(a&63)/2,v);chip.banks[(a&63)/2]=(v&7)<<20;return;}write8(a,v>>8);write8(a+1,v);}
 void boot();void run_cycles(u64 end);void command(const std::vector<u8>&data){unsigned a=(comm[0x480]<<8|comm[0x481])/2;for(u8 v:data){comm[a++]=v;if(a>=0x400)a=0;}comm[0x480]=(a*2)>>8;comm[0x481]=a*2;}
};
