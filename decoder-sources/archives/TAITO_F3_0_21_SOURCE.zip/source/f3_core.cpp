#include "f3_machine.h"
#include "hash/mednafen/mednafen.h"
#include "hash/sha256.h"
#include <deque>
#include <string>
static std::unique_ptr<F3Machine>f3_state;
static bool loaded=false;static u32 output_rate=0;static u64 output_position=0,queue_base=0;
static std::deque<std::array<float,2>>pcm;static std::string error_text,stats_text;
static u32 r32(const u8*p){return u32(p[0])|u32(p[1])<<8|u32(p[2])<<16|u32(p[3])<<24;}
static void ensure(u64 index){unsigned guard=0;while(queue_base+pcm.size()<=index){if(++guard>1024)throw std::runtime_error("F3 PCM not advancing");f3_state->run_cycles(f3_state->cycles+512);}}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_f3_close(){loaded=false;pcm.clear();f3_state.reset();output_position=queue_base=0;}
API const char*gremlin_f3_error(){return error_text.c_str();}
API const char*gremlin_f3_devices(){return "[{\"type\":\"es5505\",\"clock_hz\":15238090,\"internal_sample_rate\":29761,\"voices\":32,\"original_sound_cpu\":\"MC68000@15238090\",\"core\":\"pinned MAME ES5505+full ES5510 with bounded MC68681 adapter\",\"DSP\":\"ES5510 original program and delay memory\",\"game_rom_or_bios_dependency\":false}]";}
API const char*gremlin_f3_stats(){char b[700];if(!f3_state)return "{}";snprintf(b,sizeof(b),"{\"cpu_cycles\":%llu,\"cpu_pc\":%u,\"es_writes\":%llu,\"dsp_writes\":%llu,\"dsp_runs\":%llu,\"irq_ticks\":%llu,\"unmapped_reads\":%llu,\"unmapped_writes\":%llu,\"rate_changes\":%llu}",f3_state->cycles,m68k_get_reg(nullptr,M68K_REG_PC),f3_state->es_writes,f3_state->dsp_writes,f3_state->dsp_runs,f3_state->irq_ticks,f3_state->unmapped_reads,f3_state->unmapped_writes,f3_state->rate_changes);stats_text=b;return stats_text.c_str();}
API int gremlin_f3_load(const u8*b,u32 length,u32 rate,u32 command){gremlin_f3_close();error_text.clear();try{
 if(!b||length<160||memcmp(b,"F3M\x1a",4)||r32(b+4)!=1)throw std::runtime_error("Invalid F3M1 header");
 u32 profile=r32(b+8),boot_cycles=r32(b+44);if((profile!=1&&profile!=2)||r32(b+12)!=15238090||r32(b+16)!=15238090||r32(b+20)!=4000000||r32(b+24)!=29761||r32(b+28)!=524288||r32(b+32)!=8388608||r32(b+40)!=160||boot_cycles!=(profile==1?30476180u:121904720u)||rate<8000||rate>192000)throw std::runtime_error("Unsupported original TaitoF3 profile");
 u32 count=r32(b+36),po=r32(b+48),so=r32(b+52),co=r32(b+56),tail=r32(b+60);if(!count||count>512||po!=160+u64(count)*16||so!=u64(po)+524288||co!=u64(so)+8388608||tail<co||tail!=length)throw std::runtime_error("Invalid F3 original region bounds");
 auto ph=Mednafen::sha256(b+po,524288),sh=Mednafen::sha256(b+so,8388608),ch=Mednafen::sha256(b+co,tail-co);if(memcmp(ph.data(),b+64,32)||memcmp(sh.data(),b+96,32)||memcmp(ch.data(),b+128,32))throw std::runtime_error("Original F3 bank SHA256 differs");
 bool seen[512]={},found=false;u32 offset=0,n=0,next=co;
 for(unsigned i=0;i<count;i++){const u8*p=b+160+i*16;u32 id=r32(p),a=r32(p+4),size=r32(p+8);if(id>=512||seen[id]||!size||size>128||r32(p+12)||a!=next||u64(a)+size>tail)throw std::runtime_error("Invalid F3 command table");seen[id]=true;next=a+size;if(id==command){found=true;offset=a;n=size;}}
 if(!found||next!=tail)throw std::runtime_error("Original F3 music command absent");
 f3_state=std::make_unique<F3Machine>(std::vector<u8>(b+po,b+so),std::vector<u8>(b+so,b+co));f3_state->boot();f3_state->run_cycles(boot_cycles);if(profile==2&&(f3_state->pump_halted||!f3_state->dsp_runs||!f3_state->timer_on))throw std::runtime_error("Original F3 firmware not ready");f3_state->command(std::vector<u8>(b+offset,b+offset+n));f3_state->sink=[](float l,float r){if(!std::isfinite(l)||!std::isfinite(r))throw std::runtime_error("F3 produced nonfinite PCM");pcm.push_back({l,r});};output_rate=rate;loaded=true;return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_f3_close();return 1;}}
API u32 gremlin_f3_render(float*out,u32 frames){if(!out||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;try{
 for(unsigned i=0;i<frames;i++,output_position++){u64 numerator=output_position*29761,at=numerator/output_rate;u32 rem=numerator%output_rate;ensure(at+1);size_t q=at-queue_base;for(unsigned c=0;c<2;c++){double a=pcm[q][c],b=pcm[q+1][c];out[i*2+c]=float(a+(b-a)*double(rem)/output_rate);}while(queue_base<at){pcm.pop_front();queue_base++;}}
 return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_f3_close();return 0;}}
}
