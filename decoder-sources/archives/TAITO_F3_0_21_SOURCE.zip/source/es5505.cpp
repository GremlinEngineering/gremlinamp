// license:BSD-3-Clause
// copyright-holders:Aaron Giles
#include "es5505.h"
static constexpr u32 FINE_FILTER_BIT = 16;
static constexpr u32 FILTER_BIT      = 12;
static constexpr u32 FILTER_SHIFT    = FINE_FILTER_BIT - FILTER_BIT;

static constexpr u32 ULAW_MAXBITS        = 8;

namespace {

enum : u16 {
	CONTROL_BS1         = 0x8000,
	CONTROL_BS0         = 0x4000,
	CONTROL_CMPD        = 0x2000,
	CONTROL_CA2         = 0x1000,
	CONTROL_CA1         = 0x0800,
	CONTROL_CA0         = 0x0400,
	CONTROL_LP4         = 0x0200,
	CONTROL_LP3         = 0x0100,
	CONTROL_IRQ         = 0x0080,
	CONTROL_DIR         = 0x0040,
	CONTROL_IRQE        = 0x0020,
	CONTROL_BLE         = 0x0010,
	CONTROL_LPE         = 0x0008,
	CONTROL_LEI         = 0x0004,
	CONTROL_STOP1       = 0x0002,
	CONTROL_STOP0       = 0x0001,

	CONTROL_BSMASK      = (CONTROL_BS1 | CONTROL_BS0),
	CONTROL_CAMASK      = (CONTROL_CA2 | CONTROL_CA1 | CONTROL_CA0),
	CONTROL_LPMASK      = (CONTROL_LP4 | CONTROL_LP3),
	CONTROL_LOOPMASK    = (CONTROL_BLE | CONTROL_LPE),
	CONTROL_STOPMASK    = (CONTROL_STOP1 | CONTROL_STOP0),

	// ES5505 has sightly different control bit
	CONTROL_5505_LP4    = 0x0800,
	CONTROL_5505_LP3    = 0x0400,
	CONTROL_5505_CA1    = 0x0200,
	CONTROL_5505_CA0    = 0x0100,

	CONTROL_5505_LPMASK = (CONTROL_5505_LP4 | CONTROL_5505_LP3),
	CONTROL_5505_CAMASK = (CONTROL_5505_CA1 | CONTROL_5505_CA0)
};

}


es550x_device::es550x_device():m_stream(nullptr),m_sample_rate(0),m_master_clock(15238090),m_address_acc_shift(0),m_address_acc_mask(0),m_volume_shift(0),m_volume_acc_shift(0),m_current_page(0),m_active_voices(31),m_mode(0),m_irqv(0x80),m_voice_index(0),m_channels(4){}
es5505_device::es5505_device(){m_stream=&stream;compute_tables(8,4,4);get_accum_mask(20,9);m_sample_rate=15238090/(16*32);}
static inline s32 apply_lowpass(s32 out, s32 cutoff, s32 in)
{
	return ((s32)(cutoff >> FILTER_SHIFT) * (out - in) / (1 << FILTER_BIT)) + in;
}

static inline s32 apply_highpass(s32 out, s32 cutoff, s32 in, s32 prev)
{
	return out - prev + ((s32)(cutoff >> FILTER_SHIFT) * in) / (1 << (FILTER_BIT + 1)) + in / 2;
}

// update poles from outputs
static inline void update_pole(s32 &pole, s32 sample)
{
	pole = sample;
}

static inline void update_2_pole(s32 &prev, s32 &pole, s32 sample)
{
	prev = pole;
	pole = sample;
}

void es550x_device::update_irq_state()
{
	// ES5505/6 irq line has been set high - inform the host
	m_irq_cb(1); // IRQB set high
}

void es550x_device::update_internal_irq_state()
{
	/*  Host (cpu) has just read the voice interrupt vector (voice IRQ ack).

	    Reset the voice vector to show the IRQB line is low (top bit set).
	    If we have any stacked interrupts (other voices waiting to be
	    processed - with their IRQ bit set) then they will be moved into
	    the vector next time the voice is processed.  In emulation
	    terms they get updated next time generate_samples() is called.
	*/

	m_irqv = 0x80;

	m_irq_cb(0); // IRQB set low
}

void es550x_device::compute_tables(u32 total_volume_bit, u32 exponent_bit, u32 mantissa_bit)
{
	// allocate ulaw lookup table
	m_ulaw_lookup.resize(1 << ULAW_MAXBITS);

	// generate ulaw lookup table
	for (int i = 0; i < (1 << ULAW_MAXBITS); i++)
	{
		const u16 rawval = (i << (16 - ULAW_MAXBITS)) | (1 << (15 - ULAW_MAXBITS));
		const u8 exponent = rawval >> 13;
		u32 mantissa = (rawval << 3) & 0xffff;

		if (exponent == 0)
			m_ulaw_lookup[i] = s16(mantissa) >> 7;
		else
		{
			mantissa = (mantissa >> 1) | (~mantissa & 0x8000);
			m_ulaw_lookup[i] = s16(mantissa) >> (7 - exponent);
		}
	}

	const u32 volume_bit = (exponent_bit + mantissa_bit);
	m_volume_shift = total_volume_bit - volume_bit;
	const u32 volume_len = 1 << volume_bit;
	// allocate volume lookup table
	m_volume_lookup.resize(volume_len);

	// generate volume lookup table
	const u32 exponent_shift = 1 << exponent_bit;
	const u32 exponent_mask = exponent_shift - 1;

	const u32 mantissa_len = (1 << mantissa_bit);
	const u32 mantissa_mask = (mantissa_len - 1);
	const u32 mantissa_shift = exponent_shift - mantissa_bit - 1;

	for (int i = 0; i < volume_len; i++)
	{
		const u32 exponent = (i >> mantissa_bit) & exponent_mask;
		const u32 mantissa = (i & mantissa_mask) | mantissa_len;

		m_volume_lookup[i] = (mantissa << mantissa_shift) >> (exponent_shift - exponent);
	}
	m_volume_acc_shift = (16 + exponent_mask) - VOLUME_ACC_BIT;

	// init the voices
	for (int j = 0; j < 32; j++)
	{
		m_voice[j].index = j;
		m_voice[j].control = CONTROL_STOPMASK;
		m_voice[j].lvol = (1 << (total_volume_bit - 1));
		m_voice[j].rvol = (1 << (total_volume_bit - 1));
	}
}

void es550x_device::get_accum_mask(u32 address_integer, u32 address_frac)
{
	m_address_acc_shift = ADDRESS_FRAC_BIT - address_frac;
	m_address_acc_mask = lshift_signed<u64, s8>(((((1 << address_integer) - 1) << address_frac) | ((1 << address_frac) - 1)), m_address_acc_shift);
	if (m_address_acc_shift > 0)
		m_address_acc_mask |= ((1 << m_address_acc_shift) - 1);
}

inline s32 es550x_device::interpolate(s32 sample1, s32 sample2, u64 accum)
{
	const u32 shifted = 1 << ADDRESS_FRAC_BIT;
	const u32 mask = shifted - 1;
	accum &= mask & m_address_acc_mask;
	return (sample1 * (s32)(shifted - accum) +
			sample2 * (s32)(accum)) >> ADDRESS_FRAC_BIT;
}

inline void es550x_device::apply_filters(es550x_voice *voice, s32 &sample)
{
	// pole 1 is always low-pass using K1
	sample = apply_lowpass(sample, voice->k1, voice->o1n1);
	update_pole(voice->o1n1, sample);

	// pole 2 is always low-pass using K1
	sample = apply_lowpass(sample, voice->k1, voice->o2n1);
	update_2_pole(voice->o2n2, voice->o2n1, sample);

	// remaining poles depend on the current filter setting
	switch (get_lp(voice->control))
	{
		case 0:
			// pole 3 is high-pass using K2
			sample = apply_highpass(sample, voice->k2, voice->o3n1, voice->o2n2);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is high-pass using K2
			sample = apply_highpass(sample, voice->k2, voice->o4n1, voice->o3n2);
			update_pole(voice->o4n1, sample);
			break;

		case LP3:
			// pole 3 is low-pass using K1
			sample = apply_lowpass(sample, voice->k1, voice->o3n1);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is high-pass using K2
			sample = apply_highpass(sample, voice->k2, voice->o4n1, voice->o3n2);
			update_pole(voice->o4n1, sample);
			break;

		case LP4:
			// pole 3 is low-pass using K2
			sample = apply_lowpass(sample, voice->k2, voice->o3n1);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is low-pass using K2
			sample = apply_lowpass(sample, voice->k2, voice->o4n1);
			update_pole(voice->o4n1, sample);
			break;

		case LP3 | LP4:
			// pole 3 is low-pass using K1
			sample = apply_lowpass(sample, voice->k1, voice->o3n1);
			update_2_pole(voice->o3n2, voice->o3n1, sample);

			// pole 4 is low-pass using K2
			sample = apply_lowpass(sample, voice->k2, voice->o4n1);
			update_pole(voice->o4n1, sample);
			break;
	}
}

void es550x_device::generate_ulaw(es550x_voice *voice, s32 *dest)
{
	const u32 freqcount = voice->freqcount;
	u64 accum = voice->accum & m_address_acc_mask;

	// outer loop, in case we switch directions
	if (!(voice->control & CONTROL_STOPMASK))
	{
		// two cases: first case is forward direction
		if (!(voice->control & CONTROL_DIR))
		{
			// fetch two samples
			s32 val1 = read_sample(voice, get_integer_addr(accum));
			s32 val2 = read_sample(voice, get_integer_addr(accum, 1));

			// decompress u-law
			val1 = m_ulaw_lookup[val1 >> (16 - ULAW_MAXBITS)];
			val2 = m_ulaw_lookup[val2 >> (16 - ULAW_MAXBITS)];

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum + freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_forward(voice, accum);
		}

		// two cases: second case is backward direction
		else
		{
			// fetch two samples
			s32 val1 = read_sample(voice, get_integer_addr(accum));
			s32 val2 = read_sample(voice, get_integer_addr(accum, 1));

			// decompress u-law
			val1 = m_ulaw_lookup[val1 >> (16 - ULAW_MAXBITS)];
			val2 = m_ulaw_lookup[val2 >> (16 - ULAW_MAXBITS)];

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum - freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_reverse(voice, accum);
		}
	}
	else
	{
		// if we stopped, process any additional envelope
		if (voice->ecount != 0)
			update_envelopes(voice);
	}

	voice->accum = accum;
}

void es550x_device::generate_pcm(es550x_voice *voice, s32 *dest)
{
	const u32 freqcount = voice->freqcount;
	u64 accum = voice->accum & m_address_acc_mask;

	// outer loop, in case we switch directions
	if (!(voice->control & CONTROL_STOPMASK))
	{
		// two cases: first case is forward direction
		if (!(voice->control & CONTROL_DIR))
		{
			// fetch two samples
			s32 val1 = (s16)read_sample(voice, get_integer_addr(accum));
			s32 val2 = (s16)read_sample(voice, get_integer_addr(accum, 1));

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum + freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_forward(voice, accum);
		}

		// two cases: second case is backward direction
		else
		{
			// fetch two samples
			s32 val1 = (s16)read_sample(voice, get_integer_addr(accum));
			s32 val2 = (s16)read_sample(voice, get_integer_addr(accum, 1));

			// interpolate
			val1 = interpolate(val1, val2, accum);
			accum = (accum - freqcount) & m_address_acc_mask;

			// apply filters
			apply_filters(voice, val1);

			// update filters/volumes
			if (voice->ecount != 0)
				update_envelopes(voice);

			// apply volumes and add
			dest[0] += get_sample(val1, voice->lvol);
			dest[1] += get_sample(val1, voice->rvol);

			// check for loop end
			check_for_end_reverse(voice, accum);
		}
	}
	else
	{
		// if we stopped, process any additional envelope
		if (voice->ecount != 0)
			update_envelopes(voice);
	}

	voice->accum = accum;
}

inline void es550x_device::generate_irq(es550x_voice *voice, int v)
{
	// does this voice have it's IRQ bit raised?
	if (voice->control & CONTROL_IRQ)
	{
		LOG("es5506: IRQ raised on voice %d!!\n",v);

		// only update voice vector if existing IRQ is acked by host
		if (m_irqv & 0x80)
		{
			// latch voice number into vector, and set high bit low
			m_irqv = v & 0x1f;

			// take down IRQ bit on voice
			voice->control &= ~CONTROL_IRQ;

			// inform host of irq
			update_irq_state();
		}
	}
}

inline void es5505_device::update_envelopes(es550x_voice *voice)
{
	// no envelopes in ES5505
	voice->ecount = 0;
}

inline void es5505_device::check_for_end_forward(es550x_voice *voice, u64 &accum)
{
	// are we past the end?
	if (accum > voice->end)
	{
		// generate interrupt if required
		if (voice->control & CONTROL_IRQE)
			voice->control |= CONTROL_IRQ;

		// handle the different types of looping
		switch (voice->control & CONTROL_LOOPMASK)
		{
			// non-looping
			case 0:
			case CONTROL_BLE:
				voice->control |= CONTROL_STOP0;
				break;

			// uni-directional looping
			case CONTROL_LPE:
				accum = (voice->start + (accum - voice->end)) & m_address_acc_mask;
				break;

			// bi-directional looping
			case CONTROL_LPE | CONTROL_BLE:
				accum = (voice->end - (accum - voice->end)) & m_address_acc_mask;
				voice->control ^= CONTROL_DIR;
				break;
		}
	}
}

inline void es5505_device::check_for_end_reverse(es550x_voice *voice, u64 &accum)
{
	// are we past the end?
	if (accum < voice->start)
	{
		// generate interrupt if required
		if (voice->control & CONTROL_IRQE)
			voice->control |= CONTROL_IRQ;

		// handle the different types of looping
		switch (voice->control & CONTROL_LOOPMASK)
		{
			// non-looping
			case 0:
			case CONTROL_BLE:
				voice->control |= CONTROL_STOP0;
				break;

			// uni-directional looping
			case CONTROL_LPE:
				accum = (voice->end - (voice->start - accum)) & m_address_acc_mask;
				break;

			// bi-directional looping
			case CONTROL_LPE | CONTROL_BLE:
				accum = (voice->start + (voice->start - accum)) & m_address_acc_mask;
				voice->control ^= CONTROL_DIR;
				break;
		}
	}
}

void es5505_device::generate_samples(sound_stream &stream)
{
	// loop while we still have samples to generate
	for (int sampindex = 0; sampindex < stream.samples(); sampindex++)
	{
		// loop over voices
		s32 cursample[12] = { 0 };
		for (int v = 0; v <= m_active_voices; v++)
		{
			es550x_voice *voice = &m_voice[v];

// This special case does not appear to match the behaviour observed in the es5505 in
// actual Ensoniq synthesizers: those, it turns out, do set loop start and end to the
// same value, and expect the voice to keep running. Examples can be found among the
// transwaves on the VFX / SD-1 series of synthesizers.
#if 0
			// special case: if end == start, stop the voice
			if (voice->start == voice->end)
				voice->control |= CONTROL_STOP0;
#endif

			const int voice_channel = get_ca(voice->control);
			const int channel = voice_channel % m_channels;
			const int l = channel << 1;

			// generate from the appropriate source
			// no compressed sample support
			generate_pcm(voice, &cursample[l]);

			// does this voice have it's IRQ bit raised?
			generate_irq(voice, v);
		}

		for (int c = 0; c < stream.output_count(); c++)
			// generated samples are 20-bit signed, range is [-2^19 .. 2^19-1]
			stream.put_int_clamp(c, sampindex, cursample[c], (1 << 19));
	}
}

inline void es5505_device::reg_write_low(es550x_voice *voice, offs_t offset, u16 data, u16 mem_mask)
{
	switch (offset)
	{
		case 0x00:  // CR
			voice->control |= 0xf000; // bit 15-12 always 1
			if (ACCESSING_BITS_0_7)
			{
#if RAINE_CHECK
				voice->control &= ~(CONTROL_STOPMASK | CONTROL_LOOPMASK | CONTROL_DIR);
#else
				voice->control &= ~0x00ff;
#endif
				voice->control |= (data & 0x00ff);
			}
			if (ACCESSING_BITS_8_15)
				voice->control = (voice->control & ~0x0f00) | (data & 0x0f00);

			LOG("%s:voice %d, control=%04x (raw=%04x & %04x)\n", machine().describe_context(), m_current_page & 0x1f, voice->control, data, mem_mask ^ 0xffff);
			break;

		case 0x01:  // FC
			if (ACCESSING_BITS_0_7)
				voice->freqcount = (voice->freqcount & ~get_address_acc_shifted_val(0x00fe, 1)) | (get_address_acc_shifted_val((data & 0x00fe), 1));
			if (ACCESSING_BITS_8_15)
				voice->freqcount = (voice->freqcount & ~get_address_acc_shifted_val(0xff00, 1)) | (get_address_acc_shifted_val((data & 0xff00), 1));
			LOG("%s:voice %d, freq count=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->freqcount, 1));
			break;

		case 0x02:  // STRT (hi)
			if (ACCESSING_BITS_0_7)
				voice->start = (voice->start & ~get_address_acc_shifted_val(0x00ff0000)) | (get_address_acc_shifted_val((data & 0x00ff) << 16));
			if (ACCESSING_BITS_8_15)
				voice->start = (voice->start & ~get_address_acc_shifted_val(0x1f000000)) | (get_address_acc_shifted_val((data & 0x1f00) << 16));
			LOG("%s:voice %d, loop start=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->start));
			break;

		case 0x03:  // STRT (lo)
			if (ACCESSING_BITS_0_7)
				voice->start = (voice->start & ~get_address_acc_shifted_val(0x000000e0)) | (get_address_acc_shifted_val(data & 0x00e0));
			if (ACCESSING_BITS_8_15)
				voice->start = (voice->start & ~get_address_acc_shifted_val(0x0000ff00)) | (get_address_acc_shifted_val(data & 0xff00));
			LOG("%s:voice %d, loop start=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->start));
			break;

		case 0x04:  // END (hi)
			if (ACCESSING_BITS_0_7)
				voice->end = (voice->end & ~get_address_acc_shifted_val(0x00ff0000)) | (get_address_acc_shifted_val((data & 0x00ff) << 16));
			if (ACCESSING_BITS_8_15)
				voice->end = (voice->end & ~get_address_acc_shifted_val(0x1f000000)) | (get_address_acc_shifted_val((data & 0x1f00) << 16));
#if RAINE_CHECK
			voice->control |= CONTROL_STOP0;
#endif
			LOG("%s:voice %d, loop end=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->end));
			break;

		case 0x05:  // END (lo)
			if (ACCESSING_BITS_0_7)
				voice->end = (voice->end & ~get_address_acc_shifted_val(0x000000e0)) | (get_address_acc_shifted_val(data & 0x00e0));
			if (ACCESSING_BITS_8_15)
				voice->end = (voice->end & ~get_address_acc_shifted_val(0x0000ff00)) | (get_address_acc_shifted_val(data & 0xff00));
#if RAINE_CHECK
			voice->control |= CONTROL_STOP0;
#endif
			LOG("%s:voice %d, loop end=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->end));
			break;

		case 0x06:  // K2
			if (ACCESSING_BITS_0_7)
				voice->k2 = (voice->k2 & ~0x00f0) | (data & 0x00f0);
			if (ACCESSING_BITS_8_15)
				voice->k2 = (voice->k2 & ~0xff00) | (data & 0xff00);
			LOG("%s:voice %d, K2=%03x\n", machine().describe_context(), m_current_page & 0x1f, voice->k2 >> FILTER_SHIFT);
			break;

		case 0x07:  // K1
			if (ACCESSING_BITS_0_7)
				voice->k1 = (voice->k1 & ~0x00f0) | (data & 0x00f0);
			if (ACCESSING_BITS_8_15)
				voice->k1 = (voice->k1 & ~0xff00) | (data & 0xff00);
			LOG("%s:voice %d, K1=%03x\n", machine().describe_context(), m_current_page & 0x1f, voice->k1 >> FILTER_SHIFT);
			break;

		case 0x08:  // LVOL
			if (ACCESSING_BITS_8_15)
				voice->lvol = (voice->lvol & ~0xff) | ((data & 0xff00) >> 8);
			LOG("%s:voice %d, left vol=%02x\n", machine().describe_context(), m_current_page & 0x1f, voice->lvol);
			break;

		case 0x09:  // RVOL
			if (ACCESSING_BITS_8_15)
				voice->rvol = (voice->rvol & ~0xff) | ((data & 0xff00) >> 8);
			LOG("%s:voice %d, right vol=%02x\n", machine().describe_context(), m_current_page & 0x1f, voice->rvol);
			break;

		case 0x0a:  // ACC (hi)
			if (ACCESSING_BITS_0_7)
				voice->accum = (voice->accum & ~get_address_acc_shifted_val(0x00ff0000)) | (get_address_acc_shifted_val((data & 0x00ff) << 16));
			if (ACCESSING_BITS_8_15)
				voice->accum = (voice->accum & ~get_address_acc_shifted_val(0x1f000000)) | (get_address_acc_shifted_val((data & 0x1f00) << 16));
			LOG("%s:voice %d, accum=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->accum));
			break;

		case 0x0b:  // ACC (lo)
			if (ACCESSING_BITS_0_7)
				voice->accum = (voice->accum & ~get_address_acc_shifted_val(0x000000ff)) | (get_address_acc_shifted_val(data & 0x00ff));
			if (ACCESSING_BITS_8_15)
				voice->accum = (voice->accum & ~get_address_acc_shifted_val(0x0000ff00)) | (get_address_acc_shifted_val(data & 0xff00));
			LOG("%s:voice %d, accum=%08x\n", machine().describe_context(), m_current_page & 0x1f, get_address_acc_res(voice->accum));
			break;

		case 0x0c:  // unused
			break;

		case 0x0d:  // ACT
			if (ACCESSING_BITS_0_7)
			{
				m_active_voices = data & 0x1f;
				m_sample_rate = m_master_clock / (16 * (m_active_voices + 1));
				m_stream->set_sample_rate(m_sample_rate);
				m_sample_rate_changed_cb(m_sample_rate);

				LOG("active voices=%d, sample_rate=%d\n", m_active_voices, m_sample_rate);
			}
			break;

		case 0x0e:  // IRQV - read only
			break;

		case 0x0f:  // PAGE
			if (ACCESSING_BITS_0_7)
				m_current_page = data & 0x7f;
			break;
	}
}

inline void es5505_device::reg_write_high(es550x_voice *voice, offs_t offset, u16 data, u16 mem_mask)
{
	switch (offset)
	{
		case 0x00:  // CR
			voice->control |= 0xf000; // bit 15-12 always 1
			if (ACCESSING_BITS_0_7)
				voice->control = (voice->control & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->control = (voice->control & ~0x0f00) | (data & 0x0f00);

			LOG("%s:voice %d, control=%04x (raw=%04x & %04x)\n", machine().describe_context(), m_current_page & 0x1f, voice->control, data, mem_mask);
			break;

		case 0x01:  // O4(n-1)
			if (ACCESSING_BITS_0_7)
				voice->o4n1 = (voice->o4n1 & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->o4n1 = (s16)((voice->o4n1 & ~0xff00) | (data & 0xff00));
			LOG("%s:voice %d, O4(n-1)=%04x\n", machine().describe_context(), m_current_page & 0x1f, voice->o4n1 & 0xffff);
			break;

		case 0x02:  // O3(n-1)
			if (ACCESSING_BITS_0_7)
				voice->o3n1 = (voice->o3n1 & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->o3n1 = (s16)((voice->o3n1 & ~0xff00) | (data & 0xff00));
			LOG("%s:voice %d, O3(n-1)=%04x\n", machine().describe_context(), m_current_page & 0x1f, voice->o3n1 & 0xffff);
			break;

		case 0x03:  // O3(n-2)
			if (ACCESSING_BITS_0_7)
				voice->o3n2 = (voice->o3n2 & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->o3n2 = (s16)((voice->o3n2 & ~0xff00) | (data & 0xff00));
			LOG("%s:voice %d, O3(n-2)=%04x\n", machine().describe_context(), m_current_page & 0x1f, voice->o3n2 & 0xffff);
			break;

		case 0x04:  // O2(n-1)
			if (ACCESSING_BITS_0_7)
				voice->o2n1 = (voice->o2n1 & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->o2n1 = (s16)((voice->o2n1 & ~0xff00) | (data & 0xff00));
			LOG("%s:voice %d, O2(n-1)=%04x\n", machine().describe_context(), m_current_page & 0x1f, voice->o2n1 & 0xffff);
			break;

		case 0x05:  // O2(n-2)
			if (ACCESSING_BITS_0_7)
				voice->o2n2 = (voice->o2n2 & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->o2n2 = (s16)((voice->o2n2 & ~0xff00) | (data & 0xff00));
			LOG("%s:voice %d, O2(n-2)=%04x\n", machine().describe_context(), m_current_page & 0x1f, voice->o2n2 & 0xffff);
			break;

		case 0x06:  // O1(n-1)
			if (ACCESSING_BITS_0_7)
				voice->o1n1 = (voice->o1n1 & ~0x00ff) | (data & 0x00ff);
			if (ACCESSING_BITS_8_15)
				voice->o1n1 = (s16)((voice->o1n1 & ~0xff00) | (data & 0xff00));
			LOG("%s:voice %d, O1(n-1)=%04x (accum=%08x)\n", machine().describe_context(), m_current_page & 0x1f, voice->o1n1 & 0xffff, get_address_acc_res(voice->accum));
			break;

		case 0x07:
		case 0x08:
		case 0x09:
		case 0x0a:
		case 0x0b:
		case 0x0c:  // unused
			break;

		case 0x0d:  // ACT
			if (ACCESSING_BITS_0_7)
			{
				m_active_voices = data & 0x1f;
				m_sample_rate = m_master_clock / (16 * (m_active_voices + 1));
				m_stream->set_sample_rate(m_sample_rate);
				m_sample_rate_changed_cb(m_sample_rate);

				LOG("active voices=%d, sample_rate=%d\n", m_active_voices, m_sample_rate);
			}
			break;

		case 0x0e:  // IRQV - read only
			break;

		case 0x0f:  // PAGE
			if (ACCESSING_BITS_0_7)
				m_current_page = data & 0x7f;
			break;
	}
}

inline void es5505_device::reg_write_test(es550x_voice *voice, offs_t offset, u16 data, u16 mem_mask)
{
	switch (offset)
	{
		case 0x00:  // CH0L
		case 0x01:  // CH0R
		case 0x02:  // CH1L
		case 0x03:  // CH1R
		case 0x04:  // CH2L
		case 0x05:  // CH2R
		case 0x06:  // CH3L
		case 0x07:  // CH3R
			break;

		case 0x08:  // SERMODE
			m_mode |= 0x7f8; // bit 10-3 always 1
			if (ACCESSING_BITS_8_15)
				m_mode = (m_mode & ~0xf800) | (data & 0xf800); // MSB[4:0] (unknown purpose)
			if (ACCESSING_BITS_0_7)
				m_mode = (m_mode & ~0x0007) | (data & 0x0007); // SONY/BB, TEST, A/D
			LOGMASKED(LOG_SERIAL, "%s: serial mode = %04x & %04x", machine().describe_context(), m_mode, mem_mask);
			break;

		case 0x09:  // PAR
			break;

		case 0x0d:  // ACT
			if (ACCESSING_BITS_0_7)
			{
				m_active_voices = data & 0x1f;
				m_sample_rate = m_master_clock / (16 * (m_active_voices + 1));
				m_stream->set_sample_rate(m_sample_rate);
				m_sample_rate_changed_cb(m_sample_rate);

				LOG("active voices=%d, sample_rate=%d\n", m_active_voices, m_sample_rate);
			}
			break;

		case 0x0e:  // IRQV - read only
			break;

		case 0x0f:  // PAGE
			if (ACCESSING_BITS_0_7)
				m_current_page = data & 0x7f;
			break;
	}
}

void es5505_device::write(offs_t offset, u16 data, u16 mem_mask)
{
	es550x_voice *voice = &m_voice[m_current_page & 0x1f];

//  logerror("%s:ES5505 write %02x/%02x = %04x & %04x\n", machine().describe_context(), m_current_page, offset, data, mem_mask);

	// force an update
	m_stream->update();

	// switch off the page and register
	if (m_current_page < 0x20)
		reg_write_low(voice, offset, data, mem_mask);
	else if (m_current_page < 0x40)
		reg_write_high(voice, offset, data, mem_mask);
	else
		reg_write_test(voice, offset, data, mem_mask);
}

inline u16 es5505_device::reg_read_low(es550x_voice *voice, offs_t offset)
{
	u16 result = 0;

	switch (offset)
	{
		case 0x00:  // CR
			result = voice->control | 0xf000;
			break;

		case 0x01:  // FC
			result = get_address_acc_res(voice->freqcount, 1);
			break;

		case 0x02:  // STRT (hi)
			result = get_address_acc_res(voice->start) >> 16;
			break;

		case 0x03:  // STRT (lo)
			result = get_address_acc_res(voice->start);
			break;

		case 0x04:  // END (hi)
			result = get_address_acc_res(voice->end) >> 16;
			break;

		case 0x05:  // END (lo)
			result = get_address_acc_res(voice->end);
			break;

		case 0x06:  // K2
			result = voice->k2;
			break;

		case 0x07:  // K1
			result = voice->k1;
			break;

		case 0x08:  // LVOL
			result = voice->lvol << 8;
			break;

		case 0x09:  // RVOL
			result = voice->rvol << 8;
			break;

		case 0x0a:  // ACC (hi)
			result = get_address_acc_res(voice->accum) >> 16;
			break;

		case 0x0b:  // ACC (lo)
			result = get_address_acc_res(voice->accum);
			break;

		case 0x0c:  // unused
			break;

		case 0x0d:  // ACT
			result = m_active_voices;
			break;

		case 0x0e:  // IRQV
			result = m_irqv;
			if (!machine().side_effects_disabled())
				update_internal_irq_state();
			break;

		case 0x0f:  // PAGE
			result = m_current_page;
			break;
	}
	return result;
}

inline u16 es5505_device::reg_read_high(es550x_voice *voice, offs_t offset)
{
	u16 result = 0;

	switch (offset)
	{
		case 0x00:  // CR
			result = voice->control | 0xf000;
			break;

		case 0x01:  // O4(n-1)
			result = voice->o4n1 & 0xffff;
			break;

		case 0x02:  // O3(n-1)
			result = voice->o3n1 & 0xffff;
			break;

		case 0x03:  // O3(n-2)
			result = voice->o3n2 & 0xffff;
			break;

		case 0x04:  // O2(n-1)
			result = voice->o2n1 & 0xffff;
			break;

		case 0x05:  // O2(n-2)
			result = voice->o2n2 & 0xffff;
			break;

		case 0x06:  // O1(n-1)
			// special case for the Taito F3 games: they set the accumulator on a stopped
			// voice and assume the filters continue to process the data. They then read
			// the O1(n-1) in order to extract raw data from the sound ROMs. Since we don't
			// want to waste time filtering stopped channels, we just look for a read from
			// this register on a stopped voice, and return the raw sample data at the
			// accumulator
			if ((voice->control & CONTROL_STOPMASK))
			{
				voice->o1n1 = read_sample(voice, get_integer_addr(voice->accum));
				// logerror("%02x %08x ==> %08x\n",voice->o1n1,get_bank(voice->control),get_integer_addr(voice->accum));
			}
			result = voice->o1n1 & 0xffff;
			break;

		case 0x07:
		case 0x08:
		case 0x09:
		case 0x0a:
		case 0x0b:
		case 0x0c:  // unused
			break;

		case 0x0d:  // ACT
			result = m_active_voices;
			break;

		case 0x0e:  // IRQV
			result = m_irqv;
			if (!machine().side_effects_disabled())
				update_internal_irq_state();
			break;

		case 0x0f:  // PAGE
			result = m_current_page;
			break;
	}
	return result;
}

inline u16 es5505_device::reg_read_test(es550x_voice *voice, offs_t offset)
{
	u16 result = 0;

	switch (offset)
	{
		case 0x00:  // CH0L
		case 0x01:  // CH0R
		case 0x02:  // CH1L
		case 0x03:  // CH1R
		case 0x04:  // CH2L
		case 0x05:  // CH2R
		case 0x06:  // CH3L
		case 0x07:  // CH3R
			break;

		case 0x08:  // SERMODE
			result = m_mode | 0x7f8;
			break;

		case 0x09:  // PAR
			if (!m_read_port_cb.isunset())
				result = m_read_port_cb(0) & 0xffc0; // 10 bit, 15:6
			break;

		// The following are global, and thus accessible form all pages
		case 0x0d:  // ACT
			result = m_active_voices;
			break;

		case 0x0e:  // IRQV
			result = m_irqv;
			if (!machine().side_effects_disabled())
				update_internal_irq_state();
			break;

		case 0x0f:  // PAGE
			result = m_current_page;
			break;
	}
	return result;
}

u16 es5505_device::read(offs_t offset)
{
	es550x_voice *voice = &m_voice[m_current_page & 0x1f];
	u16 result;

	LOG("read from %02x/%02x -> ", m_current_page, offset);

	// force an update
	m_stream->update();

	// switch off the page and register
	if (m_current_page < 0x20)
		result = reg_read_low(voice, offset);
	else if (m_current_page < 0x40)
		result = reg_read_high(voice, offset);
	else
		result = reg_read_test(voice, offset);

	LOG("%04x (accum=%08x)\n", result, voice->accum);

	// return the high byte
	return result;
}
