// license:BSD-3-Clause; copyright-holders:Aaron Giles, Christian Brunschen
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <memory>
#include <vector>
#include <algorithm>
#include <cassert>
#include <type_traits>
using u8=uint8_t;using s8=int8_t;using u16=uint16_t;using s16=int16_t;using u32=uint32_t;using s32=int32_t;using u64=uint64_t;using s64=int64_t;using offs_t=u32;
#define ES5506_MAKE_WAVS 0
#define RAINE_CHECK 0
#define LOG(...) ((void)0)
#define LOGMASKED(...) ((void)0)
#define BIT(x,n) (((x)>>(n))&1)
#define ACCESSING_BITS_0_7 (mem_mask&0xff)
#define ACCESSING_BITS_8_15 (mem_mask&0xff00)
namespace util { template<class T>inline std::make_signed_t<T> sext(T v,unsigned n){return std::make_signed_t<T>(int64_t(uint64_t(v)<<(64-n))>>(64-n));} }
inline int64_t mul_32x32(int32_t a,int32_t b){return int64_t(a)*b;}
struct Callback { bool isunset()const{return true;} u32 operator()(u32=0)const{return 0;} };
struct MachineShim { bool side_effects_disabled()const{return false;} const char* describe_context()const{return "";} };inline MachineShim machine(){return {};}
struct sound_stream { float* out=nullptr;void update(){}void set_sample_rate(unsigned){}int samples()const{return 1;}int output_count()const{return 8;}void put_int_clamp(int c,int,s32 v,s32 scale){out[c]=std::clamp(float(v)/float(scale),-1.0f,1.0f);} };
struct address_space{};
