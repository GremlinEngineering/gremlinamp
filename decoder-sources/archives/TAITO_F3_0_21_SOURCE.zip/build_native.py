from pathlib import Path
import subprocess
R=Path(__file__).resolve().parent;S=R/'source';B=R/'build';B.mkdir(exist_ok=True)
flags=['-O2','-fwrapv','-ffp-contract=off','-DM68K_EMULATE_010=0','-DM68K_EMULATE_EC020=0','-DM68K_EMULATE_020=0','-DM68K_EMULATE_030=0','-DM68K_EMULATE_040=0','-DM68K_EMULATE_PMMU=0','-DM68K_EMULATE_INT_ACK=1']
for n in ['m68kcpu','m68kops','softfloat/softfloat']:
 subprocess.run(['clang',*flags,'-c',str(S/'musashi'/(n+'.c')),'-o',str(B/(Path(n).name+'.o'))],check=True)
files=['f3_core.cpp','f3_machine.cpp','es5505.cpp','es5510.cpp','hash/sha256.cpp'];subprocess.run(['clang++','-std=c++17',*flags,'-Wno-deprecated-declarations','-fvisibility=hidden','-dynamiclib','-I'+str(S/'hash'),*[str(S/f)for f in files],str(B/'m68kcpu.o'),str(B/'m68kops.o'),str(B/'softfloat.o'),'-o',str(B/'libgremlin-f3.dylib')],check=True)
