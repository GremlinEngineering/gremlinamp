// Gremlin 076 standalone scheduling/stream glue for pinned original MAME mathematics.
// All electrical components and node step/reset algorithms are in mame_*.inc.
#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <numbers>
#include <stdexcept>
#include <string>
#include <vector>
#define UNEXPECTED(x) (x)
#define EXPECTED(x) (x)
// Little helpers for magnitude conversions
constexpr double RES_R(double res) { return res; }
constexpr double RES_K(double res) { return res * 1e3; }
constexpr double RES_M(double res) { return res * 1e6; }
#define RES_INF    (-1)
constexpr double CAP_U(double cap) { return cap * 1e-6; }
constexpr double CAP_N(double cap) { return cap * 1e-9; }
constexpr double CAP_P(double cap) { return cap * 1e-12; }
constexpr double IND_U(double ind) { return ind * 1e-6; }
constexpr double IND_N(double ind) { return ind * 1e-9; }
constexpr double IND_P(double ind) { return ind * 1e-12; }

//  vin --/\r1/\-- out --/\r2/\-- gnd
constexpr double RES_VOLTAGE_DIVIDER(double r1, double r2) { return r2 / (r1 + r2); }

#define RES_2_PARALLEL(r1, r2)          (((r1) * (r2)) / ((r1) + (r2)))
#define RES_3_PARALLEL(r1, r2, r3)      (1.0 / (1.0 / (r1) + 1.0 / (r2) + 1.0 / (r3)))
#define RES_4_PARALLEL(r1, r2, r3, r4)  (1.0 / (1.0 / (r1) + 1.0 / (r2) + 1.0 / (r3) + 1.0 / (r4)))
#define RES_5_PARALLEL(r1, r2, r3, r4, r5)  (1.0 / (1.0 / (r1) + 1.0 / (r2) + 1.0 / (r3) + 1.0 / (r4) + 1.0 / (r5)))
#define RES_6_PARALLEL(r1, r2, r3, r4, r5, r6)  (1.0 / (1.0 / (r1) + 1.0 / (r2) + 1.0 / (r3) + 1.0 / (r4) + 1.0 / (r5) + 1.0 / (r6)))

#define RES_2_SERIAL(r1,r2)             ((r1)+(r2))

[[noreturn]] inline void fatalerror(const char *fmt,...){char b[1024];va_list a;va_start(a,fmt);vsnprintf(b,sizeof(b),fmt,a);va_end(a);throw std::runtime_error(b);}
using osd_ticks_t=uint64_t;
#include "mame_constants.h"
struct discrete_block {
 int node;
 std::unique_ptr<discrete_base_node>(*factory)(discrete_device&,const discrete_block&);
 int type,active_inputs;
 int input_node[DISCRETE_MAX_INPUTS];double initial[DISCRETE_MAX_INPUTS];
 const void *custom;const char *name,*mod_name;
};
class discrete_step_interface {public:virtual ~discrete_step_interface(){};virtual void step()=0;osd_ticks_t run_time=0;discrete_base_node*self=nullptr;};
class discrete_input_interface {public:virtual ~discrete_input_interface(){};virtual void input_write(int,uint8_t)=0;};
struct ioport_port {int read(){return 90;}};
class discrete_device {
 public:
 int rate=48000;std::vector<std::unique_ptr<discrete_base_node>> nodes;
 std::vector<discrete_step_interface*> steps;
 discrete_base_node *indexed[DISCRETE_MAX_NODES+1]{};discrete_base_node *output=nullptr;
 ioport_port adjust;
 int sample_rate(){return rate;}double sample_time(){return 1.0/rate;}
 const double *node_output_ptr(int n);
 discrete_base_node *discrete_find_node(int n);
 template<class...T>void discrete_log(const char*f,T...v){fprintf(stderr,f,v...);}
 template<class...T>void logerror(const char*f,T...v){fprintf(stderr,f,v...);}
 void update_to_current_time(){} // Caller renders up to the exact timestamp first.
 discrete_device&machine(){return *this;}discrete_device&root_device(){return *this;}
 std::string siblingtag(const char*t){return t;}
 ioport_port*ioport(const char*t){if(std::string(t)!="VR2")fatalerror("unsupported adjustment");return &adjust;}
 void build(const discrete_block*blocks);void reset();
 void write(int n,uint8_t value);float sample(double route);
};
class discrete_base_node {
 public:
 virtual ~discrete_base_node(){};virtual void reset(){};virtual void start(){};virtual void stop(){};virtual int max_output(){return 1;}
 double input(int n){return *m_input[n];}void set_output(int n,double value){m_output[n]=value;}
 int index(){return NODE_INDEX(m_block->node);}int block_node()const{return m_block->node;}
 const void*custom_data(){return m_block->custom;}int input_node(int n){return m_block->input_node[n];}
 int active_inputs(){return m_block->active_inputs;}int input_is_node(){return m_input_is_node;}
 double sample_time(){return m_device->sample_time();}int sample_rate(){return m_device->sample_rate();}
 const char*module_name(){return m_block->mod_name;}int module_type(){return m_block->type;}
 void init(discrete_device*d,const discrete_block*b){m_device=d;m_block=b;}
 void resolve();
 double m_output[DISCRETE_MAX_OUTPUTS]{};
 protected:
 const double*m_input[DISCRETE_MAX_INPUTS]{};discrete_device*m_device=nullptr;
 const discrete_block*m_block=nullptr;int m_input_is_node=0;
};
template<class C>class discrete_node_factory{public:static std::unique_ptr<discrete_base_node>create(discrete_device&d,const discrete_block&b){auto r=std::make_unique<C>();r->init(&d,&b);return r;}};
#include "mame_declarations.h"
// Framework adapters: byte-valued DAC stream and float output transport.
class discrete_dss_input_buffer_node:public discrete_base_node,public discrete_input_interface {
 public:void reset()override{set_output(0,0);}void input_write(int,uint8_t value)override{set_output(0,value);}
};
class discrete_dso_output_node:public discrete_base_node,public discrete_step_interface {
 public:void step()override{set_output(0,input(0)*input(1)*(1.0/32768.0));}
};
#include "mame_dsl.h"
struct GremlinClock {double value;double dvalue()const{return value;}};
// Original DK master crystal /5/4/16/12/2/2 = 4000 Hz.
static constexpr GremlinClock CLOCK_2VF{4000};
#include "mame_math.inc"
#include "mame_graphs.inc"
inline discrete_base_node*discrete_device::discrete_find_node(int n){return n>NODE_START&&n<NODE_END?indexed[NODE_INDEX(n)]:nullptr;}
inline const double*discrete_device::node_output_ptr(int n){auto p=discrete_find_node(n);return p?&p->m_output[NODE_CHILD_NODE_NUM(n)]:nullptr;}
inline void discrete_base_node::resolve(){
 for(int i=0;i<active_inputs();i++){
  int n=m_block->input_node[i];
  if(IS_VALUE_A_NODE(n)){
   auto p=m_device->discrete_find_node(n);if(!p||NODE_CHILD_NODE_NUM(n)>=p->max_output())fatalerror("missing graph input %d",n);
   m_input[i]=&p->m_output[NODE_CHILD_NODE_NUM(n)];m_input_is_node|=1<<i;
  }else{if(IS_VALUE_A_NODE(m_block->initial[i]))fatalerror("node on static graph input");m_input[i]=&m_block->initial[i];}
 }
 for(int i=active_inputs();i<DISCRETE_MAX_INPUTS;i++)m_input[i]=&m_block->initial[i];
}
inline void discrete_device::build(const discrete_block*b){
 for(;b->type!=DSS_NULL;b++){
  if(b->type==DSO_TASK_START||b->type==DSO_TASK_END)continue;
  auto n=b->factory(*this,*b);auto p=n.get();
  if(b->node!=NODE_SPECIAL){if(indexed[NODE_INDEX(b->node)])fatalerror("duplicate graph node");indexed[NODE_INDEX(b->node)]=p;}
  if(b->type==DSO_OUTPUT)output=p;
  if(auto s=dynamic_cast<discrete_step_interface*>(p))steps.push_back(s);
  nodes.push_back(std::move(n));
 }
 for(auto&n:nodes)n->resolve();for(auto&n:nodes)n->start();reset();
}
inline void discrete_device::reset(){for(auto&n:nodes){n->m_output[0]=0;n->reset();}}
inline void discrete_device::write(int n,uint8_t value){auto p=discrete_find_node(n);auto i=dynamic_cast<discrete_input_interface*>(p);if(!i)fatalerror("not graph input %d",n);i->input_write(0,value);}
inline float discrete_device::sample(double route){for(auto*s:steps)s->step();return float(output->m_output[0])*float(route);}
