// Pinned MAME BSD-3-Clause excerpts; see source-receipts.json and originals.
#define DISCRETE_CLASS_NAME(_name) discrete_ ## _name ## _node

#define DISCRETE_CLASS_INPUT(_name, _num)   inline double _name() { return *(m_input[_num]); }

#define DISCRETE_CLASS_CONSTRUCTOR(_name, _base)                        \
	public:                                                             \
		DISCRETE_CLASS_NAME(_name)()                                    \
			: DISCRETE_CLASS_NAME(_base)() { }

#define DISCRETE_CLASS_DESTRUCTOR(_name)                                \
	public:                                                             \
		virtual ~ DISCRETE_CLASS_NAME(_name)() { }

#define  DISCRETE_CLASS_STEP_RESET(_name, _maxout, _priv)               \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node, public discrete_step_interface         \
{                                                                       \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
public:                                                                 \
	virtual void step() override;                                       \
	virtual void reset() override;                                      \
	virtual int max_output() override { return _maxout; }               \
private:                                                                \
	_priv                                                               \
}

#define DISCRETE_CLASS_STEP(_name, _maxout, _priv)                      \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node, public discrete_step_interface             \
{                                                                       \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
public:                                                                 \
	virtual void step() override;                                       \
	virtual void reset() override  { this->step(); }                    \
	virtual int max_output() override { return _maxout; }               \
private:                                                                \
	_priv                                                               \
}

#define DISCRETE_CLASS_RESET(_name, _maxout)                            \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node             \
{                                                                       \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
public:                                                                 \
	virtual void reset() override;                                      \
	virtual int max_output() override { return _maxout; }               \
}

#define DISCRETE_CLASS(_name, _maxout, _priv)                      \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node, public discrete_step_interface             \
{                                                                       \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
public:                                                                 \
	virtual void step() override;                                       \
	virtual void reset() override;                                      \
	virtual void start() override;                                      \
	virtual void stop() override;                                       \
	virtual int max_output() override { return _maxout; }               \
private:                                                                \
	_priv                                                               \
}

class DISCRETE_CLASS_NAME(special): public discrete_base_node
{
	DISCRETE_CLASS_CONSTRUCTOR(special, base)
	DISCRETE_CLASS_DESTRUCTOR(special)
public:
	virtual int max_output() override { return 0; }
};

class DISCRETE_CLASS_NAME(unimplemented): public discrete_base_node
{
	DISCRETE_CLASS_CONSTRUCTOR(unimplemented, base)
	DISCRETE_CLASS_DESTRUCTOR(unimplemented)
public:
	virtual int max_output() override { return 0; }
};

class DISCRETE_CLASS_NAME(dss_adjustment): public discrete_base_node, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_adjustment, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_adjustment)
public:
	virtual void step() override;
	virtual void reset() override;
private:
	ioport_port *m_port = 0;
	int32_t                 m_lastpval = 0;
	int32_t                 m_pmin = 0;
	double                  m_pscale = 0.0;
	double                  m_min = 0.0;
	double                  m_scale = 0.0;
};

DISCRETE_CLASS_RESET(dss_constant, 1);

class DISCRETE_CLASS_NAME(dss_input_data): public discrete_base_node, public discrete_input_interface
{
	DISCRETE_CLASS_DESTRUCTOR(dss_input_data)
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_data, base)
public:
	virtual void reset() override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	double      m_gain = 0.0;       /* node gain */
	double      m_offset = 0.0;     /* node offset */
	uint8_t     m_data = 0;         /* data written */
};

class DISCRETE_CLASS_NAME(dss_input_logic): public discrete_base_node, public discrete_input_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_logic, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_input_logic)
public:
	virtual void reset() override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	double      m_gain = 0.0;       /* node gain */
	double      m_offset = 0.0;     /* node offset */
	uint8_t     m_data = 0;         /* data written */
};

class DISCRETE_CLASS_NAME(dss_input_not): public discrete_base_node, public discrete_input_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_not, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_input_not)
public:
	virtual void reset() override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	double      m_gain = 0.0;       /* node gain */
	double      m_offset = 0.0;     /* node offset */
	uint8_t     m_data = 0;         /* data written */
};



DISCRETE_CLASS_STEP_RESET(dss_counter, 1,
	int             m_clock_type = 0;
	int             m_out_type = 0;
	int             m_is_7492 = 0;
	int             m_last_clock = 0;
	uint32_t        m_last_count = 0;
	//uint32_t        m_last = 0;             /* Last clock state */
	uint32_t        m_min = 0;
	uint32_t        m_max = 0;
	uint32_t        m_diff = 0;
	double          m_t_left = 0.0;         /* time unused during last sample in seconds */
);

DISCRETE_CLASS_STEP_RESET(dss_lfsr_noise, 2,
	unsigned int    m_lfsr_reg = 0;
	int             m_last = 0;             /* Last clock state */
	double          m_t_clock = 0.0;        /* fixed counter clock in seconds */
	double          m_t_left = 0.0;         /* time unused during last sample in seconds */
	//double          m_sample_step = 0.0;
	//double          m_t = 0.0;
	uint8_t         m_reset_on_high = 0;
	uint8_t         m_invert_output = 0;
	uint8_t         m_out_is_f0 = 0;
	uint8_t         m_out_lfsr_reg = 0;
);

DISCRETE_CLASS_STEP_RESET(dss_noise, 2,
	double          m_phase = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dss_note, 1,
	int             m_clock_type = 0;
	int             m_out_type = 0;
	int             m_last = 0;             /* Last clock state */
	double          m_t_clock = 0.0;        /* fixed counter clock in seconds */
	double          m_t_left = 0.0;         /* time unused during last sample in seconds */
	int             m_max1 = 0;             /* Max 1 Count stored as int for easy use. */
	int             m_max2 = 0;             /* Max 2 Count stored as int for easy use. */
	int             m_count1 = 0;           /* current count1 */
	int             m_count2 = 0;           /* current count2 */
);

DISCRETE_CLASS_STEP_RESET(dss_sawtoothwave, 1,
	double          m_phase = 0.0;
	int             m_type = 0;
);

DISCRETE_CLASS_STEP_RESET(dss_sinewave, 1,
	double          m_phase = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dss_squarewave, 1,
	double          m_phase = 0.0;
	double          m_trigger = 0.0;
);
DISCRETE_CLASS_STEP_RESET(dss_squarewfix, 1,
	int             m_flip_flop = 0;
	double          m_sample_step = 0.0;
	double          m_t_left = 0.0;
	double          m_t_off = 0.0;
	double          m_t_on = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dss_squarewave2, 1,
	double          m_phase = 0.0;
	double          m_trigger = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dss_trianglewave, 1,
	double          m_phase = 0.0;
);

/* Component specific modules */

#define DSS_INV_TAB_SIZE    500
#define DEFAULT_CD40XX_VALUES(_vB)  (_vB),(_vB)*0.02,(_vB)*0.98,(_vB)/5.0*1.5,(_vB)/5.0*3.5, 0.1

class DISCRETE_CLASS_NAME(dss_inverter_osc): public discrete_base_node, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_inverter_osc, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_inverter_osc)
public:
	struct description
	{
		double  vB = 0.0;
		double  vOutLow = 0.0;
		double  vOutHigh = 0.0;
		double  vInFall = 0.0;  // voltage that triggers the gate input to go low (0V) on fall
		double  vInRise = 0.0;  // voltage that triggers the gate input to go high (vGate) on rise
		double  clamp = 0.0;    // voltage is clamped to -clamp ... vb+clamp if clamp>= 0;
		int     options = 0.0;  // bitmapped options
	};
	enum {
		IS_TYPE1 = 0x00,
		IS_TYPE2 = 0x01,
		IS_TYPE3 = 0x02,
		IS_TYPE4 = 0x03,
		IS_TYPE5 = 0x04,
		TYPE_MASK = 0x0f,
		OUT_IS_LOGIC = 0x10
	};
	void step() override;
	void reset() override;
protected:
	inline double tftab(double x);
	inline double tf(double x);
private:
	DISCRETE_CLASS_INPUT(I_ENABLE,  0);
	DISCRETE_CLASS_INPUT(I_MOD,     1);
	DISCRETE_CLASS_INPUT(I_RC,      2);
	DISCRETE_CLASS_INPUT(I_RP,      3);
	DISCRETE_CLASS_INPUT(I_C,       4);
	DISCRETE_CLASS_INPUT(I_R2,      5);

	double          mc_v_cap = 0.0;
	double          mc_v_g2_old = 0.0;
	double          mc_w = 0.0;
	double          mc_wc = 0.0;
	double          mc_rp = 0.0;
	double          mc_r1 = 0.0;
	double          mc_r2 = 0.0;
	double          mc_c = 0.0;
	double          mc_tf_a = 0.0;
	double          mc_tf_b = 0.0;
	double          mc_tf_tab[DSS_INV_TAB_SIZE]{ 0.0 };
};

DISCRETE_CLASS_STEP_RESET(dss_op_amp_osc, 1,
	const double *  m_r[8]{ nullptr };      /* pointers to resistor values */
	int             m_type = 0;
	uint8_t         m_flip_flop = 0;        /* flip/flop output state */
	uint8_t         m_flip_flop_xor = 0;    /* flip_flop ^ flip_flop_xor, 0 = discharge, 1 = charge */
	uint8_t         m_output_type = 0;
	uint8_t         m_has_enable = 0;
	double          m_v_out_high = 0.0;
	double          m_threshold_low = 0.0;  /* falling threshold */
	double          m_threshold_high = 0.0; /* rising threshold */
	double          m_v_cap = 0.0;          /* current capacitor voltage */
	double          m_r_total = 0.0;        /* all input resistors in parallel */
	double          m_i_fixed = 0.0;        /* fixed current at the input */
	double          m_i_enable = 0.0;       /* fixed current at the input if enabled */
	double          m_temp1 = 0.0;          /* Multi purpose */
	double          m_temp2 = 0.0;          /* Multi purpose */
	double          m_temp3 = 0.0;          /* Multi purpose */
	double          m_is_linear_charge = 0.0;
	double          m_charge_rc[2]{ 0.0 };
	double          m_charge_exp[2]{ 0.0 };
	double          m_charge_v[2]{ 0.0 };
);

DISCRETE_CLASS_STEP_RESET(dss_schmitt_osc, 1,
	double          m_ration_in = 0.0;      /* ratio of total charging voltage that comes from the input */
	double          m_ratio_feedback = 0.0; /* ratio of total charging voltage that comes from the feedback */
	double          m_v_cap = 0.0;          /* current capacitor voltage */
	double          m_rc = 0.0;             /* r*c */
	double          m_exponent = 0.0;
	int             m_state = 0;            /* state of the output */
	int             m_enable_type = 0;
	uint8_t         m_input_is_voltage = 0;
);

/* Not yet implemented */
DISCRETE_CLASS_STEP_RESET(dss_adsrenv,  1,
	//double          m_phase = 0.0;
);





DISCRETE_CLASS_STEP(dst_adder, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_clamp, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_divide, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_gain, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_inv, 1, /* no context */ );

DISCRETE_CLASS_STEP_RESET(dst_bits_decode, 8,
	int             m_count = 0;
	int             m_decode_x_time = 0;
	int             m_from = 0;
	int             m_last_val = 0;
	int             m_last_had_x_time = 0;
);

DISCRETE_CLASS_STEP(dst_logic_and, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_nand, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_or, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_nor, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_xor, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_nxor, 1, /* no context */ );

DISCRETE_CLASS_STEP_RESET(dst_logic_dff, 1,
	int             m_last_clk = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_logic_jkff, 1,
	double          m_v_out = 0;
	int             m_last_clk = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_logic_shift, 1,
	double          m_t_left = 0.0;             /* time unused during last sample in seconds */
	uint32_t        m_shift_data = 0;
	uint32_t        m_bit_mask = 0;
	uint8_t         m_clock_type = 0;
	uint8_t         m_reset_on_high = 0;
	uint8_t         m_shift_r = 0;
	uint8_t         m_last = 0;
);

DISCRETE_CLASS_STEP(dst_lookup_table, 1, /* no context */ );

DISCRETE_CLASS_STEP_RESET(dst_multiplex, 1,
	int             m_size = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_oneshot, 1,
	double          m_countdown = 0.0;
	int             m_state = 0;
	int             m_last_trig = 0;
	int             m_type = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_ramp, 1,
	double          m_v_out = 0.0;
	double          m_step = 0.0;
	int             m_dir = 0;              /* 1 if End is higher then Start */
	int             m_last_en = 0;          /* Keep track of the last enable value */
);

DISCRETE_CLASS_STEP_RESET(dst_samphold, 1,
	double          m_last_input = 0.0;
	int             m_clocktype = 0;
);

DISCRETE_CLASS_STEP(dst_switch, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_aswitch, 1, /* no context */ );

DISCRETE_CLASS_STEP(, 1, /* no context */ );
class DISCRETE_CLASS_NAME(dst_transform): public discrete_base_node, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dst_transform, base)
	DISCRETE_CLASS_DESTRUCTOR(dst_transform)
public:
	enum token {
		TOK_END = 0,
		TOK_MULT,
		TOK_DIV,
		TOK_ADD,
		TOK_MINUS,
		TOK_0,
		TOK_1,
		TOK_2,
		TOK_3,
		TOK_4,
		TOK_DUP,
		TOK_ABS,         /* absolute value */
		TOK_NEG,         /* * -1 */
		TOK_NOT,         /* Logical NOT of Last Value */
		TOK_EQUAL,       /* Logical = */
		TOK_GREATER,     /* Logical > */
		TOK_LESS,        /* Logical < */
		TOK_AND,         /* Bitwise AND */
		TOK_OR,          /* Bitwise OR */
		TOK_XOR          /* Bitwise XOR */
	};
	void step() override;
	void reset() override;
private:
	DISCRETE_CLASS_INPUT(I_IN0,     0);
	DISCRETE_CLASS_INPUT(I_IN1,     1);
	DISCRETE_CLASS_INPUT(I_IN2,     2);
	DISCRETE_CLASS_INPUT(I_IN3,     3);
	DISCRETE_CLASS_INPUT(I_IN4,     4);
	enum token precomp[32]{ TOK_END };
};

/* Component specific */

DISCRETE_CLASS_STEP_RESET(dst_comp_adder, 1,
	double          m_total[256]{ 0.0 };
);

DISCRETE_CLASS_STEP_RESET(dst_dac_r1, 1,
	double          m_v_out = 0.0;
	double          m_exponent = 0.0;
	double          m_last_v = 0.0;
	double          m_v_step[256]{ 0.0 };
	int             m_has_c_filter = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_diode_mix, 1,
	int             m_size = 0;
	double          m_v_junction[8]{ 0.0 };
);

DISCRETE_CLASS_STEP_RESET(dst_integrate, 1,
	double          m_v_out = 0.0;
	double          m_change = 0.0;
	double          m_v_max_in = 0.0;       /* v1 - norton VBE */
	double          m_v_max_in_d = 0.0;     /* v1 - norton VBE - diode drop */
	double          m_v_max_out = 0.0;
);

#define DISC_MIXER_MAX_INPS 8
DISCRETE_CLASS_STEP_RESET(dst_mixer, 1,
	int             m_type = 0;
	int             m_size = 0;
	int             m_r_node_bit_flag = 0;
	int             m_c_bit_flag = 0;
	double          m_r_total = 0.0;
	const double *  m_r_node[DISC_MIXER_MAX_INPS]{ nullptr };      /* Either pointer to resistance node output OR nullptr */
	double          m_r_last[DISC_MIXER_MAX_INPS]{ 0.0 };
	double          m_exponent_rc[DISC_MIXER_MAX_INPS]{ 0.0 }; /* For high pass filtering cause by cIn */
	double          m_v_cap[DISC_MIXER_MAX_INPS]{ 0.0 };       /* cap voltage of each input */
	double          m_exponent_c_f = 0.0;   /* Low pass on mixed inputs */
	double          m_exponent_c_amp = 0.0; /* Final high pass caused by out cap and amp input impedance */
	double          m_v_cap_f = 0.0;        /* cap voltage of cF */
	double          m_v_cap_amp = 0.0;      /* cap voltage of cAmp */
	double          m_gain = 0.0;           /* used for DISC_MIXER_IS_OP_AMP_WITH_RI */
);

DISCRETE_CLASS_STEP_RESET(dst_op_amp, 1,
	uint8_t         m_has_cap = 0;
	uint8_t         m_has_r1 = 0;
	uint8_t         m_has_r4 = 0;
	double          m_v_max = 0.0;
	double          m_i_fixed = 0.0;
	double          m_v_cap = 0.0;
	double          m_exponent = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dst_op_amp_1sht, 1,
	double          m_v_out = 0.0;
	double          m_i_fixed = 0.0;
	double          m_v_max = 0.0;
	double          m_r34ratio = 0.0;
	double          m_v_cap1 = 0.0;
	double          m_v_cap2 = 0.0;
	double          m_exponent1c = 0.0;
	double          m_exponent1d = 0.0;
	double          m_exponent2 = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dst_tvca_op_amp, 1,
	double          m_v_out_max = 0.0;      /* Maximum output voltage */
	double          m_v_trig[2]{ 0.0 };     /* Voltage used to charge cap1 based on function F3 */
	double          m_v_trig2 = 0.0;        /* Voltage used to charge cap2 */
	double          m_v_trig3 = 0.0;        /* Voltage used to charge cap3 */
	double          m_i_fixed = 0.0;        /* Fixed current going into - input */
	double          m_exponent_c[2]{ 0.0 }; /* Charge exponents based on function F3 */
	double          m_exponent_d[2]{ 0.0 }; /* Discharge exponents based on function F3 */
	double          m_exponent2[2]{ 0.0 };  /* Discharge/charge exponents based on function F4 */
	double          m_exponent3[2]{ 0.0 };  /* Discharge/charge exponents based on function F5 */
	double          m_exponent4 = 0.0;      /* Discharge/charge exponents for c4 */
	double          m_v_cap1 = 0.0;         /* charge on cap c1 */
	double          m_v_cap2 = 0.0;         /* charge on cap c2 */
	double          m_v_cap3 = 0.0;         /* charge on cap c3 */
	double          m_v_cap4 = 0.0;         /* charge on cap c4 */
	double          m_r67 = 0.0;            /* = r6 + r7 (for easy use later) */
	uint8_t         m_has_c4 = 0;
	uint8_t         m_has_r4 = 0;
);

DISCRETE_CLASS_STEP(dst_xtime_buffer, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_xtime_and, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_xtime_or, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_xtime_xor, 1, /* no context */ );





struct discrete_filter_coeff
{
	double x1 = 0.0, x2 = 0.0;              /* x[k-1], x[k-2], previous 2 input values */
	double y1 = 0.0, y2 = 0.0;              /* y[k-1], y[k-2], previous 2 output values */
	double a1 = 0.0, a2 = 0.0;              /* digital filter coefficients, denominator */
	double b0 = 0.0, b1 = 0.0, b2 = 0.0;    /* digital filter coefficients, numerator */
};


DISCRETE_CLASS_STEP_RESET(dst_filter1, 1,
	/* uses x1, y1, a1, b0, b1 */
	discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_filter2, 1,
	discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_sallen_key, 1,
	discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_crfilter, 1,
	double          m_vCap = 0.0;
	double          m_rc = 0.0;
	double          m_exponent = 0.0;
	uint8_t         m_has_rc_nodes = 0;
	//uint8_t         m_is_fast = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_op_amp_filt, 1,
	int             m_type = 0;             /* What kind of filter */
	int             m_is_norton = 0;        /* 1 = Norton op-amps */
	double          m_vRef = 0.0;
	double          m_vP = 0.0;
	double          m_vN = 0.0;
	double          m_rTotal = 0.0;         /* All input resistance in parallel. */
	double          m_iFixed = 0.0;         /* Current supplied by r3 & r4 if used. */
	double          m_exponentC1 = 0.0;
	double          m_exponentC2 = 0.0;
	double          m_exponentC3 = 0.0;
	double          m_rRatio = 0.0;         /* divide ratio of resistance network */
	double          m_vC1 = 0.0;            /* Charge on C1 */
	double          m_vC1b = 0.0;           /* Charge on C1, part of C1 charge if needed */
	double          m_vC2 = 0.0;            /* Charge on C2 */
	double          m_vC3 = 0.0;            /* Charge on C2 */
	double          m_gain = 0.0;           /* Gain of the filter */
	discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_rc_circuit_1, 1,
	double          m_v_cap = 0.0;
	double          m_v_charge_1_2 = 0.0;
	double          m_v_drop = 0.0;
	double          m_exp_1 = 0.0;
	double          m_exp_1_2 = 0.0;
	double          m_exp_2 = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc, 1,
	int             m_state = 0;
	double          m_t = 0.0;              /* time */
	double          m_exponent0 = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc2, 1,
	int             m_state = 0;
	double          m_v_out = 0.0;
	double          m_t = 0.0;              /* time */
	double          m_exponent0 = 0.0;
	double          m_exponent1 = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc3, 1,
	int             m_state = 0;
	double          m_v_out = 0.0;
	double          m_t = 0.0;              /* time */
	double          m_exponent0 = 0.0;
	double          m_exponent1 = 0.0;
	double          m_v_diode = 0.0;        /* rcdisc3 */
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc4, 1,
	int             m_type = 0;
	double          m_max_out = 0.0;
	double          m_vC1 = 0.0;
	double          m_v[2]{ 0.0 };
	double          m_exp[2]{ 0.0 };
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc5, 1,
	int             m_state = 0;
	double          m_t = 0.0;              /* time */
	double          m_exponent0 = 0.0;
	double          m_v_cap = 0.0;          /* rcdisc5 */
);

DISCRETE_CLASS_STEP_RESET(dst_rcintegrate, 1,
	int             m_type = 0;
	double          m_gain_r1_r2 = 0.0;
	double          m_f = 0.0;              /* r2,r3 gain */
	double          m_vCap = 0.0;
	double          m_vCE = 0.0;
	double          m_exponent0 = 0.0;
	double          m_exponent1 = 0.0;
	double          m_exp_exponent0 = 0.0;
	double          m_exp_exponent1 = 0.0;
	double          m_c_exp0 = 0.0;
	double          m_c_exp1 = 0.0;
	double          m_EM_IC_0_7 = 0.0;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc_mod, 1,
	double          m_v_cap = 0.0;
	double          m_exp_low[2]{ 0.0 };
	double          m_exp_high[4]{ 0.0 };
	double          m_gain[2]{ 0.0 };
	double          m_vd_gain[4]{ 0.0 };
);

DISCRETE_CLASS_STEP_RESET(dst_rcfilter, 1,
	double          m_v_out = 0.0;
	double          m_vCap = 0.0;
	double          m_rc = 0.0;
	double          m_exponent = 0.0;
	uint8_t         m_has_rc_nodes = 0;
	uint8_t         m_is_fast = 0;
);

DISCRETE_CLASS_STEP_RESET(dst_rcfilter_sw, 1,
	double          m_vCap[4]{ 0.0 };
	double          m_exp[4]{ 0.0 };
	double          m_exp0 = 0.0;           /* fast case bit 0 */
	double          m_exp1 = 0.0;           /* fast case bit 1 */
	double          m_factor = 0.0;         /* fast case */
	double          m_f1[16]{ 0.0 };
	double          m_f2[16]{ 0.0 };
);

DISCRETE_CLASS_STEP_RESET(dst_rcdiscN, 1,
	double          m_x1 = 0.0;             /* x[k-1], previous input value */
	double          m_y1 = 0.0;             /* y[k-1], previous output value */
	double          m_a1 = 0.0;             /* digital filter coefficients, denominator */
	//double          m_b[2]{ 0.0 };          /* digital filter coefficients, numerator */
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc2N, 1,
	discrete_filter_coeff m_fc0;
	discrete_filter_coeff m_fc1;
	double          m_x1 = 0.0;
	double          m_y1 = 0.0;
);





DISCRETE_CLASS_STEP_RESET(dsd_555_astbl, 1,
	int             m_use_ctrlv;
	int             m_output_type;
	int             m_output_is_ac;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* 555 flip/flop output state */
	double          m_cap_voltage;              /* voltage on cap */
	double          m_threshold;
	double          m_trigger;
	double          m_v_out_high;               /* Logic 1 voltage level */
	double          m_v_charge;
	const double *  m_v_charge_node;            /* point to output of node */
	int             m_has_rc_nodes;
	double          m_exp_bleed;
	double          m_exp_charge;
	double          m_exp_discharge;
	double          m_t_rc_bleed;
	double          m_t_rc_charge;
	double          m_t_rc_discharge;
	double          m_last_r1;
	double          m_last_r2;
	double          m_last_c;
);

DISCRETE_CLASS_STEP_RESET(dsd_555_mstbl, 1,
	int             m_trig_is_logic;
	int             m_trig_discharges_cap;
	int             m_output_type;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* 555 flip/flop output state */
	int             m_has_rc_nodes;
	double          m_exp_charge;
	double          m_cap_voltage;              /* voltage on cap */
	double          m_threshold;
	double          m_trigger;
	double          m_v_out_high;               /* Logic 1 voltage level */
	double          m_v_charge;
);

DISCRETE_CLASS_STEP_RESET(dsd_555_cc, 1,
	unsigned int    m_type;                     /* type of 555cc circuit */
	int             m_output_type;
	int             m_output_is_ac;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* 555 flip/flop output state */
	double          m_cap_voltage;              /* voltage on cap */
	double          m_threshold;
	double          m_trigger;
	double          m_v_out_high;               /* Logic 1 voltage level */
	double          m_v_cc_source;
	int             m_has_rc_nodes;
	double          m_exp_bleed;
	double          m_exp_charge;
	double          m_exp_discharge;
	double          m_exp_discharge_01;
	double          m_exp_discharge_no_i;
	double          m_t_rc_charge;
	double          m_t_rc_discharge;
	double          m_t_rc_discharge_01;
	double          m_t_rc_discharge_no_i;
);

DISCRETE_CLASS_STEP_RESET(dsd_555_vco1, 1,
	int             m_ctrlv_is_node;
	int             m_output_type;
	int             m_output_is_ac;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* flip/flop output state */
	double          m_v_out_high;               /* 555 high voltage */
	double          m_threshold;                /* falling threshold */
	double          m_trigger;                  /* rising threshold */
	double          m_i_charge;                 /* charge current */
	double          m_i_discharge;              /* discharge current */
	double          m_cap_voltage;              /* current capacitor voltage */
);

DISCRETE_CLASS_STEP_RESET(dsd_566, 1,
	//unsigned int    m_state[2];                 /* keeps track of excess flip_flop changes during the current step */
	int             m_flip_flop;                /* 566 flip/flop output state */
	double          m_cap_voltage;              /* voltage on cap */
	double          m_v_sqr_low;                /* voltage for a squarewave at low */
	double          m_v_sqr_high;               /* voltage for a squarewave at high */
	double          m_v_sqr_diff;
	double          m_threshold_low;            /* falling threshold */
	double          m_threshold_high;           /* rising threshold */
	double          m_ac_shift;                 /* used to fake AC */
	double          m_v_osc_stable;
	double          m_v_osc_stop;
	int             m_fake_ac;
	int             m_out_type;
);

DISCRETE_CLASS_STEP_RESET(dsd_ls624, 1,
	double          m_exponent;
	double          m_t_used;
	double          m_v_cap_freq_in;
	double          m_v_freq_scale;
	double          m_v_rng_scale;
	int             m_flip_flop;
	int             m_has_freq_in_cap;
	int             m_out_type;
);



