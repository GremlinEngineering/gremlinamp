from pathlib import Path
import difflib
R=Path(__file__).resolve().parent
p=R/'fbneo-research/src/burn/drv/pre90s/d_dkong.cpp'
s=p.read_text(); (R/'d_dkong.original.cpp').write_text(s)
anchor='static void sync_sound()'
observer='''// Gremlin 076: read-only MCU input/output observer; original emulation unchanged.
static UINT64 gremlin_mcu_base = 0;
static FILE *gremlin_mcu_log = nullptr;
static void gremlin_mcu_event(UINT32 kind, UINT32 value) {
 if (!gremlin_mcu_log) { const char *p = getenv("GREMLIN_MCU_TRACE"); if (p) gremlin_mcu_log = fopen(p, "ab"); }
 if (gremlin_mcu_log) { UINT64 cycle = gremlin_mcu_base + (UINT32)mcs48TotalCycles(); fwrite(&cycle,8,1,gremlin_mcu_log); fwrite(&kind,4,1,gremlin_mcu_log); fwrite(&value,4,1,gremlin_mcu_log); }
}

'''
s=s.replace(anchor,observer+anchor,1)
for fname,end in [('dkong_main_write','static UINT8'),('dkongjr_main_write','static void __fastcall radarscp_main_write')]:
 start=s.index('static void __fastcall '+fname); stop=s.index(end,start+10);part=s[start:stop]
 part=part.replace('sync_sound();','sync_sound();\n\t\t\tgremlin_mcu_event(address, data);')
 s=s[:start]+part+s[stop:]
s=s.replace('static void i8039_sound_write_port(UINT32 port, UINT8 data)\n{','static void i8039_sound_write_port(UINT32 port, UINT8 data)\n{\n\tgremlin_mcu_event(0x10000 | port, data);',1)
s=s.replace('\tmcs48NewFrame();','\tmcs48Open(0);\n\tgremlin_mcu_base += (UINT32)mcs48TotalCycles();\n\tmcs48Close();\n\tmcs48NewFrame();',1)
s=s.replace('static INT32 DrvDoReset()\n{','static INT32 DrvDoReset()\n{\n\tgremlin_mcu_base = 0;',1)
p.write_text(s)
(R/'observer.patch').write_text(''.join(difflib.unified_diff((R/'d_dkong.original.cpp').read_text().splitlines(True),s.splitlines(True),fromfile='stock/d_dkong.cpp',tofile='observer/d_dkong.cpp')))
print(R/'observer.patch')
