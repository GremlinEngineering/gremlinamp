from pathlib import Path
import struct,zlib,json,hashlib
R=Path(__file__).resolve().parent;O=R/'native';O.mkdir(exist_ok=True)
def make(key,name,events,preroll,duration):
 program=(R/'original'/key/'program.bin').read_bytes();data=(R/'original'/key/'external-data.bin').read_bytes()
 payload=b''.join(struct.pack('<IHBB',t,p,v,0)for t,p,v in events)
 h=bytearray(128);h[:4]=b'DKM\x1a';offset=128+len(program)+len(data);length=offset+len(payload)
 fields=[1,1 if key=='dkong'else 2,6000000,400000,48000,4096,len(data),len(events),offset,preroll,duration,0,length,zlib.crc32(program),zlib.crc32(data),zlib.crc32(payload)]
 struct.pack_into('<16I',h,4,*fields);blob=bytes(h)+program+data+payload;p=O/(name+'.dkm');p.write_bytes(blob)
 return {'game':key,'name':name,'file':str(p),'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'preroll_samples':preroll,'duration_samples':duration,'seconds':duration/48000,'events':len(events),'program_sha256':hashlib.sha256(program).hexdigest(),'data_sha256':hashlib.sha256(data).hexdigest()}
rows=[]
for key,choices in [('dkong',[(1,'opening-stage-1',6.5),(2,'how-high-can-you-get',4)]),('dkongjr',[(8,'opening-save-your-papa',10.5),(1,'stage-1-vines',36)])]:
 events=[x for x in struct.iter_unpack('<QII',(R/f'fbneo-host/{key}-observer/mcu-events.bin').read_bytes())if x[1]<65536]
 end=max(t for t,p,v in struct.iter_unpack('<QII',(R/f'fbneo-host/{key}-observer/mcu-events.bin').read_bytes()))
 rows.append({**make(key,key+'-full-source-check',events,0,end*48000//400000),'research_only':True,'source_full_trace':True})
 for cue,title,seconds in choices:
  at=next(t for t,p,v in events if p==0x7c00 and v==cue)
  # Keep every original host input through the observed three-frame cue pulse.
  cut=at+40000
  selected=[e for e in events if e[0]<=cut]
  row=make(key,key+'-'+title,selected,at*48000//400000,round(seconds*48000))
  row.update({'cue_value_original_main_bus':cue,'cue_cycle':at,'prefix_source_cut_cycle':cut,'title_context':title,'research_only':True,'duration_provisional':True})
  rows.append(row)
(R/'banks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps([{k:r[k]for k in ['name','bytes','seconds','events']}for r in rows],indent=2))
