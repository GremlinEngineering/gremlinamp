// Independent transport reference: original whole-game raw output trace drives
// the pinned MAME circuit directly, without the standalone CPU/render host.
#include "source/burnint.h"
#include "source/mcs48.h"
#include "source/discrete/host.h"
#include <fstream>
#include <iostream>
struct Event{uint64_t t;uint32_t p,v;};
int main(int n,char**v){try{if(n!=4)return 2;bool jr=std::string(v[1])=="dkongjr";std::ifstream in(v[2],std::ios::binary);if(!in)return 2;FILE*out=fopen(v[3],"wb");if(!out)return 2;discrete_device graph;graph.build(jr?dkongjr_discrete:dkong2b_discrete);uint64_t samples=0,ports=0;Event e;
 while(in.read(reinterpret_cast<char*>(&e),16)){
  if(e.p<65536)continue;
  uint64_t target=e.t*48000/400000;
  while(samples<target){float s=graph.sample(jr?.5:.9),frame[2]={s,s};if(!std::isfinite(s))return 2;fwrite(frame,4,2,out);samples++;}
  if(e.p==(0x10000|MCS48_P1))graph.write(DS_DAC,e.v);
  else if(e.p==(0x10000|MCS48_P2))graph.write(DS_DISCHARGE_INV,(e.v>>7)&1);
  ports++;
 }
 fclose(out);std::cout<<"{\"profile\":\""<<v[1]<<"\",\"frames\":"<<samples<<",\"source_port_events\":"<<ports<<",\"source\":\"Unmodified whole-game original MCU port trace, pinned original MAME math; effects inputs held at reset for music-only profile\"}\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
