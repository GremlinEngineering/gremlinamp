#include "source/mcs48.cpp"
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <stdexcept>
struct Event {UINT64 t;UINT32 p,v;};
static std::vector<UINT8> program,data;
static std::vector<Event> outputs;
static UINT8 pins=255,t0=1,t1=1,page=0,latch=15;
static bool jr=false;static size_t position=0;static unsigned errors=0;
std::vector<UINT8> readfile(const std::string&p){std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error(p);return std::vector<UINT8>((std::istreambuf_iterator<char>(f)),{});}
static UINT8 rd(UINT32 port){
 if(port<256||port==MCS48_BUS){if(jr)return latch;return(page&64)?latch:data[(page&7)*256+(port&255)];}
 switch(port){case MCS48_P1:return 255;case MCS48_P2:return pins;case MCS48_T0:return t0;case MCS48_T1:return t1;default:return 255;}}
static void wr(UINT32 port,UINT8 value){
 if(port==MCS48_P2)page=value;
 if(position>=outputs.size())return;
 auto e=outputs[position++];UINT64 at=mcs48TotalCycles();
 if(e.t!=at||e.p!=(port|0x10000)||e.v!=value){if(errors++<10)std::cerr<<"mismatch "<<position<<" expected "<<e.t<<","<<e.p<<","<<e.v<<" actual "<<at<<","<<(port|0x10000)<<","<<unsigned(value)<<"\n";}
}
int main(int n,char**v){try{
 if(n!=3)return 2;std::string dir=v[1];jr=dir.find("dkongjr")!=std::string::npos;program=readfile(dir+"/program.bin");data=readfile(dir+"/external-data.bin");auto bytes=readfile(v[2]);if(bytes.size()%16)return 2;
 std::vector<Event> inputs;UINT64 end=0;
 for(size_t i=0;i<bytes.size();i+=16){Event e;memcpy(&e,bytes.data()+i,16);if(e.p<65536)inputs.push_back(e);else outputs.push_back(e);end=std::max(end,e.t);}
 mcs48Init(0,8884,program.data());mcs48Open(0);mcs48_set_read_port(rd);mcs48_set_write_port(wr);mcs48Reset();
 for(auto e:inputs){while(UINT64(mcs48TotalCycles())<e.t)mcs48Run(1);if(UINT64(mcs48TotalCycles())!=e.t){std::cerr<<"input boundary "<<e.t<<" actual "<<mcs48TotalCycles()<<"\n";return 1;}
  switch(e.p){case 0x7c00:latch=jr?e.v:((e.v&15)^15);break;case 0x7c81:pins=(pins&~64)|((~e.v&1)<<6);break;case 0x7d03:pins=(pins&~32)|((~e.v&1)<<5);break;case 0x7d04:t1=~e.v&1;break;case 0x7d05:t0=~e.v&1;break;case 0x7d80:mcs48SetIRQLine(0,e.v?1:0);break;default:throw std::runtime_error("unknown port");}
 }
 while(UINT64(mcs48TotalCycles())<=end)mcs48Run(1);
 std::cout<<"{\"outputs_compared\":"<<position<<",\"outputs_expected\":"<<outputs.size()<<",\"inputs_replayed\":"<<inputs.size()<<",\"mismatches\":"<<errors<<",\"machine_cycles\":"<<mcs48TotalCycles()<<"}\n";
 mcs48Close();mcs48Exit();return errors||position!=outputs.size();
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
