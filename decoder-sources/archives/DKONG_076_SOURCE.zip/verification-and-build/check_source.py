from pathlib import Path
import json,subprocess
import numpy as np
from render_dk import Player
R=Path(__file__).resolve().parent;results=[];p=Player()
for key in ['dkong','dkongjr']:
 ref=R/'probes'/(key+'-source-trace.f32')
 capture=json.loads(subprocess.check_output([str(R/'render-trace'),key,str(R/f'fbneo-host/{key}-observer/mcu-events.bin'),str(ref)]))
 a=np.fromfile(ref,dtype='<f4').reshape(-1,2);p.load(R/'native'/(key+'-full-source-check.dkm'));remaining=len(a);pieces=[]
 while remaining:
  n=min(4096,remaining);pieces.append(p.render(n));remaining-=n
 b=np.concatenate(pieces);stats=json.loads(p.l.gremlin_dk_stats());p.close();delta=a.astype(np.float64)-b;row={'game':key,'capture':capture,'frames':len(a),'max_error':float(np.max(np.abs(delta))),'rms_error':float(np.sqrt(np.mean(delta**2))),'exact':bool(np.array_equal(a,b)),'stats':stats};row['pass']=row['exact'];results.append(row);print(json.dumps(row),flush=True)
(R/'source-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r['pass']for r in results)
