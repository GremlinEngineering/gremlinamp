from pathlib import Path
import json,shutil,hashlib
import numpy as np
from render_dk import Player
R=Path(__file__).resolve().parent;G=R.parent;P=R/'player/games/music_player'
shutil.copytree(G/'work-069/release/player/games/music_player',P,dirs_exist_ok=True)
vendor=P/'vendor/dkong';vendor.mkdir(exist_ok=True)
for name in ['gremlin-dkong.wasm','gremlin-dkong.js','BUILD.json']:shutil.copy2(R/'built'/name,vendor/name)
shutil.copy2(R/'dkong-worker.js',P/'dkong-worker.js')
p=P/'decoders.js';s=p.read_text();s=s.replace('export const DECODERS=Object.freeze({',"export const DECODERS=Object.freeze({\n  dkong:Object.freeze(['dkm']),");s=s.replace("worker:id==='ki'?","worker:id==='dkong'?'dkong-worker.js':id==='ki'?");p.write_text(s)
rows=[];player=Player()
for b in json.loads((R/'banks.json').read_text()):
 if b['name'].endswith('stage-1-vines'):continue
 for rate in [44100,48000]:
  player.load(b['file'],rate);total=(b['duration_samples']*rate+47999)//48000;out=R/'probes'/(b['name']+f'-{rate}-browser-reference.f32');remaining=total
  with out.open('wb')as f:
   while remaining:
    n=min(4096,remaining);f.write(player.render(n).tobytes());remaining-=n
  player.close();rows.append({'key':b['name'],'rate':rate,'file':b['file'],'sha256':b['sha256'],'expected':str(out),'frames':total})
(R/'browser-plan.json').write_text(json.dumps(rows,indent=2)+'\n');print('browser plan',len(rows))
