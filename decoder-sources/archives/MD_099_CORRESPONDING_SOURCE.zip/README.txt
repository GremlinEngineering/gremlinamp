Original full-machine Mega Drive / 32X music backend099, player0.29
PicoDrive source: https://github.com/libretro/picodrive/tree/1890c2932234c9d30f4cd3851d02228baae8f09e
The original upstream core, CPU implementations, FM/PSG/PWM synthesis and ROMs are unchanged.
md_host.c is a small standard Libretro frontend: exact original ROM in memory, ordinary controller inputs, original audio callbacks.
No melody data, samples, CPU instructions, emulated hardware or initialization music state is patched.
Portable build: FAME68000, CZ80, SH2 C interpreter, no ARM assembly or dynamic recompilers. Default original core options, 3-button controller.
Only original cartridge profiles are admitted by the music worker. CD, network and audio stream inputs are not exposed. Upstream contains optional MP3/OGG helper source; no MP3 or premixed music is included.

Licensing: upstream COPYING forbids commercial use and requires complete corresponding source for modified distributions. Preserve all component licenses and original archives. This backend requires a license review before use in a commercial website. No website is published in this work.

Build with the same Emscripten6.0.13-git SDK:
python3 build_wasm.py --emsdk /path/to/emsdk --output /path/to/output
The script reads the four exact local source archives and uses a temporary build directory without spaces because upstream Make does not quote paths. It never downloads files. The unused Cyclone and libchdr submodules are disabled. Source archive hashes and output hashes are written to BUILD.json.

Native verification only: the original PicoReset uses rand() for startup frame phase. A new Wasm module starts the toolchain musl PRNG in its static zero state; Darwin libc has another PRNG. Native reference links the exact Emscripten musl rand.c and native_reference_init.c sets srand(1), which gives that same zero state. Each reference is a fresh native process to match one fresh Wasm module per song. No PRNG replacement or reset shim is used in the delivered Wasm core.

Timing: the original Libretro frontend reports44100Hz and60Hz for these NTSC cartridges. This is an emulator profile, not a measurement of a physical board. Default output filtering is preserved. Music selection windows preserve source phase; no exact loop claim is made without a source loop marker.
