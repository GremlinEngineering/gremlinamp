#include <stdlib.h>
void gremlin_md_reference_reset_random(void){srand(1);}
