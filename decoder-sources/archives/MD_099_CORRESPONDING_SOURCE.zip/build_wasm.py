#!/usr/bin/env python3
"""Rebuild the unchanged pinned PicoDrive core and small music frontend.

Requires an Emscripten SDK and make. No network access, ROMs or music needed.
Upstream Makefile requires a build directory without spaces.
"""
import argparse, hashlib, json, os, shlex, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCES = [
    ('099-picodrive-source.zip', ''),
    ('099-libpicofe-source.zip', 'platform/libpicofe'),
    ('099-emu2413-source.zip', 'pico/sound/emu2413'),
    ('099-dr-libs-source.zip', 'platform/common/dr_libs'),
]
COMMON = [
    'formats/png/rpng.c', 'streams/trans_stream.c', 'streams/trans_stream_pipe.c',
    'streams/trans_stream_zlib.c', 'file/file_path_io.c', 'file/file_path.c',
    'vfs/vfs_implementation.c', 'time/rtime.c', 'string/stdstring.c',
    'encodings/encoding_utf.c', 'compat/compat_strl.c',
    'compat/compat_posix_string.c', 'compat/fopen_utf8.c',
    'streams/file_stream.c', 'streams/file_stream_transforms.c', 'memmap/memmap.c',
]
EXPORTS = [
    '_malloc', '_free', '_gremlin_md_load', '_gremlin_md_close', '_gremlin_md_step',
    '_gremlin_md_audio', '_gremlin_md_audio_frames', '_gremlin_md_video',
    '_gremlin_md_video_width', '_gremlin_md_video_height', '_gremlin_md_capture_video',
    '_gremlin_md_error', '_gremlin_md_source_rate', '_gremlin_md_source_fps',
    '_gremlin_md_hardware_flags',
]

def unpack(archive, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        prefix = names[0].split('/')[0] + '/'
        for name in names:
            if name.endswith('/'):
                continue
            assert name.startswith(prefix)
            relative = Path(name[len(prefix):])
            assert not relative.is_absolute() and '..' not in relative.parts
            target = dest / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(name))

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--emsdk', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--archives', type=Path, default=HERE / 'archives')
    a = p.parse_args()
    sdk = a.emsdk.resolve()
    em = sdk / 'install/emscripten'
    if not em.exists():
        em = sdk / 'upstream/emscripten'
    assert (em / 'emcc.py').exists()
    output = a.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, EM_CONFIG=str(sdk / '.emscripten'))
    with tempfile.TemporaryDirectory(prefix='gremlin-pico-build-', dir='/private/tmp' if Path('/private/tmp').exists() else None) as tmp:
        core = Path(tmp) / 'picodrive'
        for name, subdir in SOURCES:
            unpack(a.archives.resolve() / name, core / subdir)
        # The original archive contains unused legacy objects. Let upstream Make
        # choose the portable CPU and original hardware source files itself.
        flags = ['platform=emscripten', 'NO_ARM_ASM=1', 'use_sh2drc=0',
                 'use_svpdrc=0', 'use_libchdr=0']
        for var, name in [('CC', 'emcc.py'), ('CXX', 'em++.py'), ('AR', 'emar.py')]:
            flags.append(var + '=' + shlex.quote(sys.executable) + ' ' + shlex.quote(str(em / name)))
        log = output / 'upstream-build.log'
        with log.open('w') as f:
            subprocess.run(['make', '-f', 'Makefile.libretro', *flags, '-j4'], cwd=core, env=env, stdout=f, stderr=subprocess.STDOUT, check=True)
        frontend = Path(tmp) / 'frontend'
        frontend.mkdir()
        shutil.copyfile(core / 'picodrive_libretro_emscripten.bc', frontend / 'libpicodrive.a')
        cc = [sys.executable, str(em / 'emcc.py')]
        includes = ['-I' + str(core), '-I' + str(core / 'platform/libretro'),
                    '-I' + str(core / 'platform/libretro/libretro-common/include')]
        objects = []
        for name in COMMON:
            src = core / 'platform/libretro/libretro-common' / name
            obj = frontend / (name.replace('/', '-') + '.o')
            subprocess.run([*cc, '-O3', '-DNDEBUG', '-D__LIBRETRO__', '-DUSE_LIBRETRO_VFS', *includes, '-c', str(src), '-o', str(obj)], env=env, check=True)
            objects.append(obj)
        host = frontend / 'md_host.o'
        subprocess.run([*cc, '-O3', '-DNDEBUG', *includes, '-c', str(HERE / 'md_host.c'), '-o', str(host)], env=env, check=True)
        subprocess.run([*cc, '-O3', '--no-entry', str(host), str(frontend / 'libpicodrive.a'), *map(str, sorted(objects)),
                        '-sMODULARIZE', '-sEXPORT_NAME=GremlinMegaDriveMusic',
                        '-sENVIRONMENT=web,worker,node', '-sALLOW_MEMORY_GROWTH',
                        '-sINITIAL_MEMORY=67108864', '-sSTACK_SIZE=1048576', '-sFILESYSTEM=1',
                        '-sEXPORTED_FUNCTIONS=' + json.dumps(EXPORTS),
                        '-sEXPORTED_RUNTIME_METHODS=' + json.dumps(['HEAPU8', 'HEAP16', 'HEAPU32', 'UTF8ToString']),
                        '-o', str(output / 'gremlin-md.js')], env=env, check=True)
    metadata = {'core': 'PicoDrive', 'commit': '1890c2932234c9d30f4cd3851d02228baae8f09e',
                'core_changes': False, 'cpu': 'FAME 68000 / CZ80 / SH2 C interpreter',
                'source_archives': {}, 'outputs': {}}
    for name, _ in SOURCES:
        b = (a.archives / name).read_bytes()
        metadata['source_archives'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    for name in ['gremlin-md.js', 'gremlin-md.wasm']:
        b = (output / name).read_bytes()
        metadata['outputs'][name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    (output / 'BUILD.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata, indent=2))

if __name__ == '__main__':
    main()
