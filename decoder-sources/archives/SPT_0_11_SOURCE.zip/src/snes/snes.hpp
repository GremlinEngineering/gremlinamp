#ifndef __SNES_HPP
#define __SNES_HPP

#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <vector>
typedef uint64_t uint64;typedef int64_t int64;typedef uint8_t uint8;typedef uint16_t uint16;typedef uint32_t uint32;typedef int8_t int8;typedef int16_t int16;typedef int32_t int32;
#define alwaysinline inline __attribute__((always_inline))
struct GremlinSettings{bool MSU1=false;int InterpolationMethod=2;bool SeparateEchoBuffer=false;};extern GremlinSettings Settings;
class Resampler{public:std::vector<int16_t> pcm;void push_sample(int l,int r){pcm.push_back((int16_t)l);pcm.push_back((int16_t)r);}};
inline void S9xMSU1Generate(int){}

#define debugvirtual

namespace SNES
{

struct Processor
{
    unsigned frequency;
    int32 clock;
};

#include "../smp/smp.hpp"
#include "../dsp/sdsp.hpp"

class CPU
{
public:
    uint8 registers[4];

    inline void reset ()
    {
        registers[0] = registers[1] = registers[2] = registers[3] = 0;
    }

    alwaysinline void port_write (uint8 port, uint8 data)
    {
        registers[port & 3] = data;
    }

    alwaysinline uint8 port_read (uint8 port)
    {
        return registers[port & 3];
    }
};

extern CPU cpu;

} // namespace SNES

#endif
