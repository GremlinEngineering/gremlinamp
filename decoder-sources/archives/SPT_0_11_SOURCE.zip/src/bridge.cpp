#include "snes/snes.hpp"
#include <cstdio>
#include <cstdlib>
GremlinSettings Settings;
namespace SNES {CPU cpu;}
static Resampler output;
static std::vector<uint8_t> state;
static std::vector<uint32_t> events;
static uint32_t now=0,end=0;static size_t event_pos=0,read_pos=0;
static void advance(uint32_t t){SNES::smp.clock-=int32_t(t-now);SNES::smp.enter();SNES::dsp.synchronize();now=t;}
extern "C" int spt_load(const uint8_t* b,int n){
 if(n<32+66560 || memcmp(b,"SPT1",4)||b[4]!=1)return -1;
 uint32_t h[8];memcpy(h,b,32);if(h[2]!=1025280||h[3]!=66560||h[6]!=0||h[7]!=0||uint64_t(n)!=uint64_t(32+66560)+uint64_t(8)*h[5])return -2;
 if(h[4]>0x7fffffff)return -4;end=h[4];state.assign(b+32,b+32+66560);events.resize(h[5]*2);memcpy(events.data(),b+32+66560,h[5]*8);
 for(size_t i=0;i<events.size();i+=2)if(events[i]>end||(i&&events[i]<events[i-2])||(events[i+1]&0xffff00fc))return -3;
 SNES::smp.power();SNES::dsp.power();uint8_t* p=state.data();SNES::smp.load_state(&p);SNES::dsp.load_state(&p);p+=8;memcpy(&SNES::dsp.clock,p,4);p+=4;memcpy(SNES::cpu.registers,p,4);SNES::dsp.spc_dsp.set_output(&output);now=0;event_pos=read_pos=0;output.pcm.clear();return 0;
}
extern "C" int spt_render(int16_t* out,int frames){int need=frames*2;while(output.pcm.size()-read_pos<(size_t)need && now<end){uint32_t next=event_pos<events.size()?events[event_pos]:end;next=std::min(next,std::min(end,now+32768));advance(next);while(event_pos<events.size()&&events[event_pos]==now){auto v=events[event_pos+1];SNES::cpu.port_write(v&3,(v>>8)&255);event_pos+=2;}if(event_pos>=events.size()&&now==end)break;}
 int n=std::min((size_t)need,output.pcm.size()-read_pos);memcpy(out,output.pcm.data()+read_pos,n*2);read_pos+=n;if(read_pos>65536){output.pcm.erase(output.pcm.begin(),output.pcm.begin()+read_pos);read_pos=0;}return n/2;}
#ifndef __EMSCRIPTEN__
int main(int argc,char**argv){if(argc!=2)return 1;FILE*f=fopen(argv[1],"rb");if(!f)return 2;fseek(f,0,SEEK_END);int n=ftell(f);rewind(f);std::vector<uint8_t>b(n);fread(b.data(),1,n,f);fclose(f);int e=spt_load(b.data(),n);if(e){fprintf(stderr,"load:%d\n",e);return 3;}int16_t out[8192];for(;;){int k=spt_render(out,4096);if(k<=0)break;fwrite(out,4,k,stdout);}return 0;}
#endif
