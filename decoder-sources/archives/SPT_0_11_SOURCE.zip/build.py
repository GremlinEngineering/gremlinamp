from pathlib import Path
import argparse,os,subprocess,json,hashlib
P=Path(__file__).resolve().parent;a=argparse.ArgumentParser();a.add_argument('--sdk',type=Path);a.add_argument('--output',type=Path);v=a.parse_args();src=P/'src';sources=[src/x for x in ['bridge.cpp','smp/smp.cpp','smp/smp_state.cpp','dsp/sdsp.cpp']];flags=['-O3','-std=c++17','-fno-exceptions','-I'+str(src)];out=v.output or P/'built';out.mkdir(parents=True,exist_ok=True)
subprocess.run(['g++',*flags,*map(str,sources),'-o',str(out/'render-spt')],check=True)
if v.sdk:
 sdk=v.sdk.resolve();env={**os.environ,'EM_CONFIG':str(sdk/'.emscripten')};subprocess.run(['python3',str(sdk/'upstream/emscripten/em++.py'),*flags,*map(str,sources),'--no-entry','-sMODULARIZE=1','-sEXPORT_NAME=GremlinSPT','-sENVIRONMENT=worker','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sEXPORTED_FUNCTIONS=["_malloc","_free","_spt_load","_spt_render"]','-sEXPORTED_RUNTIME_METHODS=["HEAPU8","HEAP16"]','-o',str(out/'gremlin-spt.js')],env=env,check=True)
print(json.dumps([{'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in sorted(out.iterdir())if f.is_file()],indent=2))
