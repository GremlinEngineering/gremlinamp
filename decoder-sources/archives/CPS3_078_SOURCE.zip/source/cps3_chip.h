// Standalone transport for pinned original MAME CPS3 PCM mathematics.
#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <vector>
using offs_t=uint32_t;
#define COMBINE_DATA(p) (*(p)=(*(p)&~mem_mask)|(data&mem_mask))
// Container bytes use the original little-endian MAME linear-bank layout.
template<class T>constexpr T BYTE4_XOR_LE(T value){return value;}
struct sound_stream {
 float out[2]{};int samples()const{return 1;}void update(){}
 void add_int(int channel,int,int32_t value,int32_t scale){out[channel]+=float(value)/float(scale);}
 void clear(){out[0]=out[1]=0;}
};
struct OriginalROM {
 uint32_t logical_size=0;bool full=false,collect=false;
 std::vector<int8_t>bytes;std::vector<int32_t>pages;std::vector<uint8_t>used;
 int8_t operator[](uint32_t address){
  if(address>=logical_size)throw std::runtime_error("CPS3 sample outside original bank");
  uint32_t page=address>>12;if(collect)used[page]=1;
  if(full)return bytes[address];
  int32_t slot=pages[page];if(slot<0)throw std::runtime_error("CPS3 original sample page absent");
  return bytes[size_t(slot)*4096+(address&4095)];
 }
 void load_full(std::vector<int8_t>data){logical_size=data.size();bytes=std::move(data);full=true;used.assign((logical_size+4095)/4096,0);}
};
#include "mame_cps3_voice.h"
class cps3_sound_device {
 public:
 cps3_voice m_voice[16];uint16_t m_key=0;OriginalROM m_base;sound_stream stream; sound_stream*m_stream=&stream;
 void sound_stream_update(sound_stream&stream);
 void sound_w(offs_t offset,uint32_t data,uint32_t mem_mask);
 uint32_t sound_r(offs_t offset,uint32_t mem_mask);
 void logerror(const char*fmt,...){va_list a;va_start(a,fmt);vfprintf(stderr,fmt,a);va_end(a);}
 void original_word_write(uint32_t address,uint16_t value){
  uint32_t offset=address/4;
  if(address&2)sound_w(offset,value,0x0000ffff);
  else sound_w(offset,uint32_t(value)<<16,0xffff0000);
 }
 std::array<float,2>sample(){
  stream.clear();sound_stream_update(stream);
  // Original MAME machine configuration routes stream1 left, stream0 right.
  return {stream.out[1],stream.out[0]};
 }
};
#include "mame_cps3_methods.inc"

