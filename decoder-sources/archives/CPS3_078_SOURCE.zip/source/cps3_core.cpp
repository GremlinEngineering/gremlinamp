// Gremlin CPS3 native original-register container host, BSD-3-Clause.
// PCM mathematics are the exact pinned original MAME methods in cps3_chip.h.
#include "cps3_chip.h"
#include <deque>
#include <string>
namespace gremlin_cps3 {
constexpr uint32_t CHIP_CLOCK=14318181,CHIP_RATE=37286,SOURCE_CLOCK=25000000;
struct Event {uint64_t tick;uint16_t address,value;uint32_t at_sample;};
static uint32_t r32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static uint64_t r64(const uint8_t*p){return uint64_t(r32(p))|(uint64_t(r32(p+4))<<32);}
static uint32_t crc32(const uint8_t*p,size_t n){uint32_t c=~0u;for(size_t i=0;i<n;i++){c^=p[i];for(int bit=0;bit<8;bit++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
struct State {
 cps3_sound_device chip;std::vector<Event>events;size_t event_position=0;
 uint32_t rate=48000,phase=0,duration=0;uint64_t origin=0,end_delta=0,position=0,generated=0,queue_base=0;
 std::deque<std::array<float,2>>pcm;
 void generate(){
  while(event_position<events.size()&&events[event_position].at_sample<=generated){
   auto&e=events[event_position++];chip.original_word_write(e.address,e.value);
  }
  auto frame=chip.sample();if(!std::isfinite(frame[0])||!std::isfinite(frame[1]))throw std::runtime_error("CPS3 produced nonfinite sample");
  pcm.push_back(frame);generated++;
 }
 void ensure(uint64_t index){if(index>=duration)return;while(queue_base+pcm.size()<=index)generate();}
 std::array<float,2>at(uint64_t index){if(index>=duration)return {0,0};ensure(index);return pcm[index-queue_base];}
};
static std::unique_ptr<State>state;static std::string error_text,stats_text;
}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_cps3_close(){gremlin_cps3::state.reset();}
API const char*gremlin_cps3_error(){return gremlin_cps3::error_text.c_str();}
API const char*gremlin_cps3_devices(){return "[{\"type\":\"cps3_pcm\",\"voices\":16,\"clock_hz\":14318181,\"internal_sample_rate\":37286,\"source_timebase_hz\":25000000,\"core\":\"pinned original MAME CPS3 PCM\",\"source\":\"original register events and original SIMM sample pages\",\"initial_state\":\"verified all-key-off snapshot with preserved chip phase\",\"stereo_route\":\"original MAME stream1 left, stream0 right\",\"rendered_track\":false,\"physical_board_measured\":false}]";}
API const char*gremlin_cps3_stats(){using namespace gremlin_cps3;if(!state)return "{}";auto&s=*state;char b[600];snprintf(b,sizeof(b),"{\"events_applied\":%zu,\"events_total\":%zu,\"key\":%u,\"original_sample_bank_bytes\":%u,\"stored_sample_bytes\":%zu,\"chip_samples\":%llu,\"duration_samples\":%u,\"source_origin_cycle\":%llu,\"sample_phase\":%u,\"output_frames\":%llu}",s.event_position,s.events.size(),s.chip.m_key,s.chip.m_base.logical_size,s.chip.m_base.bytes.size(),s.generated,s.duration,s.origin,s.phase,s.position);stats_text=b;return stats_text.c_str();}
API int gremlin_cps3_load(const uint8_t*b,uint32_t length,uint32_t rate,uint32_t subsong){using namespace gremlin_cps3;gremlin_cps3_close();error_text.clear();try{
 if(!b||length<640||length>24000000||memcmp(b,"C3M\x1a",4)||r32(b+4)!=1)throw std::runtime_error("Invalid C3M1 header");
 uint32_t bank_size=r32(b+24),pages=r32(b+28),count=r32(b+32),phase=r32(b+40),duration=r32(b+44);
 uint32_t table=r32(b+52),data=r32(b+56),ev=r32(b+60);uint64_t origin=r64(b+88),end_delta=r64(b+96);
 if(r32(b+8)!=1||r32(b+12)!=CHIP_CLOCK||r32(b+16)!=CHIP_RATE||r32(b+20)!=SOURCE_CLOCK||r32(b+36)!=512||r32(b+48)!=128||r32(b+64)!=length||rate<8000||rate>192000||subsong)throw std::runtime_error("Unsupported original CPS3 profile");
 if(!bank_size||bank_size>0x8000000||(bank_size&4095)||!pages||pages>4096||!count||count>1000000||table!=640||data!=uint64_t(table)+pages*4ull||ev!=uint64_t(data)+pages*4096ull||uint64_t(ev)+count*16ull!=length)throw std::runtime_error("Invalid C3M1 region bounds");
 if(origin>uint64_t(SOURCE_CLOCK)*86400||phase>=SOURCE_CLOCK||phase!=(origin*CHIP_RATE)%SOURCE_CLOCK||!end_delta||end_delta>uint64_t(SOURCE_CLOCK)*600||duration!=(end_delta*CHIP_RATE+phase)/SOURCE_CLOCK||!duration)throw std::runtime_error("Invalid CPS3 source timing");
 if(r32(b+84))throw std::runtime_error("Nonzero C3M1 reserved field");
 for(unsigned i=104;i<128;i++)if(b[i])throw std::runtime_error("Nonzero C3M1 reserved extension");
 if(crc32(b+128,512)!=r32(b+68)||crc32(b+table,pages*4)!=r32(b+72)||crc32(b+data,pages*4096)!=r32(b+76)||crc32(b+ev,count*16)!=r32(b+80))throw std::runtime_error("Original CPS3 state, ROM pages or events checksum differs");
 state=std::make_unique<State>();auto&s=*state;s.rate=rate;s.phase=phase;s.duration=duration;s.origin=origin;s.end_delta=end_delta;
 // Only all-key-off starts are supported: every later key-on resets pos/frac,
 // so the original register snapshot and sample-clock phase fully define output.
 for(unsigned i=0;i<16;i++)for(unsigned j=0;j<8;j++)s.chip.m_voice[i].regs[j]=r32(b+128+(i*8+j)*4);
 s.chip.m_key=0;s.chip.m_base.logical_size=bank_size;s.chip.m_base.full=false;s.chip.m_base.pages.assign(bank_size/4096,-1);
 uint32_t previous_page=0;
 for(unsigned i=0;i<pages;i++){uint32_t page=r32(b+table+i*4);if(page>=bank_size/4096||(i&&page<=previous_page))throw std::runtime_error("Invalid original CPS3 page map");s.chip.m_base.pages[page]=i;previous_page=page;}
 s.chip.m_base.bytes.assign(reinterpret_cast<const int8_t*>(b+data),reinterpret_cast<const int8_t*>(b+ev));
 uint64_t previous_tick=0;
 for(unsigned i=0;i<count;i++){
  const uint8_t*p=b+ev+i*16;uint64_t tick=r64(p);uint16_t address=p[8]|uint16_t(p[9])<<8,value=p[10]|uint16_t(p[11])<<8;
  if(r32(p+12)||tick<previous_tick||tick>=end_delta||address>0x200||(address&1))throw std::runtime_error("Invalid original CPS3 register event");
  s.events.push_back({tick,address,value,uint32_t((tick*CHIP_RATE+phase)/SOURCE_CLOCK)});previous_tick=tick;
 }
 return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_cps3_close();return 1;}}
API uint32_t gremlin_cps3_render(float*out,uint32_t frames){using namespace gremlin_cps3;if(!out||!frames||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!state)return 0;try{
 auto&s=*state;
 for(unsigned i=0;i<frames;i++,s.position++){
  uint64_t numerator=s.position*CHIP_RATE,at=numerator/s.rate;uint32_t rem=numerator%s.rate;
  auto a=s.at(at),b=s.at(at+1);
  for(unsigned c=0;c<2;c++)out[i*2+c]=float(double(a[c])+(double(b[c])-a[c])*double(rem)/s.rate);
  while(s.queue_base<at&&!s.pcm.empty()){s.pcm.pop_front();s.queue_base++;}
 }
 return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_cps3_close();return 0;}}
}

