#include "source/cps3_chip.h"
#include <fstream>
#include <iostream>
#include <string>
#include <limits>
struct SourceEvent{uint64_t tick;uint32_t address,value;};
static std::vector<int8_t>readbytes(const std::string&p){std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error("missing "+p);return std::vector<int8_t>((std::istreambuf_iterator<char>(f)),{});}
int main(int n,char**v){try{
 if(n!=9)return 2;auto raw=readbytes(v[2]);if(raw.empty()||(raw.size()&4095))return 2;
 std::vector<int8_t>canonical(raw.size());for(size_t i=0;i<raw.size();i++)canonical[i]=raw[i^1];
 cps3_sound_device chip;chip.m_base.load_full(std::move(canonical));
 uint64_t origin=std::stoull(v[3]),end=std::stoull(v[4]),first=origin*37286/25000000,last=end*37286/25000000,count=0,previous=0,events=0,wanted=0;
 bool snapshot=false;FILE*out=fopen(v[5],"wb");if(!out)return 2;
 auto advance=[&](uint64_t tick){uint64_t target=tick*37286/25000000;while(count<target){
  chip.m_base.collect=count>=first&&count<last;auto frame=chip.sample();
  if(count>=first&&count<last){if(!std::isfinite(frame[0])||!std::isfinite(frame[1]))throw std::runtime_error("nonfinite reference");fwrite(frame.data(),4,2,out);wanted++;}count++;
 }};
 auto save_snapshot=[&](){
  advance(origin);if(chip.m_key)throw std::runtime_error("source origin is not all-key-off");
  FILE*f=fopen(v[7],"wb");if(!f)throw std::runtime_error("snapshot output");
  for(auto&voice:chip.m_voice)fwrite(voice.regs,4,8,f);fclose(f);snapshot=true;
 };
 std::ifstream input(v[1],std::ios::binary);if(!input)return 2;SourceEvent e;
 while(input.read(reinterpret_cast<char*>(&e),16)){
  if(e.address>0x200)continue;
  if(e.tick<previous)throw std::runtime_error("source register time moved backwards");previous=e.tick;
  if(e.tick>=origin&&!snapshot)save_snapshot();
  if(e.tick>=end)break;
  advance(e.tick);chip.original_word_write(e.address,e.value);events++;
 }
 if(!snapshot)save_snapshot();advance(end);fclose(out);
 FILE*pageout=fopen(v[6],"wb");if(!pageout)return 2;uint32_t pages=0;
 for(uint32_t p=0;p<chip.m_base.used.size();p++)if(chip.m_base.used[p]){fwrite(&p,4,1,pageout);pages++;}
 fclose(pageout);
 FILE*stats=fopen(v[8],"w");if(!stats)return 2;
 fprintf(stats,"{\"source\":\"original whole-game register trace, original full SIMM bank, exact pinned MAME PCM methods\",\"source_origin_cycle\":%llu,\"source_end_cycle\":%llu,\"source_frames\":%llu,\"window_frames\":%llu,\"events_replayed\":%llu,\"full_bank_bytes\":%u,\"used_original_pages\":%u,\"initial_all_key_off\":true,\"final_key\":%u,\"sample_phase\":%llu,\"native_rate\":37286}\n",origin,end,count,wanted,events,chip.m_base.logical_size,pages,chip.m_key,(origin*37286)%25000000);fclose(stats);
 std::cout<<"frames "<<wanted<<" originalPages "<<pages<<" finalKey "<<chip.m_key<<"\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}

