from pathlib import Path
import ctypes as c,sys,os,json,hashlib
from PIL import Image
R=Path(__file__).resolve().parent
driver=sys.argv[1]; profile=sys.argv[2]
D=R/'fbneo-host'/f'{driver}-{profile}';D.mkdir(parents=True,exist_ok=True);(D/'config/games').mkdir(parents=True,exist_ok=True)
os.chdir(D)
if profile in ['observer','bsd-reference']:
 trace=D/'pcm-registers.bin'
 if trace.exists():trace.unlink()
 os.environ['GREMLIN_CPS3_TRACE']=str(trace)
l=c.CDLL(str(R/'build'/f'fbneo-{profile}.dylib'))
l.FBHeadlessSetRomPath.argtypes=[c.c_char_p];l.FBHeadlessLoadDriver.argtypes=[c.c_char_p]
l.FBHeadlessGetVideoBuffer.restype=c.c_void_p;l.FBHeadlessGetAudioBuffer.restype=c.c_void_p
assert l.FBHeadlessInit()==0
l.FBHeadlessSetRomPath(str(R/'fbneo-host/roms').encode());assert l.FBHeadlessLoadDriver(driver.encode())==0
audio=hashlib.sha256();video=hashlib.sha256();samples=0;frames=0;actions=[]
def run(n,buttons=(),label=None):
 global samples,frames
 for b in buttons:l.FBHeadlessSetInput(0,b,1)
 for _ in range(n):
  l.FBHeadlessRunFrame(1);count=l.FBHeadlessGetAudioFrames();samples+=count
  audio.update(c.string_at(l.FBHeadlessGetAudioBuffer(),count*4));frames+=1
  w=l.FBHeadlessGetVideoWidth();h=l.FBHeadlessGetVideoHeight();pitch=l.FBHeadlessGetVideoPitch()
  pixels=c.string_at(l.FBHeadlessGetVideoBuffer(),h*pitch);video.update(pixels)
 for b in buttons:l.FBHeadlessSetInput(0,b,0)
 actions.append({'frame_after':frames,'frames':n,'buttons':list(buttons),'label':label})
 if label:
  Image.frombytes('RGB',(w,h),pixels,'raw','BGRX',pitch).save(D/(label+'.png'))
  print(driver,profile,frames,label,flush=True)
run(900,label='boot');run(3,[11]);run(60,label='credit');run(3,[10]);run(60,label='start')
for i in range(12):run(120,label=f'context-{i:02}')
summary={'driver':driver,'profile':profile,'frames':frames,'samples':samples,'audio_s16_sha256':audio.hexdigest(),'video_sha256':video.hexdigest(),'frame_rate_x100':l.FBHeadlessGetFrameRate(),'actions':actions,'no_gameplay_memory_writes':True,'missing_prerecorded_sfx_samples':False,'music_reference':'Original CPS3 game PCM register writes and original ROM sample data; no missing external SFX samples.'}
l.FBHeadlessExit();(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
