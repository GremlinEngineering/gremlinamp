from pathlib import Path
import ctypes as c,struct,zlib,json
import numpy as np
from render_cps3 import Player
R=Path(__file__).resolve().parent;p=Player();results=[];original=bytearray((R/'native/sfiii-soundtest-01.c3m').read_bytes())
def u32(b,n):return struct.unpack_from('<I',b,n)[0]
def set32(b,n,v):struct.pack_into('<I',b,n,v)
def set64(b,n,v):struct.pack_into('<Q',b,n,v)
def crc_events(b):set32(b,80,zlib.crc32(b[u32(b,60):]))
def attempt(name,blob,rate=48000,subsong=0):
 a=c.create_string_buffer(bytes(blob));status=p.l.gremlin_cps3_load(a,len(blob),rate,subsong);results.append({'test':name,'pass':bool(status),'error':p.l.gremlin_cps3_error().decode()})
 if status==0:p.close()
for name,at,value in [
 ('magic',0,0),('version',4,2),('profile',8,2),('chip clock',12,0),('chip rate',16,44100),('source clock',20,0),
 ('zero bank',24,0),('unaligned bank',24,u32(original,24)+1),('oversized logical bank',24,0x8001000),('zero pages',28,0),('page bound',28,4097),
 ('zero events',32,0),('event bound',32,1000001),('snapshot size',36,0),('phase mismatch',40,(u32(original,40)+1)%25000000),
 ('phase overflow',40,25000000),('zero duration',44,0),('duration mismatch',44,u32(original,44)+1),('header size',48,127),
 ('table offset',52,641),('sample offset',56,0),('events offset',60,0),('file length',64,len(original)+1),
 ('snapshot CRC',68,0),('page table CRC',72,0),('sample CRC',76,0),('events CRC',80,0),('reserved',84,1),('reserved extension',124,1)
]:
 b=original.copy();set32(b,at,value);attempt(name,b)
for name,at,value in [('origin bound',88,25000000*86400+1),('origin phase mismatch',88,struct.unpack_from('<Q',original,88)[0]+1),('zero time',96,0),('time bound',96,25000000*601)]:
 b=original.copy();set64(b,at,value);attempt(name,b)
for length in [0,3,127,639,len(original)-1]:attempt('truncated '+str(length),original[:length])
for name,at in [('snapshot modified',128),('table modified',640),('ROM byte modified',u32(original,56)),('event modified',len(original)-6)]:
 b=original.copy();b[at]^=1;attempt(name,b)
for name,change in [
 ('duplicate original page',lambda b:set32(b,644,u32(b,640))),
 ('page outside bank',lambda b:set32(b,640,u32(b,24)//4096)),
]:
 b=original.copy();change(b);set32(b,72,zlib.crc32(b[640:u32(b,56)]));attempt(name,b)
offset=u32(original,60);end=struct.unpack_from('<Q',original,96)[0]
for name,change in [
 ('unknown register',lambda b:struct.pack_into('<H',b,offset+8,0x202)),
 ('odd register',lambda b:struct.pack_into('<H',b,offset+8,1)),
 ('reserved event',lambda b:set32(b,offset+12,1)),
 ('late event',lambda b:set64(b,offset,end)),
 ('overflow event',lambda b:set64(b,offset,0xffffffffffffffff)),
 ('unordered events',lambda b:set64(b,offset,struct.unpack_from('<Q',b,offset+16)[0]+1)),
]:
 b=original.copy();change(b);crc_events(b);attempt(name,b)
for rate in [0,7999,192001,0xffffffff]:attempt('rate '+str(rate),original,rate)
attempt('absent subsong',original,48000,1)
# Invalid ROM addressing must fail before a sample escapes, even for CRC-correct files.
for name,address in [('missing original page',0),('outside original bank',u32(original,24))]:
 b=original[:offset];b[128:640]=bytes(512);set32(b,68,zlib.crc32(b[128:640]))
 start=address+0x400000;finish=start+32
 word_events=[(4,start&65535),(6,start>>16),(8,0),(10,0),(12,0x1000),(20,finish&65535),(22,finish>>16),(28,0x2000),(30,0x2000),(512,1)]
 payload=b''.join(struct.pack('<QHHI',0,a,v,0)for a,v in word_events);b.extend(payload);set32(b,32,len(word_events));set32(b,64,len(b));crc_events(b)
 data=c.create_string_buffer(bytes(b));status=p.l.gremlin_cps3_load(data,len(b),48000,0);out=np.zeros((64,2),dtype='<f4');render=p.l.gremlin_cps3_render(out.ctypes.data,64)if not status else 64
 results.append({'test':name+' safely rejected on render','pass':status==0 and render==0 and not np.any(out),'error':p.l.gremlin_cps3_error().decode()});p.close()
for rate in [8000,44100,48000,192000]:
 p.load(R/'native/sfiii-soundtest-01.c3m',rate);n=0;target=round(17*rate);tail=None
 while n<target:
  count=min(4096,target-n);tail=p.render(count);n+=count
 results.append({'test':'valid rate and finite zero tail '+str(rate),'pass':bool(np.all(tail==0))});p.close()
def render_chunks(sizes):
 p.load(R/'native/sfiii-soundtest-01.c3m');parts=[];n=0
 while n<96000:
  count=min(sizes[n%len(sizes)],96000-n);parts.append(p.render(count));n+=count
 p.close();return np.concatenate(parts)
a=render_chunks([4096]);b=render_chunks([1,3,17,511,16384]);results.append({'test':'render block size invariant','pass':bool(np.array_equal(a,b))})
p.load(R/'native/sfiii-soundtest-01.c3m');attempt('bad replacement unloads previous',b'bad')
out=np.ones((4,2),dtype='<f4');status=p.l.gremlin_cps3_render(out.ctypes.data,4);results.append({'test':'no stale audio after failed load','pass':status==0 and not np.any(out)})
p.load(R/'native/sfiii-soundtest-01.c3m');again=p.render(4096);p.close();results.append({'test':'clean reload after failures','pass':bool(np.array_equal(again,a[:4096]))})
(R/'input-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'checks':len(results),'passed':sum(x['pass']for x in results),'failed':[x for x in results if not x['pass']]}));assert all(x['pass']for x in results)

