from pathlib import Path
import json,struct,subprocess,hashlib,zlib
R=Path(__file__).resolve().parent;O=R/'native';O.mkdir(exist_ok=True);P=R/'probes';P.mkdir(exist_ok=True)
CPU=25000000;RATE=37286
plans=json.loads((R/'music-plan.json').read_text())
for plan in plans:
 key=plan['game'];name=f"{key}-soundtest-{plan['sound_test_code']:02x}"
 raw=list(struct.iter_unpack('<QII',Path(plan['source_trace']).read_bytes()))
 origin=plan['origin_cycle'];captured=plan['captured_end_cycle']
 effective=[(t,a,v)for t,a,v in raw if a<=512]
 if plan['sound_test_code']==1:
  last_on=max(t for t,a,v in effective if origin<=t<captured and a==512 and v)
  natural_off=next(t for t,a,v in effective if t>last_on and a==512 and v==0)
  end=min(captured,natural_off+CPU//4);plan['natural_all_key_off_cycle']=natural_off;plan['ending_kind']='natural_music_end_with250ms_silence'
 else:
  end=min(captured,origin+CPU*63)if plan['sound_test_code']==2 else captured;plan['ending_kind']='original looping music; final3s player fade; no historical recording duration equivalence claimed'
 plan['selected_end_cycle']=end
 reference=P/(name+'-reference.f32');pages_file=P/(name+'-pages.bin');snapshot=P/(name+'-snapshot.bin');stats=P/(name+'-reference.json')
 subprocess.run([str(R/'reference-cps3'),plan['source_trace'],str(R/'original'/(key+'-romuser.bin')),str(origin),str(end),str(reference),str(pages_file),str(snapshot),str(stats)],check=True)
 state=snapshot.read_bytes();assert len(state)==512
 pages=[x[0]for x in struct.iter_unpack('<I',pages_file.read_bytes())];assert pages and pages==sorted(set(pages))
 rom=(R/'original'/(key+'-romuser.bin')).read_bytes();sample_pages=b''.join(bytes(rom[(p*4096+i)^1]for i in range(4096))for p in pages)
 all_events=[(t-origin,a,v)for t,a,v in effective if origin<=t<end]
 # Losslessly omit only writes that leave every original register and key bit unchanged.
 words=[]
 for value, in struct.iter_unpack('<I',state):words.extend([value>>16,value&65535])
 words.append(0);events=[]
 for t,a,v in all_events:
  index=a//2
  if words[index]!=v:events.append((t,a,v));words[index]=v
 assert events

 payload=b''.join(struct.pack('<QHHI',t,a,v,0)for t,a,v in events)
 
 table=b''.join(struct.pack('<I',p)for p in pages);data_offset=640+len(table);event_offset=data_offset+len(sample_pages);size=event_offset+len(payload)
 phase=(origin*RATE)%CPU;duration=((end-origin)*RATE+phase)//CPU
 h=bytearray(128);h[:4]=b'C3M\x1a'
 fields=[1,1,14318181,RATE,CPU,len(rom),len(pages),len(events),512,phase,duration,128,640,data_offset,event_offset,size,zlib.crc32(state),zlib.crc32(table),zlib.crc32(sample_pages),zlib.crc32(payload),0]
 struct.pack_into('<21I',h,4,*fields);struct.pack_into('<QQ',h,88,origin,end-origin)
 blob=bytes(h)+state+table+sample_pages+payload;assert len(blob)==size
 file=O/(name+'.c3m');file.write_bytes(blob)
 plan.update(name=name,file=str(file),bytes=size,sha256=hashlib.sha256(blob).hexdigest(),original_sample_pages=len(pages),stored_original_sample_bytes=len(sample_pages),events=len(events),source_effective_writes=len(all_events),unchanged_writes_omitted=len(all_events)-len(events),phase=phase,duration_samples=duration,seconds=duration/RATE,reference=str(reference),reference_stats=str(stats),initial_snapshot=str(snapshot),no_rendered_track_in_native_file=True,research_only=True)
 print(json.dumps({k:plan[k]for k in ['name','bytes','original_sample_pages','stored_original_sample_bytes','events','seconds']}),flush=True)
(R/'banks.json').write_text(json.dumps(plans,indent=2)+'\n')

