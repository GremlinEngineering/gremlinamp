from pathlib import Path
import re,json,hashlib
R=Path(__file__).resolve().parent;G=R.parent;S=G/'work-040/references';O=R/'source';O.mkdir(exist_ok=True)
def clean(s):
 return re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:' '*len(m[0]),s,flags=re.S)
def body(s,pattern):
 m=re.search(pattern,s,re.M);assert m,pattern;c=clean(s);p=c.index('{',m.start());depth=1;i=p+1
 while depth:
  if c[i]=='{':depth+=1
  elif c[i]=='}':depth-=1
  i+=1
 return s[m.start():i],s[:m.start()].count('\n')+1
src=(S/'071-src_mame_capcom_cps3_a.cpp').read_text();methods=[];proof=[]
for pattern in [r'^void cps3_sound_device::sound_stream_update',r'^void cps3_sound_device::sound_w',r'^uint32_t cps3_sound_device::sound_r']:
 text,line=body(src,pattern);methods.append(text);proof.append({'source':'071-src_mame_capcom_cps3_a.cpp','start_line':line,'sha256':hashlib.sha256(text.encode()).hexdigest(),'unchanged':True})
(O/'mame_cps3_methods.inc').write_text('// license:BSD-3-Clause\n// copyright-holders:Philip Bennett\n// Exact pinned original methods; framework/ROM transport provided by cps3_chip.h.\n\n'+'\n\n'.join(methods)+'\n')
h=(S/'071-src_mame_capcom_cps3_a.h').read_text();a=h.index('struct cps3_voice');b=h.index('// ======================> cps3_sound_device',a)
(O/'mame_cps3_voice.h').write_text('// license:BSD-3-Clause\n// copyright-holders:Philip Bennett\n'+h[a:b])
(R/'method-extraction-proof.json').write_text(json.dumps({'pin':'40d0f1125befade5edc08ec5699442ca3a229c01','original_source_sha256':hashlib.sha256(src.encode()).hexdigest(),'methods':proof,'voice_definition_sha256':hashlib.sha256(h[a:b].encode()).hexdigest()},indent=2)+'\n')
print('Copied3 unchanged original MAME CPS3 PCM methods and exact voice state')

