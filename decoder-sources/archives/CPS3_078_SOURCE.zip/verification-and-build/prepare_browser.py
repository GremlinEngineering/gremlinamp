from pathlib import Path
import json,shutil,hashlib,gzip
import numpy as np
R=Path(__file__).resolve().parent;G=R.parent;P=R/'player/games/music_player'
shutil.copytree(G/'work-077/player/games/music_player',P,dirs_exist_ok=True)
vendor=P/'vendor/cps3';vendor.mkdir(exist_ok=True)
for name in ['gremlin-cps3.wasm','gremlin-cps3.js','BUILD.json']:shutil.copy2(R/'built'/name,vendor/name)
shutil.copy2(R/'cps3-worker.js',P/'cps3-worker.js')
p=P/'decoders.js';s=p.read_text();s=s.replace('export const DECODERS=Object.freeze({',"export const DECODERS=Object.freeze({\n  cps3:Object.freeze(['c3m','c3z']),");s=s.replace("worker:id==='mario'?","worker:id==='cps3'?'cps3-worker.js':id==='mario'?");p.write_text(s)
rows=[];banks=json.loads((R/'banks.json').read_text())
for b in banks:
 payload=Path(b['file']).read_bytes();compressed=gzip.compress(payload,compresslevel=9,mtime=0);asset=Path(b['file']).with_suffix('.c3z');asset.write_bytes(compressed)
 b.update(compressed_file=str(asset),compressed_bytes=len(compressed),compressed_sha256=hashlib.sha256(compressed).hexdigest())
 source=np.fromfile(b['reference'],dtype='<f4').reshape(-1,2);data=np.vstack([source,np.zeros((2,2),dtype='<f4')])
 for rate in [44100,48000]:
  frames=(len(source)*rate+37285)//37286;num=np.arange(frames,dtype=np.int64)*37286;at=num//rate;rem=num%rate
  a=data[at].astype(np.float64);z=data[at+1].astype(np.float64)
  expected=(a+(z-a)*rem[:,None]/rate).astype('<f4')
  path=R/'probes'/(b['name']+f'-{rate}-browser-reference.f32');expected.tofile(path)
  rows.append({'key':b['name'],'rate':rate,'file':str(asset),'sha256':b['compressed_sha256'],'expected':str(path),'frames':frames,'format':'c3z'})
(R/'banks.json').write_text(json.dumps(banks,indent=2)+'\n');(R/'browser-plan.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Browser source-reference plan',len(rows),'production compressed bytes',[b['compressed_bytes']for b in banks])

