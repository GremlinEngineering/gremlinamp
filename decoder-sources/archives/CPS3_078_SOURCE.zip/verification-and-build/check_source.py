from pathlib import Path
import json,hashlib
import numpy as np
from render_cps3 import Player
R=Path(__file__).resolve().parent;p=Player();results=[]
for b in json.loads((R/'banks.json').read_text()):
 expected=np.fromfile(b['reference'],dtype='<f4').reshape(-1,2)
 p.load(b['file'],37286);n=0;maximum=0.;energy=0.;peak=0.;same=True;last=None
 while n<len(expected):
  count=min(4096,len(expected)-n);a=p.render(count);ref=expected[n:n+count];delta=a.astype(np.float64)-ref;same=same and np.array_equal(a,ref);maximum=max(maximum,float(np.max(np.abs(delta))));energy+=float(np.sum(delta**2));peak=max(peak,float(np.max(np.abs(a))));n+=count;last=a
 stats=json.loads(p.l.gremlin_cps3_stats());p.close()
 row={'name':b['name'],'frames':len(expected),'full_original_bank_reference':b['reference_stats'],'trimmed_snapshot_and_sparse_original_pages':True,'max_error':maximum,'rms_error':(energy/(len(expected)*2))**.5,'bit_exact':bool(same),'peak':peak,'reference_sha256':hashlib.sha256(Path(b['reference']).read_bytes()).hexdigest(),'stats':stats,'pass':bool(same)}
 results.append(row);print(json.dumps(row),flush=True)
(R/'source-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(x['pass']for x in results)

