from pathlib import Path
import subprocess,os,json,hashlib
R=Path(__file__).resolve().parent;SDK=R.parent/'work-040/references/emsdk';B=R/'build-wasm';B.mkdir(exist_ok=True);O=R/'built';O.mkdir(exist_ok=True)
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten')}
exports=['_gremlin_cps3_load','_gremlin_cps3_render','_gremlin_cps3_close','_gremlin_cps3_error','_gremlin_cps3_devices','_gremlin_cps3_stats','_malloc','_free']
cmd=['python3',str(SDK/'install/emscripten/em++.py'),'-std=c++20','-O3','-fwrapv','-ffp-contract=off','-fwasm-exceptions',str(R/'source/cps3_core.cpp'),'--no-entry','-sSUPPORT_LONGJMP=wasm','-sMODULARIZE=1','-sEXPORT_NAME=GremlinCPS3Music','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=67108864','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(O/'gremlin-cps3.js')]
with(B/'build.log').open('w')as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
result={'compiler':'Emscripten 6.0.13','format':'C3M1 original CPS3 PCM register events, original SIMM pages, all-key-off snapshot with exact sample phase; unchanged pinned MAME PCM methods; no rendered track','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in O.glob('gremlin-cps3.*')]}
(O/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
