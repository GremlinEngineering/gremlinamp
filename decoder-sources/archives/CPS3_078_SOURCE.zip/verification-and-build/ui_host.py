from pathlib import Path
import ctypes as c,json,os,sys,hashlib
from PIL import Image
R=Path(__file__).resolve().parent
class Host:
 def __init__(self,driver='sfiii',folder='service-1',profile='observer'):
  self.driver=driver;self.profile=profile;self.directory=R/'fbneo-host'/f'{driver}-{folder}'
  self.directory.mkdir(parents=True,exist_ok=True);(self.directory/'config/games').mkdir(parents=True,exist_ok=True);os.chdir(self.directory)
  self.frames=0;self.audio=hashlib.sha256();self.video=hashlib.sha256();self.samples=0;self.actions=[]
  self.trace=self.directory/'pcm-registers.bin'
  if self.trace.exists():raise RuntimeError('Refuse to overwrite existing trace; choose a fresh folder')
  if profile=='observer':os.environ['GREMLIN_CPS3_TRACE']=str(self.trace)
  l=self.l=c.CDLL(str(R/'build'/f'fbneo-{profile}.dylib'))
  l.FBHeadlessSetRomPath.argtypes=[c.c_char_p];l.FBHeadlessLoadDriver.argtypes=[c.c_char_p]
  l.FBHeadlessGetVideoBuffer.restype=c.c_void_p;l.FBHeadlessGetAudioBuffer.restype=c.c_void_p
  assert l.FBHeadlessInit()==0;l.FBHeadlessSetRomPath(str(R/'fbneo-host/roms').encode());assert l.FBHeadlessLoadDriver(driver.encode())==0
  if hasattr(l,'FBHeadlessCPS3OriginalBank'):
   l.FBHeadlessCPS3OriginalBank.restype=c.c_void_p;l.FBHeadlessCPS3Cycle.restype=c.c_uint64
   self.bank_before=hashlib.sha256(c.string_at(l.FBHeadlessCPS3OriginalBank(),l.FBHeadlessCPS3OriginalBankSize())).hexdigest()
 def run(self,n,buttons=()):
  if not isinstance(n,int)or not 0<n<=20000:raise ValueError('frame bound')
  for b in buttons:self.l.FBHeadlessSetInput(0,b,1)
  for _ in range(n):
   l=self.l;l.FBHeadlessRunFrame(1);count=l.FBHeadlessGetAudioFrames();self.audio.update(c.string_at(l.FBHeadlessGetAudioBuffer(),count*4));self.samples+=count;self.frames+=1
   self.video.update(c.string_at(l.FBHeadlessGetVideoBuffer(),l.FBHeadlessGetVideoHeight()*l.FBHeadlessGetVideoPitch()))
  for b in buttons:self.l.FBHeadlessSetInput(0,b,0)
  self.l.FBHeadlessCPS3TraceFlush();row={'frames':n,'buttons':list(buttons),**self.stats()};self.actions.append(row);(self.directory/'actions.json').write_text(json.dumps(self.actions,indent=2)+'\n');return row
 def stats(self):
  return {'frames_after':self.frames,'samples_after':self.samples,'cpu_cycle':self.l.FBHeadlessCPS3Cycle(),'events':self.trace.stat().st_size//16 if self.trace.exists()else 0}
 def screen(self,name):
  l=self.l;w=l.FBHeadlessGetVideoWidth();h=l.FBHeadlessGetVideoHeight();pitch=l.FBHeadlessGetVideoPitch();pixels=c.string_at(l.FBHeadlessGetVideoBuffer(),pitch*h);p=self.directory/(name+'.png');Image.frombytes('RGB',(w,h),pixels,'raw','BGRX',pitch).save(p);return str(p)
 def bank(self):
  l=self.l;raw=c.string_at(l.FBHeadlessCPS3OriginalBank(),l.FBHeadlessCPS3OriginalBankSize());sha=hashlib.sha256(raw).hexdigest();assert sha==self.bank_before,'original ROM bank changed during execution'
  target=R/'original';target.mkdir(exist_ok=True);p=target/(self.driver+'-romuser.bin');p.write_bytes(raw)
  row={'game':self.driver,'file':str(p),'bytes':len(raw),'sha256':sha,'unchanged_since_load':True,'canonical_sample_byte':'raw[address xor1], as original source fetch','source':'original SIMM ROM pairs, original FBNeo loader; archive identities checked separately'}
  (target/(self.driver+'-romuser-proof.json')).write_text(json.dumps(row,indent=2)+'\n');return row
 def close(self):
  self.l.FBHeadlessCPS3TraceFlush();summary={'driver':self.driver,'profile':self.profile,'frame_rate_x100':self.l.FBHeadlessGetFrameRate(),'actions':self.actions,'audio_s16_sha256':self.audio.hexdigest(),'video_sha256':self.video.hexdigest(),'no_gameplay_memory_writes':True,**self.stats()}
  (self.directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');self.l.FBHeadlessExit();return summary
if __name__=='__main__':
 h=Host(sys.argv[1]if len(sys.argv)>1 else'sfiii',sys.argv[2]if len(sys.argv)>2 else'service-1')
 print(json.dumps({'ready':True,'directory':str(h.directory)}),flush=True)
 for line in sys.stdin:
  try:
   d=json.loads(line);cmd=d['cmd']
   if cmd=='run':result=h.run(d['frames'],d.get('buttons',()))
   elif cmd=='screen':result=h.screen(d['name'])
   elif cmd=='bank':result=h.bank()
   elif cmd=='stats':result=h.stats()
   elif cmd=='close':result=h.close();print(json.dumps({'result':result}),flush=True);break
   else:raise ValueError(cmd)
   print(json.dumps({'result':result}),flush=True)
  except Exception as e:print(json.dumps({'error':str(e)}),flush=True)

