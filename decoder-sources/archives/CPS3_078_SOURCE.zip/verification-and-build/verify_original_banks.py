from pathlib import Path
import json,zipfile,hashlib,re
R=Path(__file__).resolve().parent;G=R.parent;driver=(R/'fbneo-research/src/burn/drv/cps3/d_cps3.cpp').read_text();results=[]
for game,macro in [('sfiii','SFIII_970204_FLASH'),('sfiii2','SFIII2_970930_FLASH'),('sfiii3','SFIII3_990608_FLASH')]:
 proof=R/'original'/(game+'-romuser-proof.json')
 if not proof.exists():continue
 start=driver.index('#define '+macro);stop=driver.index('\n\n',start);section=driver[start:stop]
 entries=[(name,int(size,16),int(crc,16))for name,size,crc,flags in re.findall(r'\{\s*"([^"]+)",\s*(0x[0-9a-fA-F]+),\s*(0x[0-9a-fA-F]+),\s*([^}]+)\}',section)if 'BRF_GRA'in flags or'BRF_SND'in flags]
 raw=(R/'original'/(game+'-romuser.bin')).read_bytes();offset=0;rows=[];canonical_digest=hashlib.sha256()
 with zipfile.ZipFile(G/'work-040/references'/(game+'-original-078.zip'))as z:
  for i in range(0,len(entries),2):
   pair=[]
   for name,size,crc in entries[i:i+2]:
    infos=[x for x in z.infolist()if x.CRC==crc and x.file_size==size];assert infos,(game,name,hex(crc))
    info=next((x for x in infos if Path(x.filename).name==name),infos[0]);data=z.read(info);pair.append(data);rows.append({'name':name,'archive_member':info.filename,'bytes':len(data),'crc32':f'{crc:08x}','sha1':hashlib.sha1(data).hexdigest(),'sha256':hashlib.sha256(data).hexdigest()})
   a,b=pair;assert len(a)==len(b);block=raw[offset:offset+len(a)*2];assert block[0::2]==a and block[1::2]==b
   # Exact current MAME copy_from_nvram u32 expression, serialized LE:
   # (flash0[i]<<8)|(flash0[i+1]<<24)|flash1[i]|(flash1[i+1]<<16).
   mame=bytearray(len(block));mame[0::4]=b[0::2];mame[1::4]=a[0::2];mame[2::4]=b[1::2];mame[3::4]=a[1::2]
   expected=bytearray(len(block));expected[0::2]=block[1::2];expected[1::2]=block[0::2];assert expected==mame
   canonical_digest.update(mame);offset+=len(block)
 assert offset==len(raw),(game,offset,len(raw))
 row={'game':game,'all_original_bytes_verified':True,'raw_bank_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'canonical_mame_bank_sha256':canonical_digest.hexdigest(),'canonical_mapping':'raw[address xor1]; exactly pinned MAME copy_from_nvram plus BYTE4_XOR_LE on LE host','original_SIMMs':rows};results.append(row);print(game,'all original bank bytes verified',len(rows),'SIMMs',flush=True)
(R/'original-sample-bank-proof.json').write_text(json.dumps(results,indent=2)+'\n')

