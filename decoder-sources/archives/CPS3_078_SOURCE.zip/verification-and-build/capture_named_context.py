from ui_host import Host
import sys,json
game=sys.argv[1];h=Host(game,'named-context-1')
h.run(4800);h.screen('attract')
for _ in range(2):h.run(3,[11]);h.run(45)
h.screen('two-coins');h.run(3,[10]);h.run(120);h.screen('player-select')
h.run(300);h.screen('player-select-wait');h.run(3,[4]);h.run(90);h.run(3,[4]);h.run(300);h.screen('battle-start')
h.run(600);h.screen('battle-context')
summary=h.close();print(json.dumps({'game':game,'frames':summary['frames_after'],'directory':str(h.directory)}))

