const fs=require('node:fs'),http=require('node:http'),path=require('node:path');
const{chromium}=require('/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const R=__dirname,player=path.join(R,'player/games/music_player');
function findNwz(folder){for(const d of fs.readdirSync(folder,{withFileTypes:true})){const p=path.join(folder,d.name);if(d.isDirectory()){const v=findNwz(p);if(v)return v;}else if(d.name.endsWith('.nwz'))return p;}}
const baseline=path.resolve(R,'../full-transfer/Gremlin_Music_Codex_Full_No_MP3_039');
const legacy=findNwz(path.join(baseline,'music'));
(async()=>{
 const server=http.createServer((req,res)=>{
  const u=new URL(req.url,'http://localhost');if(u.pathname==='/'){res.setHeader('Content-Type','text/html');return res.end('<!doctype html>');}
  if(u.pathname==='/legacy.nwz')return res.end(fs.readFileSync(legacy));
  const music=u.pathname.startsWith('/music/'),base=music?player:path.join(R,'native'),rel=u.pathname.slice(music?7:8),file=path.resolve(base,rel);
  if(!file.startsWith(base+path.sep))return res.writeHead(404).end();
  res.setHeader('Content-Type',({'.js':'application/javascript','.wasm':'application/wasm'})[path.extname(file)]||'application/octet-stream');fs.readFile(file,(e,b)=>{res.statusCode=e?404:200;res.end(e?'missing':b)});
 });await new Promise(r=>server.listen(8981,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--autoplay-policy=no-user-gesture-required','--mute-audio','--disable-audio-output']});
 const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:8981');
 const results=await page.evaluate(async()=>{
  const{MusicEngine}=await import('/music/engine.js');const e=new MusicEngine(),checks=[],nodes=[];const orig=AudioContext.prototype.createGain;
  AudioContext.prototype.createGain=function(...args){const n=orig.apply(this,args);nodes.push(n);return n;};
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  function manifest(file,topGain=false,cue=0){const t={backend:'native',asset:{url:file==='legacy.nwz'?'/legacy.nwz':'/native/'+file,format:file.split('.').pop(),path:file,bytes:10000},subsong:cue,play_ms:60000,fade_ms:0};if(topGain)t.gain_db=-6;else t.playback={gain_db:-6};return{id:file+'-'+cue,manifestURL:location.href,delivery:{preload_budget_bytes:0},tracks:[t]};}
  const a=manifest('sfiii-soundtest-01.c3z');e.setVolume(1);await e.play(a,0);await wait(1800);
  checks.push({test:'Original CPS3 register events and original sample pages start and produce PCM',pass:e.state==='playing'&&e.diagnostics.rms>0,error:e.error,context:{state:e.context.state,time:e.context.currentTime},seconds:e.seconds,diagnostics:e.diagnostics});
  e.pause();await wait(100);const paused=e.seconds;await wait(300);checks.push({test:'pause holds position',pass:e.state==='paused'&&Math.abs(e.seconds-paused)<.12});
  await e.play(a,0);await wait(400);checks.push({test:'resume advances',pass:e.state==='playing'&&e.seconds>paused});
  checks.push({test:'nested gain_db',pass:Math.abs(nodes[0].gain.value-10**(-6/20))<1e-6});
  e.setVolume(.4);checks.push({test:'volume scales gain',pass:Math.abs(nodes[0].gain.value-.4*10**(-6/20))<1e-6});
  for(const [file,cue]of [['sfiii-soundtest-01.c3z',0],['legacy.nwz',0],['sfiii-soundtest-01.c3z',0]]){await e.play(manifest(file,true,cue),0);checks.push({test:'switch '+file,pass:e.state==='playing',error:e.error});}
  const gainNode=nodes[nodes.length-1];checks.push({test:'top-level gain_db',pass:Math.abs(gainNode.gain.value-.4*10**(-6/20))<1e-6});
  e.stop();checks.push({test:'stop disposes backend',pass:e.state==='idle'&&e.backend===null&&e.seconds===0});
  const pending=e.play(manifest('sfiii-soundtest-01.c3z'),0);e.stop();await pending;checks.push({test:'stop cancels loading',pass:e.state==='idle'&&e.backend===null});
  const short=manifest('sfiii-soundtest-01.c3z');short.id='succession';short.tracks[0].play_ms=700;short.tracks.push({...manifest('sfiii-soundtest-01.c3z').tracks[0]});await e.play(short,0);for(let i=0;i<250&&!(e.index===1&&e.state==='playing');i++)await wait(100);checks.push({test:'natural end advances playlist',pass:e.index===1&&e.state==='playing',error:e.error});
  e.stop();if(e.context)await e.context.close();AudioContext.prototype.createGain=orig;return checks;
 });
 await browser.close();await new Promise(r=>server.close(r));fs.writeFileSync(path.join(R,'controls-results.json'),JSON.stringify({results,errors},null,2));console.log(JSON.stringify({results,errors}));if(errors.length||results.some(x=>!x.pass))process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
