from pathlib import Path
import sys,json
from ui_host import Host,R
game=sys.argv[1];codes=[int(x,0)for x in sys.argv[2].split(',')];folder=sys.argv[3]if len(sys.argv)>3 else'expanded-soundtest-1'
h=Host(game,folder);plans=[]
def run(frames,buttons=()):
 row=h.run(frames,buttons);print(json.dumps({'game':game,**row}),flush=True);return row
def press(button):run(3,[button]);run(10)
run(900);press(12);run(60);press(1);press(1);press(4);run(60);h.screen('sound-test-menu')
current=0
for code in codes:
 while current<code:press(0);current+=1
 while current>code:press(1);current-=1
 h.screen(f'code-{code:02x}-before');origin=h.stats()['cpu_cycle']
 run(3,[4]);run(12800 if code>=5 else 9000);end=h.stats()['cpu_cycle'];h.screen(f'code-{code:02x}-played')
 plan={'game':game,'source_trace':str(h.trace),'sound_test_code':code,'origin_cycle':origin,'captured_end_cycle':end,'source':'Ordinary original Sound&Voice Test controls; no gameplay memory writes','minimum_requirement_not_upper_limit':True}
 plans.append(plan);(h.directory/'music-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
 run(3,[5]);run(30);h.screen(f'code-{code:02x}-stopped')
h.bank();summary=h.close();print(json.dumps({'complete':True,'game':game,'codes':codes,'frames':summary['frames_after'],'plans':str(h.directory/'music-plan.json')}),flush=True)

