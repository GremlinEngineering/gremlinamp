from pathlib import Path
import difflib
R=Path(__file__).resolve().parent;D=R/'fbneo-research/src/burn/drv/cps3'
p=D/'cps3run.cpp';s=p.read_text();(R/'cps3run.original.cpp').write_text(s)
a=s.index('static UINT32 cps3_data_rom_size;')+len('static UINT32 cps3_data_rom_size;')
glue='''
// Gremlin078: read-only original PCM register/ROM observer.
static UINT64 gremlin_cps3_frame_base=0;
static UINT32 gremlin_cps3_frame_index=0;
static FILE*gremlin_cps3_trace=nullptr;
static void gremlin_cps3_record(UINT64 time,UINT32 address,UINT32 value){
 if(!gremlin_cps3_trace){const char*p=getenv("GREMLIN_CPS3_TRACE");if(p)gremlin_cps3_trace=fopen(p,"ab");}
 if(gremlin_cps3_trace){fwrite(&time,8,1,gremlin_cps3_trace);fwrite(&address,4,1,gremlin_cps3_trace);fwrite(&value,4,1,gremlin_cps3_trace);}
}
void gremlin_cps3_event(UINT32 address,UINT32 value){
 gremlin_cps3_record(gremlin_cps3_frame_base+(UINT32)Sh2TotalCycles(),address,value);
}
extern "C" __attribute__((visibility("default"))) const UINT8*FBHeadlessCPS3OriginalBank(){return RomUser;}
extern "C" __attribute__((visibility("default"))) UINT32 FBHeadlessCPS3OriginalBankSize(){return cps3_data_rom_size;}
extern "C" __attribute__((visibility("default"))) UINT64 FBHeadlessCPS3Cycle(){return gremlin_cps3_frame_base+(UINT32)Sh2TotalCycles();}
extern "C" __attribute__((visibility("default"))) void FBHeadlessCPS3TraceFlush(){if(gremlin_cps3_trace)fflush(gremlin_cps3_trace);}
'''
s=s[:a]+glue+s[a:]
anchor='\tSh2NewFrame();'
assert s.count(anchor)==1
s=s.replace(anchor,anchor+'''
\tif(gremlin_cps3_frame_index)gremlin_cps3_frame_base+=(UINT32)((double)25000000*100/nBurnFPS);
\tgremlin_cps3_record(gremlin_cps3_frame_base,0xffff0000,gremlin_cps3_frame_index++);
''',1)
p.write_text(s)
p=D/'cps3snd.cpp';t=p.read_text();(R/'cps3snd.original.cpp').write_text(t)
t=t.replace('void __fastcall cps3SndWriteWord(UINT32 addr, UINT16 data)\n{','void __fastcall cps3SndWriteWord(UINT32 addr, UINT16 data)\n{\n\tgremlin_cps3_event(addr & 0x3ff,data);',1)
p.write_text(t)
p=D/'cps3.h';h=p.read_text();(R/'cps3.original.h').write_text(h);p.write_text(h+'\n// Gremlin078 read-only original effective register-write observer.\nvoid gremlin_cps3_event(UINT32 address,UINT32 value);\n')
patch=''.join(difflib.unified_diff((R/'cps3run.original.cpp').read_text().splitlines(True),s.splitlines(True),fromfile='stock/cps3run.cpp',tofile='observer/cps3run.cpp'))
patch+=''.join(difflib.unified_diff((R/'cps3snd.original.cpp').read_text().splitlines(True),t.splitlines(True),fromfile='stock/cps3snd.cpp',tofile='observer/cps3snd.cpp'))
(R/'observer.patch').write_text(patch)
p=R/'capture_context.py';s=p.read_text().replace("os.environ['GREMLIN_MCU_TRACE']","os.environ['GREMLIN_CPS3_TRACE']").replace("'mcu-events.bin'","'pcm-registers.bin'").replace("'missing_prerecorded_sfx_samples':True","'missing_prerecorded_sfx_samples':False").replace("'music_reference':'Unmodified original MCU program; prerecorded SFX path excluded from native target.'","'music_reference':'Original CPS3 game PCM register writes and original ROM sample data; no missing external SFX samples.'")
p.write_text(s)
print('Prepared read-only CPS3 register/ROM observer with original25MHz frame profile')

