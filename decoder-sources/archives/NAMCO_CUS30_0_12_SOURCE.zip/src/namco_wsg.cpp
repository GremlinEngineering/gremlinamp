// Standalone Namco WSG register-stream renderer.
// Chip algorithms adapted from MAME namco.cpp/namco.h at commit
// 40d0f1125befade5edc08ec5699442ca3a229c01.
// license: BSD-3-Clause
// copyright-holders: Nicola Salmoria, Aaron Giles
#include <stdint.h>
#include <string.h>
#include <limits>
#include <numeric>
#include <string>
#include <vector>
#include <algorithm>
#include <stdio.h>
struct NwsEvent { uint32_t tick,op,arg; };
struct Voice {
 uint32_t frequency=0,counter=0,noise_seed=1,noise_counter=0;
 uint8_t volume=0,right_volume=0,waveform=0,noise_state=0;
 bool noise=false;
 uint32_t noise_hold=0;
};
static std::vector<NwsEvent> events;
static Voice voices[8];
static uint8_t prom[256],regs[64];
static uint32_t profile=0,clock_hz=0,event_rate=0,rate=0,voice_count=0,internal_rate=0,frac_bits=0,total_ticks=0,start_tick=0,loop_index=0xffffffffu,loop_tick=0xffffffffu;
static size_t event_index=0;
static uint64_t common_clock=0,tick_unit=0,internal_unit=0,output_unit=0,now=0,next_internal=0,epoch=0;
static bool enabled=true,loaded=false;
static int32_t current=0;
static std::string error_text,device_text;
static uint32_t le32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static uint64_t gcd64(uint64_t a,uint64_t b){while(b){uint64_t c=a%b;a=b;b=c;}return a;}
static uint64_t lcm64(uint64_t a,uint64_t b){a/=gcd64(a,b);if(a>UINT64_MAX/b)return 0;return a*b;}
static void write_reg(uint32_t offset,uint8_t data){
 if(profile==1)data&=15;
 if(regs[offset]==data)return;
 regs[offset]=data;
 if(profile==1){
  // Pac-Man/Pengo PROM WSG: three voices; only voice0 has the low frequency nibble.
  for(unsigned ch=0;ch<3;ch++){
   auto&v=voices[ch];v.waveform=regs[5+ch*5]&7;v.volume=regs[0x15+ch*5]&15;
   v.frequency=(ch==0?regs[0x10]:0)|(uint32_t(regs[0x11+ch*5])<<4)|(uint32_t(regs[0x12+ch*5])<<8)|(uint32_t(regs[0x13+ch*5])<<12)|(uint32_t(regs[0x14+ch*5])<<16);
  }
 }else if(profile==2){
  auto&v=voices[offset>>3];unsigned base=offset&~7u;
  switch(offset&7){
   case 2:v.counter=(v.counter&((uint32_t(1)<<frac_bits)-1))|(uint32_t(data&31)<<frac_bits);break;
   case 3:v.volume=data&15;break;
   case 6:v.waveform=(data>>4)&7;[[fallthrough]];
   case 4:case 5:v.frequency=uint32_t(regs[base+4])|(uint32_t(regs[base+5])<<8)|(uint32_t(regs[base+6]&15)<<16);break;
  }
 }else{
  auto&v=voices[offset>>3];unsigned base=offset&~7u;
  switch(offset&7){
   case 0:v.volume=data&15;break;
   case 1:v.waveform=(data>>4)&15;[[fallthrough]];
   case 2:case 3:v.frequency=(uint32_t(regs[base+1]&15)<<16)|(uint32_t(regs[base+2])<<8)|regs[base+3];break;
   case 4:v.right_volume=data&15;voices[((offset>>3)+1)&7].noise=bool(data&128);break;
  }
 }
}
static void step_internal(){
 for(;;){
  while(event_index<events.size()&&epoch+uint64_t(events[event_index].tick)*tick_unit<=now){
   const auto&e=events[event_index++];if(e.op==0)write_reg(e.arg>>8,uint8_t(e.arg));else if(e.op==1)enabled=bool(e.arg);else if(e.op==3)prom[e.arg>>8]=uint8_t(e.arg);else enabled=profile==1?bool(e.arg&255):bool(e.arg>>8);
  }
  if(now<epoch+uint64_t(total_ticks)*tick_unit)break;
  if(loop_index==0xffffffffu){current=0;return;}
  epoch+=uint64_t(total_ticks-loop_tick)*tick_unit;event_index=loop_index;
 }

 current=0;if(!enabled)return;
 for(unsigned ch=0;ch<voice_count;ch++){
  auto&v=voices[ch];
  if(profile==3&&v.noise){
   // CUS30 mono: right volume still gates noise-state advancement (MAME).
   if(v.volume||v.right_volume){
    int value=7*(v.volume>>1);current+=v.noise_state?value:-value;
    if(v.noise_hold){v.noise_hold--;continue;}
    v.noise_hold=uint32_t(1)<<(frac_bits-16);
    v.noise_counter+=(v.frequency&255)<<4;
    uint32_t count=v.noise_counter>>12;v.noise_counter&=4095;
    while(count--){if((v.noise_seed+1)&2)v.noise_state^=1;if(v.noise_seed&1)v.noise_seed^=0x28000;v.noise_seed>>=1;}
   }
   continue;
  }
  // Match MAME: muted voices retain their phase; the global enable latch also freezes phase.
  if(v.volume){const uint32_t p=(uint32_t(v.waveform)<<5)|((v.counter>>frac_bits)&31);const unsigned packed=profile==3?(prom[(p>>1)&255]>>((~p&1)*4)):prom[p];current+=(int(packed&15)-8)*v.volume;v.counter+=v.frequency;}
 }
}
extern "C" {
void gremlin_nws_close(){events.clear();for(auto&v:voices)v=Voice{};memset(prom,0,sizeof(prom));memset(regs,0,sizeof(regs));profile=voice_count=0;now=next_internal=epoch=0;current=0;event_index=0;enabled=true;loaded=false;device_text.clear();}
const char*gremlin_nws_error(){return error_text.c_str();}
const char*gremlin_nws_devices(){return device_text.c_str();}
int gremlin_nws_load(const uint8_t*b,uint32_t length,uint32_t output_rate){
 gremlin_nws_close();error_text.clear();
 auto fail=[](const char*s){error_text=s;return 1;};
 if(!b||length<320||memcmp(b,"NWS\x1a",4)||le32(b+4)!=1)return fail("Invalid NWS1 signature/header");
 profile=le32(b+8);clock_hz=le32(b+12);event_rate=le32(b+16);const uint32_t count=le32(b+20);total_ticks=le32(b+24);start_tick=le32(b+48);loop_index=le32(b+28);loop_tick=le32(b+32);const uint32_t prom_size=le32(b+36),prom_ofs=le32(b+40),event_ofs=le32(b+44);
 if((profile!=1&&profile!=2&&profile!=3)||clock_hz<1000||clock_hz>1000000||event_rate<1000||event_rate>2000000||output_rate<8000||output_rate>192000||!total_ticks||start_tick>=total_ticks)return fail("Unsupported NWS chip profile or timing");
 if(profile==3&&clock_hz!=24000)return fail("CUS30 profile 3 supports the verified 24000 Hz mono configuration");
 if(prom_size!=256||prom_ofs!=64||event_ofs!=320||uint64_t(event_ofs)+uint64_t(count)*12!=length)return fail("Invalid NWS data boundaries");
 if((loop_index==0xffffffffu)!=(loop_tick==0xffffffffu)|| (loop_index!=0xffffffffu&&(loop_index>=count||loop_tick>=total_ticks||loop_tick<start_tick)))return fail("Invalid NWS loop");
 for(unsigned i=52;i<64;i++)if(b[i])return fail("Unsupported NWS reserved flags");
 voice_count=profile==1?3:8;rate=output_rate;internal_rate=clock_hz;frac_bits=15;
 while(internal_rate<192000){internal_rate*=2;frac_bits++;}
 common_clock=lcm64(lcm64(internal_rate,event_rate),rate);if(!common_clock)return fail("NWS timing overflow");tick_unit=common_clock/event_rate;internal_unit=common_clock/internal_rate;output_unit=common_clock/rate;if(uint64_t(total_ticks)>UINT64_MAX/tick_unit)return fail("NWS duration overflow");
 memcpy(prom,b+prom_ofs,256);events.reserve(count);uint32_t previous=0;
 for(uint32_t i=0;i<count;i++){
  const uint8_t*p=b+event_ofs+i*12;NwsEvent e{le32(p),le32(p+4),le32(p+8)};
  if(e.tick<previous||e.tick>total_ticks||e.op>3||(e.op==0&&(e.arg>0xffff||(e.arg>>8)>=(profile==1?32u:64u)))||(e.op==1&&e.arg>1)||(e.op==2&&(profile==3||e.arg>0xffff||(e.arg>>8)>(profile==1?0u:1u)))||(e.op==3&&(profile!=3||e.arg>0xffff)))return fail("Invalid NWS event");
  previous=e.tick;events.push_back(e);
 }
 if(loop_index!=0xffffffffu&&events[loop_index].tick<loop_tick)return fail("NWS event precedes loop time");
 char text[320];snprintf(text,sizeof(text),"[{\"type\":\"%s\",\"voices\":%u,\"clock_hz\":%u,\"internal_sample_rate\":%u,\"source_event_rate\":%u,\"output_sample_rate\":%u,\"core\":\"MAME-derived Namco WSG BSD3\"}]",profile==1?"namco_wsg_3":profile==2?"namco_15xx_8":"namco_cus30",voice_count,clock_hz,internal_rate,event_rate,rate);device_text=text;loaded=true;
 // Preserve original chip initialization/phase, while omitting the ripper's boot delay from playback.
 const uint64_t first=uint64_t(start_tick)*tick_unit;
 while(now<first){if(now==next_internal){step_internal();next_internal+=internal_unit;}now=std::min(first,next_internal);}
 return 0;
}
uint32_t gremlin_nws_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;
 memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;
 for(uint32_t i=0;i<frames;i++){
  const uint64_t end=now+output_unit;int64_t sum=0;
  while(now<end){if(now==next_internal){step_internal();next_internal+=internal_unit;}const uint64_t boundary=std::min(end,next_internal);sum+=int64_t(current)*int64_t(boundary-now);now=boundary;}
  const float value=float(double(sum)/double(output_unit)/double(128*voice_count));out[i*2]=out[i*2+1]=value;
 }
 return frames;
}
}
