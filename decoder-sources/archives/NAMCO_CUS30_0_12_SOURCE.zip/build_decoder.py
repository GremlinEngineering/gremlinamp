from pathlib import Path
import subprocess, os, json, hashlib
R=Path(__file__).resolve().parent
sdk=R/'references/emsdk'
out=R/'namco-cus30-0.12/built';out.mkdir(exist_ok=True)
env={**os.environ,'EM_CONFIG':str(sdk/'.emscripten')}
exports=['_gremlin_nws_load','_gremlin_nws_render','_gremlin_nws_close','_gremlin_nws_error','_gremlin_nws_devices','_malloc','_free']
cmd=['python3',str(sdk/'install/emscripten/em++.py'),'-O3','-std=c++17','-ffp-contract=off',str(R/'namco-cus30-0.12/src/namco_wsg.cpp'),'--no-entry','-sMODULARIZE=1','-sEXPORT_NAME=GremlinNamcoWSG','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=134217728','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(out/'namco-wsg.js')]
subprocess.run(cmd,env=env,check=True)
rows=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in out.iterdir() if p.is_file() and p.name!='NAMCO_BUILD.json']
(out/'NAMCO_BUILD.json').write_text(json.dumps({'player_version':'0.12','compiler':'Emscripten 6.0.13','profiles':['namco_wsg_3','namco_15xx_8','namco_cus30_mono'],'files':rows},indent=2)+'\n')
print(rows)
