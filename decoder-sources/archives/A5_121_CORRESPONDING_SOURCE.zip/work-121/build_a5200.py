from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,zipfile,re
W=Path(__file__).resolve().parent;G=W.parent
p=argparse.ArgumentParser();p.add_argument('--emsdk',default=str(G/'work-040/references/emsdk'));p.add_argument('--output',default=str(W/'a5200-wasm'));p.add_argument('--native',action='store_true');a=p.parse_args()
B=Path(a.output).resolve();E=B/'core';E.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(W/'sources/a5200-source.zip')as z:
 for i in z.infolist():
  rel=Path(*Path(i.filename).parts[1:])
  if not rel.parts or i.is_dir():continue
  d=E/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(z.read(i))
common=(E/'Makefile.common').read_text();names=re.findall(r'\$\((LIBRETRO_DIR|CORE_SRC_DIR|LIBRETRO_COMM_DIR)\)/([^\s\\]+\.c)',common)
roots={'LIBRETRO_DIR':E/'libretro','CORE_SRC_DIR':E/'emu','LIBRETRO_COMM_DIR':E/'libretro/libretro-common'}
sources=[roots[k]/v for k,v in names]+[W/'a5_host.c'];SDK=Path(a.emsdk).resolve()
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'SOURCE_DATE_EPOCH':'0','DEVELOPER_DIR':'/Library/Developer/CommandLineTools'}
cc=['clang']if a.native else[sys.executable,str(SDK/'install/emscripten/emcc.py')]
flags=['-O2','-DNDEBUG','-D__LIBRETRO__','-DGIT_VERSION="40c6f2f"','-Drand=gremlin_a5_rand','-fsigned-char','-fno-strict-overflow','-ffp-contract=off','-I'+str(E/'emu'),'-I'+str(E/'libretro'),'-I'+str(E/'libretro/libretro-common/include')]
flags+=['-ffile-prefix-map='+str(W)+'=/gremlin-session121','-ffile-prefix-map='+str(B)+'=/gremlin-a5-build']
objects=[]
with(B/'build.log').open('w')as f:
 for n,s in enumerate(sources):
  o=B/(str(n)+'-'+s.stem+'.o');subprocess.run([*cc,*flags,'-c',str(s),'-o',str(o)],env=env,stdout=f,stderr=subprocess.STDOUT,check=True);objects.append(str(o))
 if a.native:
  outputs=['libgremlin-a5.dylib'];cmd=[*cc,'-dynamiclib',*objects,'-lm','-o',str(B/outputs[0])]
 else:
  outputs=['gremlin-a5.js','gremlin-a5.wasm'];exports=['_malloc','_free']+['_gremlin_a5_'+x for x in['load','close','step','audio','audio_frames','video','video_width','video_height','capture_video','error','source_rate','source_fps']]
  cmd=[*cc,'-O2','--no-entry',*objects,'-lm','-sMODULARIZE=1','-sEXPORT_NAME=GremlinAtari5200Music','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=33554432','-sSTACK_SIZE=1048576','-sFILESYSTEM=1','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16","HEAPU32","FS"]','-o',str(B/outputs[0])]
 subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
proof={'core':'libretro/a5200','commit':'40c6f2f1ad4a3145b328d5baaf010fae6c7e752b','original_core_source_unchanged':True,'floating_point_contraction':'off for both architectures','C_library_rand_adapter':'Park-Miller seed1, matching native reference; original quarter-LSB dither retained','outputs':{n:{'bytes':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()}for n in outputs}}
(B/'BUILD.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
