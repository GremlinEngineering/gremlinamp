from pathlib import Path
import json,hashlib,argparse
W=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--source',default=str(W/'dcs-source/DCSDecoder'));p.add_argument('--output',default=str(W/'dcs-arcade-reference'));a=p.parse_args()
src=Path(a.source)/'DCSDecoderEmu.cpp';text=src.read_text()
needle='uint16_t DCSDecoderEmulated::ReadDM(uint16_t addr)\n{'
assert needle in text
text=text.replace(needle,needle+'\n\t// Arcade DCS2K/UART sound latch. Original MK ROM programs unchanged.\n\tif (hwVersion == HWVersion::DCS93 && addr >= 0x3400 && addr <= 0x37FF)\n\t\treturn ReadDataPort();',1)
needle='void DCSDecoderEmulated::WriteDM(uint16_t addr, uint16_t data)\n{'
assert needle in text
text=text.replace(needle,needle+'\n\tif (hwVersion == HWVersion::DCS93 && addr >= 0x3400 && addr <= 0x37FF)\n\t\thost->ReceiveDataPort(static_cast<uint8_t>(data));',1)
out=Path(a.output);out.mkdir(parents=True,exist_ok=True);(out/'DCSDecoderEmu.cpp').write_text(text)
proof={'original_upstream':'mjrgh/DCSExplorer@3d2220f58406756293b9552b7df0b264969b7061','reference_board_adapter':'Arcade DCS2K/UART latch DM3400..37ff; pinball PM3000 retained','ADSP_interpreter_source_changes':False,'original_game_ROM_bytes_changed':False,'speedups':False,'PCM_or_music_program_changes':False,'upstream_file_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'adapted_file_sha256':hashlib.sha256((out/'DCSDecoderEmu.cpp').read_bytes()).hexdigest(),'board_reference':'FBNeo src/burn/drv/midway/dcs2k.cpp DCS_2K InputLatch / OutputLatch mappings'}
(out/'ADAPTER.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
