#include <cstring>
#include <cstddef>
#ifndef _countof
#define _countof(x) (sizeof(x)/sizeof((x)[0]))
#endif
/* MSVC's array overload is used only in the optional interactive debugger. */
template<std::size_t N> int strcpy_s(char (&out)[N],const char *s){
 const std::size_t n=std::strlen(s);
 if(n>=N){out[0]=0;return 1;}
 std::memcpy(out,s,n+1);return 0;
}
