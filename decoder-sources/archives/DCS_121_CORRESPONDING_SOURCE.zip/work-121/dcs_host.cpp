/* BSD-3-Clause. Frontend for unchanged pinned DCSExplorer original-ROM decoder.
 * Reference build selects its strict ADSP interpreter, with speedups disabled. */
#ifdef GREMLIN_DCS_REFERENCE
#include "DCSDecoderEmu.h"
using Decoder=DCSDecoderEmulated;
#else
#include "DCSDecoderNative.h"
using Decoder=DCSDecoderNative;
#endif
#include <cstdint>
#include <cstdio>
#include <memory>
#include <vector>
#include <string>
#include <exception>
static DCSDecoder::MinHost host;
static std::unique_ptr<Decoder> decoder;
static std::vector<uint8_t> original;
static std::string error;
static int16_t pcm[32768];
#define API extern "C" __attribute__((visibility("default")))
API void gremlin_dcs_close(){decoder.reset();original.clear();}
API const char*gremlin_dcs_error(){return error.c_str();}
API int gremlin_dcs_load(const uint8_t*data,uint32_t bytes,uint32_t chips,uint32_t chip_bytes){
 gremlin_dcs_close();error.clear();
 if(!data||chips<1||chips>8||(chip_bytes!=524288&&chip_bytes!=1048576)||bytes!=chips*chip_bytes){error="DCS bank bounds";return 1;}
 try{
  original.assign(data,data+bytes);
#ifdef GREMLIN_DCS_REFERENCE
  decoder=std::make_unique<Decoder>(&host,false);
#else
  decoder=std::make_unique<Decoder>(&host);
#endif
  for(unsigned i=0;i<chips;i++)decoder->AddROM(i+2,original.data()+i*chip_bytes,chip_bytes);
  if(decoder->CheckROMs()!=1){error="Original DCS ROM catalog/checksum failed";return 2;}
  decoder->SoftBoot();if(!decoder->IsRunning()){error=decoder->GetErrorMessage();return 3;}
  return 0;
 }catch(const char*s){error=s;return 4;}catch(const std::exception&e){error=e.what();return 4;}
}
API int gremlin_dcs_select(uint32_t track,uint32_t volume){
 if(!decoder||!decoder->IsRunning()||track>0x54ff||volume>255){error="DCS track/volume bounds";return 1;}
 DCSDecoder::TrackInfo info;if(!decoder->GetTrackInfo(track,info)){error="Original DCS track missing";return 2;}
 decoder->SetMasterVolume(volume);decoder->WriteDataPort(track>>8);decoder->WriteDataPort(track&255);return 0;
}
API int gremlin_dcs_render(uint32_t frames){
 if(!decoder||!decoder->IsRunning()||!frames||frames>16384){error="DCS render bounds";return 1;}
 try{for(unsigned i=0;i<frames;i++){const int16_t v=decoder->GetNextSample();pcm[2*i]=pcm[2*i+1]=v;}if(!decoder->IsRunning()){error=decoder->GetErrorMessage();return 2;}return 0;}
 catch(const char*s){error=s;return 3;}catch(const std::exception&e){error=e.what();return 3;}
}
API const int16_t*gremlin_dcs_audio(){return pcm;}
