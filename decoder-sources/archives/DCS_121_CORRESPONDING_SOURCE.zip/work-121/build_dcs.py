from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,zipfile

W=Path(__file__).resolve().parent;G=W.parent
p=argparse.ArgumentParser()
p.add_argument('--emsdk',default=str(G/'work-040/references/emsdk'))
p.add_argument('--output',default=str(W/'dcs-wasm'))
p.add_argument('--native',action='store_true')
a=p.parse_args();B=Path(a.output).resolve();E=B/'core';E.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(W/'sources/DCSExplorer-3d2220f.zip')as z:
 for i in z.infolist():
  rel=Path(*Path(i.filename).parts[1:])
  if not rel.parts or i.is_dir():continue
  d=E/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(z.read(i))
board=B/'board-adapter'
subprocess.run([sys.executable,str(W/'prepare_dcs_arcade_reference.py'),'--source',str(E/'DCSDecoder'),'--output',str(board)],check=True,stdout=subprocess.DEVNULL)
SDK=Path(a.emsdk).resolve()
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten'),'SOURCE_DATE_EPOCH':'0','DEVELOPER_DIR':'/Library/Developer/CommandLineTools'}
cc=['clang++']if a.native else[sys.executable,str(SDK/'install/emscripten/em++.py')]
flags=['-std=c++17','-O2','-fexceptions','-DGREMLIN_DCS_REFERENCE','-DLSB_FIRST','-DINLINE=inline','-DHAS_ADSP2101=1','-DHAS_ADSP2105=1','-Wno-format','-Wno-deprecated-declarations','-include',str(W/'dcs_emu_compat.h'),'-I'+str(E/'DCSDecoder')]
flags+=['-ffile-prefix-map='+str(W)+'=/gremlin-session121','-ffile-prefix-map='+str(B)+'=/gremlin-dcs-build']
sources=[W/'dcs_host.cpp',E/'DCSDecoder/DCSDecoder.cpp',board/'DCSDecoderEmu.cpp',E/'DCSDecoder/adsp2100/adsp2100.cpp',E/'DCSDecoder/adsp2100/2100dasm.cpp']
objects=[]
with(B/'build.log').open('w')as f:
 for i,s in enumerate(sources):
  o=B/f'{i}-{s.stem}.o';subprocess.run([*cc,*flags,'-c',str(s),'-o',str(o)],env=env,stdout=f,stderr=subprocess.STDOUT,check=True);objects.append(str(o))
 if a.native:
  outputs=['libgremlin-dcs.dylib'];cmd=[*cc,'-dynamiclib',*objects,'-o',str(B/outputs[0])]
 else:
  outputs=['gremlin-dcs.js','gremlin-dcs.wasm']
  exports=['_malloc','_free']+['_gremlin_dcs_'+x for x in['load','close','select','render','audio','error']]
  cmd=[*cc,'-O2','-fexceptions','--no-entry',*objects,'-sMODULARIZE=1','-sEXPORT_NAME=GremlinDCSMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=67108864','-sSTACK_SIZE=2097152','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAP16"]','-o',str(B/outputs[0])]
 subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
proof={'core':'DCSExplorer strict ADSP2105 original ROM interpreter','upstream_commit':'3d2220f58406756293b9552b7df0b264969b7061','speedups':False,'ADSP_interpreter_source_unchanged':True,'board_adapter':'Original arcade DCS2K/UART DM3400..37ff latch; original pinball PM3000 remains supported','original_ROM_notes_sequences_compressed_streams_unchanged':True,'outputs':{n:{'bytes':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()}for n in outputs}}
(B/'BUILD.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
