from pathlib import Path
import subprocess,concurrent.futures,os,json,hashlib,time
R=Path(__file__).resolve().parent;source=R/'lsm-source';sdk=R.parent/'work-040/references/emsdk';build=R/'build/lsm-wasm';build.mkdir(exist_ok=True);out=R/'built';out.mkdir(exist_ok=True)
env={**os.environ,'EM_CONFIG':str(sdk/'.emscripten')}
cpp=['lynx/'+n+'.cpp'for n in ['lynxdec','cart','memmap','mikie','ram','rom','susie','system','eeprom']]+['libretro/libretro.cpp','blip/Blip_Buffer.cpp','blip/Stereo_Buffer.cpp','lsm_decoder.cpp']
cs=['libretro-common/'+n+'.c'for n in ['compat/compat_posix_string','compat/compat_snprintf','compat/compat_strcasestr','compat/compat_strl','compat/fopen_utf8','encodings/encoding_utf','file/file_path','file/file_path_io','streams/file_stream','streams/file_stream_transforms','string/stdstring','time/rtime','vfs/vfs_implementation']]
common=['-O3','-DNDEBUG','-DWANT_CRC32','-DFRONTEND_SUPPORTS_RGB565','-Wno-deprecated-declarations','-I'+str(source),'-I'+str(source/'lynx'),'-I'+str(source/'libretro'),'-I'+str(source/'libretro-common/include')]
def compile(name):
    file=source/name;obj=build/(name.replace('/','_')+'.o');log=build/(obj.name+'.log')
    compiler=sdk/('install/emscripten/em++.py'if name.endswith('.cpp')else'install/emscripten/emcc.py')
    cmd=['python3',str(compiler),*common,*(['-std=c++17','-ffp-contract=off']if name.endswith('.cpp')else[]),'-c',str(file),'-o',str(obj)]
    with log.open('w')as stream:result=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError(name+'\n'+log.read_text()[-3000:])
    return obj
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:objects=list(pool.map(compile,cpp+cs))
exports=['_gremlin_lsm_load','_gremlin_lsm_render','_gremlin_lsm_close','_gremlin_lsm_error','_gremlin_lsm_devices','_malloc','_free']
cmd=['python3',str(sdk/'install/emscripten/em++.py'),'-O3','-ffp-contract=off',*[str(p)for p in objects],'--no-entry','-sMODULARIZE=1','-sEXPORT_NAME=GremlinLynxMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=134217728','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(out/'gremlin-lsm.js')]
with(build/'link.log').open('w')as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:raise RuntimeError((build/'link.log').read_text()[-4000:])
files=[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in out.iterdir()if p.suffix in('.js','.wasm')]
(out/'BUILD.json').write_text(json.dumps({'player':'0.13','compiler':'Emscripten6.0.13','source_commit':'bc55d462f0b2d6b073ea93dc552ebd73cec60fd1','format':'LSM1/LSZ, cartridge-independent original Lynx sound-driver machine states','source_rate':48000,'output':'StereoFloat32 from original Handy16-bit PCM, deterministic rational linear conversion for other rates','files':files},indent=2)+'\n');print(files)
