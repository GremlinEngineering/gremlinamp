// Lynx Sound Module research container / original-driver player bridge.
// Original CPU, timers, Mikey and Blip algorithms: pinned Handy/libretro source.
// This bridge is an altered distribution; it is not the upstream Handy frontend.
#include "libretro.h"
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <deque>
#include <array>
#include <cstdio>
extern "C" { unsigned long long gremlin_lsm_cart_reads=0; }
extern "C" void gremlin_lsm_reset_filter_delta();
static std::vector<uint8_t>blank(131072,0),state;
static std::deque<std::array<int16_t,2>>pcm;
static uint64_t output_frame=0,queue_base=0;
static uint32_t output_rate=0;
static bool initialized=false,loaded=false;
static std::string error_text,devices;
static retro_game_info_ext content{};
static uint32_t rd(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static void wr(uint8_t*p,uint32_t n){for(unsigned i=0;i<4;i++)p[i]=uint8_t(n>>(i*8));}
static uint32_t crc32_bytes(const uint8_t*p,size_t n){uint32_t v=~0u;while(n--){v^=*p++;for(unsigned i=0;i<8;i++)v=(v>>1)^(0xedb88320u&uint32_t(-int(v&1)));}return ~v;}
static void silent_log(retro_log_level,const char*,...){}
static bool environment(unsigned command,void*data){
 if(command==RETRO_ENVIRONMENT_GET_LOG_INTERFACE){static_cast<retro_log_callback*>(data)->log=silent_log;return true;}
 if(command==RETRO_ENVIRONMENT_GET_GAME_INFO_EXT){*static_cast<const retro_game_info_ext**>(data)=&content;return true;}
 if(command==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return *static_cast<unsigned*>(data)==RETRO_PIXEL_FORMAT_RGB565;
 if(command==RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE){*static_cast<bool*>(data)=false;return true;}
 return false;
}
static void video(const void*,unsigned,unsigned,size_t){}
static void audio(int16_t,int16_t){}
static size_t batch(const int16_t*data,size_t frames){for(size_t i=0;i<frames;i++)pcm.push_back({data[i*2],data[i*2+1]});return frames;}
static void poll(){}
static int16_t input(unsigned,unsigned,unsigned,unsigned){return 0;}
static size_t find_tag(const uint8_t*b,size_t length,const char*tag){size_t n=strlen(tag);for(size_t i=0;i+n<=length;i++)if(!memcmp(b+i,tag,n))return i;return SIZE_MAX;}
extern "C" {
void gremlin_lsm_close(){
 if(initialized){retro_unload_game();retro_deinit();}
 initialized=loaded=false;pcm.clear();state.clear();output_frame=queue_base=0;gremlin_lsm_cart_reads=0;
}
const char*gremlin_lsm_error(){return error_text.c_str();}
const char*gremlin_lsm_devices(){return devices.c_str();}
int gremlin_lsm_load(const uint8_t*b,uint32_t length,uint32_t rate){
 gremlin_lsm_close();error_text.clear();devices.clear();
 auto fail=[](const char*s){error_text=s;gremlin_lsm_close();return 1;};
 if(!b||length<96||memcmp(b,"LSM\x1a",4)||rd(b+4)!=1)return fail("Invalid LSM1 header");
 if(rd(b+8)!=16000000||rd(b+12)!=1||rd(b+20)!=96||rd(b+32)!=0x200||rd(b+36)!=1||rate<8000||rate>192000)return fail("Unsupported LSM timing, ABI or host mode");
 uint32_t bytes=rd(b+16);if(bytes<65536||bytes>262144||uint64_t(bytes)+96!=length)return fail("Invalid LSM state boundaries");
 if(rd(b+28)!=131072&&rd(b+28)!=262144)return fail("Unsupported source cartridge size");
 for(unsigned i=72;i<96;i++)if(b[i])return fail("Unsupported LSM reserved flags");
 const uint8_t*s=b+96;
 if(memcmp(s,"LSS3",4)||rd(s+4)!=rd(b+24))return fail("LSM original state identity mismatch");
 size_t cart=find_tag(s,bytes,"CCart::ContextSave"),cpu=find_tag(s,bytes,"C6502::ContextSave");
 if(cart==SIZE_MAX||cpu==SIZE_MAX||cart+70>bytes||cpu+46>bytes||rd(s+cart+18+11*4)!=1||rd(s+cart+18+12*4)!=65535||rd(s+cpu+18+5*4)!=0x200)return fail("Unsupported LSM saved machine layout");
 retro_set_environment(environment);retro_set_video_refresh(video);retro_set_audio_sample(audio);retro_set_audio_sample_batch(batch);retro_set_input_poll(poll);retro_set_input_state(input);retro_init();initialized=true;
 content={};content.name="original-music-driver";content.data=blank.data();content.size=blank.size();content.full_path="music.bin";
 retro_game_info game{};game.path="music.bin";
 if(!retro_load_game(&game))return fail("Could not initialize the Lynx music host");
 if(retro_serialize_size()!=bytes)return fail("LSM pinned state ABI size differs");
 // A music state has no cartridge dependency. Normalize only the LSS integrity
 // field in a private in-memory copy so the upstream loader accepts an empty cart.
 // The original CRC and SHA256 remain unchanged in the LSM file and provenance.
 state.assign(s,s+bytes);wr(state.data()+4,crc32_bytes(blank.data(),blank.size()));
 if(!retro_unserialize(state.data(),state.size()))return fail("Could not restore original music-driver state");
 auto ram=static_cast<const uint8_t*>(retro_get_memory_data(RETRO_MEMORY_SYSTEM_RAM));
 if(!ram||ram[0x200]!=0x4c||ram[0x201]!=0||ram[0x202]!=2)return fail("LSM music idle shim differs");
 gremlin_lsm_reset_filter_delta();pcm.clear();output_frame=queue_base=0;gremlin_lsm_cart_reads=0;output_rate=rate;loaded=true;
 char text[420];snprintf(text,sizeof text,"[{\"type\":\"atari_mikey\",\"voices\":4,\"master_clock_hz\":16000000,\"source_sample_rate\":48000,\"output_sample_rate\":%u,\"cpu\":\"original65C02driver\",\"core\":\"pinned Handy, original CPU/timers/Mikey/Blip\",\"cartridge_dependency\":false}]",rate);devices=text;
 return 0;
}
uint32_t gremlin_lsm_render(float*out,uint32_t frames){
 if(!out||frames>16384)return 0;
 memset(out,0,size_t(frames)*2*sizeof(float));if(!loaded)return 0;
 for(unsigned i=0;i<frames;i++,output_frame++){
  uint64_t numerator=output_frame*48000,position=numerator/output_rate;uint32_t remainder=numerator%output_rate;
  unsigned guard=0;
  while(queue_base+pcm.size()<=position+1){
   size_t previous=pcm.size();retro_run();
   if(gremlin_lsm_cart_reads){error_text="Original driver requested cartridge data outside this isolated music state";loaded=false;return 0;}
   if(pcm.size()<=previous||++guard>64){error_text="Original driver produced no audio frames";loaded=false;return 0;}
  }
  size_t at=size_t(position-queue_base);
  for(unsigned channel=0;channel<2;channel++){
   double first=pcm[at][channel],second=pcm[at+1][channel];out[i*2+channel]=float((first+(second-first)*double(remainder)/double(output_rate))/32768.0);
  }
  while(queue_base<position){pcm.pop_front();queue_base++;}
 }
 return frames;
}
}
