from pathlib import Path
import shutil,subprocess,difflib
R=Path(__file__).resolve().parent;source=R/'references/libretro-handy-bc55d462f0b2d6b073ea93dc552ebd73cec60fd1';target=R/'lsm-source'
shutil.copytree(source,target,dirs_exist_ok=True);shutil.copyfile(R/'lsm_decoder.cpp',target/'lsm_decoder.cpp')
cart=target/'lynx/cart.cpp';before=cart.read_text();after=before.replace('UBYTE CCart::Peek0(void)','extern "C" unsigned long long gremlin_lsm_cart_reads;\nUBYTE CCart::Peek0(void)')
for name in ['Peek0','Peek0A','Peek1','Peek1A']:after=after.replace(f'UBYTE CCart::{name}(void)\n{{',f'UBYTE CCart::{name}(void)\n{{\n   gremlin_lsm_cart_reads++;')
cart.write_text(after);patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original/lynx/cart.cpp',tofile='lsm/lynx/cart.cpp'))
mikie=target/'lynx/mikie.cpp';before=mikie.read_text();after=before.replace('   static int last_lsample = 0;','').replace('   static int last_rsample = 0;','').replace('last_lsample','gremlin_lsm_last_lsample').replace('last_rsample','gremlin_lsm_last_rsample')
marker='CMikie::CMikie('
at=after.index(marker)
after=after[:at]+'// LSM bridge: reset filter delta history for a fresh music-module load.\nstatic int gremlin_lsm_last_lsample=0,gremlin_lsm_last_rsample=0;\nextern "C" void gremlin_lsm_reset_filter_delta(){gremlin_lsm_last_lsample=gremlin_lsm_last_rsample=0;}\n\n'+after[at:]
mikie.write_text(after);patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original/lynx/mikie.cpp',tofile='lsm/lynx/mikie.cpp'));(R/'build/lsm-source.patch').write_text(patch)
common=target/'Makefile.common';common.write_text(common.read_text()+'\nSOURCES_CXX += $(CORE_DIR)/lsm_decoder.cpp\n')
with(R/'build/lsm-native-build.log').open('w')as log:subprocess.run(['make','-j4','platform=osx','ARCH=arm64','GIT_VERSION=bc55d462-lsm1-bridge'],cwd=target,stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copyfile(target/'handy_libretro.dylib',R/'build/libgremlin-lsm-native.dylib');print('Built LSM1 native music host')
