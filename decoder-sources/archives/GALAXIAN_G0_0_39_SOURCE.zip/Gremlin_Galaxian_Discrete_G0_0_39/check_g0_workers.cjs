const fs=require('fs'),path=require('path'),zlib=require('zlib');
const {chromium}=require('/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const W=__dirname,base=process.argv[2],rows=JSON.parse(fs.readFileSync(path.join(W,'g0-reference/RESULTS.json')));
(async()=>{
 const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--no-sandbox','--mute-audio']});
 const page=await browser.newPage();await page.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());await page.goto(base);
 const results=[];
 for(const row of rows)for(const rate of [44100,48000]){
  const result=await page.evaluate(async({base,row,rate})=>{
   const w=new Worker(base+'player/games/music_player/g0-worker.js');let pending;
   w.onmessage=({data:d})=>{if(pending){const p=pending;pending=null;d.type==='error'?p.reject(Error(d.message)):p.resolve(d)}};w.onerror=e=>pending?.reject(Error(e.message));
   const rpc=(m)=>new Promise((resolve,reject)=>{pending={resolve,reject};w.postMessage(m)});
   try{
    const bytes=await(await fetch(base+'g0-capsules/'+row.file)).arrayBuffer(),expected=new Float32Array(await(await fetch(base+'g0-reference/'+row.expected[String(rate)].file)).arrayBuffer());
    const ready=await rpc({type:'load',bytes,sampleRate:rate,subsong:0});let offset=0,maxError=0,nonfinite=0;const begin=performance.now();
    while(offset<expected.length){const n=Math.min(4096,(expected.length-offset)/2),p=await rpc({type:'render',frames:n});if(p.type!=='pcm')throw Error('Unexpected worker response');const a=new Float32Array(p.pcm);if(a.length!==n*2)throw Error('PCM size');for(let i=0;i<a.length;i++){if(!Number.isFinite(a[i]))nonfinite++;maxError=Math.max(maxError,Math.abs(a[i]-expected[offset+i]))}offset+=a.length}
    return{file:row.file,rate,frames:offset/2,maxError,nonfinite,devices:ready.devices,render_ms:performance.now()-begin,pass:maxError<=1e-7&&nonfinite===0};
   }finally{w.terminate()}
  },{base,row,rate});results.push(result);console.log('PCM',row.file,rate,'error',result.maxError,'PASS',result.pass);
 }
 function editHeader(source,fn){const b=zlib.gunzipSync(source),j=b.readUInt32LE(4),p=JSON.parse(b.subarray(16,16+j));fn(p);const h=Buffer.from(JSON.stringify(p)),head=Buffer.from(b.subarray(0,16));head.writeUInt32LE(h.length,4);return zlib.gzipSync(Buffer.concat([head,h,b.subarray(16+j)]))}
 const source=fs.readFileSync(path.join(W,'g0-capsules/moonaln-game-start.g0z')),raw=zlib.gunzipSync(source),romStart=16+raw.readUInt32LE(4),badRom=Buffer.from(raw);badRom[romStart]^=1;
 const tests=[['ROM-corruption',zlib.gzipSync(badRom)],['wrong-game',editHeader(source,p=>p.game_id='game-ra-15604')],['wrong-circuit',editHeader(source,p=>p.circuit=1)],['wrong-profile',editHeader(source,p=>p.profile=999)],['duration-change',editHeader(source,p=>p.audio_frames++)],['prefix-change',editHeader(source,p=>p.start_sample++)],['clock-change',editHeader(source,p=>p.source_cpu_clock=1789750)],['unknown-selector',source,{subsong:1}],['output-rate-bounds',source,{sampleRate:0}],['expansion-bounds',zlib.gzipSync(Buffer.alloc(2000001))],['truncated',source.subarray(0,source.length-8)]];
 const guards=[];
 for(const[name,buffer,overrides]of tests){const r=await page.evaluate(async({base,bytes,overrides,name})=>{
  const w=new Worker(base+'player/games/music_player/g0-worker.js');try{return await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('guard timeout')),10000);w.onmessage=({data:d})=>{clearTimeout(timer);resolve({name,pass:d.type==='error',message:d.message||d.type})};w.onerror=e=>reject(Error(e.message));w.postMessage({type:'load',bytes:new Uint8Array(bytes).buffer,sampleRate:48000,subsong:0,...overrides})})}finally{w.terminate()}
 },{base,bytes:Array.from(buffer),overrides:overrides||{},name});guards.push(r);console.log('GUARD',name,r.pass)}
 const report={fullPCM:results,negativeGuards:guards,external_network_blocked:true,all_pass:results.every(x=>x.pass)&&guards.every(x=>x.pass)};fs.writeFileSync(path.join(W,'g0-browser-qa.json'),JSON.stringify(report,null,2)+'\n');await browser.close();if(!report.all_pass)throw Error('G0 browser QA failed');
})().catch(e=>{console.error(e.stack||e);process.exitCode=1});
