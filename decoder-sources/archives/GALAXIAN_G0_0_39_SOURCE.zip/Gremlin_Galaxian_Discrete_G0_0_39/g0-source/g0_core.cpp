// BSD-3-Clause MAME discrete graph host. Original CPU register traces are
// interpreted by the capsule worker; this core contains no invented note tables.
#include "discrete/host.h"
static std::unique_ptr<discrete_device> graph;
static std::string last_error;
static float pcm[32768];
extern "C" {
int gremlin_g0_reset(int variant){
 try{if(variant<0||variant>1)throw std::runtime_error("Unsupported original circuit");graph=std::make_unique<discrete_device>();graph->rate=48000;graph->build(variant?gremlin_mooncrst_discrete:gremlin_galaxian_discrete);graph->write(GAL_INP_PITCH,255);last_error.clear();return 0;}catch(const std::exception&e){graph.reset();last_error=e.what();return 1;}
}
int gremlin_g0_write(int port,int value){
 try{if(!graph||port<0||port>2||value<0||value>(port?1:255))throw std::runtime_error("Original register bounds");graph->write(port==0?GAL_INP_PITCH:port==1?GAL_INP_VOL1:GAL_INP_VOL2,value);return 0;}catch(const std::exception&e){last_error=e.what();return 1;}
}
int gremlin_g0_render(int frames){
 try{if(!graph||frames<1||frames>16384)throw std::runtime_error("Render bounds");for(int i=0;i<frames;i++){float s=graph->sample(1.0);if(!std::isfinite(s))throw std::runtime_error("Nonfinite circuit output");pcm[i*2]=s;pcm[i*2+1]=s;}return 0;}catch(const std::exception&e){last_error=e.what();return 1;}
}
const float *gremlin_g0_audio(){return pcm;}
const char *gremlin_g0_error(){return last_error.c_str();}
void gremlin_g0_close(){graph.reset();}
}
