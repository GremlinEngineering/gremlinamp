G0 original Galaxian / Moon Cresta discrete circuit player0.39

Build with Python3, clang++, Emscripten6.0.13:
GREMLIN_EMSDK=/absolute/path/to/emsdk python3 build_g0.py
Outputs: g0-built/gremlin-g0.js, gremlin-g0.wasm, libgremlin-g0.dylib.

The prepared g0-source folder is self-contained. Original upstream files are included for auditing exact node mathematics and circuit values. The extraction and capsule scripts document project-specific research and need the original project layout; they are not needed to compile the prepared core.

Playback runs original CPU register traces through the original discrete circuit graphs. It does not execute the Z80 CPU. Original ROM bytes in capsules identify the source; there are no hand-transcribed note tables and no rendered PCM tracks. Capture timing is the explicitly retained FBNeo60Hz context, not a physical-board timing measurement.

Both full original graphs include their original resistor/capacitor values and loading. Only original pitch and two volume inputs are driven for these selected melodic cues.
