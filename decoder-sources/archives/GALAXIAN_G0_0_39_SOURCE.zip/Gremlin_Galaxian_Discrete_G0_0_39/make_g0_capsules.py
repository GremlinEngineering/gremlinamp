from pathlib import Path
import struct,json,hashlib,gzip,zipfile
W=Path(__file__).resolve().parent;O=W/'g0-capsules';O.mkdir(exist_ok=True)
proofs=json.loads((W/'first13-ROM-proof.json').read_text());profiles={};proof=[]
cases=[('moonaln','15721',0,1,'game-start','Начало игры',396,588,{0x1726}),('moonal2','15606',1,2,'game-start','Начало игры',396,588,{0x1726}),('kong','15604',1,3,'credit-cue','Мелодическая отбивка кредита',304,319,{0x1262,0x1297}),('kong','15604',1,4,'stage-start','Начало этапа',399,746,{0x1262,0x1297})]
for game,gid,circuit,profile,key,title,startframe,endframe,musicpc in cases:
 raw=(W/'contexts'/f'{game}-musictrace/sound-events.bin').read_bytes();trace=list(struct.iter_unpack('<IIIII',raw))
 pitch=[e for e in trace if e[1]==8]
 first=next(e for e in pitch if e[0]==startframe and e[3]in musicpc and e[2]!=255)
 last=next(e for e in pitch if e[0]==endframe and e[3]in musicpc and e[2]==255)
 def sample(e):return max(0,(e[0]-1)*800+e[4]//64)
 start=sample(first);stop=sample(last);duration=stop-start+7200
 events=[];excluded=[]
 for e in trace:
  f,kind,a,b,cycle=e
  if kind==8:
   at=sample(e)
   if start<=at<=stop and b not in musicpc:excluded.append({'frame':f,'value':a,'PC':hex(b)});continue
   port=0;value=a
  elif kind==4 and a in [6,7]:at=sample(e);port=a-5;value=b&1
  else:continue
  if at>start+duration:continue
  if kind==8 and at>stop:continue
  events.append((at,port,value))
 events.sort(key=lambda e:e[0]);lastvalue={0:255,1:0,2:0};kept=[]
 for at,port,value in events:
  if lastvalue[port]==value:continue
  kept.append((at,port,value));lastvalue[port]=value
 eventbytes=b''.join(struct.pack('<IBBH',at,port,value,0)for at,port,value in kept)
 p=next(p for p in proofs if p['game']==game)
 with zipfile.ZipFile(W/'sources'/f'{game}-original.zip')as z:rom=b''.join(z.read(c['match'])for c in p['chips']if 'BRF_PRG' in (c.get('flags')or '')) if any('flags'in c for c in p['chips'])else b''
 # First13 proof intentionally stores table identity, not flag strings.
 if not rom:
  source=(W/'stock-source/src/burn/drv/galaxian/d_galaxian.cpp').read_text();import re
  table=re.search(r'static struct BurnRomInfo '+game+r'RomDesc\[\].*?\n\};',source,re.S|re.I).group()
  names=re.findall(r'\{\s*"([^"]+)"[^\n]*BRF_PRG[^\n]*',table)
  with zipfile.ZipFile(W/'sources'/f'{game}-original.zip')as z:rom=b''.join(z.read(next(c['match']for c in p['chips']if c['name']==name))for name in names)
 assert rom and kept
 romhash=hashlib.sha256(rom).hexdigest();eventhash=hashlib.sha256(eventbytes).hexdigest()
 header={'version':1,'profile':profile,'game_id':'game-ra-'+gid,'track_id':key,'title':title,'source_rate':48000,'source_cpu_clock':3072000,'capture_fps':60,'circuit':circuit,'MAME_commit':'40d0f1125befade5edc08ec5699442ca3a229c01','rom_sha256':romhash,'events_sha256':eventhash,'start_sample':start,'audio_frames':duration,'playback_model':'original_register_trace_and_discrete_circuit','capture_CPU_program_unmodified':True,'trace_sha256':hashlib.sha256(raw).hexdigest()}
 hb=json.dumps(header,ensure_ascii=False,separators=(',',':')).encode();b=b'G0M\x1a'+struct.pack('<III',len(hb),len(rom),len(kept))+hb+rom+eventbytes
 path=O/f'{game}-{key}.g0z';path.write_bytes(gzip.compress(b,compresslevel=9,mtime=0))
 profiles[str(profile)]={**header,'rom_bytes':len(rom),'event_count':len(kept),'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
 proof.append({'profile':profile,'original_sound_writer_PCs':[hex(x)for x in sorted(musicpc)],'removed_nonmusical_tone_writes_during_play':excluded,'whole_original_note_values_and_order_preserved':True,'manual_note_transcription':False,'events':kept,'circuit_source':'sources/galaxian_a.cpp','circuit_configuration_source':'sources/galaxian.cpp','capture_timing':'Original program run by FBNeo at60Hz; retain that explicitly documented timing. No claim of measured physical-board timing.'})
 print(game,key,'events',len(kept),'removedFX',len(excluded),'duration',duration/48000,'bytes',path.stat().st_size)
(O/'profiles.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n');(O/'CAPTURE_PROOF.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
