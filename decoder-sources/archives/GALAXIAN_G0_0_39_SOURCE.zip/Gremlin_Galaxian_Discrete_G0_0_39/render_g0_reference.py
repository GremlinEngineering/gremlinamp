from pathlib import Path
import ctypes as c,gzip,struct,json,hashlib,wave
import numpy as np
W=Path(__file__).resolve().parent;O=W/'g0-reference';O.mkdir(exist_ok=True)
l=c.CDLL(str(W/'g0-built/libgremlin-g0.dylib'));l.gremlin_g0_audio.restype=c.c_void_p;l.gremlin_g0_error.restype=c.c_char_p
results=[]
for path in sorted((W/'g0-capsules').glob('*.g0z')):
 b=gzip.decompress(path.read_bytes());j,r,n=struct.unpack_from('<III',b,4);p=json.loads(b[16:16+j]);events=list(struct.iter_unpack('<IBBH',b[16+j+r:]));assert len(events)==n
 assert l.gremlin_g0_reset(p['circuit'])==0,l.gremlin_g0_error();at=0;index=0;blocks=[];end=p['start_sample']+p['audio_frames']
 while at<end:
  while index<n and events[index][0]==at:
   e=events[index];assert l.gremlin_g0_write(e[1],e[2])==0;index+=1
  stop=min(end,events[index][0]if index<n else end,at+4096)
  if at<p['start_sample']:stop=min(stop,p['start_sample'])
  count=stop-at;assert count>0
  assert l.gremlin_g0_render(count)==0,l.gremlin_g0_error()
  if at>=p['start_sample']:blocks.append(c.string_at(l.gremlin_g0_audio(),count*8))
  at=stop
 raw=b''.join(blocks);x=np.frombuffer(raw,dtype='<f4').reshape(-1,2);assert len(x)==p['audio_frames'];assert np.isfinite(x).all()
 (O/(path.stem+'.f32')).write_bytes(raw)
 assert np.abs(x).max()<1,'Audible output clips; inspect original circuit/headroom.'
 with wave.open(str(O/(path.stem+'-diagnostic.wav')),'wb')as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(48000);f.writeframes((x*32767).astype('<i2').tobytes())
 row={'file':path.name,'frames':len(x),'seconds':len(x)/48000,'rms':float(np.sqrt(np.mean(x.astype(float)**2))),'peak':float(np.abs(x).max()),'last20ms_peak':float(np.abs(x[-960:]).max()),'native_f32_sha256':hashlib.sha256(raw).hexdigest(),'expected':{}}
 for rate in [44100,48000]:
  outframes=int(np.ceil(len(x)*rate/48000))+128;idx=np.arange(outframes,dtype=np.int64);num=idx*48000;offset=num//rate;rem=num%rate;valid=offset<len(x);xx=np.vstack([x,np.zeros((1,2),np.float32)]).astype(np.float64);out=np.zeros((outframes,2),'<f4');a=xx[offset[valid]];z=xx[offset[valid]+1];out[valid]=(a+(z-a)*rem[valid,None]/rate).astype('<f4');dest=O/f'{path.stem}-{rate}-expected.f32';out.tofile(dest);row['expected'][str(rate)]={'file':dest.name,'frames':outframes,'sha256':hashlib.sha256(out.tobytes()).hexdigest()}
 results.append(row);print(row['file'],'seconds',row['seconds'],'peak',row['peak'],'RMS',row['rms'],'tail',row['last20ms_peak'],flush=True)
l.gremlin_g0_close();(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
