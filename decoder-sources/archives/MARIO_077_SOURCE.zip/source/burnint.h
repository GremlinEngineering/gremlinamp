// Minimal standalone host glue. Original BSD MCS48 instruction core unchanged.
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <cstdarg>
using UINT8=uint8_t;using UINT16=uint16_t;using UINT32=uint32_t;using UINT64=uint64_t;
using INT8=int8_t;using INT16=int16_t;using INT32=int32_t;using INT64=int64_t;
#define _T(x) x
#define PRINT_ERROR 1
#define ACB_DRIVER_DATA 1
#define STRUCT_SIZE_HELPER(type,member) (offsetof(type,member)+sizeof(((type*)0)->member))
inline void ScanVar(void*,size_t,const char*){}
inline int bprintf(int,const char*fmt,...){va_list a;va_start(a,fmt);int n=vfprintf(stderr,fmt,a);va_end(a);return n;}
