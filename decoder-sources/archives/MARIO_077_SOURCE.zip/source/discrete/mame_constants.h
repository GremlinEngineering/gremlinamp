// Pinned MAME BSD-3-Clause excerpts; see source-receipts.json and originals.
#define RC_CHARGE_EXP(rc)                       (1.0 - exp(-this->sample_time() / (rc)))
/* calculate charge exponent using given sample time */
#define RC_CHARGE_EXP_DT(rc, dt)                (1.0 - exp(-(dt) / (rc)))
#define RC_CHARGE_NEG_EXP_DT(rc, dt)            (1.0 - exp((dt) / (rc)))

/* calculate discharge exponent using discrete sample time */
#define RC_DISCHARGE_EXP(rc)                    (exp(-this->sample_time() / (rc)))
/* calculate discharge exponent using given sample time */
#define RC_DISCHARGE_EXP_DT(rc, dt)             (exp(-(dt) / (rc)))
#define RC_DISCHARGE_NEG_EXP_DT(rc, dt)         (exp((dt) / (rc)))

#define FREQ_OF_555(_r1, _r2, _c)   (1.49 / ((_r1 + 2 * _r2) * _c))

/*************************************
 *
 *  Interface & Naming
 *
 *************************************/

#define DISCRETE_CLASS_FUNC(_class, _func)      DISCRETE_CLASS_NAME(_class) :: _func

#define DISCRETE_STEP(_class)                   void DISCRETE_CLASS_FUNC(_class, step)(void)
#define DISCRETE_RESET(_class)                  void DISCRETE_CLASS_FUNC(_class, reset)(void)
#define DISCRETE_START(_class)                  void DISCRETE_CLASS_FUNC(_class, start)(void)
#define DISCRETE_STOP(_class)                   void DISCRETE_CLASS_FUNC(_class, stop)(void)
#define DISCRETE_DECLARE_INFO(_name)            const _name *info = (const  _name *)this->custom_data();

//#define DISCRETE_INPUT(_num)                  (*(this->m_input[_num]))
#define DISCRETE_INPUT(_num)                    (input(_num))

/*************************************
 *
 *  Core constants
 *
 *************************************/

#define DISCRETE_MAX_NODES                  300
#define DISCRETE_MAX_INPUTS                 10
#define DISCRETE_MAX_OUTPUTS                8

#define DISCRETE_MAX_TASK_GROUPS            10


/*************************************
 *
 *  Node-specific constants
 *
 *************************************/

#define DEFAULT_TTL_V_LOGIC_1               3.4

#define DISC_LOGADJ                         1.0
#define DISC_LINADJ                         0.0

/* DISCRETE_COMP_ADDER types */
#define DISC_COMP_P_CAPACITOR               0x00
#define DISC_COMP_P_RESISTOR                0x01

/* clk types */
#define DISC_CLK_MASK                       0x03
#define DISC_CLK_ON_F_EDGE                  0x00
#define DISC_CLK_ON_R_EDGE                  0x01
#define DISC_CLK_BY_COUNT                   0x02
#define DISC_CLK_IS_FREQ                    0x03

#define DISC_COUNT_DOWN                     0
#define DISC_COUNT_UP                       1

#define DISC_COUNTER_IS_7492                0x08

#define DISC_OUT_MASK                       0x30
#define DISC_OUT_DEFAULT                    0x00
#define DISC_OUT_IS_ENERGY                  0x10
#define DISC_OUT_HAS_XTIME                  0x20

/* Function possibilities for the LFSR feedback nodes */
/* 2 inputs, one output                               */
#define DISC_LFSR_XOR                       0
#define DISC_LFSR_OR                        1
#define DISC_LFSR_AND                       2
#define DISC_LFSR_XNOR                      3
#define DISC_LFSR_NOR                       4
#define DISC_LFSR_NAND                      5
#define DISC_LFSR_IN0                       6
#define DISC_LFSR_IN1                       7
#define DISC_LFSR_NOT_IN0                   8
#define DISC_LFSR_NOT_IN1                   9
#define DISC_LFSR_REPLACE                   10
#define DISC_LFSR_XOR_INV_IN0               11
#define DISC_LFSR_XOR_INV_IN1               12

/* LFSR Flag Bits */
#define DISC_LFSR_FLAG_OUT_INVERT           0x01
#define DISC_LFSR_FLAG_RESET_TYPE_L         0x00
#define DISC_LFSR_FLAG_RESET_TYPE_H         0x02
#define DISC_LFSR_FLAG_OUTPUT_F0            0x04
#define DISC_LFSR_FLAG_OUTPUT_SR_SN1        0x08

/* Sample & Hold supported clock types */
#define DISC_SAMPHOLD_REDGE                 0
#define DISC_SAMPHOLD_FEDGE                 1
#define DISC_SAMPHOLD_HLATCH                2
#define DISC_SAMPHOLD_LLATCH                3

/* Shift options */
#define DISC_LOGIC_SHIFT__RESET_L           0x00
#define DISC_LOGIC_SHIFT__RESET_H           0x10
#define DISC_LOGIC_SHIFT__LEFT              0x00
#define DISC_LOGIC_SHIFT__RIGHT             0x20

/* Maximum number of resistors in ladder chain */
#define DISC_LADDER_MAXRES                  8

/* Filter types */
#define DISC_FILTER_LOWPASS                 0
#define DISC_FILTER_HIGHPASS                1
#define DISC_FILTER_BANDPASS                2

/* Mixer types */
#define DISC_MIXER_IS_RESISTOR              0
#define DISC_MIXER_IS_OP_AMP                1
#define DISC_MIXER_IS_OP_AMP_WITH_RI        2   /* Used only internally.  Use DISC_MIXER_IS_OP_AMP */

/* Triggered Op Amp Functions */
enum
{
	DISC_OP_AMP_TRIGGER_FUNCTION_NONE,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG0,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG0_INV,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG1,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG1_INV,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG2,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG2_INV,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG01_AND,
	DISC_OP_AMP_TRIGGER_FUNCTION_TRG01_NAND
};


/* Common Op Amp Flags and values */
#define DISC_OP_AMP_IS_NORTON               0x100
#define OP_AMP_NORTON_VBE                   0.5     // This is the norton junction voltage. Used only internally.
#define OP_AMP_VP_RAIL_OFFSET               1.5     // This is how close an op-amp can get to the vP rail. Used only internally.

/* Integrate options */
#define DISC_INTEGRATE_OP_AMP_1             0x00
#define DISC_INTEGRATE_OP_AMP_2             0x10

/* op amp 1 shot types */
#define DISC_OP_AMP_1SHT_1                  0x00

/* Op Amp Filter Options */
#define DISC_OP_AMP_FILTER_IS_LOW_PASS_1    0x00
#define DISC_OP_AMP_FILTER_IS_HIGH_PASS_1   0x10
#define DISC_OP_AMP_FILTER_IS_BAND_PASS_1   0x20
#define DISC_OP_AMP_FILTER_IS_BAND_PASS_1M  0x30
#define DISC_OP_AMP_FILTER_IS_HIGH_PASS_0   0x40
#define DISC_OP_AMP_FILTER_IS_BAND_PASS_0   0x50
#define DISC_OP_AMP_FILTER_IS_LOW_PASS_1_A  0x60

#define DISC_OP_AMP_FILTER_TYPE_MASK        (0xf0 | DISC_OP_AMP_IS_NORTON)  // Used only internally.

/* Sallen-Key filter Options */
#define DISC_SALLEN_KEY_LOW_PASS            0x01
#define DISC_SALLEN_KEY_HIGH_PASS           0x02


/* Op Amp Oscillator Flags */
#define DISC_OP_AMP_OSCILLATOR_TYPE_MASK    (0xf0 | DISC_OP_AMP_IS_NORTON)  // Used only internally.
#define DISC_OP_AMP_OSCILLATOR_1            0x00
#define DISC_OP_AMP_OSCILLATOR_2            0x10
#define DISC_OP_AMP_OSCILLATOR_VCO_1        0x20
#define DISC_OP_AMP_OSCILLATOR_VCO_2        0x30
#define DISC_OP_AMP_OSCILLATOR_VCO_3        0x40

#define DISC_OP_AMP_OSCILLATOR_OUT_MASK         0x07
#define DISC_OP_AMP_OSCILLATOR_OUT_CAP          0x00
#define DISC_OP_AMP_OSCILLATOR_OUT_SQW          0x01
#define DISC_OP_AMP_OSCILLATOR_OUT_ENERGY       0x02
#define DISC_OP_AMP_OSCILLATOR_OUT_LOGIC_X      0x03
#define DISC_OP_AMP_OSCILLATOR_OUT_COUNT_F_X    0x04
#define DISC_OP_AMP_OSCILLATOR_OUT_COUNT_R_X    0x05

/* Schmitt Oscillator Options */
#define DISC_SCHMITT_OSC_IN_IS_LOGIC        0x00
#define DISC_SCHMITT_OSC_IN_IS_VOLTAGE      0x01

#define DISC_SCHMITT_OSC_ENAB_IS_AND        0x00
#define DISC_SCHMITT_OSC_ENAB_IS_NAND       0x02
#define DISC_SCHMITT_OSC_ENAB_IS_OR         0x04
#define DISC_SCHMITT_OSC_ENAB_IS_NOR        0x06

#define DISC_SCHMITT_OSC_ENAB_MASK          0x06    /* Bits that define output enable type.
                                                     * Used only internally in module. */

/* 555 Common output flags */
#define DISC_555_OUT_DC                     0x00
#define DISC_555_OUT_AC                     0x10

#define DISC_555_TRIGGER_IS_LOGIC           0x00
#define DISC_555_TRIGGER_IS_VOLTAGE         0x20
#define DISC_555_TRIGGER_IS_COUNT           0x40
#define DSD_555_TRIGGER_TYPE_MASK           0x60
#define DISC_555_TRIGGER_DISCHARGES_CAP     0x80

#define DISC_555_OUT_SQW                    0x00    /* Squarewave */
#define DISC_555_OUT_CAP                    0x01    /* Cap charge waveform */
#define DISC_555_OUT_COUNT_F                0x02    /* Falling count */
#define DISC_555_OUT_COUNT_R                0x03    /* Rising count */
#define DISC_555_OUT_ENERGY                 0x04
#define DISC_555_OUT_LOGIC_X                0x05
#define DISC_555_OUT_COUNT_F_X              0x06
#define DISC_555_OUT_COUNT_R_X              0x07

#define DISC_555_OUT_MASK                   0x07    /* Bits that define output type.
                                                 * Used only internally in module. */

#define DISC_555_ASTABLE_HAS_FAST_CHARGE_DIODE      0x80
#define DISCRETE_555_CC_TO_DISCHARGE_PIN            0x00
#define DISCRETE_555_CC_TO_CAP                      0x80

/* 566 output flags */
#define DISC_566_OUT_DC                     0x00
#define DISC_566_OUT_AC                     0x10

#define DISC_566_OUT_SQUARE                 0x00    /* Squarewave */
#define DISC_566_OUT_ENERGY                 0x01    /* anti-aliased Squarewave */
#define DISC_566_OUT_TRIANGLE               0x02    /* Triangle waveform */
#define DISC_566_OUT_LOGIC                  0x03    /* 0/1 logic output */
#define DISC_566_OUT_COUNT_F                0x04
#define DISC_566_OUT_COUNT_R                0x05
#define DISC_566_OUT_COUNT_F_X              0x06
#define DISC_566_OUT_COUNT_R_X              0x07
#define DISC_566_OUT_MASK                   0x07    /* Bits that define output type.
                                                     * Used only internally in module. */

/* LS624 output flags */
#define DISC_LS624_OUT_SQUARE               0x01
#define DISC_LS624_OUT_ENERGY               0x02
#define DISC_LS624_OUT_LOGIC                0x03
#define DISC_LS624_OUT_LOGIC_X              0x04
#define DISC_LS624_OUT_COUNT_F              0x05
#define DISC_LS624_OUT_COUNT_R              0x06
#define DISC_LS624_OUT_COUNT_F_X            0x07
#define DISC_LS624_OUT_COUNT_R_X            0x08

/* Oneshot types */
#define DISC_ONESHOT_FEDGE                  0x00
#define DISC_ONESHOT_REDGE                  0x01

#define DISC_ONESHOT_NORETRIG               0x00
#define DISC_ONESHOT_RETRIG                 0x02

#define DISC_OUT_ACTIVE_LOW                 0x04
#define DISC_OUT_ACTIVE_HIGH                0x00

#define DISC_CD4066_THRESHOLD               2.75

/* Integrate */

#define DISC_RC_INTEGRATE_TYPE1             0x00
#define DISC_RC_INTEGRATE_TYPE2             0x01
#define DISC_RC_INTEGRATE_TYPE3             0x02

/*************************************
 *
 *  Classes and structs to handle
 *  linked lists.
 *
 *************************************/

/*
 * add and delete may be slow - the focus is on access!
 */

	// TODO: replace with vector from utils
template<class _ElementType> struct vector_t
{
public:
	vector_t(int initial) {
		m_count = 0;
		m_allocated = initial;
		m_arr = make_unique_clear<_ElementType[]>(m_allocated);
	}
	vector_t()  {
		m_count = 0;
		m_allocated = 16;
		m_arr = make_unique_clear<_ElementType[]>(m_allocated);
	}
	~vector_t() {
		m_arr = nullptr;
	}
	_ElementType& operator [] (unsigned int index) const // get array item
	{
		return m_arr[index];
	}

	vector_t(const vector_t &a)  // copy constructor
	{
		m_allocated = a.count();
		if (m_allocated < 16)
			m_allocated = 16;
		m_count = a.count();
		m_arr = make_unique_clear<_ElementType[]>(m_allocated);
		for (int i=0; i < m_count; i++)
			m_arr[i] = a[i];
	}
	vector_t& operator = (const vector_t &a) // assignment operator
	{
		if (this == &a) return *this;
		m_allocated = a.count();
		if (m_allocated < 16)
			m_allocated = 16;
		m_count = a.count();
		m_arr = make_unique_clear<_ElementType[]>(m_allocated);
		for (int i=0; i < m_count; i++)
			m_arr[i] = a[i];
		return *this;
	}

	inline _ElementType* add(_ElementType object)
	{
		if (m_count >= m_allocated)
		{
			auto oldarr = make_unique_clear<_ElementType[]>(m_allocated);
			for (int i = 0; i < m_count; i++)
				oldarr[i] = m_arr[i];

			m_allocated *= 2;
			m_arr = make_unique_clear<_ElementType[]>(m_allocated);
			for (int i = 0; i < m_count; i++)
				m_arr[i] = oldarr[i];
		}
		m_arr[m_count] = object;
		m_count++;
		return &m_arr[m_count-1];
	}
	inline void remove(int index)
	{
		for (int i=index+1; i < m_count; i++)
			m_arr[i-1] = m_arr[i];
		m_count--;
	}
	inline void clear(void) { m_count = 0;  }
	inline int count(void) const { return m_count; }
	inline _ElementType *begin_ptr(void) const { return m_arr.get(); }
	inline _ElementType *end_ptr(void) const { return m_arr.get() + (m_count - 1); }
private:
	std::unique_ptr<_ElementType[]> m_arr;
	int m_count;
	int m_allocated;
};

/*************************************
 *
 *  Node-specific struct types
 *
 *************************************/

struct discrete_lfsr_desc
{
	int clock_type;
	int bitlength;
	int reset_value;

	int feedback_bitsel0;
	int feedback_bitsel1;
	int feedback_function0;         /* Combines bitsel0 & bitsel1 */

	int feedback_function1;         /* Combines funct0 & infeed bit */

	int feedback_function2;         /* Combines funct1 & shifted register */
	int feedback_function2_mask;    /* Which bits are affected by function 2 */

	int flags;

	int output_bit;
};


struct discrete_op_amp_osc_info
{
	uint32_t  type;
	double  r1;
	double  r2;
	double  r3;
	double  r4;
	double  r5;
	double  r6;
	double  r7;
	double  r8;
	double  c;
	double  vP;     // Op amp B+
};


#define DEFAULT_7414_VALUES     1.7, 0.9, 3.4

#define DEFAULT_74LS14_VALUES   1.6, 0.8, 3.4

struct discrete_schmitt_osc_desc
{
	double  rIn;
	double  rFeedback;
	double  c;
	double  trshRise;   // voltage that triggers the gate input to go high (vGate) on rise
	double  trshFall;   // voltage that triggers the gate input to go low (0V) on fall
	double  vGate;      // the output high voltage of the gate that gets fedback through rFeedback
	int     options;    // bitmapped options
};


struct discrete_comp_adder_table
{
	int     type;
	double  cDefault;               // Default component.  0 if not used.
	int     length;
	double  c[DISC_LADDER_MAXRES];  // Component table
};


struct discrete_dac_r1_ladder
{
	int     ladderLength;       // 2 to DISC_LADDER_MAXRES.  1 would be useless.
	double  r[DISC_LADDER_MAXRES];  // Don't use 0 for valid resistors.  That is a short.
	double  vBias;          // Voltage Bias resistor is tied to (0 = not used)
	double  rBias;          // Additional resistor tied to vBias (0 = not used)
	double  rGnd;           // Resistor tied to ground (0 = not used)
	double  cFilter;        // Filtering cap (0 = not used)
};


struct discrete_integrate_info
{
	uint32_t  type;
	double  r1;     // r1a + r1b
	double  r2;     // r2a + r2b
	double  r3;     // r3a + r3b
	double  c;
	double  v1;
	double  vP;
	double  f0;
	double  f1;
	double  f2;
};


#define DISC_MAX_MIXER_INPUTS   8
struct discrete_mixer_desc
{
	int     type;
	double  r[DISC_MAX_MIXER_INPUTS];       /* static input resistance values.  These are in series with rNode, if used. */
	int     r_node[DISC_MAX_MIXER_INPUTS];  /* variable resistance nodes, if needed.  0 if not used. */
	double  c[DISC_MAX_MIXER_INPUTS];
	double  rI;
	double  rF;
	double  cF;
	double  cAmp;
	double  vRef;
	double  gain;               /* Scale value to get output close to +/- 32767 */
};


struct discrete_op_amp_info
{
	uint32_t  type;
	double  r1;
	double  r2;
	double  r3;
	double  r4;
	double  c;
	double  vN;     // Op amp B-
	double  vP;     // Op amp B+
};


struct discrete_op_amp_1sht_info
{
	uint32_t  type;
	double  r1;
	double  r2;
	double  r3;
	double  r4;
	double  r5;
	double  c1;
	double  c2;
	double  vN;     // Op amp B-
	double  vP;     // Op amp B+
};


struct discrete_op_amp_tvca_info
{
	double  r1;
	double  r2;     // r2a + r2b
	double  r3;     // r3a + r3b
	double  r4;
	double  r5;
	double  r6;
	double  r7;
	double  r8;
	double  r9;
	double  r10;
	double  r11;
	double  c1;
	double  c2;
	double  c3;
	double  c4;
	double  v1;
	double  v2;
	double  v3;
	double  vP;
	int     f0;
	int     f1;
	int     f2;
	int     f3;
	int     f4;
	int     f5;
};


struct discrete_op_amp_filt_info
{
	double  r1;
	double  r2;
	double  r3;
	double  r4;
	double  rF;
	double  c1;
	double  c2;
	double  c3;
	double  vRef;
	double  vP;
	double  vN;
};


#define DEFAULT_555_CHARGE      -1
#define DEFAULT_555_HIGH        -1
#define DEFAULT_555_VALUES      DEFAULT_555_CHARGE, DEFAULT_555_HIGH

struct discrete_555_desc
{
	int     options;    /* bit mapped options */
	double  v_pos;      /* B+ voltage of 555 */
	double  v_charge;   /* voltage to charge circuit  (Defaults to v_pos) */
	double  v_out_high; /* High output voltage of 555 (Defaults to v_pos - 1.2V) */
};

#define DEFAULT_555_CC_SOURCE   DEFAULT_555_CHARGE

struct discrete_555_cc_desc
{
	int     options;        /* bit mapped options */
	double  v_pos;          /* B+ voltage of 555 */
	double  v_cc_source;    /* Voltage of the Constant Current source */
	double  v_out_high;     /* High output voltage of 555 (Defaults to v_pos - 1.2V) */
	double  v_cc_junction;  /* The voltage drop of the Constant Current source transistor (0 if Op Amp) */
};


struct discrete_555_vco1_desc
{
	int    options;             /* bit mapped options */
	double r1, r2, r3, r4, c;
	double v_pos;               /* B+ voltage of 555 */
	double v_charge;            /* (ignored) */
	double v_out_high;          /* High output voltage of 555 (Defaults to v_pos - 1.2V) */
};


struct discrete_adsr
{
	double attack_time;  /* All times are in seconds */
	double attack_value;
	double decay_time;
	double decay_value;
	double sustain_time;
	double sustain_value;
	double release_time;
	double release_value;
};


/*************************************
 *
 *  The node numbers themselves
 *
 *************************************/

#define NODE0_DEF(_x) NODE_ ## 0 ## _x = (0x40000000 + (_x) * DISCRETE_MAX_OUTPUTS), \
	NODE_ ## 0 ## _x ## _00 = NODE_ ## 0 ## _x, NODE_ ## 0 ## _x ## _01, NODE_ ## 0 ## _x ## _02, NODE_ ## 0 ## _x ## _03, \
	NODE_ ## 0 ## _x ## _04, NODE_ ## 0 ## _x ## _05, NODE_ ## 0 ## _x ## _06, NODE_ ## 0 ## _x ## _07
#define NODE_DEF(_x) NODE_ ## _x = (0x40000000 + (_x) * DISCRETE_MAX_OUTPUTS), \
	NODE_ ## _x ## _00 = NODE_ ## _x, NODE_ ## _x ## _01, NODE_ ## _x ## _02, NODE_ ## _x ## _03, \
	NODE_ ## _x ## _04, NODE_ ## _x ## _05, NODE_ ## _x ## _06, NODE_ ## _x ## _07

enum {
	NODE0_DEF(0), NODE0_DEF(1), NODE0_DEF(2), NODE0_DEF(3), NODE0_DEF(4), NODE0_DEF(5), NODE0_DEF(6), NODE0_DEF(7), NODE0_DEF(8), NODE0_DEF(9),
	NODE_DEF(10), NODE_DEF(11), NODE_DEF(12), NODE_DEF(13), NODE_DEF(14), NODE_DEF(15), NODE_DEF(16), NODE_DEF(17), NODE_DEF(18), NODE_DEF(19),
	NODE_DEF(20), NODE_DEF(21), NODE_DEF(22), NODE_DEF(23), NODE_DEF(24), NODE_DEF(25), NODE_DEF(26), NODE_DEF(27), NODE_DEF(28), NODE_DEF(29),
	NODE_DEF(30), NODE_DEF(31), NODE_DEF(32), NODE_DEF(33), NODE_DEF(34), NODE_DEF(35), NODE_DEF(36), NODE_DEF(37), NODE_DEF(38), NODE_DEF(39),
	NODE_DEF(40), NODE_DEF(41), NODE_DEF(42), NODE_DEF(43), NODE_DEF(44), NODE_DEF(45), NODE_DEF(46), NODE_DEF(47), NODE_DEF(48), NODE_DEF(49),
	NODE_DEF(50), NODE_DEF(51), NODE_DEF(52), NODE_DEF(53), NODE_DEF(54), NODE_DEF(55), NODE_DEF(56), NODE_DEF(57), NODE_DEF(58), NODE_DEF(59),
	NODE_DEF(60), NODE_DEF(61), NODE_DEF(62), NODE_DEF(63), NODE_DEF(64), NODE_DEF(65), NODE_DEF(66), NODE_DEF(67), NODE_DEF(68), NODE_DEF(69),
	NODE_DEF(70), NODE_DEF(71), NODE_DEF(72), NODE_DEF(73), NODE_DEF(74), NODE_DEF(75), NODE_DEF(76), NODE_DEF(77), NODE_DEF(78), NODE_DEF(79),
	NODE_DEF(80), NODE_DEF(81), NODE_DEF(82), NODE_DEF(83), NODE_DEF(84), NODE_DEF(85), NODE_DEF(86), NODE_DEF(87), NODE_DEF(88), NODE_DEF(89),
	NODE_DEF(90), NODE_DEF(91), NODE_DEF(92), NODE_DEF(93), NODE_DEF(94), NODE_DEF(95), NODE_DEF(96), NODE_DEF(97), NODE_DEF(98), NODE_DEF(99),
	NODE_DEF(100),NODE_DEF(101),NODE_DEF(102),NODE_DEF(103),NODE_DEF(104),NODE_DEF(105),NODE_DEF(106),NODE_DEF(107),NODE_DEF(108),NODE_DEF(109),
	NODE_DEF(110),NODE_DEF(111),NODE_DEF(112),NODE_DEF(113),NODE_DEF(114),NODE_DEF(115),NODE_DEF(116),NODE_DEF(117),NODE_DEF(118),NODE_DEF(119),
	NODE_DEF(120),NODE_DEF(121),NODE_DEF(122),NODE_DEF(123),NODE_DEF(124),NODE_DEF(125),NODE_DEF(126),NODE_DEF(127),NODE_DEF(128),NODE_DEF(129),
	NODE_DEF(130),NODE_DEF(131),NODE_DEF(132),NODE_DEF(133),NODE_DEF(134),NODE_DEF(135),NODE_DEF(136),NODE_DEF(137),NODE_DEF(138),NODE_DEF(139),
	NODE_DEF(140),NODE_DEF(141),NODE_DEF(142),NODE_DEF(143),NODE_DEF(144),NODE_DEF(145),NODE_DEF(146),NODE_DEF(147),NODE_DEF(148),NODE_DEF(149),
	NODE_DEF(150),NODE_DEF(151),NODE_DEF(152),NODE_DEF(153),NODE_DEF(154),NODE_DEF(155),NODE_DEF(156),NODE_DEF(157),NODE_DEF(158),NODE_DEF(159),
	NODE_DEF(160),NODE_DEF(161),NODE_DEF(162),NODE_DEF(163),NODE_DEF(164),NODE_DEF(165),NODE_DEF(166),NODE_DEF(167),NODE_DEF(168),NODE_DEF(169),
	NODE_DEF(170),NODE_DEF(171),NODE_DEF(172),NODE_DEF(173),NODE_DEF(174),NODE_DEF(175),NODE_DEF(176),NODE_DEF(177),NODE_DEF(178),NODE_DEF(179),
	NODE_DEF(180),NODE_DEF(181),NODE_DEF(182),NODE_DEF(183),NODE_DEF(184),NODE_DEF(185),NODE_DEF(186),NODE_DEF(187),NODE_DEF(188),NODE_DEF(189),
	NODE_DEF(190),NODE_DEF(191),NODE_DEF(192),NODE_DEF(193),NODE_DEF(194),NODE_DEF(195),NODE_DEF(196),NODE_DEF(197),NODE_DEF(198),NODE_DEF(199),
	NODE_DEF(200),NODE_DEF(201),NODE_DEF(202),NODE_DEF(203),NODE_DEF(204),NODE_DEF(205),NODE_DEF(206),NODE_DEF(207),NODE_DEF(208),NODE_DEF(209),
	NODE_DEF(210),NODE_DEF(211),NODE_DEF(212),NODE_DEF(213),NODE_DEF(214),NODE_DEF(215),NODE_DEF(216),NODE_DEF(217),NODE_DEF(218),NODE_DEF(219),
	NODE_DEF(220),NODE_DEF(221),NODE_DEF(222),NODE_DEF(223),NODE_DEF(224),NODE_DEF(225),NODE_DEF(226),NODE_DEF(227),NODE_DEF(228),NODE_DEF(229),
	NODE_DEF(230),NODE_DEF(231),NODE_DEF(232),NODE_DEF(233),NODE_DEF(234),NODE_DEF(235),NODE_DEF(236),NODE_DEF(237),NODE_DEF(238),NODE_DEF(239),
	NODE_DEF(240),NODE_DEF(241),NODE_DEF(242),NODE_DEF(243),NODE_DEF(244),NODE_DEF(245),NODE_DEF(246),NODE_DEF(247),NODE_DEF(248),NODE_DEF(249),
	NODE_DEF(250),NODE_DEF(251),NODE_DEF(252),NODE_DEF(253),NODE_DEF(254),NODE_DEF(255),NODE_DEF(256),NODE_DEF(257),NODE_DEF(258),NODE_DEF(259),
	NODE_DEF(260),NODE_DEF(261),NODE_DEF(262),NODE_DEF(263),NODE_DEF(264),NODE_DEF(265),NODE_DEF(266),NODE_DEF(267),NODE_DEF(268),NODE_DEF(269),
	NODE_DEF(270),NODE_DEF(271),NODE_DEF(272),NODE_DEF(273),NODE_DEF(274),NODE_DEF(275),NODE_DEF(276),NODE_DEF(277),NODE_DEF(278),NODE_DEF(279),
	NODE_DEF(280),NODE_DEF(281),NODE_DEF(282),NODE_DEF(283),NODE_DEF(284),NODE_DEF(285),NODE_DEF(286),NODE_DEF(287),NODE_DEF(288),NODE_DEF(289),
	NODE_DEF(290),NODE_DEF(291),NODE_DEF(292),NODE_DEF(293),NODE_DEF(294),NODE_DEF(295),NODE_DEF(296),NODE_DEF(297),NODE_DEF(298),NODE_DEF(299)
};

/* Some Pre-defined nodes for convenience */

#define NODE(_x)    (NODE_00 + (_x) * DISCRETE_MAX_OUTPUTS)
#define NODE_SUB(_x, _y) ((_x) + (_y))

#if DISCRETE_MAX_OUTPUTS == 8
#define NODE_CHILD_NODE_NUM(_x)     ((int)(_x) & 7)
#define NODE_DEFAULT_NODE(_x)       ((int)(_x) & ~7)
#define NODE_INDEX(_x)              (((int)(_x) - NODE_START)>>3)
#else
#error "DISCRETE_MAX_OUTPUTS != 8"
#endif

#define NODE_RELATIVE(_x, _y) (NODE(NODE_INDEX(_x) + (_y)))

#define NODE_NC  NODE_00
#define NODE_SPECIAL  NODE(DISCRETE_MAX_NODES)

#define NODE_START  NODE_00
#define NODE_END    NODE_SPECIAL

#define IS_VALUE_A_NODE(val)    (((val) > NODE_START) && ((val) <= NODE_END))

// Optional node such as used in CR_FILTER
#define OPT_NODE(val)   (int) val
/*************************************
 *
 *  Enumerated values for Node types
 *  in the simulation
 *
 *      DSS - Discrete Sound Source
 *      DST - Discrete Sound Transform
 *      DSD - Discrete Sound Device
 *      DSO - Discrete Sound Output
 *
 *************************************/

enum discrete_node_type
{
	DSS_NULL,           /* Nothing, nill, zippo, only to be used as terminating node */
	DSS_NOP,            /* just do nothing, placeholder for potential DISCRETE_REPLACE in parent block */

	/* standard node */

	DSS_NODE,           /* a standard node */

	/* Custom */
	DST_CUSTOM,         /* whatever you want */

	/* Debugging */
	DSO_CSVLOG,         /* Dump nodes as csv file */
	DSO_WAVLOG,     /* Dump nodes as wav file */

	/* Parallel execution */
	DSO_TASK_START, /* start of parallel task */
	DSO_TASK_END,   /* end of parallel task */

	/* Output Node -- this must be the last entry in this enum! */
	DSO_OUTPUT,         /* The final output node */

	/* Import another blocklist */
	DSO_IMPORT,         /* import from another discrete block */
	DSO_REPLACE,        /* replace next node */
	DSO_DELETE,         /* delete nodes */

	/* Marks end of this enum -- must be last entry ! */
	DSO_LAST
};

/*************************************
 *
 *  Forward declarations
 *
 *************************************/

struct discrete_block;
class discrete_node_base_factory;
class discrete_task;
class discrete_base_node;
class discrete_dss_input_stream_node;
class discrete_device;
typedef vector_t<discrete_base_node *> node_list_t;
typedef vector_t<discrete_dss_input_stream_node *> istream_node_list_t;
typedef vector_t<discrete_task *> task_list_t;


/*************************************
 *
 *  Discrete module definition
 *
 *************************************/


/*************************************
 *
 *  The discrete sound blocks as
 *  defined in the drivers
 *
 *************************************/


