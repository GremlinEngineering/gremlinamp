// Pinned MAME BSD-3-Clause excerpts; see source-receipts.json and originals.
#define DISCRETE_CLASS_NAME(_name) discrete_ ## _name ## _node

#define DISCRETE_CLASS_INPUT(_name, _num)   inline double _name (void) { return *(m_input[_num]); }

#define DISCRETE_CLASS_CONSTRUCTOR(_name, _base)                        \
	public:                                                             \
		DISCRETE_CLASS_NAME(_name)()                                    \
			: DISCRETE_CLASS_NAME(_base)() { }

#define DISCRETE_CLASS_DESTRUCTOR(_name)                                \
	public:                                                             \
		virtual ~ DISCRETE_CLASS_NAME(_name)(void) { }

#define  DISCRETE_CLASS_STEP_RESET(_name, _maxout, _priv)               \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node, public discrete_step_interface         \
{                                                                       \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
public:                                                                 \
	virtual void step(void) override;                                                    \
	virtual void reset(void) override;                                                   \
	virtual int max_output(void) override { return _maxout; }                    \
private:                                                                \
	_priv                                                               \
}

#define DISCRETE_CLASS_STEP(_name, _maxout, _priv)                      \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node, public discrete_step_interface             \
{                                                                       \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
public:                                                                 \
	virtual void step(void) override;                                   \
	virtual void reset(void) override  { this->step(); }                \
	virtual int max_output(void) override { return _maxout; }           \
private:                                                                \
	_priv                                                               \
}

#define  DISCRETE_CLASS_RESET(_name, _maxout)                           \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node             \
{                                                                       \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
public:                                                                 \
	virtual void reset(void) override;                                                    \
	virtual int max_output(void) override { return _maxout; }                    \
}

#define  DISCRETE_CLASS(_name, _maxout, _priv)                      \
class DISCRETE_CLASS_NAME(_name): public discrete_base_node, public discrete_step_interface             \
{                                                                       \
	DISCRETE_CLASS_DESTRUCTOR(_name)                                    \
	DISCRETE_CLASS_CONSTRUCTOR(_name, base)                             \
public:                                                                 \
	virtual void step(void) override;                                                    \
	virtual void reset(void) override;                                                   \
	virtual void start(void) override;                                                   \
	virtual void stop(void) override;                                                    \
	virtual int max_output(void) override { return _maxout; }                    \
private:                                                                \
	_priv                                                               \
}

class DISCRETE_CLASS_NAME(special): public discrete_base_node
{
	DISCRETE_CLASS_CONSTRUCTOR(special, base)
	DISCRETE_CLASS_DESTRUCTOR(special)
public:
	virtual int max_output(void) override { return 0; }
};

class DISCRETE_CLASS_NAME(unimplemented): public discrete_base_node
{
	DISCRETE_CLASS_CONSTRUCTOR(unimplemented, base)
	DISCRETE_CLASS_DESTRUCTOR(unimplemented)
public:
	virtual int max_output(void) override { return 0; }
};

class DISCRETE_CLASS_NAME(dss_adjustment): public discrete_base_node, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_adjustment, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_adjustment)
public:
	virtual void step(void) override;
	virtual void reset(void) override;
private:
	ioport_port *m_port;
	int32_t                   m_lastpval;
	int32_t                   m_pmin;
	double                  m_pscale;
	double                  m_min;
	double                  m_scale;
};

DISCRETE_CLASS_RESET(dss_constant, 1);

class DISCRETE_CLASS_NAME(dss_input_data): public discrete_base_node, public discrete_input_interface
{
	DISCRETE_CLASS_DESTRUCTOR(dss_input_data)
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_data, base)
public:
	virtual void reset(void) override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	double      m_gain;             /* node gain */
	double      m_offset;           /* node offset */
	uint8_t       m_data;             /* data written */
};

class DISCRETE_CLASS_NAME(dss_input_logic): public discrete_base_node, public discrete_input_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_logic, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_input_logic)
public:
	virtual void reset(void) override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	double      m_gain;             /* node gain */
	double      m_offset;           /* node offset */
	uint8_t       m_data;             /* data written */
};

class DISCRETE_CLASS_NAME(dss_input_not): public discrete_base_node, public discrete_input_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_not, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_input_not)
public:
	virtual void reset(void) override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	double      m_gain;             /* node gain */
	double      m_offset;           /* node offset */
	uint8_t       m_data;             /* data written */
};

class DISCRETE_CLASS_NAME(dss_input_pulse): public discrete_base_node, public discrete_input_interface, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_input_pulse, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_input_pulse)
public:
	virtual void step(void) override;
	virtual void reset(void) override;
	virtual void input_write(int sub_node, uint8_t data ) override;
private:
	//double      m_gain;             /* node gain */
	//double      m_offset;           /* node offset */
	uint8_t       m_data;             /* data written */
};



DISCRETE_CLASS_STEP_RESET(dss_counter, 1,
	int             m_clock_type;
	int             m_out_type;
	int             m_is_7492;
	int             m_last_clock;
	uint32_t          m_last_count;
	//uint32_t          m_last;                 /* Last clock state */
	uint32_t          m_min;
	uint32_t          m_max;
	uint32_t          m_diff;
	double          m_t_left;               /* time unused during last sample in seconds */
);

DISCRETE_CLASS_STEP_RESET(dss_lfsr_noise, 2,
	unsigned int    m_lfsr_reg;
	int             m_last;                 /* Last clock state */
	double          m_t_clock;              /* fixed counter clock in seconds */
	double          m_t_left;               /* time unused during last sample in seconds */
	//double          m_sample_step;
	//double          m_t;
	uint8_t           m_reset_on_high;
	uint8_t           m_invert_output;
	uint8_t           m_out_is_f0;
	uint8_t           m_out_lfsr_reg;
);

DISCRETE_CLASS_STEP_RESET(dss_noise, 2,
	double          m_phase;
);

DISCRETE_CLASS_STEP_RESET(dss_note, 1,
	int             m_clock_type;
	int             m_out_type;
	int             m_last;                 /* Last clock state */
	double          m_t_clock;              /* fixed counter clock in seconds */
	double          m_t_left;               /* time unused during last sample in seconds */
	int             m_max1;                 /* Max 1 Count stored as int for easy use. */
	int             m_max2;                 /* Max 2 Count stored as int for easy use. */
	int             m_count1;               /* current count1 */
	int             m_count2;               /* current count2 */
);

DISCRETE_CLASS_STEP_RESET(dss_sawtoothwave, 1,
	double          m_phase;
	int             m_type;
);

DISCRETE_CLASS_STEP_RESET(dss_sinewave, 1,
	double          m_phase;
);

DISCRETE_CLASS_STEP_RESET(dss_squarewave, 1,
	double          m_phase;
	double          m_trigger;
);
DISCRETE_CLASS_STEP_RESET(dss_squarewfix, 1,
	int             m_flip_flop;
	double          m_sample_step;
	double          m_t_left;
	double          m_t_off;
	double          m_t_on;
);

DISCRETE_CLASS_STEP_RESET(dss_squarewave2, 1,
	double          m_phase;
	double          m_trigger;
);

DISCRETE_CLASS_STEP_RESET(dss_trianglewave, 1,
	double          m_phase;
);

/* Component specific modules */

#define DSS_INV_TAB_SIZE    500
#define DEFAULT_CD40XX_VALUES(_vB)  (_vB),(_vB)*0.02,(_vB)*0.98,(_vB)/5.0*1.5,(_vB)/5.0*3.5, 0.1

class DISCRETE_CLASS_NAME(dss_inverter_osc): public discrete_base_node, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dss_inverter_osc, base)
	DISCRETE_CLASS_DESTRUCTOR(dss_inverter_osc)
public:
	struct description
	{
		double  vB;
		double  vOutLow;
		double  vOutHigh;
		double  vInFall;    // voltage that triggers the gate input to go low (0V) on fall
		double  vInRise;    // voltage that triggers the gate input to go high (vGate) on rise
		double  clamp;      // voltage is clamped to -clamp ... vb+clamp if clamp>= 0;
		int     options;    // bitmapped options
	};
	enum {
		IS_TYPE1 = 0x00,
		IS_TYPE2 = 0x01,
		IS_TYPE3 = 0x02,
		IS_TYPE4 = 0x03,
		IS_TYPE5 = 0x04,
		TYPE_MASK = 0x0f,
		OUT_IS_LOGIC = 0x10
	};
	void step(void) override;
	void reset(void) override;
protected:
	inline double tftab(double x);
	inline double tf(double x);
private:
	DISCRETE_CLASS_INPUT(I_ENABLE,  0);
	DISCRETE_CLASS_INPUT(I_MOD,     1);
	DISCRETE_CLASS_INPUT(I_RC,      2);
	DISCRETE_CLASS_INPUT(I_RP,      3);
	DISCRETE_CLASS_INPUT(I_C,       4);
	DISCRETE_CLASS_INPUT(I_R2,      5);

	double          mc_v_cap;
	double          mc_v_g2_old;
	double          mc_w;
	double          mc_wc;
	double          mc_rp;
	double          mc_r1;
	double          mc_r2;
	double          mc_c;
	double          mc_tf_a;
	double          mc_tf_b;
	double          mc_tf_tab[DSS_INV_TAB_SIZE];
};

DISCRETE_CLASS_STEP_RESET(dss_op_amp_osc, 1,
	const double *  m_r[8];                 /* pointers to resistor values */
	int             m_type;
	uint8_t           m_flip_flop;            /* flip/flop output state */
	uint8_t           m_flip_flop_xor;        /* flip_flop ^ flip_flop_xor, 0 = discharge, 1 = charge */
	uint8_t           m_output_type;
	uint8_t           m_has_enable;
	double          m_v_out_high;
	double          m_threshold_low;        /* falling threshold */
	double          m_threshold_high;       /* rising threshold */
	double          m_v_cap;                /* current capacitor voltage */
	double          m_r_total;              /* all input resistors in parallel */
	double          m_i_fixed;              /* fixed current at the input */
	double          m_i_enable;             /* fixed current at the input if enabled */
	double          m_temp1;                /* Multi purpose */
	double          m_temp2;                /* Multi purpose */
	double          m_temp3;                /* Multi purpose */
	double          m_is_linear_charge;
	double          m_charge_rc[2];
	double          m_charge_exp[2];
	double          m_charge_v[2];
);

DISCRETE_CLASS_STEP_RESET(dss_schmitt_osc, 1,
	double          m_ration_in;            /* ratio of total charging voltage that comes from the input */
	double          m_ratio_feedback;       /* ratio of total charging voltage that comes from the feedback */
	double          m_v_cap;                /* current capacitor voltage */
	double          m_rc;                   /* r*c */
	double          m_exponent;
	int             m_state;                /* state of the output */
	int             m_enable_type;
	uint8_t           m_input_is_voltage;
);

/* Not yet implemented */
DISCRETE_CLASS_STEP_RESET(dss_adsrenv,  1,
	//double          m_phase;
);





DISCRETE_CLASS_STEP(dst_adder, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_clamp, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_divide, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_gain, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_inv, 1, /* no context */ );

DISCRETE_CLASS_STEP_RESET(dst_bits_decode, 8,
	int             m_count;
	int             m_decode_x_time;
	int             m_from;
	int             m_last_val;
	int             m_last_had_x_time;
);

DISCRETE_CLASS_STEP(dst_logic_and, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_nand, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_or, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_nor, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_xor, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_logic_nxor, 1, /* no context */ );

DISCRETE_CLASS_STEP_RESET(dst_logic_dff, 1,
	int             m_last_clk;
);

DISCRETE_CLASS_STEP_RESET(dst_logic_jkff, 1,
	double          m_v_out;
	int             m_last_clk;
);

DISCRETE_CLASS_STEP_RESET(dst_logic_shift, 1,
	double          m_t_left;                   /* time unused during last sample in seconds */
	uint32_t          m_shift_data;
	uint32_t          m_bit_mask;
	uint8_t           m_clock_type;
	uint8_t           m_reset_on_high;
	uint8_t           m_shift_r;
	uint8_t           m_last;
);

DISCRETE_CLASS_STEP(dst_lookup_table, 1, /* no context */ );

DISCRETE_CLASS_STEP_RESET(dst_multiplex, 1,
	int             m_size;
);

DISCRETE_CLASS_STEP_RESET(dst_oneshot, 1,
	double          m_countdown;
	int             m_state;
	int             m_last_trig;
	int             m_type;
);

DISCRETE_CLASS_STEP_RESET(dst_ramp, 1,
	double          m_v_out;
	double          m_step;
	int             m_dir;                  /* 1 if End is higher then Start */
	int             m_last_en;              /* Keep track of the last enable value */
);

DISCRETE_CLASS_STEP_RESET(dst_samphold, 1,
	double          m_last_input;
	int             m_clocktype;
);

DISCRETE_CLASS_STEP(dst_switch, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_aswitch, 1, /* no context */ );

DISCRETE_CLASS_STEP(, 1, /* no context */ );
class DISCRETE_CLASS_NAME(dst_transform): public discrete_base_node, public discrete_step_interface
{
	DISCRETE_CLASS_CONSTRUCTOR(dst_transform, base)
	DISCRETE_CLASS_DESTRUCTOR(dst_transform)
public:
	enum token {
		TOK_END = 0,
		TOK_MULT,
		TOK_DIV,
		TOK_ADD,
		TOK_MINUS,
		TOK_0,
		TOK_1,
		TOK_2,
		TOK_3,
		TOK_4,
		TOK_DUP,
		TOK_ABS,         /* absolute value */
		TOK_NEG,         /* * -1 */
		TOK_NOT,         /* Logical NOT of Last Value */
		TOK_EQUAL,       /* Logical = */
		TOK_GREATER,     /* Logical > */
		TOK_LESS,        /* Logical < */
		TOK_AND,         /* Bitwise AND */
		TOK_OR,          /* Bitwise OR */
		TOK_XOR          /* Bitwise XOR */
	};
	void step(void) override;
	void reset(void) override;
private:
	DISCRETE_CLASS_INPUT(I_IN0,     0);
	DISCRETE_CLASS_INPUT(I_IN1,     1);
	DISCRETE_CLASS_INPUT(I_IN2,     2);
	DISCRETE_CLASS_INPUT(I_IN3,     3);
	DISCRETE_CLASS_INPUT(I_IN4,     4);
	enum token precomp[32];
};

/* Component specific */

DISCRETE_CLASS_STEP_RESET(dst_comp_adder, 1,
	double          m_total[256];
);

DISCRETE_CLASS_STEP_RESET(dst_dac_r1, 1,
	double          m_v_out;
	double          m_exponent;
	double          m_last_v;
	double          m_v_step[256];
	int             m_has_c_filter;
);

DISCRETE_CLASS_STEP_RESET(dst_diode_mix, 1,
	int             m_size;
	double          m_v_junction[8];
);

DISCRETE_CLASS_STEP_RESET(dst_integrate, 1,
	double          m_v_out;
	double          m_change;
	double          m_v_max_in;             /* v1 - norton VBE */
	double          m_v_max_in_d;           /* v1 - norton VBE - diode drop */
	double          m_v_max_out;
);

#define DISC_MIXER_MAX_INPS 8
DISCRETE_CLASS_STEP_RESET(dst_mixer, 1,
	int             m_type;
	int             m_size;
	int             m_r_node_bit_flag;
	int             m_c_bit_flag;
	double          m_r_total;
	const double *  m_r_node[DISC_MIXER_MAX_INPS];      /* Either pointer to resistance node output OR nullptr */
	double          m_r_last[DISC_MIXER_MAX_INPS];
	double          m_exponent_rc[DISC_MIXER_MAX_INPS]; /* For high pass filtering cause by cIn */
	double          m_v_cap[DISC_MIXER_MAX_INPS];       /* cap voltage of each input */
	double          m_exponent_c_f;         /* Low pass on mixed inputs */
	double          m_exponent_c_amp;       /* Final high pass caused by out cap and amp input impedance */
	double          m_v_cap_f;              /* cap voltage of cF */
	double          m_v_cap_amp;            /* cap voltage of cAmp */
	double          m_gain;                 /* used for DISC_MIXER_IS_OP_AMP_WITH_RI */
);

DISCRETE_CLASS_STEP_RESET(dst_op_amp, 1,
	uint8_t           m_has_cap;
	uint8_t           m_has_r1;
	uint8_t           m_has_r4;
	double          m_v_max;
	double          m_i_fixed;
	double          m_v_cap;
	double          m_exponent;
);

DISCRETE_CLASS_STEP_RESET(dst_op_amp_1sht, 1,
	double          m_v_out;
	double          m_i_fixed;
	double          m_v_max;
	double          m_r34ratio;
	double          m_v_cap1;
	double          m_v_cap2;
	double          m_exponent1c;
	double          m_exponent1d;
	double          m_exponent2;
);

DISCRETE_CLASS_STEP_RESET(dst_tvca_op_amp, 1,
	double          m_v_out_max;            /* Maximum output voltage */
	double          m_v_trig[2];            /* Voltage used to charge cap1 based on function F3 */
	double          m_v_trig2;              /* Voltage used to charge cap2 */
	double          m_v_trig3;              /* Voltage used to charge cap3 */
	double          m_i_fixed;              /* Fixed current going into - input */
	double          m_exponent_c[2];        /* Charge exponents based on function F3 */
	double          m_exponent_d[2];        /* Discharge exponents based on function F3 */
	double          m_exponent2[2];         /* Discharge/charge exponents based on function F4 */
	double          m_exponent3[2];         /* Discharge/charge exponents based on function F5 */
	double          m_exponent4;            /* Discharge/charge exponents for c4 */
	double          m_v_cap1;               /* charge on cap c1 */
	double          m_v_cap2;               /* charge on cap c2 */
	double          m_v_cap3;               /* charge on cap c3 */
	double          m_v_cap4;               /* charge on cap c4 */
	double          m_r67;                  /* = r6 + r7 (for easy use later) */
	uint8_t           m_has_c4;
	uint8_t           m_has_r4;
);

DISCRETE_CLASS_STEP(dst_xtime_buffer, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_xtime_and, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_xtime_or, 1, /* no context */ );

DISCRETE_CLASS_STEP(dst_xtime_xor, 1, /* no context */ );





struct discrete_filter_coeff
{
	double x1, x2;      /* x[k-1], x[k-2], previous 2 input values */
	double y1, y2;      /* y[k-1], y[k-2], previous 2 output values */
	double a1, a2;      /* digital filter coefficients, denominator */
	double b0, b1, b2;  /* digital filter coefficients, numerator */
};


DISCRETE_CLASS_STEP_RESET(dst_filter1, 1,
	/* uses x1, y1, a1, b0, b1 */
	struct discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_filter2, 1,
	struct discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_sallen_key, 1,
	struct discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_crfilter, 1,
	double          m_vCap;
	double          m_rc;
	double          m_exponent;
	uint8_t           m_has_rc_nodes;
	//uint8_t           m_is_fast;
);

DISCRETE_CLASS_STEP_RESET(dst_op_amp_filt, 1,
	int             m_type;                 /* What kind of filter */
	int             m_is_norton;            /* 1 = Norton op-amps */
	double          m_vRef;
	double          m_vP;
	double          m_vN;
	double          m_rTotal;               /* All input resistance in parallel. */
	double          m_iFixed;               /* Current supplied by r3 & r4 if used. */
	double          m_exponentC1;
	double          m_exponentC2;
	double          m_exponentC3;
	double          m_rRatio;               /* divide ratio of resistance network */
	double          m_vC1;                  /* Charge on C1 */
	double          m_vC1b;                 /* Charge on C1, part of C1 charge if needed */
	double          m_vC2;                  /* Charge on C2 */
	double          m_vC3;                  /* Charge on C2 */
	double          m_gain;                 /* Gain of the filter */
	struct discrete_filter_coeff m_fc;
);

DISCRETE_CLASS_STEP_RESET(dst_rc_circuit_1, 1,
	double          m_v_cap;
	double          m_v_charge_1_2;
	double          m_v_drop;
	double          m_exp_1;
	double          m_exp_1_2;
	double          m_exp_2;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc, 1,
	int             m_state;
	double          m_t;                    /* time */
	double          m_exponent0;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc2, 1,
	int             m_state;
	double          m_v_out;
	double          m_t;                    /* time */
	double          m_exponent0;
	double          m_exponent1;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc3, 1,
	int             m_state;
	double          m_v_out;
	double          m_t;                    /* time */
	double          m_exponent0;
	double          m_exponent1;
	double          m_v_diode;              /* rcdisc3 */
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc4, 1,
	int             m_type;
	double          m_max_out;
	double          m_vC1;
	double          m_v[2];
	double          m_exp[2];
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc5, 1,
	int             m_state;
	double          m_t;                    /* time */
	double          m_exponent0;
	double          m_v_cap;                /* rcdisc5 */
);

DISCRETE_CLASS_STEP_RESET(dst_rcintegrate, 1,
	int             m_type;
	double          m_gain_r1_r2;
	double          m_f;                    /* r2,r3 gain */
	double          m_vCap;
	double          m_vCE;
	double          m_exponent0;
	double          m_exponent1;
	double          m_exp_exponent0;
	double          m_exp_exponent1;
	double          m_c_exp0;
	double          m_c_exp1;
	double          m_EM_IC_0_7;
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc_mod, 1,
	double          m_v_cap;
	double          m_exp_low[2];
	double          m_exp_high[4];
	double          m_gain[2];
	double          m_vd_gain[4];
);

DISCRETE_CLASS_STEP_RESET(dst_rcfilter, 1,
	double          m_v_out;
	double          m_vCap;
	double          m_rc;
	double          m_exponent;
	uint8_t           m_has_rc_nodes;
	uint8_t           m_is_fast;
);

DISCRETE_CLASS_STEP_RESET(dst_rcfilter_sw, 1,
	double          m_vCap[4];
	double          m_exp[4];
	double          m_exp0;                 /* fast case bit 0 */
	double          m_exp1;                 /* fast case bit 1 */
	double          m_factor;               /* fast case */
	double          m_f1[16];
	double          m_f2[16];
);

DISCRETE_CLASS_STEP_RESET(dst_rcdiscN, 1,
	double          m_x1;                   /* x[k-1], previous input value */
	double          m_y1;                   /* y[k-1], previous output value */
	double          m_a1;                   /* digital filter coefficients, denominator */
	//double          m_b[2];                 /* digital filter coefficients, numerator */
);

DISCRETE_CLASS_STEP_RESET(dst_rcdisc2N, 1,
	struct discrete_filter_coeff m_fc0;
	struct discrete_filter_coeff m_fc1;
	double          m_x1;
	double          m_y1;
);





DISCRETE_CLASS_STEP_RESET(dsd_555_astbl, 1,
	int             m_use_ctrlv;
	int             m_output_type;
	int             m_output_is_ac;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* 555 flip/flop output state */
	double          m_cap_voltage;              /* voltage on cap */
	double          m_threshold;
	double          m_trigger;
	double          m_v_out_high;               /* Logic 1 voltage level */
	double          m_v_charge;
	const double *  m_v_charge_node;            /* point to output of node */
	int             m_has_rc_nodes;
	double          m_exp_bleed;
	double          m_exp_charge;
	double          m_exp_discharge;
	double          m_t_rc_bleed;
	double          m_t_rc_charge;
	double          m_t_rc_discharge;
	double          m_last_r1;
	double          m_last_r2;
	double          m_last_c;
);

DISCRETE_CLASS_STEP_RESET(dsd_555_mstbl, 1,
	int             m_trig_is_logic;
	int             m_trig_discharges_cap;
	int             m_output_type;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* 555 flip/flop output state */
	int             m_has_rc_nodes;
	double          m_exp_charge;
	double          m_cap_voltage;              /* voltage on cap */
	double          m_threshold;
	double          m_trigger;
	double          m_v_out_high;               /* Logic 1 voltage level */
	double          m_v_charge;
);

DISCRETE_CLASS_STEP_RESET(dsd_555_cc, 1,
	unsigned int    m_type;                     /* type of 555cc circuit */
	int             m_output_type;
	int             m_output_is_ac;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* 555 flip/flop output state */
	double          m_cap_voltage;              /* voltage on cap */
	double          m_threshold;
	double          m_trigger;
	double          m_v_out_high;               /* Logic 1 voltage level */
	double          m_v_cc_source;
	int             m_has_rc_nodes;
	double          m_exp_bleed;
	double          m_exp_charge;
	double          m_exp_discharge;
	double          m_exp_discharge_01;
	double          m_exp_discharge_no_i;
	double          m_t_rc_charge;
	double          m_t_rc_discharge;
	double          m_t_rc_discharge_01;
	double          m_t_rc_discharge_no_i;
);

DISCRETE_CLASS_STEP_RESET(dsd_555_vco1, 1,
	int             m_ctrlv_is_node;
	int             m_output_type;
	int             m_output_is_ac;
	double          m_ac_shift;                 /* DC shift needed to make waveform ac */
	int             m_flip_flop;                /* flip/flop output state */
	double          m_v_out_high;               /* 555 high voltage */
	double          m_threshold;                /* falling threshold */
	double          m_trigger;                  /* rising threshold */
	double          m_i_charge;                 /* charge current */
	double          m_i_discharge;              /* discharge current */
	double          m_cap_voltage;              /* current capacitor voltage */
);

DISCRETE_CLASS_STEP_RESET(dsd_566, 1,
	//unsigned int    m_state[2];                 /* keeps track of excess flip_flop changes during the current step */
	int             m_flip_flop;                /* 566 flip/flop output state */
	double          m_cap_voltage;              /* voltage on cap */
	double          m_v_sqr_low;                /* voltage for a squarewave at low */
	double          m_v_sqr_high;               /* voltage for a squarewave at high */
	double          m_v_sqr_diff;
	double          m_threshold_low;            /* falling threshold */
	double          m_threshold_high;           /* rising threshold */
	double          m_ac_shift;                 /* used to fake AC */
	double          m_v_osc_stable;
	double          m_v_osc_stop;
	int             m_fake_ac;
	int             m_out_type;
);

DISCRETE_CLASS_STEP_RESET(dsd_ls624, 1,
	double          m_exponent;
	double          m_t_used;
	double          m_v_cap_freq_in;
	double          m_v_freq_scale;
	double          m_v_rng_scale;
	int             m_flip_flop;
	int             m_has_freq_in_cap;
	int             m_out_type;
);



