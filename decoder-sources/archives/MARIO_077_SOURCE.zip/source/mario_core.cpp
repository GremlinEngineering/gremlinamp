// Gremlin original Mario external firmware, documented I8039 bootstrap compatibility + BSD MCS48
// instruction core + complete original MAME discrete graphs. No rendered track.
#include "mcs48.cpp"
#include "discrete/host.h"
#include <deque>
namespace gremlin_mario {
struct Event {uint32_t cycle;uint16_t address;uint8_t value;};
struct State;
static State*current=nullptr;
static uint32_t r32(const uint8_t*p){return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24;}
static uint32_t crc32(const uint8_t*p,size_t n){uint32_t c=~0u;for(size_t i=0;i<n;i++){c^=p[i];for(int bit=0;bit<8;bit++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
struct State {
 bool cpu_open=false;uint8_t p1=0xf0,p2=255,t0=0,t1=0,latch=0;
 uint32_t rate=48000,preroll=0,duration=0;uint64_t position=0,samples=0,queue_base=0,port_writes=0;
 std::vector<uint8_t>program,data;std::vector<Event>events;size_t event_position=0;
 discrete_device graph;std::deque<float>pcm;
 ~State(){if(cpu_open){mcs48Close();mcs48Exit();}}
 void advance(uint64_t cycle){
  uint64_t target=cycle*720000/11000000;
  while(samples<target){float s=graph.sample(1);if(!std::isfinite(s))throw std::runtime_error("nonfinite Mario graph output");
   if(samples>=preroll)pcm.push_back(samples-preroll<duration?s:0.f);samples++;
  }
 }
 static uint8_t read(uint32_t p){auto&s=*current;
  if(p<256)return(s.p2&128)?s.latch:s.program[(s.p2&15)*256+(p&255)];
  switch(p){case MCS48_P1:return s.p1;case MCS48_P2:return s.p2&0xef;case MCS48_T0:return s.t0;case MCS48_T1:return s.t1;default:return 0;}}
 static void write(uint32_t p,uint8_t value){auto&s=*current;s.advance(uint32_t(mcs48TotalCycles()));s.port_writes++;
  if(p<256)s.graph.write(DS_DAC,value);else if(p==MCS48_P1)s.p1=value;else if(p==MCS48_P2)s.p2=value;
 }
 void input(const Event&e){switch(e.address){
  case 0x7e00:latch=e.value;break;case 0x7f00:mcs48SetIRQLine(0,e.value?1:0);break;case 0x7f01:t0=e.value;break;
  case 0x7f03:p1=(p1&~1)|(e.value<<0);break;case 0x7f04:p1=(p1&~2)|(e.value<<1);break;case 0x7f05:p1=(p1&~4)|(e.value<<2);break;
  default:throw std::runtime_error("unsupported Mario host input");}}
 void step(){uint32_t at=mcs48TotalCycles();
  while(event_position<events.size()&&events[event_position].cycle<=at){
   if(events[event_position].cycle!=at)throw std::runtime_error("MCU command is not on original instruction boundary");
   input(events[event_position++]);
  }
  mcs48Run(1);advance(uint32_t(mcs48TotalCycles()));
 }
 void ensure(uint64_t index){if(index>=duration)return;unsigned guard=0;
  while(queue_base+pcm.size()<=index){if(++guard>10000)throw std::runtime_error("Mario stream did not advance");step();}
 }
 float at(uint64_t index){if(index>=duration)return 0;ensure(index);return pcm[index-queue_base];}
 void boot(){
  graph.build(mario_discrete_interface);
  mcs48Init(0,8039,program.data());mcs48Open(0);cpu_open=true;
  mcs48_set_read_port(read);mcs48_set_write_port(write);mcs48Reset();p1=0xf0;
  while(samples<preroll)step();
 }
};
static std::unique_ptr<State>state;static std::string error_text,stats_text;
}
#define API __attribute__((visibility("default")))
extern "C" {
API void gremlin_mario_close(){using namespace gremlin_mario;state.reset();current=nullptr;}
API const char*gremlin_mario_error(){return gremlin_mario::error_text.c_str();}
API const char*gremlin_mario_devices(){return "[{\"type\":\"mario_m58715_i8039_compatibility\",\"clock_hz\":11000000,\"clock_divisor\":15,\"internal_sample_rate\":48000,\"sound_firmware\":\"original external ROM, documented runtime bootstrap byte1=01\",\"internal_m58715_rom_dumped\":false,\"circuit\":\"complete original MAME0.190 OLD_SOUND discrete alternative\",\"rendered_track\":false,\"analog_board_measurement\":false}]";}
API const char*gremlin_mario_stats(){using namespace gremlin_mario;if(!state)return "{}";char b[600];snprintf(b,sizeof(b),"{\"profile\":%u,\"machine_cycles\":%u,\"cpu_pc\":%u,\"port_writes\":%llu,\"events_applied\":%zu,\"events_total\":%zu,\"samples_synthesized\":%llu,\"preroll_samples\":%u,\"duration_samples\":%u,\"output_frames\":%llu}",1,uint32_t(mcs48TotalCycles()),mcs48->pc,state->port_writes,state->event_position,state->events.size(),state->samples,state->preroll,state->duration,state->position);stats_text=b;return stats_text.c_str();}
API int gremlin_mario_load(const uint8_t*b,uint32_t length,uint32_t rate,uint32_t subsong){using namespace gremlin_mario;gremlin_mario_close();error_text.clear();try{
 if(!b||length<128||length>1000000||memcmp(b,"MRM\x1a",4)||r32(b+4)!=1)throw std::runtime_error("Invalid MRM1 header");
 uint32_t profile=r32(b+8),n=r32(b+32),offset=r32(b+36),preroll=r32(b+40),duration=r32(b+44),data_size=r32(b+28);
 if(profile!=1||rate<8000||rate>192000||subsong||r32(b+12)!=11000000||r32(b+16)!=15||r32(b+20)!=48000||r32(b+24)!=4096||data_size!=0||r32(b+48)||r32(b+52)!=length)throw std::runtime_error("Unsupported original Mario music profile");
 if(!n||n>65536||offset!=128+4096+data_size||uint64_t(offset)+uint64_t(n)*8!=length||preroll>48000*120||!duration||duration>48000*600)throw std::runtime_error("Invalid MRM1 region bounds");
 for(unsigned i=68;i<128;i++)if(b[i])throw std::runtime_error("Nonzero MRM1 reserved field");
 uint32_t pcrc=crc32(b+128,4096),dcrc=crc32(b+128+4096,data_size);
 if(pcrc!=0x06b9ff85u||dcrc!=0||r32(b+56)!=pcrc||r32(b+60)!=dcrc||r32(b+64)!=crc32(b+offset,length-offset))throw std::runtime_error("Original Mario ROM or command checksum differs");
 state=std::make_unique<State>();current=state.get();auto&s=*state;s.rate=rate;s.preroll=preroll;s.duration=duration;
 s.program.assign(b+128,b+128+4096);s.program[1]=1; // Original documented MAME I8039 compatibility startup; no music-data patches.s.data.assign(b+128+4096,b+offset);
 uint32_t previous=0;uint64_t end_cycle=(uint64_t(preroll+duration)*11000000+719999)/720000;
 for(unsigned i=0;i<n;i++){const uint8_t*p=b+offset+i*8;Event e{r32(p),uint16_t(p[4]|p[5]<<8),p[6]};
  if(p[7]||e.cycle<previous||e.cycle>=end_cycle)throw std::runtime_error("Invalid MRM1 timed command");
  switch(e.address){case 0x7e00:case 0x7f00:case 0x7f01:case 0x7f03:case 0x7f04:case 0x7f05:break;default:throw std::runtime_error("Unknown MRM1 input address");}
  s.events.push_back(e);previous=e.cycle;
 }
 s.boot();return 0;
 }catch(const std::exception&e){error_text=e.what();gremlin_mario_close();return 1;}}
API uint32_t gremlin_mario_render(float*out,uint32_t frames){using namespace gremlin_mario;if(!out||!frames||frames>16384)return 0;memset(out,0,size_t(frames)*2*sizeof(float));if(!state)return 0;try{
 auto&s=*state;
 for(unsigned i=0;i<frames;i++,s.position++){
  uint64_t numerator=s.position*48000,at=numerator/s.rate;uint32_t rem=numerator%s.rate;
  float a=s.at(at),b=s.at(at+1);float sample=float(double(a)+(double(b)-a)*double(rem)/s.rate);out[i*2]=out[i*2+1]=sample;
  while(s.queue_base<at&&!s.pcm.empty()){s.pcm.pop_front();s.queue_base++;}
 }
 return frames;
 }catch(const std::exception&e){error_text=e.what();gremlin_mario_close();return 0;}}
}
