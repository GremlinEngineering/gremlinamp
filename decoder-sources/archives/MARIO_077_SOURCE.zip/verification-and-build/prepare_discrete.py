from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;G=R.parent;S=G/'work-040/references'
# Reuse only the extraction machinery and host glue; all mathematics/graph are original0.190.
s=(G/'work-076/extract_discrete.py').read_text()
s=s.replace("'076-","'077-mame0190-").replace("f'076-","f'077-mame0190-")
s=s.replace("'class DISCRETE_CLASS_NAME(dss_input_pulse)'","'class DISCRETE_CLASS_NAME(dss_input_stream)'")
a=s.index('nodes={');b=s.index("\nmath=''",a)
s=s[:a]+"""nodes={
 'inp':{'dss_input_not','dss_input_pulse'},
 'wav':{'dss_counter'},
 'mth':{'dst_gain','dst_bits_decode','dst_oneshot','dst_xtime_buffer','dst_xtime_xor','dst_xtime_and','dst_mixer','dst_op_amp'},
 'flt':{'dst_rcfilter'},
 'dev':{'dsd_ls624'},
}"""+s[b:]
s=s.replace("if section=='wav':","if section=='unused_wav':").replace("if section=='flt':","if section=='unused_flt':")
a=s.index(" if section=='mth':");b=s.index("\n parts.sort()",a)
s=s[:a]+""" if section=='wav':
  m=re.search(r'^static const int disc_7492_count\\[6\\][^\\n]*',s,re.M);assert m;parts.append((m.start(),m[0]))
 if section=='mth':
  m=re.search(r'^enum\\s*\\{\\s*XTIME__',s,re.M);assert m;parts.append((m.start(),s[m.start():balanced(s,m.start())+1]))
"""+s[b:]
a=s.index("graph=copy_range(")
s=s[:a]+"""s=(S/'077-mame0190-mario-a.cpp').read_text()
a=s.index('/* Discrete sound inputs */');b=s.index('DISCRETE_SOUND_END',a)+len('DISCRETE_SOUND_END')
put('mame_graphs.inc',s[a:b])
(O/'source-receipts.json').write_text(json.dumps(receipts,indent=2)+'\\n')
print('Copied original MAME0.190 OLD_SOUND Mario graph and mathematics.')
"""
s=s.replace("'struct discrete_block\\n{'","'struct discrete_block\\n{'")
# old header guard terminator and graph names are retained verbatim.
(R/'extract_discrete.py').write_text(s)
(R/'source/discrete').mkdir(exist_ok=True)
host=(G/'work-076/source/discrete/host.h').read_text()
a=host.index('template<class C>class discrete_node_factory');b=host.index('#include "mame_declarations.h"',a)
host=host[:a]+"""template<class C>std::unique_ptr<discrete_base_node>discrete_create_node(discrete_device&d,const discrete_block&b){
 void*storage=::operator new(sizeof(C));memset(storage,0,sizeof(C));std::unique_ptr<discrete_base_node>r(new(storage)C());r->init(&d,&b);return r;
}
"""+host[b:]
host=host.replace('// Original DK master crystal /5/4/16/12/2/2 = 4000 Hz.','// Complete original Mario MAME0.190 OLD_SOUND graph.')
# Current rescap functions retain the same exact legacy formulas.
(R/'source/discrete/host.h').write_text(host)
probe='#include "source/discrete/host.h"\n#include <iostream>\nint main(){try{discrete_device g;g.build(mario_discrete_interface);double sum=0,peak=0;for(int i=0;i<48000;i++){g.write(DS_DAC,(i/32)%256);float s=g.sample(1);if(!std::isfinite(s))return 2;sum+=s*s;peak=std::max(peak,double(fabs(s)));}std::cout<<"nodes "<<g.nodes.size()<<" rms "<<sqrt(sum/48000)<<" peak "<<peak<<"\\n";}catch(const std::exception&e){std::cerr<<e.what()<<"\\n";return 1;}}\n'
(R/'probe_graph.cpp').write_text(probe)
print('Prepared original legacy discrete host extraction')

