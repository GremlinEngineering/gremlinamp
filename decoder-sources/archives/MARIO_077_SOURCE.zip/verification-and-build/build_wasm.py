from pathlib import Path
import subprocess,os,json,hashlib
R=Path(__file__).resolve().parent;SDK=R.parent/'work-040/references/emsdk';B=R/'build-wasm';B.mkdir(exist_ok=True);O=R/'built';O.mkdir(exist_ok=True)
env={**os.environ,'EM_CONFIG':str(SDK/'.emscripten')}
exports=['_gremlin_mario_load','_gremlin_mario_render','_gremlin_mario_close','_gremlin_mario_error','_gremlin_mario_devices','_gremlin_mario_stats','_malloc','_free']
cmd=['python3',str(SDK/'install/emscripten/em++.py'),'-std=c++20','-O3','-fwrapv','-ffp-contract=off','-fwasm-exceptions',str(R/'source/mario_core.cpp'),'--no-entry','-sSUPPORT_LONGJMP=wasm','-sMODULARIZE=1','-sEXPORT_NAME=GremlinMarioMusic','-sENVIRONMENT=web,worker,node','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=16777216','-sMAXIMUM_MEMORY=67108864','-sFILESYSTEM=0','-sEXPORTED_FUNCTIONS='+json.dumps(exports),'-sEXPORTED_RUNTIME_METHODS=["UTF8ToString","HEAPU8","HEAPF32"]','-o',str(O/'gremlin-mario.js')]
with(B/'build.log').open('w')as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
result={'compiler':'Emscripten 6.0.13','format':'MRM1 original Mario external firmware; documented I8039 startup compatibility; physical11MHz/15; complete original MAME0.190 OLD_SOUND alternate circuit; no rendered track','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in O.glob('gremlin-mario.*')]}
(O/'BUILD.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
