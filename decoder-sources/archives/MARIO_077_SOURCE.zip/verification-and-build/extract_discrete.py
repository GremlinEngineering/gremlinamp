"""Copy pinned MAME node mathematics and DK graphs; no algorithm rewriting."""
from pathlib import Path
import re,json,hashlib
R=Path(__file__).resolve().parent;S=R.parent/'work-040/references';O=R/'source/discrete';O.mkdir(exist_ok=True)
receipts=[]
def put(name,text):
 (O/name).write_text('// Pinned MAME BSD-3-Clause excerpts; see source-receipts.json and originals.\n'+text+'\n')
def copy_range(name,start,stop):
 p=S/name;s=p.read_text();a=s.index(start);b=s.index(stop,a)
 text=s[a:b];receipts.append({'source':name,'start_line':s[:a].count('\n')+1,'end_line':s[:b].count('\n')+1,'sha256':hashlib.sha256(text.encode()).hexdigest()});return text
def clean(s):
 return re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:' '*len(m[0]),s,flags=re.S)
def balanced(s,start,op='{',cl='}'):
 c=clean(s);p=c.index(op,start);depth=1;i=p+1
 while depth:
  if c[i]==op:depth+=1
  elif c[i]==cl:depth-=1
  i+=1
 return i
def function(s,pattern):
 m=re.search(pattern,s,re.M);assert m,pattern;b=balanced(s,m.start());return s[m.start():b]
put('mame_constants.h',copy_range('077-mame0190-discrete.h','#define RC_CHARGE_EXP(rc)','struct discrete_block\n{'))
put('mame_dsl.h',copy_range('077-mame0190-discrete.h','#define DISCRETE_SOUND_EXTERN(name)','#endif // MAME_SOUND_DISCRETE_H'))
decl=copy_range('077-mame0190-disc_cls.h','#define DISCRETE_CLASS_NAME(_name)','/*************************************\n *\n *  disc_sys.inc')
decl+=copy_range('077-mame0190-disc_cls.h','class DISCRETE_CLASS_NAME(dss_adjustment)','class DISCRETE_CLASS_NAME(dss_input_stream)')
for name in ['077-mame0190-disc_wav.h','077-mame0190-disc_mth.h','077-mame0190-disc_flt.h','077-mame0190-disc_dev.h']:
 s=(S/name).read_text();a=s.index('#include "discrete.h"')+len('#include "discrete.h"');b=s.rindex('#endif');decl+=s[a:b]+'\n'
put('mame_declarations.h',decl)
nodes={
 'inp':{'dss_input_not','dss_input_pulse'},
 'wav':{'dss_counter'},
 'mth':{'dst_gain','dst_bits_decode','dst_oneshot','dst_xtime_buffer','dst_xtime_xor','dst_xtime_and','dst_mixer','dst_op_amp'},
 'flt':{'dst_rcfilter'},
 'dev':{'dsd_ls624'},
}
math=''
for section,wanted in nodes.items():
 name=f'077-mame0190-disc_{section}.hxx';s=(S/name).read_text();parts=[]
 # Preprocessor input aliases and shared constants are copied verbatim.
 for m in re.finditer(r'^#define[^\n]*(?:\\\n[^\n]*)*',s,re.M):parts.append((m.start(),m[0]))
 # Selected original methods, including non-macro input-write / oscillator helpers.
 for m in re.finditer(r'^(?:DISCRETE_(?:STEP|RESET)\(\s*(\w+)\s*\)|(?:inline )?(?:void|double) DISCRETE_CLASS_FUNC\(\s*(\w+)\s*,[^\n]*)',s,re.M):
  node=m[1]or m[2]
  if node not in wanted:continue
  b=balanced(s,m.start());part=s[m.start():b];parts.append((m.start(),part));receipts.append({'source':name,'node':node,'start_line':s[:m.start()].count('\n')+1,'sha256':hashlib.sha256(part.encode()).hexdigest()})
 if section=='unused_wav':
  for pat in [r'^static const int disc_7492_count\[6\][^\n]*',r'^static inline int dss_lfsr_function']:
   m=re.search(pat,s,re.M);assert m
   part=m[0]if '7492'in pat else s[m.start():balanced(s,m.start())];parts.append((m.start(),part))
 if section=='unused_flt':
  m=re.search(r'^static void calculate_filter2_coefficients',s,re.M);parts.append((m.start(),s[m.start():balanced(s,m.start())]))
 if section=='wav':
  m=re.search(r'^static const int disc_7492_count\[6\][^\n]*',s,re.M);assert m;parts.append((m.start(),m[0]))
 if section=='mth':
  m=re.search(r'^enum\s*\{\s*XTIME__',s,re.M);assert m;parts.append((m.start(),s[m.start():balanced(s,m.start())+1]))

 parts.sort();math+='\n// '+name+'\n'+'\n\n'.join(x[1]for x in parts)+'\n'
put('mame_math.inc',math)
s=(S/'077-mame0190-mario-a.cpp').read_text()
a=s.index('/* Discrete sound inputs */');b=s.index('DISCRETE_SOUND_END',a)+len('DISCRETE_SOUND_END')
put('mame_graphs.inc',s[a:b])
(O/'source-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('Copied original MAME0.190 OLD_SOUND Mario graph and mathematics.')
