from pathlib import Path
R=Path(__file__).resolve().parent;G=R.parent
s=(G/'work-076/source/dkong_core.cpp').read_text()
s=s.replace('Gremlin native DK music host: original MB8884 firmware + pinned BSD MCS48','Gremlin original Mario external firmware, documented I8039 bootstrap compatibility + BSD MCS48')
s=s.replace('gremlin_dk','gremlin_mario').replace('original MB8884','original Mario external')
s=s.replace('bool jr=false,cpu_open=false;uint8_t pins=255,t0=1,t1=1,page=0,latch=15;','bool cpu_open=false;uint8_t p1=0xf0,p2=255,t0=0,t1=0,latch=0;')
s=s.replace('cycle*48000/400000','cycle*720000/11000000').replace('graph.sample(jr?.5:.9)','graph.sample(1)')
a=s.index(' static uint8_t read(');b=s.index(' void step()',a)
s=s[:a]+''' static uint8_t read(uint32_t p){auto&s=*current;
  if(p<256)return(s.p2&128)?s.latch:s.program[(s.p2&15)*256+(p&255)];
  switch(p){case MCS48_P1:return s.p1;case MCS48_P2:return s.p2&0xef;case MCS48_T0:return s.t0;case MCS48_T1:return s.t1;default:return 0;}}
 static void write(uint32_t p,uint8_t value){auto&s=*current;s.advance(uint32_t(mcs48TotalCycles()));s.port_writes++;
  if(p<256)s.graph.write(DS_DAC,value);else if(p==MCS48_P1)s.p1=value;else if(p==MCS48_P2)s.p2=value;
 }
 void input(const Event&e){switch(e.address){
  case 0x7e00:latch=e.value;break;case 0x7f00:mcs48SetIRQLine(0,e.value?1:0);break;case 0x7f01:t0=e.value;break;
  case 0x7f03:p1=(p1&~1)|(e.value<<0);break;case 0x7f04:p1=(p1&~2)|(e.value<<1);break;case 0x7f05:p1=(p1&~4)|(e.value<<2);break;
  default:throw std::runtime_error("unsupported Mario host input");}}
'''+s[b:]
s=s.replace('graph.build(jr?dkongjr_discrete:dkong2b_discrete);','graph.build(mario_discrete_interface);')
s=s.replace('mcs48Init(0,8884,program.data())','mcs48Init(0,8039,program.data())')
s=s.replace('mcs48_set_read_port(read);mcs48_set_write_port(write);mcs48Reset();','mcs48_set_read_port(read);mcs48_set_write_port(write);mcs48Reset();p1=0xf0;')
a=s.index('API const char*gremlin_mario_devices()');b=s.index('API const char*gremlin_mario_stats()',a)
s=s[:a]+'''API const char*gremlin_mario_devices(){return "[{\\"type\\":\\"mario_m58715_i8039_compatibility\\",\\"clock_hz\\":11000000,\\"clock_divisor\\":15,\\"internal_sample_rate\\":48000,\\"sound_firmware\\":\\"original external ROM, documented runtime bootstrap byte1=01\\",\\"internal_m58715_rom_dumped\\":false,\\"circuit\\":\\"complete original MAME0.190 OLD_SOUND discrete alternative\\",\\"rendered_track\\":false,\\"analog_board_measurement\\":false}]";}
'''+s[b:]
s=s.replace('state->jr?2:1','1').replace('"DKM\\x1a"','"MRM\\x1a"')
s=s.replace('(profile!=1&&profile!=2)','profile!=1').replace('r32(b+12)!=6000000','r32(b+12)!=11000000').replace('r32(b+16)!=400000','r32(b+16)!=15').replace('data_size!=(profile==1?2048:0)','data_size!=0')
s=s.replace('pcrc!=(profile==1?0x14067b93u:0x715da5f8u)||dcrc!=(profile==1?0x4743fe92u:0u)','pcrc!=0x06b9ff85u||dcrc!=0')
s=s.replace('s.jr=profile==2;','')
s=s.replace('s.program.assign(b+128,b+128+4096);','s.program.assign(b+128,b+128+4096);s.program[1]=1; // Original documented MAME I8039 compatibility startup; no music-data patches.')
s=s.replace('(uint64_t(preroll+duration)*400000+47999)/48000','(uint64_t(preroll+duration)*11000000+719999)/720000')
s=s.replace('||(!s.jr&&e.address==0x7c81)','')
s=s.replace('case 0x7c00:case 0x7c81:case 0x7d03:case 0x7d04:case 0x7d05:case 0x7d80:','case 0x7e00:case 0x7f00:case 0x7f01:case 0x7f03:case 0x7f04:case 0x7f05:')
s=s.replace('DKM1','MRM1').replace('DK graph','Mario graph').replace('DK stream','Mario stream').replace('original DK music','original Mario music').replace('Original DK ROM','Original Mario ROM')
(R/'source/mario_core.cpp').write_text(s)
print('Prepared original external music program host, documented bootstrap and exact legacy model')

