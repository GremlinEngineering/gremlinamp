from pathlib import Path
import shutil,json,difflib
R=Path(__file__).resolve().parent
shutil.copy2(R/'build/fbneo-observer.dylib',R/'build/fbneo-legacy-observer.dylib')
for profile in ['stock','observer']:
 src=R/'fbneo-host'/('mario-'+profile);dst=R/'fbneo-host'/('mario-legacy-'+profile)
 if not dst.exists():shutil.copytree(src,dst)
(R/'legacy-reference-rejected.json').write_text(json.dumps({'status':'not_accepted_as_native_source_reference','reason':'Legacy FBNeo8039 emits IO at instruction start; modern BSD MCS48 at instruction end. Strict replay has constant initial2cycle timestamp difference and an input boundary mismatch later. No correction is fitted to audio. Use explicitly documented BSDCPU replacement research profile instead; original game and musicROM retained apart from existing documented compatibility startup byte.','strict_test_log':'mcu-equivalence.log','native_music_count':0},indent=2)+'\n')
p=R/'fbneo-research/src/burn/drv/pre90s/d_mario.cpp';s=p.read_text();original=s
s=s.replace('#include "i8039.h"','#include "i8039.h"\n#include "mcs48.h"')
assert '#include "mcs48.h"'in s
a=s.index('\tI8039Init(0);');b=s.index('\n\tDACInit(',a)
s=s[:a]+'''\tmcs48Init(0,8039,DrvSndROM);
\tmcs48Open(0);
\tmcs48_set_read_port(gremlin_mcu_read);
\tmcs48_set_write_port(gremlin_mcu_write);
\tmcs48Close();
'''+s[b:]
a=s.index('static INT32 MemIndex()')
glue='''// Gremlin077: explicit BSD MCS48 reference profile; same original external ROM,
// original main-game CPU, and existing documented I8039 startup byte patch.
static UINT32 gremlin_old_port(UINT32 p) {
 if(p<256)return p;
 switch(p){case MCS48_P1:return I8039_p1;case MCS48_P2:return I8039_p2;case MCS48_T0:return I8039_t0;case MCS48_T1:return I8039_t1;case MCS48_BUS:return I8039_bus;default:return 0x1ff;}
}
static UINT8 gremlin_mcu_read(UINT32 p){return mario_i8039_read_port(gremlin_old_port(p));}
static void gremlin_mcu_write(UINT32 p,UINT8 value){mario_i8039_write_port(gremlin_old_port(p),value);}

'''
s=s[:a]+glue+s[a:]
s=s.replace('I8039SetIrqState((data) ? 1 : 0);','mcs48SetIRQLine(0,(data) ? 1 : 0);')
for old,new in [('I8039TotalCycles','mcs48TotalCycles'),('I8039Open','mcs48Open'),('I8039Close','mcs48Close'),('I8039Reset','mcs48Reset'),('I8039NewFrame','mcs48NewFrame'),('I8039Exit','mcs48Exit')]:s=s.replace(old,new)
s=s.replace('CPU_RUN(1, I8039);','CPU_RUN(1, mcs48);').replace('I8039Scan(nAction, pnMin);','mcs48Scan(nAction);')
p.write_text(s)
shutil.copy2(R/'source/mcs48.cpp',R/'fbneo-research/src/cpu/i8x41/mcs48.cpp')
(R/'bsd-reference-adapter.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='legacy-observer/d_mario.cpp',tofile='bsd-reference/d_mario.cpp')))
p=R/'capture_context.py';s=p.read_text().replace("if profile=='observer':","if profile in ['observer','bsd-reference']:");p.write_text(s)
print('BSD CPU reference profile prepared; original music ROM retained except documented existing startup byte')

