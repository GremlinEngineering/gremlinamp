from pathlib import Path
import ctypes as c,struct,zlib,json
import numpy as np
from render_mario import Player
R=Path(__file__).resolve().parent;p=Player();results=[];original=bytearray((R/'native/mario-initial-game-start.mrm').read_bytes())
def set32(b,at,value):struct.pack_into('<I',b,at,value)
def checksum(b):set32(b,64,zlib.crc32(b[struct.unpack_from('<I',b,36)[0]:]))
def attempt(name,blob,rate=48000,subsong=0):
 a=c.create_string_buffer(bytes(blob));status=p.l.gremlin_mario_load(a,len(blob),rate,subsong)
 error=p.l.gremlin_mario_error().decode();row={'test':name,'pass':bool(status),'error':error};results.append(row)
 if status==0:p.close()
mutations=[('bad magic',0,0),('bad version',4,2),('unknown profile',8,3),('wrong crystal',12,6000001),('wrong MCU divisor',16,399999),('wrong circuit rate',20,44100),('wrong program size',24,2048),('wrong data size',28,1),('zero events',32,0),('too many events',32,65537),('wrong payload offset',36,127),('long preroll',40,48000*121),('zero duration',44,0),('long duration',44,48000*601),('reserved word',48,1),('wrong file length',52,len(original)+1),('wrong program CRC',56,0),('wrong data CRC',60,1),('wrong input CRC',64,0),('reserved extension',100,1)]
for name,at,value in mutations:
 b=original.copy();set32(b,at,value);attempt(name,b)
for length in [0,3,127,len(original)-1]:attempt('truncated '+str(length),original[:length])
for name,at in [('program changed',128),('command changed',len(original)-2)]:
 b=original.copy();b[at]^=1;attempt(name,b)
offset=struct.unpack_from('<I',original,36)[0]
for name,edit in [
 ('unknown input',lambda b:struct.pack_into('<H',b,offset+4,0x1234)),
 ('command reserved byte',lambda b:b.__setitem__(offset+7,1)),
 ('unordered times',lambda b:set32(b,offset+8,0)),
 ('outside bound',lambda b:set32(b,len(b)-8,400000*1000)),
 ('not instruction boundary',lambda b:set32(b,offset,1)),
 ('unsupported input on Mario',lambda b:struct.pack_into('<H',b,offset+4,0x7c81)),
]:
 b=original.copy();edit(b);checksum(b);attempt(name,b)
for rate in [0,7999,192001,0xffffffff]:attempt('bad output rate '+str(rate),original,rate)
attempt('absent subsong',original,48000,1)
for rate in [8000,44100,48000,192000]:
 p.load(R/'native/mario-initial-game-start.mrm',rate);n=0;tail=[]
 while n<round(7*rate):
  count=min(4096,round(7*rate)-n);a=p.render(count);n+=count
  if n>round(6.6*rate):tail.append(a[-min(len(a),round(.1*rate)):])
 results.append({'test':'valid rate and finite end '+str(rate),'pass':bool(tail and np.max(np.abs(tail[-1]))==0)})
 p.close()
# Rendering block size must not change CPU, commands, or circuit state.
def render_chunks(sizes):
 p.load(R/'native/mario-initial-game-start.mrm');pieces=[];n=0
 while n<312000:
  k=min(sizes[n%len(sizes)],312000-n);pieces.append(p.render(k));n+=k
 p.close();return np.concatenate(pieces)
a=render_chunks([4096]);b=render_chunks([1,3,17,499,16384]);results.append({'test':'render block invariance','pass':bool(np.array_equal(a,b))})
# Failed load closes the old state and the next correct load starts cleanly.
p.load(R/'native/mario-initial-game-start.mrm');attempt('failed replacement unloads prior stream',b'bad')
buffer=np.ones((4,2),dtype='<f4');status=p.l.gremlin_mario_render(buffer.ctypes.data,4);results.append({'test':'no stale music after bad load','pass':status==0 and not np.any(buffer)})
p.load(R/'native/mario-initial-game-start.mrm');again=p.render(4096);p.close();results.append({'test':'valid reload after errors','pass':bool(np.array_equal(again,a[:4096]))})
(R/'input-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'checks':len(results),'passed':sum(x['pass']for x in results),'failed':[x for x in results if not x['pass']]}));assert all(x['pass']for x in results)
