from pathlib import Path
import difflib
R=Path(__file__).resolve().parent;p=R/'fbneo-research/src/burn/drv/pre90s/d_mario.cpp';s=p.read_text();(R/'d_mario.original.cpp').write_text(s)
observer='''// Gremlin077 read-only observer; no changes to original emulation.
static UINT64 gremlin_mcu_base=0;
static FILE *gremlin_mcu_log=nullptr;
static void gremlin_mcu_event(UINT32 kind,UINT32 value) {
 if(!gremlin_mcu_log){const char*p=getenv("GREMLIN_MCU_TRACE");if(p)gremlin_mcu_log=fopen(p,"ab");}
 if(gremlin_mcu_log){UINT64 cycle=gremlin_mcu_base+(UINT32)I8039TotalCycles();fwrite(&cycle,8,1,gremlin_mcu_log);fwrite(&kind,4,1,gremlin_mcu_log);fwrite(&value,4,1,gremlin_mcu_log);}
}
'''
a=s.index('static void __fastcall mario_main_write(');s=s[:a]+observer+'\n'+s[a:]
for statement in ['I8039SetIrqState((data) ? 1 : 0);','i8039_t[0] = data;','i8039_p[1] = ACTIVEHIGH_PORT_BIT(i8039_p[1], 0, data);','i8039_p[1] = ACTIVEHIGH_PORT_BIT(i8039_p[1], 1, data);','i8039_p[1] = ACTIVEHIGH_PORT_BIT(i8039_p[1], 2, data);','*soundlatch = data;']:
 assert s.count(statement)==1,statement
 s=s.replace(statement,'gremlin_mcu_event(address,data);\n\t\t\t'+statement,1)
s=s.replace('static void __fastcall mario_i8039_write_port(UINT32 port, UINT8 data)\n{','static void __fastcall mario_i8039_write_port(UINT32 port, UINT8 data)\n{\n\tgremlin_mcu_event(0x10000|(port&0x1ff),data);',1)
s=s.replace('\tI8039NewFrame();','\tI8039Open(0);\n\tgremlin_mcu_base += (UINT32)I8039TotalCycles();\n\tI8039Close();\n\tI8039NewFrame();',1)
s=s.replace('static INT32 DrvDoReset()\n{','static INT32 DrvDoReset()\n{\n\tgremlin_mcu_base=0;',1)
p.write_text(s);(R/'observer.patch').write_text(''.join(difflib.unified_diff((R/'d_mario.original.cpp').read_text().splitlines(True),s.splitlines(True),fromfile='stock/d_mario.cpp',tofile='observer/d_mario.cpp')))
print('Read-only Mario input/output observer prepared')

