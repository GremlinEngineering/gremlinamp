from pathlib import Path
import ctypes as c,json,sys
import numpy as np
R=Path(__file__).resolve().parent
class Player:
 def __init__(self):
  l=self.l=c.CDLL(str(R/'build/libgremlin-mario.dylib'))
  l.gremlin_mario_load.argtypes=[c.c_void_p,c.c_uint32,c.c_uint32,c.c_uint32];l.gremlin_mario_load.restype=c.c_int
  l.gremlin_mario_render.argtypes=[c.c_void_p,c.c_uint32];l.gremlin_mario_render.restype=c.c_uint32
  l.gremlin_mario_error.restype=c.c_char_p;l.gremlin_mario_stats.restype=c.c_char_p;l.gremlin_mario_devices.restype=c.c_char_p
 def load(self,path,rate=48000):
  b=Path(path).read_bytes();a=c.create_string_buffer(b)
  assert self.l.gremlin_mario_load(a,len(b),rate,0)==0,self.l.gremlin_mario_error().decode()
 def render(self,n):
  a=np.zeros((n,2),dtype='<f4');assert self.l.gremlin_mario_render(a.ctypes.data,n)==n,self.l.gremlin_mario_error().decode();return a
 def close(self):self.l.gremlin_mario_close()
if __name__=='__main__':
 name=sys.argv[1];seconds=float(sys.argv[2]);rate=int(sys.argv[3])if len(sys.argv)>3 else 48000
 p=Player();p.load(R/'native'/(name+'.mrm'),rate);n=int(seconds*rate);pieces=[]
 while n:
  frames=min(4096,n);pieces.append(p.render(frames));n-=frames
 a=np.concatenate(pieces);out=R/'probes'/(name+f'-{rate}.f32');a.tofile(out)
 b=a[:,0];windows=[float(np.sqrt(np.mean(x.astype(np.float64)**2)))for x in np.array_split(b,int(seconds*2))]
 result={'name':name,'sample_rate':rate,'frames':len(a),'peak':float(np.max(np.abs(a))),'rms':float(np.sqrt(np.mean(a.astype(np.float64)**2))),'stats':json.loads(p.l.gremlin_mario_stats()),'half_second_rms':windows,'pcm':str(out),'diagnostic_pcm_not_for_delivery':True}
 p.close();(R/'probes'/(name+f'-{rate}.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
