// Independent transport reference: original whole-game raw output trace drives
// the pinned MAME circuit directly, without the standalone CPU/render host.
#include "source/burnint.h"
#include "source/mcs48.h"
#include "source/discrete/host.h"
#include <fstream>
#include <iostream>
struct Event{uint64_t t;uint32_t p,v;};
int main(int n,char**v){try{if(n!=4)return 2;bool jr=false;std::ifstream in(v[2],std::ios::binary);if(!in)return 2;FILE*out=fopen(v[3],"wb");if(!out)return 2;discrete_device graph;graph.build(mario_discrete_interface);uint64_t samples=0,ports=0;Event e;
 while(in.read(reinterpret_cast<char*>(&e),16)){
  if(e.p<65536)continue;
  uint64_t target=e.t*720000/11000000;
  while(samples<target){float s=graph.sample(1),frame[2]={s,s};if(!std::isfinite(s))return 2;fwrite(frame,4,2,out);samples++;}
  if((e.p&0xffff)<256)graph.write(DS_DAC,e.v);
  ports++;
 }
 fclose(out);std::cout<<"{\"profile\":\""<<v[1]<<"\",\"frames\":"<<samples<<",\"source_port_events\":"<<ports<<",\"source\":\"Explicit BSD8039 full-game MCU profile; original external musicROM and documented compatibility startup; original MAME0.190 OLD_SOUND graph; effects at reset; physical clock11MHz/15\"}\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
