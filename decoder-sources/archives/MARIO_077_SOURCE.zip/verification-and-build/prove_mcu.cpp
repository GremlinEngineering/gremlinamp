#include "source/mcs48.cpp"
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <stdexcept>
struct Event{UINT64 t;UINT32 p,v;};
static std::vector<UINT8>program;static std::vector<Event>outputs;
static UINT8 p1=0xf0,p2=255,t0=0,t1=0,latch=0;
static size_t position=0;static unsigned errors=0;static bool booting=false;
std::vector<UINT8>readfile(const std::string&p){std::ifstream f(p,std::ios::binary);if(!f)throw std::runtime_error(p);return std::vector<UINT8>((std::istreambuf_iterator<char>(f)),{});}
static UINT8 rd(UINT32 p){
 if(p<256)return(p2&128)?latch:program[(p2&15)*256+(p&255)];
 switch(p){case MCS48_P1:return p1;case MCS48_P2:return p2&0xef;case MCS48_T0:return t0;case MCS48_T1:return t1;default:return 0;}}
static void wr(UINT32 p,UINT8 value){
 if(booting)return;
 unsigned canonical=p;
 if(p==MCS48_P1){p1=value;canonical=0x101;}
 else if(p==MCS48_P2){p2=value;canonical=0x102;}
 else if(p==MCS48_BUS)canonical=0x120;
 if(position>=outputs.size())return;
 auto e=outputs[position++];UINT64 at=mcs48TotalCycles();
 if(e.t!=at||e.p!=(canonical|0x10000)||e.v!=value){if(errors++<15)std::cerr<<"mismatch "<<position<<" expected "<<e.t<<","<<e.p<<","<<e.v<<" actual "<<at<<","<<(canonical|0x10000)<<","<<unsigned(value)<<"\n";}
}
int main(int n,char**v){try{
 if(n!=3)return 2;program=readfile(v[1]);program[1]=1;auto bytes=readfile(v[2]);if(bytes.size()%16)return 2;
 std::vector<Event>inputs;UINT64 end=0;
 for(size_t i=0;i<bytes.size();i+=16){Event e;memcpy(&e,bytes.data()+i,16);if(e.p<65536)inputs.push_back(e);else outputs.push_back(e);end=std::max(end,e.t);}
 mcs48Init(0,8039,program.data());mcs48Open(0);mcs48_set_read_port(rd);mcs48_set_write_port(wr);mcs48Reset();p1=0xf0;
 for(auto e:inputs){while(UINT64(mcs48TotalCycles())<e.t)mcs48Run(1);if(UINT64(mcs48TotalCycles())!=e.t){std::cerr<<"input boundary "<<e.t<<" actual "<<mcs48TotalCycles()<<" after outputs "<<position<<"\n";return 1;}
  switch(e.p){case 0x7e00:latch=e.v;break;case 0x7f00:mcs48SetIRQLine(0,e.v?1:0);break;case 0x7f01:t0=e.v;break;case 0x7f03:p1=(p1&~1)|(e.v<<0);break;case 0x7f04:p1=(p1&~2)|(e.v<<1);break;case 0x7f05:p1=(p1&~4)|(e.v<<2);break;default:throw std::runtime_error("unknown input");}
 }
 while(UINT64(mcs48TotalCycles())<=end)mcs48Run(1);
 std::cout<<"{\"outputs_compared\":"<<position<<",\"outputs_expected\":"<<outputs.size()<<",\"inputs_replayed\":"<<inputs.size()<<",\"mismatches\":"<<errors<<",\"machine_cycles\":"<<mcs48TotalCycles()<<"}\n";
 mcs48Close();mcs48Exit();return errors||position!=outputs.size();
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}

