from pathlib import Path
import struct,zlib,json,hashlib
R=Path(__file__).resolve().parent;O=R/'native';O.mkdir(exist_ok=True)
program=(R/'original/external.bin').read_bytes()
events=[x for x in struct.iter_unpack('<QII',(R/'fbneo-host/mario-bsd-reference/mcu-events.bin').read_bytes())if x[1]<65536]
end=max(t for t,p,v in struct.iter_unpack('<QII',(R/'fbneo-host/mario-bsd-reference/mcu-events.bin').read_bytes()))
def make(name,selected,preroll,duration):
 payload=b''.join(struct.pack('<IHBB',t,p,v,0)for t,p,v in selected);offset=128+4096;length=offset+len(payload);h=bytearray(128);h[:4]=b'MRM\x1a'
 fields=[1,1,11000000,15,48000,4096,0,len(selected),offset,preroll,duration,0,length,zlib.crc32(program),0,zlib.crc32(payload)]
 struct.pack_into('<16I',h,4,*fields);blob=bytes(h)+program+payload;p=O/(name+'.mrm');p.write_bytes(blob)
 return {'name':name,'file':str(p),'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),'preroll_samples':preroll,'duration_samples':duration,'seconds':duration/48000,'events':len(selected),'original_external_rom_sha256':hashlib.sha256(program).hexdigest(),'profile':'MAME documented I8039 startup / MAME0.190 OLD_SOUND complete graph','research_only':True}
rows=[{**make('mario-full-source-check',events,0,end*720000//11000000),'source_full_trace':True}]
for cue,title,seconds in [(10,'initial-game-start',6.5),(9,'phase-1-game-start',3.5)]:
 at=next(t for t,p,v in events if p==0x7e00 and v==cue);cut=at+round(11000000/15*.15)
 row=make('mario-'+title,[e for e in events if e[0]<=cut],at*720000//11000000,round(48000*seconds))
 row.update({'cue_value_original_main_bus':cue,'cue_cycle':at,'prefix_source_cut_cycle':cut,'title_context':title,'duration_provisional':True});rows.append(row)
(R/'banks.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{k:r[k]for k in ['name','bytes','seconds','events']}for r in rows],indent=2))

